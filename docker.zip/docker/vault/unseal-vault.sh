#!/bin/bash

source env.sh

curl -H "Content-Type: application/json" -XPUT $VAULT_ADDR/v1/sys/unseal -d '{"key": "'$UNSEAL_KEY'"}'