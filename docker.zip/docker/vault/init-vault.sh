#!/bin/bash

source env.sh

curl \
    --request POST \
    --data '{"secret_shares": 1, "secret_threshold": 1}' \
    $VAULT_ADDR/v1/sys/init  > init.out

cat init.out | jq -r .root_token > token.txt
cat init.out | jq -r .keys > keys.txt


