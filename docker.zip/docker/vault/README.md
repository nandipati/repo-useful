# Vault Docker Image Build


* We start with an Alpine base image and add init scripts.
* Finally a specific Vault build is fetched and the rest of the Vault-specific
  configuration happens according to the Dockerfile.
* To build the image run:

docker build -t cnd/vault:1.4   .