function get_keys {

    aws s3 cp s3://cnd-terraform-assets/keys/cndcorenp_tools /root/.ssh/cnd_tools
    aws s3 cp s3://cnd-terraform-assets/keys/cndcorenp_tools.pub /root/.ssh/cnd_tools.pub

    chmod 600 /root/.ssh/cnd_tools*
}

function install_cloud_squirrel {
    mkdir -p /etc/cloud_squirrel
    cd /etc/cloud_squirrel
    eval `ssh-agent -s`
    ssh-add /root/.ssh/cnd_tools
    GIT_SSH_COMMAND="ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no" git clone git@github.com:rsinsights/rcs-tools.git
    cd rcs-tools/cloud-squirrel
    sed -i 's#$HOME/.cs#/etc/cloud_squirrel/rcs-tools/cloud-squirrel/config/#g' ./src/cs.go
    sed -i "s/\"active\": \"local\"/\"active\": \"np\"/g" ./config/cs.json
    make install
}


get_keys

install_cloud_squirrel
