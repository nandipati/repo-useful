#!/bin/bash

cat > /dev/null

update_quotas_usage
