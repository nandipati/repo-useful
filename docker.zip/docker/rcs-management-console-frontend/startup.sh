echo resolver $(awk 'BEGIN{ORS=" "} $1=="nameserver" {print $2}' /etc/resolv.conf) " valid=10s ipv6=off;" > /etc/nginx/resolvers.conf

# Start Nginx with special option in order to run in foreground
nginx -g "daemon off;"
