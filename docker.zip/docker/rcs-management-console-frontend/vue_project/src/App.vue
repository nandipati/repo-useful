<template>
  <div id="app">
    <v-app id="inspire">
      <v-navigation-drawer fixed v-model="drawer" app>
        <v-list three-line>

	<v-list-tile @click="goToRCSApplicationQuotas">
            <v-list-tile-content>
              <v-list-tile-title>Application Quotas</v-list-tile-title>
              <v-list-tile-sub-title>
                All Application Quotas  in RCS
              </v-list-tile-sub-title>
            </v-list-tile-content>
          </v-list-tile>
        
        </v-list>
      </v-navigation-drawer>
      <v-toolbar color="green lighten-1" dark fixed app>
        <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
        <v-toolbar-title>RCS Dashboard</v-toolbar-title>
      </v-toolbar>
      <v-content>
        <v-container grid-list-md text-xs-center>
          <v-layout row wrap>
            <v-flex xs12 class="mt-5">
              <img src="./assets/Riverside_Insights.jpg">
            </v-flex>
            <v-flex xs12 class="mt-5">
              <router-view/>
            </v-flex>
          </v-layout>
        </v-container>
      </v-content>
      <v-footer color="green lighten-1" app>
        <span class="white--text">Riverside Cloud Services Management Console</span>
      </v-footer>
    </v-app>
  </div>
</template>
<script>
/* beautify preserve:start */
export default {
  name: 'app',
  data: () => ({
    drawer: null
  }),
  methods: {
    goToRCSApplicationQuotas: function () {
      this.$router.push({ name: 'RCSApplicationQuotas' })
    }
  },
  props: {
    source: String
  }
}
/* beautify preserve:end */
</script>
