import Vue from 'vue'
import Router from 'vue-router'


import RCSApplicationQuotas from '@/components/RCSApplicationQuotas'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/get-application-quotas',
      name: 'RCSApplicationQuotas',
      component: RCSApplicationQuotas
    }
  ]
})
