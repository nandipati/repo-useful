<template>
  <div>
    <v-card class="pb-3">
      <v-card-title primary-title>
        <h3 class="headline mb-0">RCS Application Quotas</h3>
      </v-card-title>

      <v-progress-circular v-if="showLoader" indeterminate :size="50" color="primary"></v-progress-circular>

        <v-data-table :headers="headers" :items="rows"  class="elevation-1">
          <template slot="items" slot-scope="props">
            <td>{{ props.item['quota_group'] }}</td>
            <td>{{ props.item['quota_item'] }}</td>
            <td>{{ props.item['limit'] }}</td>
            <td>{{ props.item['utilization'] }}</td>
            <td>{{ props.item['available'] }}</td>
          </template>
        </v-data-table>

      <v-alert color="error" icon="warning" :value="showErrorMessage">Error: {{ errorMessage }}</v-alert>
    </v-card>
  </div>
</template>
<script>
/* beautify preserve:start */

import {HTTP} from '../http-constants'

export default {
  name: 'RCSApplicationQuotas',
  data () {
    return {
      showLoader: false,
      showResults: false,
      showRowsNb: false,
      rowsNb: '',
      rows: [],
      errors: [],
      errorMessage: '',
      showErrorMessage: false,
      headers: [
          { text: 'Quota Group', value: 'quota_group' },
          { text: 'Quota Item', value: 'quota_item' },
          { text: 'Limit', value: 'limit' },
          { text: 'Utilization', value: 'utilization' },
          { text: 'Available', value: 'availabale' }
      ]
    }
  },
  methods: {
    GetApplicationQuotas: function () {
      this.showResults = false
      this.showRowsNb = false
      this.showLoader = true
      HTTP.get(`rcs-api/get-application-quotas`)
        .then(response => {
          this.rows = response.data
          console.log(this.rows)
          this.rowsNb = this.rows.length
          this.showLoader = false
          this.showRowsNb = true
          this.errors = []
          this.errorMessage = response.data
          this.showErrorMessage = false
        })
        .catch(e => {
          this.errors = e
          this.errorMessage = e.response.data
          this.showErrorMessage = true
          this.showLoader = false
          this.showResults = false
          this.showRowsNb = false
        })
    }
  },
  beforeMount () {
    this.GetApplicationQuotas()
  }
}

/* beautify preserve:end */
</script>
