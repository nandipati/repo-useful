# Purpose
Front end of the Riverside Cloud Services Management Console API.
Frontend of the app which is a VueJS/Axios/Vuetify app sending info to a Go backend. 
The Go backend exposes REST API.

# Link to the application
http://console.rcsnp.rsiapps.com

# Project setup

1. `npm install -g vue-cli`
1. `vue init webpack vue_project`
1. `cd vue_project`
1. `npm install`
1. `npm install --save axios`
1. `npm run dev`
1. `npm run build`

# Local development

`npm run dev`
