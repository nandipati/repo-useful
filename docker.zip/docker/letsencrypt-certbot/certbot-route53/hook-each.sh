#!/bin/sh

# Override this file in your child image with specific handling.
