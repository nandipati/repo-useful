// cleans up AWS resources for the purpose of cost optimization
// @author Lenko Donchev

package main

import (
	"./utils"
	"fmt"
	"github.com/davecgh/go-spew/spew"
	"strconv"
	"time"

	//	consulapi "github.com/hashicorp/consul/api"
	//	nomadapi "github.com/hashicorp/nomad/api"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
	"os"

	"regexp"
)

const (
	AWS_KEY_ID                  = "awskid"
	AWS_ACCESS_KEY              = "awssak"
	ERR_CERT_UPLOAD             = 1
	ERR_MISSING_CONFIG_PROPERTY = 4
	ERR_QUOTA_LIMIT_EXCEEDED    = 3
	ERR_EXEC_CMD                = 6
	ERR_DOCKER_BUILDER          = 2
	ERR_AWS                     = 5
	EXIT_SUCCESS                = 0
)

func main() {

	env := utils.GetDataFromConsulWithPath("env", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)
	awskid := utils.GetDataFromVault(utils.GetEnvPath(AWS_KEY_ID, env))
	awssak := utils.GetDataFromVault(utils.GetEnvPath(AWS_ACCESS_KEY, env))
	aws_region := "us-east-1"

	session, err := session.NewSession(&aws.Config{
		Region:      aws.String(aws_region),
		Credentials: credentials.NewStaticCredentials(awskid, awssak, ""),
	},
	)

	if err != nil {
		fmt.Println(err)
		os.Exit(ERR_AWS)
	}

	owner := utils.GetDataFromConsulWithPath(utils.GetEnvPath("owner", env), utils.CONSUL_AWS_CLEAN_SWEEP_PATH) // 187631879586
	input := &ec2.DescribeSnapshotsInput{
		Filters: []*ec2.Filter{
			{
				Name: aws.String("status"),
				Values: []*string{
					aws.String("completed"),
				},
			},
		},
		OwnerIds: []*string{
			aws.String(owner),
		},
	}

	svc := ec2.New(session)
	result, err := svc.DescribeSnapshots(input)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			default:
				fmt.Println(aerr.Error())
			}
		} else {
			// Print the error, cast err to awserr.Error to get the Code and
			// Message from an error.
			fmt.Println(err.Error())
		}
		return
	}

	isVerbose := utils.GetDataFromConsulWithPath("verbose", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)
	logExtraDebugInfo := utils.GetDataFromConsulWithPath("log_extra_debug_info", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)

	fmt.Printf("\n Found total %d snapshots before filtering. \n", len(result.Snapshots))

	older_than_number_of_days, _ := strconv.Atoi(utils.GetDataFromConsulWithPath("older_than_number_of_days", utils.CONSUL_AWS_CLEAN_SWEEP_PATH))
	tag_name_to_match1 := utils.GetDataFromConsulWithPath("tag_name_to_match1", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)
	tag_value_to_match1 := utils.GetDataFromConsulWithPath("tag_value_to_match1", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)

	var totalVolumeSizeBeforeFiltering int64
	var volumeSizeToBeDeleted int64
	snapshotIdsToDelete := []string{}
	for _, snapshot := range result.Snapshots {
		utils.Log("++++++++++++", isVerbose, false)
		utils.Log(snapshot, logExtraDebugInfo, true)

		totalVolumeSizeBeforeFiltering = totalVolumeSizeBeforeFiltering + *snapshot.VolumeSize

		startTime := snapshot.StartTime
		if (*startTime).Before(time.Now().AddDate(0, 0, -older_than_number_of_days)) {
			utils.Log(fmt.Sprintf(" \n found snapshot(%s) with time in the past:%v \n ", *snapshot.SnapshotId, startTime), logExtraDebugInfo, false)

			for _, tag := range snapshot.Tags {
				if *tag.Key == tag_name_to_match1 && *tag.Value == tag_value_to_match1 {
					utils.Log("!!!------------ Found matching tag", logExtraDebugInfo, false)
					volumeId := *snapshot.VolumeId

					snapshotDescription := *snapshot.Description

					instanceId := ""
					amiId := ""
					re := regexp.MustCompile("(ami-[^\\s]+)")
					amiIdResult := re.FindStringSubmatch(snapshotDescription)
					if amiIdResult != nil {
						amiId = amiIdResult[1]
					}

					if amiId == "" {
						re = regexp.MustCompile("instance: ([^\\s]+)")
						instanceIdResult := re.FindStringSubmatch(snapshotDescription)
						if instanceIdResult != nil {
							instanceId = instanceIdResult[1]
						}
					}

					if amiId == "" && instanceId == "" {
						utils.Log(fmt.Sprintf(" \n Snapshot(%s) doesnt have AMI information or has unexpected decription field. Description field:(%s) ", *snapshot.SnapshotId, snapshotDescription), isVerbose, false)
					} else {
						utils.Log(fmt.Sprintf(" \n Found amiID:(%s) or instanceId:(%s)  for snapshot:(%s) ", amiId, instanceId, *snapshot.SnapshotId), isVerbose, false)
					}

					if (amiId != "" || instanceId != "") && !utils.IsAMIdeleted(amiId, svc, instanceId, isVerbose) {
						utils.Log(fmt.Sprintf(" \n Skipping snapshot(%s) because the AMI associated with it(%s) is not deleted. instanceId:(%s) ", *snapshot.SnapshotId, amiId, instanceId), isVerbose, false)
						continue
					}

					if !utils.IsVolumeInUse(volumeId, svc) {
						snapshotIdsToDelete = append(snapshotIdsToDelete, *snapshot.SnapshotId)
						volumeSizeToBeDeleted = volumeSizeToBeDeleted + *snapshot.VolumeSize
					} else {
						utils.Log(fmt.Sprintf(" \n Volume %s is in use  for snapshot(%s)", volumeId, *snapshot.SnapshotId), isVerbose, false)
					}
				}
			}
		}
		utils.Log("------------", isVerbose, false)

	}

	utils.Log(fmt.Sprintf(" \n Total snapshot volume size before filtering(in GB): %d", totalVolumeSizeBeforeFiltering), "true", false)
	utils.Log(fmt.Sprintf(" \n Snapshot volume size to be deleted(in GB): %d", volumeSizeToBeDeleted), "true", false)
	fmt.Printf("\n Found total %d snapshots to delete after filtering: \n", len(snapshotIdsToDelete))
	spew.Println(snapshotIdsToDelete)

	isDryRun := utils.GetDataFromConsulWithPath("is_dry_run", utils.CONSUL_AWS_CLEAN_SWEEP_PATH)
	if isDryRun == "false" {
		for _, snapshotIdToDelete := range snapshotIdsToDelete {
			utils.DeleteSnapshot(snapshotIdToDelete, svc, isVerbose)
		}
	}

}
