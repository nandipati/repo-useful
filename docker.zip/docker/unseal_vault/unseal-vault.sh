#!/bin/bash

set -o errexit

VAULT_ADDR="http://vault:8200"


IS_SEALED=`curl  $VAULT_ADDR/v1/sys/seal-status   |   jq -r .sealed `
if [ $IS_SEALED == 'false' ]; then
    echo "Vault is already unsealed. Exiting."
    exit
fi


echo "Unsealing vault..."

KEY=`curl -sS  consul:8500/v1/kv/cndnp/u?raw`
curl -H "Content-Type: application/json" -XPUT $VAULT_ADDR/v1/sys/unseal -d '{"key": "'$KEY'"}'  

echo "init PKI..."

init-public-key-infrastructure.sh
