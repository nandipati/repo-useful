#!/bin/bash

DOMAIN=cndcorenp
TTL=25920h
CERT_TTL=24000h

set -o errexit

VAULT_ADDR=http://vault:8200
export VAULT_ADDR

VAULT_TOKEN=`curl -sS  consul:8500/v1/kv/cndnp/t?raw`

echo " setting up the version of the secrets engine... "
cat << EOF > ./payload.json
{
  "options": {
      "version": "2"
  }
}
EOF

curl --header "X-Vault-Token: $VAULT_TOKEN" \
       --request POST \
       --data @payload.json \
       $VAULT_ADDR/v1/sys/mounts/secret/tune

echo "Starting PKI setup..."

vault login  $VAULT_TOKEN

echo " delete existing one "
vault secrets disable pki
vault secrets disable pki_int


echo " setup root CA "
vault secrets enable pki
vault secrets tune -max-lease-ttl=$TTL pki


# not needed for now, the S3 bucket appears to be open
#export AWS_ACCESS_KEY_ID=`curl -sS \
#    -H "X-Vault-Token: $VAULT_TOKEN" \
#    -X GET \
#    http://vault:8200/v1/secret/data/infrastructure  |  jq -r '.data.data.awskid'  `
#export AWS_SECRET_ACCESS_KEY=`curl -sS \
#    -H "X-Vault-Token: $VAULT_TOKEN" \
#    -X GET \
#    http://vault:8200/v1/secret/data/infrastructure  |  jq -r '.data.data.awssak'  `
aws s3 cp s3://cnd-terraform-assets/keys/cert_authority_bundle.pem .
if [ ! -f ./cert_authority_bundle.pem ]; then
    echo "unable to downlowad Cert file. Exiting!"
    exit 127
fi
vault write pki/config/ca pem_bundle=@./cert_authority_bundle.pem
rm -rf ./cert_authority_bundle.pem

echo " configure URLs "
vault write pki/config/urls issuing_certificates="$VAULT_ADDR/v1/pki/ca" \
crl_distribution_points="$VAULT_ADDR/v1/pki/crl"

echo " setup intermediate PKI "
vault secrets enable -path=pki_int pki
vault secrets tune -max-lease-ttl=$TTL pki_int

if [  -f ./pki_int.csr ]; then
    rm -rf  ./pki_int.csr
fi

echo " generae internal PKI "
curl \
    -H "X-Vault-Token: $VAULT_TOKEN" \
    -H "Content-Type: application/json" \
    -X POST \
    -d '{"common_name":"$DOMIAN"}' \
    $VAULT_ADDR/v1/pki_int/intermediate/generate/internal    | jq -r .data.csr  > pki_int.csr


echo " sign intermediate cert  "
vault write -format=json  pki/root/sign-intermediate csr=@pki_int.csr format=pem_bundle ttl=$CERT_TTL | jq -r .data.certificate > signed_certificate.pem

echo " set signed cert "
vault write pki_int/intermediate/set-signed certificate=@signed_certificate.pem

echo " init urls "
vault write pki_int/config/urls issuing_certificates="$VAULT_ADDR/v1/pki_int/ca"   \
crl_distribution_points="$VAULT_ADDR/v1/pki_int/crl"

echo " init roles "
vault write pki_int/roles/$DOMAIN-role \
    allow_any_name=true
    allow_subdomains=true max_ttl=$CERT_TTL

echo "Finished PKI setup"


# to issue a cert use:
# vault write pki_int/issue/$DOMAIN-role  common_name=blah.$DOMAIN
