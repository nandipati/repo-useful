# Purpose
Back end of the Riverside Cloud Services Management Console application.

The Go backend exposes REST API.

Backend of the app which is an API only receiving calls from a VueJS frontend.


