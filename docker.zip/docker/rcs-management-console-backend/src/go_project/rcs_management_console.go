package main

import (
	"./utils"
	"encoding/json"
	"fmt"

	_ "github.com/lib/pq"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

func GetQuotaKeyRoot(fullPath string) string {
	return fullPath[strings.LastIndex(fullPath, "/"):]
}

func GetRcsApplicationQuotas(w http.ResponseWriter, r *http.Request) {

	var err error

	quotasData := make([]map[string]interface{}, 1)

	quotasLimit := utils.GetListDataFromConsul("quotas/limit")
	quotasUsage := utils.GetListDataFromConsul("quotas/usage")

	quotasUsageMap := make(map[string]int)
	for _, usageMap := range quotasUsage {
		usageValue, _ := strconv.Atoi(usageMap["value"])
		quotasUsageMap[GetQuotaKeyRoot(usageMap["key"])] = usageValue
	}

	re := regexp.MustCompile(`^.+--(?P<quota_group>.+)--(?P<quota_item>.+)$`)

	for _, valuesMap := range quotasLimit {
		key := valuesMap["key"]
		value := valuesMap["value"]
		if value == "" {
			continue
		}

		fmt.Println("Processing:", key)
		match := re.FindStringSubmatch(key)

		result := make(map[string]interface{})
		for i, name := range re.SubexpNames() {
			if i != 0 && name != "" {
				result[name] = match[i]
			}
		}

		limitValue, _ := strconv.Atoi(value)
		result["limit"] = limitValue

		result["utilization"] = quotasUsageMap[GetQuotaKeyRoot(key)]

		usageValue, _ := result["utilization"].(int)
		result["available"] = limitValue - usageValue

		quotasData = append(quotasData, result)

	}

	returnedJson, err := json.Marshal(quotasData[1:])
	if err != nil {
		log.Println(err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	// Set a custom JSON header and send response to client:
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, "%s", returnedJson)
}
