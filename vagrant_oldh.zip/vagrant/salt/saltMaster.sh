rpm -ivh https://erepo.saltstack.com/sse/4.2/rhel/sse-repo-4.2.el6.rpm
cd /etc/yum.repos.d/
sleep 10
sed -i 's/$releasever/6/' sse-4.*.repo
yum install -y salt-enterprise-master salt-enterprise-ssh salt-enterprise-syndic salt-enterprise-cloud salt-enterprise-api
sleep 20
echo "default_include: master.d/*.yml" > /etc/salt/master
echo "interface: 0.0.0.0" >> /etc/salt/master
echo "file_roots:" >> /etc/salt/master
echo "   base:" >>/etc/salt/master
echo "     - /srv/salt/states" >> /etc/salt/master

echo "pillar_roots:">>/etc/salt/master
echo "  base:">>/etc/salt/master
echo "    - /srv/salt/pillars">>/etc/salt/master
sleep 20
service salt-master start

yum install -y python26-pip python26-boto salt-enterprise-minion
mkdir -p /etc/salt/minion.d
echo "10.10.10.11" > /etc/salt/minion_id
echo "master: 10.10.10.11" > /etc/salt/minion.d/99-master-address.conf
sleep 20
service salt-minion start
