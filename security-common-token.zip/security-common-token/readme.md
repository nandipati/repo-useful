# Security-Common-Token
Common Token is an common library for validating JWT Based Auth Tokens

It is not intended as a future path - it's an absolute bare bones extraction of the current method of authentication for service calls.
The focus for this extraction was on extending unit test coverage for the existing code rather than redesigning it.

As part of a follow on task we will redesign the API this library exposes and probably align with other authentication menthods


# Usage
com.rsinsights.security.common.token.utils.TokenUtils.decodeJWT will return a RSInsightsPrincipal if the token is valid, null if not
It expects a JWT value. This can be extracted from the common SIF Authorization Header

# Quality

**This library is not fit for production use yet**

## Static Analysis
We've implemented PMD and FindBugs and cleaned up any flagged issues

## Unit Test Coverage
We've greatly expanded the unit test coverage, in particular the code which verifies tokens.
