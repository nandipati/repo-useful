package com.rsi.security.common.token.header;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class SIFAuthorizationHeaderTest {
  @Before
  public void setUp() throws Exception {

  }


  @Test
  public void testTrimPrefix(){
    String suffix = "suffix";
    assertEquals(suffix, SIFAuthorizationHeader.trimPrefix("SIF_HMACSHA256 " + suffix));
    assertEquals(suffix, SIFAuthorizationHeader.trimPrefix("" + suffix));
    assertNotEquals(suffix, SIFAuthorizationHeader.trimPrefix("dummy text" + suffix));
  }


  @Test
  public void testTrimSuffix(){
    String prefix = "prefix";
    assertEquals(prefix, SIFAuthorizationHeader.trimSuffix(prefix) );
    assertEquals(prefix, SIFAuthorizationHeader.trimSuffix(prefix+":"));
    assertEquals(prefix, SIFAuthorizationHeader.trimSuffix(prefix+":ffo::"));

  }

  @Test
  public void testValidHeader(){
    String validHeader = "SIF_HMACSHA256 ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKQklGTmhiWEJzWlNCSmMzTjFaWElpTENKcFlYUWlPakUxTURNMk56UTVNVElzSW1GMVpDSTZJa0VnVTJGdGNHeGxJRUYxWkdsbGJtTmxJaXdpYzNWaUlqb2lZMjQ5U21GdVpTQkViMlVzZFdsa1BXcGtiMlVzZFc1cGNYVmxTV1JsYm5ScFptbGxjajFDUkVZeU1qWTVORUl3TmprMk0wTTBSVEEwTkRsRE9FVTVPVEJDUkRoQ09DeHZQVEExTXpRMk1qRXpMR1JqUFRBd01qRTNOekE0TEhOMFBXZGhMR005ZFhNaUxDSmxlSEFpT2pFMU1ETTJOelE1TVRJc0ltVjRkR1Z1YzJsdmJrTnNZV2x0SWpvaVJYaDBaVzV6YVc5dUlGWmhiSFZsSWl3aVpHVmhZM1JwZG1GMFpXUWlPbVpoYkhObGZRLmVzSzM0dXRjVEpLQzNuQUV1elRLZEg4N19Obko3Qm1EYmhjSUJ3OXRlS1E6R3NnM2QvV0VUUGgrbzRjNkVBU1B3ZXpOQzJFQWJiR25palBYZzlnSTdWbz0=";
    String decodedValue = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTIsImV4dGVuc2lvbkNsYWltIjoiRXh0ZW5zaW9uIFZhbHVlIiwiZGVhY3RpdmF0ZWQiOmZhbHNlfQ.esK34utcTJKC3nAEuzTKdH87_NnJ7BmDbhcIBw9teKQ";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertTrue(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testHeaderMissingPrefix(){
    String validHeader = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKQklGTmhiWEJzWlNCSmMzTjFaWElpTENKcFlYUWlPakUxTURNMk56UTVNVElzSW1GMVpDSTZJa0VnVTJGdGNHeGxJRUYxWkdsbGJtTmxJaXdpYzNWaUlqb2lZMjQ5U21GdVpTQkViMlVzZFdsa1BXcGtiMlVzZFc1cGNYVmxTV1JsYm5ScFptbGxjajFDUkVZeU1qWTVORUl3TmprMk0wTTBSVEEwTkRsRE9FVTVPVEJDUkRoQ09DeHZQVEExTXpRMk1qRXpMR1JqUFRBd01qRTNOekE0TEhOMFBXZGhMR005ZFhNaUxDSmxlSEFpT2pFMU1ETTJOelE1TVRJc0ltVjRkR1Z1YzJsdmJrTnNZV2x0SWpvaVJYaDBaVzV6YVc5dUlGWmhiSFZsSWl3aVpHVmhZM1JwZG1GMFpXUWlPbVpoYkhObGZRLmVzSzM0dXRjVEpLQzNuQUV1elRLZEg4N19Obko3Qm1EYmhjSUJ3OXRlS1E6R3NnM2QvV0VUUGgrbzRjNkVBU1B3ZXpOQzJFQWJiR25palBYZzlnSTdWbz0=";
    String decodedValue = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTIsImV4dGVuc2lvbkNsYWltIjoiRXh0ZW5zaW9uIFZhbHVlIiwiZGVhY3RpdmF0ZWQiOmZhbHNlfQ.esK34utcTJKC3nAEuzTKdH87_NnJ7BmDbhcIBw9teKQ";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertFalse(header.isValid());
    assertNotEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testHeaderMissingBody(){
    String validHeader = "SIF_HMACSHA256 ";
    String decodedValue = "";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertTrue(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testEmptyHeader(){
    String validHeader = "";
    String decodedValue = "";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertFalse(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testNullHeader(){
    String validHeader = null;
    String decodedValue = "";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertFalse(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testValidHeaderWithBadPrefix(){
    String validHeader = "BadPrefixSIF_HMACSHA256 ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKQklGTmhiWEJzWlNCSmMzTjFaWElpTENKcFlYUWlPakUxTURNMk56UTVNVElzSW1GMVpDSTZJa0VnVTJGdGNHeGxJRUYxWkdsbGJtTmxJaXdpYzNWaUlqb2lZMjQ5U21GdVpTQkViMlVzZFdsa1BXcGtiMlVzZFc1cGNYVmxTV1JsYm5ScFptbGxjajFDUkVZeU1qWTVORUl3TmprMk0wTTBSVEEwTkRsRE9FVTVPVEJDUkRoQ09DeHZQVEExTXpRMk1qRXpMR1JqUFRBd01qRTNOekE0TEhOMFBXZGhMR005ZFhNaUxDSmxlSEFpT2pFMU1ETTJOelE1TVRJc0ltVjRkR1Z1YzJsdmJrTnNZV2x0SWpvaVJYaDBaVzV6YVc5dUlGWmhiSFZsSWl3aVpHVmhZM1JwZG1GMFpXUWlPbVpoYkhObGZRLmVzSzM0dXRjVEpLQzNuQUV1elRLZEg4N19Obko3Qm1EYmhjSUJ3OXRlS1E6R3NnM2QvV0VUUGgrbzRjNkVBU1B3ZXpOQzJFQWJiR25palBYZzlnSTdWbz0=";
    String decodedValue = "";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertFalse(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

  @Test
  public void testNonBase64Characters(){
    String validHeader = "SIF_HMACSHA256 !@£$%^&**ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKQklGTmhiWEJzWlNCSmMzTjFaWElpTENKcFlYUWlPakUxTURNMk56UTVNVElzSW1GMVpDSTZJa0VnVTJGdGNHeGxJRUYxWkdsbGJtTmxJaXdpYzNWaUlqb2lZMjQ5U21GdVpTQkViMlVzZFdsa1BXcGtiMlVzZFc1cGNYVmxTV1JsYm5ScFptbGxjajFDUkVZeU1qWTVORUl3TmprMk0wTTBSVEEwTkRsRE9FVTVPVEJDUkRoQ09DeHZQVEExTXpRMk1qRXpMR1JqUFRBd01qRTNOekE0TEhOMFBXZGhMR005ZFhNaUxDSmxlSEFpT2pFMU1ETTJOelE1TVRJc0ltVjRkR1Z1YzJsdmJrTnNZV2x0SWpvaVJYaDBaVzV6YVc5dUlGWmhiSFZsSWl3aVpHVmhZM1JwZG1GMFpXUWlPbVpoYkhObGZRLmVzSzM0dXRjVEpLQzNuQUV1elRLZEg4N19Obko3Qm1EYmhjSUJ3OXRlS1E6R3NnM2QvV0VUUGgrbzRjNkVBU1B3ZXpOQzJFQWJiR25palBYZzlnSTdWbz0=";
    String decodedValue = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTIsImV4dGVuc2lvbkNsYWltIjoiRXh0ZW5zaW9uIFZhbHVlIiwiZGVhY3RpdmF0ZWQiOmZhbHNlfQ.esK34utcTJKC3nAEuzTKdH87_NnJ7BmDbhcIBw9teKQ";
    SIFAuthorizationHeader header = new SIFAuthorizationHeader(validHeader);
    assertEquals(header.getHeader(), validHeader);
    assertTrue(header.isValid());
    assertEquals(header.getDecodedHeader(), decodedValue);
  }

}