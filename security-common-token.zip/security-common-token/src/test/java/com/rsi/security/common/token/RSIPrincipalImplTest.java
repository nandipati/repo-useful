package com.rsi.security.common.token;

import org.apache.commons.lang.ArrayUtils;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class RSIPrincipalImplTest extends BaseTest {


  @Test
  public void testClaims() throws Exception {
    Map expectedClaims = new HashMap<String, Object>();
    expectedClaims.put(ROLE_CLAIM, SAMPLE_ROLE1);
    assertEquals(getUserPrincipal().getClaims(), expectedClaims);
    assertEquals(getUserPrincipal().getClaim(ROLE_CLAIM), SAMPLE_ROLE1);
    assertTrue(getUserPrincipal().containsClaim(ROLE_CLAIM));

    RSIPrincipal userWithOutClaims = new RSIPrincipalImpl(SAMPLE2_USERNAME);
    Map empty_map = Collections
            .unmodifiableMap(new HashMap<String, Object>());
    assertEquals(userWithOutClaims.getClaims(), empty_map);
    assertFalse(userWithOutClaims.containsClaim(ROLE_CLAIM));

    RSIPrincipal userWithEmptyClaims = new RSIPrincipalImpl(SAMPLE2_USERNAME, empty_map);
    assertEquals(userWithEmptyClaims.getClaims(), empty_map);
    assertFalse(userWithEmptyClaims.containsClaim(ROLE_CLAIM));
  }

  @Test
  public void testAddClaim() throws Exception {
    String claim = "A new claim";
    String claimValue = "A new claim value";
    getUserPrincipal().addClaim(claim, claimValue);
    assertTrue(getUserPrincipal().containsClaim(claim));
    assertEquals(getUserPrincipal().getClaim(claim), claimValue);
  }

  @Test
  public void testGetName() throws Exception {
    assertEquals(getUserPrincipal().getName(), SAMPLE_USERNAME);
  }


  @Test
  public void testGetUserName() throws Exception {
    assertEquals(getUserPrincipal().getUserName(), SAMPLE_USERNAME);
  }

  @Test
  public void testSetUserName() throws Exception {
    String newUserName = "A new name";
    getUserPrincipal().setUserName(newUserName);
    assertEquals(getUserPrincipal().getUserName(), newUserName);
  }

  @Test
  public void testGetGuid() throws Exception {
    assertEquals(getUserPrincipal().getGuid(), SAMPLE_GUID);
  }

  @Test
  public void testSetGuid() throws Exception {
    UUID newGuid = UUID.randomUUID();
    getUserPrincipal().setGuid(newGuid.toString());
    assertEquals(getUserPrincipal().getGuid(), newGuid.toString());
  }

  @Test
  public void testGetFullName() throws Exception {
    assertEquals(getUserPrincipal().getFullName(), SAMPLE_FULLNAME);
  }

  @Test
  public void testSetFullName() throws Exception {
    String newFullName = "A new full name";
    getUserPrincipal().setFullName(newFullName);
    assertEquals(getUserPrincipal().getFullName(), newFullName);
  }

  @Test
  public void testGetSchoolId() throws Exception {
    assertEquals(getUserPrincipal().getSchoolId(), SAMPLE_SCHOOL_ID);
  }

  @Test
  public void testSetSchoolId() throws Exception {
    String newSchoolId = "A new school id";
    getUserPrincipal().setSchoolId(newSchoolId);
    assertEquals(getUserPrincipal().getSchoolId(), newSchoolId);
  }

  @Test
  public void testGetDistrictId() throws Exception {
    assertEquals(getUserPrincipal().getDistrictId(), SAMPLE_DISTRICT_ID);
  }

  @Test
  public void testSetDistrictId() throws Exception {
    String newDistrictId = "A new district id";
    getUserPrincipal().setDistrictId(newDistrictId);
    assertEquals(getUserPrincipal().getDistrictId(), newDistrictId);
  }

  @Test
  public void testGetStateCode() throws Exception {
    assertEquals(getUserPrincipal().getStateCode(), SAMPLE_STATE_CODE);
  }

  @Test
  public void testSetStateCode() throws Exception {
    String newStateCode = "A new state code";
    getUserPrincipal().setStateCode(newStateCode);
    assertEquals(getUserPrincipal().getStateCode(), newStateCode);
  }

  @Test
  public void testGetCountryCode() throws Exception {
    assertEquals(getUserPrincipal().getCountryCode(), SAMPLE_COUNTRY_CODE);
  }

  @Test
  public void testSetCountryCode() throws Exception {
    String newCountryCode = "A new country code";
    getUserPrincipal().setCountryCode(newCountryCode);
    assertEquals(getUserPrincipal().getCountryCode(), newCountryCode);
  }

  @Test
  public void testGetRoles() throws Exception {
    assertArrayEquals(getUserPrincipal().getRoles(), new String[]{SAMPLE_ROLE1});
    RSIPrincipal userWithoutRoles = new RSIPrincipalImpl(SAMPLE2_USERNAME);
    assertArrayEquals(userWithoutRoles.getRoles(), new String[0]);
  }

  @Test
  public void testSetRoles() throws Exception {
    String[] newRoles = new String[]{SAMPLE_ROLE2};
    getUserPrincipal().setRoles(newRoles);
    assertArrayEquals(getUserPrincipal().getRoles(), newRoles);
  }

  @Test
  public void testIsUserInRole() throws Exception {
    assertFalse(getUserPrincipal().isUserInRole(SAMPLE_ROLE2));
    assertFalse(getUserPrincipal().isUserInRole(null));
    assertTrue(getUserPrincipal().isUserInRole(SAMPLE_ROLE1));
    getUserPrincipal().setRoles(null);
    assertFalse(getUserPrincipal().isUserInRole(SAMPLE_ROLE1));
    getUserPrincipal().setRoles(new String[]{SAMPLE_ROLE2});
    assertTrue(getUserPrincipal().isUserInRole(SAMPLE_ROLE2));
    assertFalse(getUserPrincipal().isUserInRole(SAMPLE_ROLE1));
  }

  @Test
  public void testGetIssuedAt() throws Exception {
    assertEquals(getUserPrincipal().getIssuedAt(), SAMPLE_ISSUED_AT_TIME);
  }

  @Test
  public void testSetIssuedAt() throws Exception {
    long now = System.currentTimeMillis();
    getUserPrincipal().setIssuedAt(now);
    assertEquals(getUserPrincipal().getIssuedAt(), now);
  }

  @Test
  public void testGetExpiresAt() throws Exception {
    assertEquals(getUserPrincipal().getExpiresAt(), SAMPLE_EXPIRED_AT_TIME);
  }

  @Test
  public void testSetExpiresAt() throws Exception {
    long now = System.currentTimeMillis();
    getUserPrincipal().setExpiresAt(now);
    assertEquals(getUserPrincipal().getExpiresAt(), now);
  }

  @Test
  public void testExtensionClaims() throws Exception {
    String newClaim = "A new claim";
    String newValue = "A new value";
    assertFalse(getUserPrincipal().getExtensionClaims().containsKey(newClaim));
    getUserPrincipal().addExtensionClaim(newClaim, newValue);
    assertTrue(getUserPrincipal().getExtensionClaims().containsKey(newClaim));
    assertEquals(getUserPrincipal().getExtensionClaims().get(newClaim), newValue);
    getUserPrincipal().removeExtensionClaim(newClaim);
    assertFalse(getUserPrincipal().getExtensionClaims().containsKey(newClaim));
  }

  @Test
  public void testParentOrgs() throws Exception {
    getUserPrincipal().setParentOrgs(null);
    assertTrue(Arrays.deepEquals(getUserPrincipal().getParentOrgs(), new String[0]));
    String parentOrg = "A parent org id";
    assertFalse(ArrayUtils.contains(getUserPrincipal().getParentOrgs(), parentOrg));
    getUserPrincipal().setParentOrgs(new String[]{parentOrg});
    assertTrue(ArrayUtils.contains(getUserPrincipal().getParentOrgs(), parentOrg));
    RSIPrincipal userWithoutParentOrgs = new RSIPrincipalImpl(SAMPLE2_USERNAME);
    assertArrayEquals(userWithoutParentOrgs.getParentOrgs(), new String[0]);

  }

  @Test
  public void testEquals() {
    // TODO - validate that users with same username should be considered equal
    assertTrue(getUserPrincipal().equals(new RSIPrincipalImpl(SAMPLE_USERNAME)));
    assertFalse(getUserPrincipal().equals(new RSIPrincipalImpl(SAMPLE2_USERNAME)));
    assertFalse(getUserPrincipal().equals(null));
    assertFalse(getUserPrincipal().equals(new Object()));
  }

  @Test
  public void testToString() {
    RSIPrincipal newUser = new RSIPrincipalImpl(SAMPLE2_USERNAME);
    String expectToString = String.format("[name: %s, uid:%s, uniqueIdentifier: %s, o: %s, dc: %s", SAMPLE_USERNAME, SAMPLE_USERNAME, SAMPLE_GUID, SAMPLE_SCHOOL_ID, SAMPLE_DISTRICT_ID);
    assertEquals(getUserPrincipal().toString(), expectToString);
  }

  @Test
  public void testHashCode() {
    assertEquals(getUserPrincipal().hashCode(), SAMPLE_USERNAME.hashCode());
  }


}