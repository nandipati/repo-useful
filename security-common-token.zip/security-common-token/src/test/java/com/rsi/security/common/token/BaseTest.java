package com.rsi.security.common.token;

import org.junit.Before;

/**
 * Created by Daniel Burke on 25/08/2017.
 */
public class BaseTest {
  // A sample user in Alcova Elementary School in Gwinnett Co Public School Dist
  public static final String SAMPLE_FULLNAME = "Jane Doe";
  public static final String SAMPLE_USERNAME = "jdoe";
  public static final String SAMPLE_GUID = "BDF22694B06963C4E0449C8E990BD8B8";
  public static final String SAMPLE_SCHOOL_ID = "05346213";
  public static final String SAMPLE_DISTRICT_ID = "00217708";
  public static final String SAMPLE_STATE_CODE = "ga";
  public static final String SAMPLE_COUNTRY_CODE = "us";
  public static final String SAMPLE_ROLE1 = "Instructor";
  public static final String SAMPLE_ROLE2 = "Student";
  public static final long SAMPLE_EXPIRED_AT_TIME = 444444444444L;
  public static final long NOW_TIME = 33333333333L;
  public static final long SAMPLE_ISSUED_AT_TIME = 2222222222L;
  public final static String ROLE_CLAIM = "http://www.imsglobal.org/imspurl/lis/v1/vocab/person";
  public static final String[] SAMPLE2_ROLES = {"ROLE1", "ROLE2", "ROLE3"};
  // Sample of a private school - Lima Christian School, Rochester NY
  public static final String SAMPLE2_FULLNAME = "John Doe";
  public static final String SAMPLE2_USERNAME = "j.doe";
  public static final String SAMPLE2_GUID = "9f45338d87864f1ab1c1b8c89fd7cc47";
  public static final String SAMPLE2_SCHOOL_ID = "02161272";
  public static final String SAMPLE2_DISTRICT_ID = "09";
  public static final String SAMPLE2_STATE_CODE = "ny";
  public static final String SAMPLE2_COUNTRY_CODE = "us";
  public static final String SAMPLE2_SUBJECT = "cn=John Doe,uid=j.doe,uniqueIdentifier=9f45338d87864f1ab1c1b8c89fd7cc47,o=02161272,dc=09,st=ny,c=us";
  public static final String SAMPLE_SUBJECT = "cn=Jane Doe,uid=jdoe,uniqueIdentifier=BDF22694B06963C4E0449C8E990BD8B8,o=05346213,dc=00217708,st=ga,c=us";
  public static final String SAMPLE_SUBJECT2 = "cn=Jane Doe,uid=jdoe,uniqueIdentifier=BDF22694B06963C4E0449C8E990BD8B8,o=05346213,dc=00217708,st=ga";
  public static final String SAMPLE_SECRET = "Not Really A Secret";
  public static final String SAMPLE_AUDIENCE = "A Sample Audience";
  public static final String SAMPLE_ISSUER = "A Sample Issuer";


  private RSIPrincipal userPrincipal;

  @Before
  public void setUp() {

    setUserPrincipal(new RSIPrincipalImpl(SAMPLE_USERNAME));
    getUserPrincipal().setUserName(SAMPLE_USERNAME);
    getUserPrincipal().setCountryCode(SAMPLE_COUNTRY_CODE);
    getUserPrincipal().setFullName(SAMPLE_FULLNAME);
    getUserPrincipal().setGuid(SAMPLE_GUID);
    getUserPrincipal().setSchoolId(SAMPLE_SCHOOL_ID);
    getUserPrincipal().setDistrictId(SAMPLE_DISTRICT_ID);
    getUserPrincipal().setStateCode(SAMPLE_STATE_CODE);
    getUserPrincipal().setCountryCode(SAMPLE_COUNTRY_CODE);
    getUserPrincipal().setExpiresAt(SAMPLE_EXPIRED_AT_TIME);
    getUserPrincipal().setIssuedAt(SAMPLE_ISSUED_AT_TIME);
    getUserPrincipal().addClaim(ROLE_CLAIM, SAMPLE_ROLE1);
    getUserPrincipal().setRoles(new String[]{SAMPLE_ROLE1});
  }

  public RSIPrincipal getUserPrincipal() {
    return userPrincipal;
  }

  public void setUserPrincipal(RSIPrincipal userPrincipal) {
    this.userPrincipal = userPrincipal;
  }
}
