package com.rsi.security.common.token;

import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class RSIPrincipalUserDetailsTest extends BaseTest {

  @Test
  public void testRSInsightsPrincipalUserDetailsFromRSInsightsPrincipal() {
    String newClaim = "A new claim";
    String newValue = "A new value";
    getUserPrincipal().addExtensionClaim(newClaim, newValue);
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertEquals(userDetails.getClaims(), getUserPrincipal().getClaims());
    assertEquals(userDetails.getExtensionClaims(), getUserPrincipal().getExtensionClaims());
    assertEquals(userDetails.getUserName(), getUserPrincipal().getUserName());
    assertEquals(userDetails.getUsername(), getUserPrincipal().getUserName());
    assertEquals(userDetails.getCountryCode(), getUserPrincipal().getCountryCode());
    assertEquals(userDetails.getDistrictId(), getUserPrincipal().getDistrictId());
    assertEquals(userDetails.getExpiresAt(), getUserPrincipal().getExpiresAt());
    assertEquals(userDetails.getFullName(), getUserPrincipal().getFullName());
    assertEquals(userDetails.getGuid(), getUserPrincipal().getGuid());
    assertEquals(userDetails.getIssuedAt(), getUserPrincipal().getIssuedAt());
    assertArrayEquals(userDetails.getParentOrgs(), getUserPrincipal().getParentOrgs());
    assertEquals(userDetails.getSchoolId(), getUserPrincipal().getSchoolId());
    assertEquals(userDetails.getStateCode(), getUserPrincipal().getStateCode());
    assertEquals(userDetails.getCountryCode(), getUserPrincipal().getCountryCode());
    assertArrayEquals(userDetails.getRoles(), getUserPrincipal().getRoles());
  }

  @Test
  public void testRSInsightsPrincipalUserDetailsFromUsername() {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal().getUserName());
    assertEquals(userDetails.getName(), getUserPrincipal().getUserName());
    assertNull(userDetails.getUserName());
    assertNull(userDetails.getUsername());
    assertNull(userDetails.getCountryCode());
    assertNull(userDetails.getDistrictId());
    assertNull(userDetails.getFullName());
    assertNull(userDetails.getGuid());
    assertNull(userDetails.getSchoolId());
    assertNull(userDetails.getStateCode());
    assertNull(userDetails.getCountryCode());
    assertEquals(userDetails.getExpiresAt(), Long.MIN_VALUE);
    assertEquals(userDetails.getIssuedAt(), Long.MIN_VALUE);
    assertTrue(userDetails.getClaims().isEmpty());
    assertTrue(userDetails.getExtensionClaims().isEmpty());
    assertTrue(userDetails.getRoles().length == 0);
    assertTrue(userDetails.getParentOrgs().length == 0);

  }


  @Test
  public void testAuthorities() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(SAMPLE_ROLE1);
    List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
    grantedAuthorityList.add(grantedAuthority);
    assertEquals(userDetails.getAuthorities(), grantedAuthorityList);
  }

  @Test
  public void getPassword() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertNull(userDetails.getPassword());
  }

  @Test
  public void isAccountNonExpired() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertTrue(userDetails.isAccountNonExpired());
  }

  @Test
  public void isAccountNonLocked() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertTrue(userDetails.isAccountNonLocked());
  }

  @Test
  public void isCredentialsNonExpired() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertTrue(userDetails.isCredentialsNonExpired());
  }

  @Test
  public void isEnabled() throws Exception {
    RSIPrincipalUserDetails userDetails = new RSIPrincipalUserDetails(getUserPrincipal());
    assertTrue(userDetails.isEnabled());
  }

}