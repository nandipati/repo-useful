/*
 * 
 *  Copyright Houghton Mifflin Harcourt 2011
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */
package com.rsi.security.common.token;

import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import org.junit.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 * @author ohiceadhap
 */
public class VerifierProviderFactoryTest extends BaseTest {

  public VerifierProviderFactoryTest() {
  }

  @BeforeClass
  public static void setUpClass() {
  }

  @AfterClass
  public static void tearDownClass() {
  }

  @Before
  public void setUp() {
  }

  @After
  public void tearDown() {
  }

  @Test
  public void testGetInstanceWithValidAlgo() {
    assertNotNull(VerifierProviderFactory.getInstance(SignatureAlgorithm.HS256.name(), SAMPLE_SECRET));
  }

  @Test
  public void testGetInstanceWithInValidAlgo() {
    assertNull(VerifierProviderFactory.getInstance(SignatureAlgorithm.HS1.name(), SAMPLE_SECRET));
  }
}
