package com.rsi.security.common.token.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.rsi.security.common.token.BaseTest;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.RSIPrincipalImpl;
import com.rsi.security.common.token.RSInsightsTokenClaimsChecker;
import net.oauth.jsontoken.Checker;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.JsonTokenParser;
import net.oauth.jsontoken.SystemClock;
import net.oauth.jsontoken.discovery.VerifierProviders;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class TokenUtilsUnitTest extends BaseTest {


  @Test
  public void testProcessArray() {

    JsonArray roles = new JsonArray();
    roles.add(new JsonPrimitive(SAMPLE_ROLE1));
    roles.add(new JsonPrimitive(SAMPLE_ROLE2));

    JsonObject payload = new JsonObject();
    payload.add(ROLE_CLAIM, roles);

    String[] expResult = {SAMPLE_ROLE1, SAMPLE_ROLE2};

    String[] result = TokenUtils.processArray(payload, ROLE_CLAIM);
    assertArrayEquals(expResult, result);

    // Check order is maintained
    JsonArray rolesReversed = new JsonArray();
    rolesReversed.add(new JsonPrimitive(SAMPLE_ROLE2));
    rolesReversed.add(new JsonPrimitive(SAMPLE_ROLE1));

    payload = new JsonObject();
    payload.add(ROLE_CLAIM, rolesReversed);

    String[] expReversedResult = {SAMPLE_ROLE2, SAMPLE_ROLE1};

    String[] reversedResult = TokenUtils.processArray(payload, ROLE_CLAIM);
    assertArrayEquals(expReversedResult, reversedResult);
  }


  @Test
  public void testProcessArraySingleString() {

    JsonObject payload = new JsonObject();
    payload.add(ROLE_CLAIM, new JsonPrimitive(SAMPLE_ROLE1));

    String[] expResult = {SAMPLE_ROLE1};

    String[] result = TokenUtils.processArray(payload, ROLE_CLAIM, true);
    assertArrayEquals(expResult, result);
  }


  @Test
  public void testAddUserDetails() {

    String userName = SAMPLE2_USERNAME;
    RSIPrincipal principal = new RSIPrincipalImpl(userName);

    TokenUtils.addUserDetails(principal, SAMPLE2_SUBJECT);
    assertEquals(principal.getUserName(), SAMPLE2_USERNAME);
    assertEquals(principal.getCountryCode(), SAMPLE2_COUNTRY_CODE);
    assertEquals(principal.getFullName(), SAMPLE2_FULLNAME);
    assertEquals(principal.getGuid(), SAMPLE2_GUID);
    assertEquals(principal.getSchoolId(), SAMPLE2_SCHOOL_ID);
    assertEquals(principal.getDistrictId(), SAMPLE2_DISTRICT_ID);
    assertEquals(principal.getStateCode(), SAMPLE2_STATE_CODE);
    assertEquals(principal.getCountryCode(), SAMPLE2_COUNTRY_CODE);
  }


  @Test
  public void testFormatSubjectClaim() {
    String result = TokenUtils.formatSubjectClaim(getUserPrincipal());
    assertEquals(SAMPLE_SUBJECT, result);
  }

  @Test
  public void testFormatSubjectClaimMissingInfo() {

    getUserPrincipal().setCountryCode(null);
    String result = TokenUtils.formatSubjectClaim(getUserPrincipal());
    assertEquals(SAMPLE_SUBJECT2, result);
  }


  @Test
  public void testAddClaimsAsArray() {

    JsonObject payload = new JsonObject();

    String claimKey = TokenUtils.ROLE_CLAIM;
    TokenUtils.addClaimsAsArray(claimKey, SAMPLE2_ROLES, payload);

    assertTrue("Array of claims were not added", payload.has(claimKey));

    JsonElement courseSectionClaim = payload.get(claimKey);
    assertTrue("Claim was not added as a JSON Array", courseSectionClaim.isJsonArray());

    JsonArray roles = courseSectionClaim.getAsJsonArray();
    assertEquals("Incorrect number of elements in array added", 3, roles.size());
    for (int i = 0; i < roles.size(); i++) {
      JsonElement courseSection = roles.get(i);
      assertEquals("Incorrect course at position " + i, courseSection.getAsString(), SAMPLE2_ROLES[i]);
    }
  }


  @Test
  public void testaddUnescapedClaims() {

    JsonObject payload = new JsonObject();

    Map<String, Object> claims = new HashMap<String, Object>();
    claims.put(TokenUtils.ROLE_CLAIM, "test\n");

    TokenUtils.addUnescapedClaims(claims, payload, true);
    assertTrue(Arrays.equals("test\n".toCharArray(), payload.get(TokenUtils.ROLE_CLAIM).getAsString().toCharArray()));

    TokenUtils.addUnescapedClaims(claims, payload, false);
    assertTrue(Arrays.equals("test\n".toCharArray(), payload.get(TokenUtils.ROLE_CLAIM).getAsString().toCharArray()));
  }


  @Test
  public void testGenerateJWTBasic() throws Exception {
    String token = TokenUtils.generateJWT(SAMPLE_AUDIENCE, SAMPLE_ISSUER, SAMPLE_SECRET, SAMPLE_SUBJECT, new DateTime(), null, null);
//        assertEquals("", token);

    String decodedValue = new String(org.apache.commons.codec.binary.Base64.decodeBase64(token), "UTF-8");
//        assertEquals("", decodedValue);

  }

  @Test
  public void testGenerateTokenExpiry() throws Exception {
    VerifierProviders locators = new VerifierProviders();
    Checker tokenChecker = new RSInsightsTokenClaimsChecker(SAMPLE_AUDIENCE);
    JsonTokenParser parser = new JsonTokenParser(new SystemClock(), locators, tokenChecker);
    DateTime currentTime = new DateTime();
    DateTime expiryTime = currentTime.plusSeconds(500);
    String token = TokenUtils.generateJWT(SAMPLE_AUDIENCE, SAMPLE_ISSUER, SAMPLE_SECRET, getUserPrincipal(), expiryTime, null, null);
    JsonToken jsonToken = parser.deserialize(token);
    RSIPrincipal principal = TokenUtils.decodeJWT(token, null, new SystemClock(), SAMPLE_AUDIENCE, SAMPLE_SECRET);
    assertEquals(principal.getExpiresAt(), jsonToken.getExpiration().getMillis());
    //rounds to the nearest second
    assertEquals(principal.getExpiresAt(), expiryTime.getMillis() - expiryTime.getMillisOfSecond());
  }

  @Test
  public void testGenerateExpiredToken() throws Exception {
    VerifierProviders locators = new VerifierProviders();
    Checker tokenChecker = new RSInsightsTokenClaimsChecker(SAMPLE_AUDIENCE);
    JsonTokenParser parser = new JsonTokenParser(new SystemClock(), locators, tokenChecker);
    DateTime currentTime = new DateTime();
    DateTime expiryTime = currentTime.minusSeconds(500);
    String token = TokenUtils.generateJWT(SAMPLE_AUDIENCE, SAMPLE_ISSUER, SAMPLE_SECRET, getUserPrincipal(), expiryTime, null, null);
    JsonToken jsonToken = parser.deserialize(token);
    RSIPrincipal principal = TokenUtils.decodeJWT(token, null, new SystemClock(), SAMPLE_AUDIENCE, SAMPLE_SECRET);
    assertNull(principal);

  }

  @Test
  public void testGenerateUUID() {
/*        String guid = "1234929";
        String uuid1 = UUIDGenerator.forOrganizationPID(guid);
        assertTrue("Invalid UUID", UUIDGenerator.isValidV4UUID(uuid1));
        String uuid2 = UUIDGenerator.forOrganizationPID(guid);
        assertTrue("Invalid UUID", UUIDGenerator.isValidV4UUID(uuid2));
        assertEquals("UUID deterministic?", uuid1, uuid2);
        
        String[] guids = { "00002709", "00636714", "00431320", "00097891", "H523376", "9UNKNOWN", "Y8821238" };
        for (int i = 0; i < guids.length; i++)
        {
            String uuid = UUIDGenerator.forOrganizationPID(guids[i]);
            assertTrue(UUIDGenerator.isValidV4UUID(uuid));
        }*/
//        assertTrue(false);
  }


  @Test
  public void testDecodeJWTBasic() throws Exception {
    DateTimeUtils.setCurrentMillisFixed(1503674911000L);
    String validToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTJ9.krPdQOti96UIvbFFwmfBjTvwfQOObXTtjSk1nemXF-M";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            validToken,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);

    principal = TokenUtils.decodeJWT(
            validToken,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);
  }


  @Test
  public void testEmptyToken() throws Exception {
    String emptyToken = "";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            emptyToken,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);

    principal = TokenUtils.decodeJWT(
            emptyToken,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);
  }



  @Test
  public void testTokenWithNoSub() {
    String tokenWithoutSub = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwiZXhwIjoxNTAzNjc0OTEyfQ.GY7Xzurifm683KopMJ4Uvt12ZmyONPAyaA4ZAMdD8OQ";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            tokenWithoutSub,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);

    principal = TokenUtils.decodeJWT(
            tokenWithoutSub,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);

  }


  @Test
  public void testTamperedToken() {
    String tamperedToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM5MjcwODQsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM5MjgwODR9.ZiN5O-xo5cVE4HVsWPPIbPuespmviljQsjfHqQzuL3Q";

    RSIPrincipal principal = TokenUtils.decodeJWT(
            tamperedToken,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);

    principal = TokenUtils.decodeJWT(
            tamperedToken,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);

  }

  @Test
  public void testExpiredToken() {
    String expiredToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjk3ODMwNjIwMCwiYXVkIjoiQSBTYW1wbGUgQXVkaWVuY2UiLCJzdWIiOiJjbj1KYW5lIERvZSx1aWQ9amRvZSx1bmlxdWVJZGVudGlmaWVyPUJERjIyNjk0QjA2OTYzQzRFMDQ0OUM4RTk5MEJEOEI4LG89MDUzNDYyMTMsZGM9MDAyMTc3MDgsc3Q9Z2EsYz11cyIsImV4cCI6OTc4MzA3MjAwfQ.ZiN5O-xo5cVE4HVsWPPIbPuespmviljQsjfHqQzuL3Q";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            expiredToken,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);

    principal = TokenUtils.decodeJWT(
            expiredToken,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNull(principal);
  }


  @Test
  public void testTokenWithExtensionClaim() {
    String tokenWithExtensionClaim = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTIsImV4dGVuc2lvbkNsYWltIjoiRXh0ZW5zaW9uIFZhbHVlIn0.EcsJZlzvvWJo2eXQ4hpiKWBmKU1_dcSqVfep5KW3e8E";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            tokenWithExtensionClaim,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);
    principal = TokenUtils.decodeJWT(
            tokenWithExtensionClaim,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);
  }

  @Test
  public void testTokenWithAdditionalStandardClaims() {
    String tokenWithExtensionClaim = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsImF1ZCI6IkEgU2FtcGxlIEF1ZGllbmNlIiwic3ViIjoiY249SmFuZSBEb2UsdWlkPWpkb2UsdW5pcXVlSWRlbnRpZmllcj1CREYyMjY5NEIwNjk2M0M0RTA0NDlDOEU5OTBCRDhCOCxvPTA1MzQ2MjEzLGRjPTAwMjE3NzA4LHN0PWdhLGM9dXMiLCJleHAiOjE1MDM2NzQ5MTIsImV4dGVuc2lvbkNsYWltIjoiRXh0ZW5zaW9uIFZhbHVlIiwiZGVhY3RpdmF0ZWQiOmZhbHNlfQ.esK34utcTJKC3nAEuzTKdH87_NnJ7BmDbhcIBw9teKQ";
    RSIPrincipal principal = TokenUtils.decodeJWT(
            tokenWithExtensionClaim,
            null,
            new SystemClock(),
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);
    principal = TokenUtils.decodeJWT(
            tokenWithExtensionClaim,
            SAMPLE_AUDIENCE,
            SAMPLE_SECRET
    );
    assertNotNull(principal);
  }


}
