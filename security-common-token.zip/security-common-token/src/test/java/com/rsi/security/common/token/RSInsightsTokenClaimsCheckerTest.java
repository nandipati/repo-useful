package com.rsi.security.common.token;

import net.oauth.jsontoken.JsonTokenParser;
import net.oauth.jsontoken.SystemClock;
import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import net.oauth.jsontoken.discovery.VerifierProvider;
import net.oauth.jsontoken.discovery.VerifierProviders;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.security.SignatureException;

import static org.junit.Assert.assertTrue;

public class RSInsightsTokenClaimsCheckerTest extends BaseTest {

  private RSInsightsTokenClaimsChecker tokenChecker = new RSInsightsTokenClaimsChecker("A Valid Audience");
  private JsonTokenParser parser;

  @Rule
  public ExpectedException thrown = ExpectedException.none();


  @Before
  public void setup() {
    super.setUp();
    DateTimeUtils.setCurrentMillisFixed(1503674911000L);
    VerifierProviders locators = new VerifierProviders();
    VerifierProvider hmacLocator = VerifierProviderFactory.getInstance(SignatureAlgorithm.HS256.name(), SAMPLE_SECRET);
    locators.setVerifierProvider(SignatureAlgorithm.HS256, hmacLocator);
    parser = new JsonTokenParser(new SystemClock(), locators, tokenChecker);

  }

  @Test
  public void checkWithValidAudience() throws Exception {
    String tokenWithValidAudience = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJhdWQiOiJBIFZhbGlkIEF1ZGllbmNlIiwiaWF0IjoxNTAzNjc0OTEyLCJzdWIiOiJjbj1KYW5lIERvZSx1aWQ9amRvZSx1bmlxdWVJZGVudGlmaWVyPUJERjIyNjk0QjA2OTYzQzRFMDQ0OUM4RTk5MEJEOEI4LG89MDUzNDYyMTMsZGM9MDAyMTc3MDgsc3Q9Z2EsYz11cyIsImV4cCI6MTUwMzY3NDkxMn0.6Ji3INqHpxDIeTIhv70HZZaKH7Tm0lZanVlkfWEx_eQ";
    assertTrue(tokenChecker.isAudienceValid(
            parser.verifyAndDeserialize(tokenWithValidAudience).getPayloadAsJsonObject()
    ));
  }

  @Test
  public void checkWithInvalidAudience() throws SignatureException {
    String tokenWithInValidAudience = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJhdWQiOiJBIEludmFsaWQgQXVkaWVuY2UiLCJpYXQiOjE1MDM2NzQ5MTIsInN1YiI6ImNuPUphbmUgRG9lLHVpZD1qZG9lLHVuaXF1ZUlkZW50aWZpZXI9QkRGMjI2OTRCMDY5NjNDNEUwNDQ5QzhFOTkwQkQ4Qjgsbz0wNTM0NjIxMyxkYz0wMDIxNzcwOCxzdD1nYSxjPXVzIiwiZXhwIjoxNTAzNjc0OTEyfQ.bNDxDa_gbhm31AteMwRlanPx_sFqm_dAMF-OYVyEw2Y";
    thrown.expect(java.security.SignatureException.class);
    tokenChecker.isAudienceValid(parser.verifyAndDeserialize(tokenWithInValidAudience).getPayloadAsJsonObject());
  }

  @Test
  public void checkWithMissingAudience() throws SignatureException {
    String tokenWithOutAudience = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJBIFNhbXBsZSBJc3N1ZXIiLCJpYXQiOjE1MDM2NzQ5MTIsInN1YiI6ImNuPUphbmUgRG9lLHVpZD1qZG9lLHVuaXF1ZUlkZW50aWZpZXI9QkRGMjI2OTRCMDY5NjNDNEUwNDQ5QzhFOTkwQkQ4Qjgsbz0wNTM0NjIxMyxkYz0wMDIxNzcwOCxzdD1nYSxjPXVzIiwiZXhwIjoxNTAzNjc0OTEyfQ.-aZ82lHzg5csifJdIHbpdkc8xA_lN-VKGSdDOkn2_CM";
    thrown.expect(java.security.SignatureException.class);
    tokenChecker.isAudienceValid(parser.verifyAndDeserialize(tokenWithOutAudience).getPayloadAsJsonObject());
  }


}