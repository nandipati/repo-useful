package com.rsi.security.common.token.utils;

import com.rsi.security.common.token.auth.SIFAuthorization;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Test;


/**
 * Created by nandipatim on 1/18/19.
 */

public class GenerateSIFToken {

  private DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

  @Test
  public void generateSIFToken(){
    String isoAuthCurrentDateTime = dateTimeFormatter.print(DateTime.now());

    SIFAuthorization sifAuthorization = new SIFAuthorization("AK1WAio16Abn9-B.rsi.com","ANH_vt05J0f8U5NqI6U9qeJonTKv0O14_WifCibjY81AmT2T4",isoAuthCurrentDateTime);
    String Authorization = sifAuthorization.getAuthorization();

    String authCurrentDateTime = sifAuthorization.getAuthCurrentDateTime();

    System.out.println("Authorization:"+Authorization+"authCurrentDateTime:"+authCurrentDateTime);
  }

  @Test
  public void generateSecret(){

    try {
      String secret = getHash();
      secret = secret.substring(0, 49);
    }catch(Exception ex){
      ex.printStackTrace();
    }
  }

  private String getHash() throws Exception {
    String textToEncrypt = UUID.randomUUID().toString().replaceAll("-","");
    Cipher cipher = getCipher(Cipher.ENCRYPT_MODE);
    byte[] encryptedBytes = cipher.doFinal(textToEncrypt.getBytes());
    String key = Base64.encodeBase64String(encryptedBytes);
    return key;
  }

  private Cipher getCipher(int cipherMode) throws Exception
  {
    String encryptionAlgorithm = "AES";
    // random 16 characters
    String encryptionKey = "";

    SecretKeySpec keySpecification = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), encryptionAlgorithm);
    Cipher cipher = Cipher.getInstance(encryptionAlgorithm);
    cipher.init(cipherMode, keySpecification);

    return cipher;
  }

  @Test
  public void generateRSISecret(){
    // Basically the client id should be <client_id>.rsi.com max 25 characters in total
    // secret should be max 49 characters
    //ALFQcNTDzuouQHO7H5kzYp0CvojHFDTYJtKKGdxa5L1vPHPA2qsFv5CUjaLDm_LV3_B2bGp_WYw97RmNgU6WKx4
    //ALFQcNTDzuouQHO7H.rsi.com
    //ANH_vt05J0f8U5NqI6U9qeJonTKv0O14_WifCibjY81AmT2T4

    String secret = Base64.encodeBase64URLSafeString(new BigInteger(512, new SecureRandom()).toByteArray()).replace("=", "");
    System.out.println(secret);
  }

  @Test
  public void testSplit(){
    String token = "AK1WAio16Abn9-B.rsi.com:!oaW4pHBJxkbiGxi0XyV2MxbqrExKkuuXydu7XL9N00M=\n:!2019-04-12T12:34:48.596-05:00";
    String[] tokenParts = token.split(":!");

    System.out.println("Lenghth of Array "+tokenParts.length);
  }

}
