package com.rsi.security.common.token.auth;

import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.client.BaseClientDetails;

/**
 * Created by nandipatim on 1/16/19.
 */
public class RSIApiClientInfo extends BaseClientDetails implements ClientInfo {

  public RSIApiClientInfo() {
  }

  public RSIApiClientInfo(ClientDetails clientDetails) {
    super(clientDetails);
  }
}
