package com.rsi.security.common.token.auth;

import javax.sql.DataSource;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;

/**
 * Created by nandipatim on 1/16/19.
 */
public class RSIDbClientInfoStore extends JdbcClientDetailsService implements ClientInfoStore {

  public RSIDbClientInfoStore(DataSource dataSource) {
    super(dataSource);
  }

  @Cacheable({"clientInfoStore"})
  public ClientInfo loadClientInfoByClientId(String clientId) {
    ClientDetails details = super.loadClientByClientId(clientId);
    return new RSIApiClientInfo(details);
  }
}
