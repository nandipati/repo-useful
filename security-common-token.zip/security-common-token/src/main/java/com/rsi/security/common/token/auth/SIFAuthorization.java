package com.rsi.security.common.token.auth;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.rsi.security.common.token.utils.TokenType;

/**
 * Created by nandipatim on 1/16/19.
 */
public class SIFAuthorization implements ApiClientAuthorization {

  private static final Logger log = Logger.getLogger(SIFAuthorization.class);
  public static final String SIF_HMAC_AUTH = "SIF_HMACSHA256 ";
  public static final String SIF_AUTH_DATE_HDR = "authCurrentDateTime";
  public static final String UTF_8 = "UTF-8";
  public static final String HMAC_SHA_256 = "HmacSHA256";
  public static final String HMAC_SHA_2561 = "HmacSHA256";
  public static final String AUTHORIZATION = "Authorization";
  public static final String delimiter = ":!";
  private TokenType tokenType;
  private String authCurrentDateTime;
  private String authorization;
  private String clientId;
  private String clientSecret;
  private String hash;
  private boolean valid = true;

  public SIFAuthorization(String clientId, String clientSecret, String authCurrentDateTime) {
    this.authCurrentDateTime = authCurrentDateTime;
    this.clientId = clientId;
    this.clientSecret = clientSecret;

    try {
      if(log.isDebugEnabled()) {
        log.debug("Creating hash");
      }

      this.hash = this.generateHash(clientSecret);
      StringBuilder ex = (new StringBuilder(clientId)).append(delimiter).append(this.hash);
      StringBuilder auth = new StringBuilder("SIF_HMACSHA256 ");
      auth.append(Base64.encodeBase64String(ex.toString().getBytes()));
      this.authorization = auth.toString();
    } catch (InvalidKeyException var6) {
      log.error("Invalid Secret Key", var6);
    } catch (NoSuchAlgorithmException var7) {
      log.error("HMAC SHA 256 Not Supported", var7);
    }

  }

  public SIFAuthorization(String clientId, String clientSecret, String authCurrentDateTime , TokenType tokenType,
                          Boolean includeTokenType) {
    this.authCurrentDateTime = authCurrentDateTime;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.tokenType = tokenType;

    try {
      if(log.isDebugEnabled()) {
        log.debug("Creating hash");
      }

      this.hash = this.generateHash(clientSecret);
      StringBuilder ex = (new StringBuilder(clientId)).append(delimiter).append(this.hash).append(delimiter).append(authCurrentDateTime);
      //StringBuilder auth = new StringBuilder(tokenType.toString()+" ");
      StringBuilder auth = new StringBuilder("");
      if(includeTokenType) {
        auth.append(tokenType.toString()+" ");
      }
      auth.append(Base64.encodeBase64String(ex.toString().getBytes()));
      this.authorization = auth.toString();
    } catch (InvalidKeyException var6) {
      log.error("Invalid Secret Key", var6);
    } catch (NoSuchAlgorithmException var7) {
      log.error("HMAC SHA 256 Not Supported", var7);
    }

  }

  public SIFAuthorization(String authHeader, String authCurrentDateTime) {
    if(log.isDebugEnabled()) {
      log.debug("Decoding authHeader");
    }

    this.authorization = authHeader;
    this.authCurrentDateTime = authCurrentDateTime;

    try {
      if(authHeader != null && (authHeader.startsWith(TokenType.BEARER.toString()+" ")||authHeader.startsWith(TokenType.MAC.toString()+" "))) {
        String ex = null;
        if(authHeader.startsWith(TokenType.BEARER.toString()+" ")) {
          ex = new String(Base64.decodeBase64(authHeader.replaceFirst(tokenType.BEARER.toString()+" ", "")), "UTF-8");
        }else{
          ex = new String(Base64.decodeBase64(authHeader.replaceFirst(tokenType.MAC.toString()+" ", "")), "UTF-8");
        }
        String[] tokenParts = ex.split(delimiter);
        if(tokenParts != null & tokenParts.length == 3) {
          this.clientId = tokenParts[0];
          this.hash = tokenParts[1];
          if(StringUtils.isEmpty(this.authCurrentDateTime)) {
            this.authCurrentDateTime = tokenParts[2];
          }
        } else {
          this.valid = false;
        }
      } else {
        this.valid = false;
      }
    } catch (UnsupportedEncodingException var5) {
      this.valid = false;
      log.error("Unable to decode token", var5);
    }

  }

  public boolean isValid(String clientSecret) {
    if(this.valid) {
      try {
        if(clientSecret != null) {
          if(this.isAuthTimeInRange()) {
            String ex = this.generateHash(clientSecret);
            if(log.isDebugEnabled()) {
              log.debug("Comparing received hash = " + this.hash + "\r\nwith generated = " + ex+"");
            }

          if(!ex.trim().equals(this.hash.trim())) {
              this.valid = false;
            }
          }
        } else {
          this.valid = false;
        }
      } catch (InvalidKeyException var3) {
        log.error("Invalid Secret Key", var3);
        this.valid = false;
      } catch (NoSuchAlgorithmException var4) {
        log.error("HMAC SHA 256 Not Supported", var4);
        this.valid = false;
      }
    }

    return this.valid;
  }

  public boolean isAuthTimeInRange() {
    return true;
  }

  private String generateHash(String clientSecret) throws InvalidKeyException, NoSuchAlgorithmException {
    StringBuilder token = (new StringBuilder(this.clientId)).append(delimiter).append(this.authCurrentDateTime);
    Charset charSet = Charset.forName("UTF-8");
    Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
    SecretKeySpec secret_key = new SecretKeySpec(charSet.encode(clientSecret).array(), "HmacSHA256");
    sha256_HMAC.init(secret_key);
    String h = Base64.encodeBase64String(sha256_HMAC.doFinal(token.toString().getBytes())) + "\n";
    if(log.isDebugEnabled()) {
      log.debug("\'" + this.clientId + "\' :: \'" + clientSecret + "\' :: \'" + this.authCurrentDateTime + "\' :: " + "Hash \'" + h + "\'");
    }

    return h;
  }

  public String getAuthCurrentDateTime() {
    return this.authCurrentDateTime;
  }

  public void setAuthCurrentDateTime(String authCurrentDateTime) {
    this.authCurrentDateTime = authCurrentDateTime;
  }

  public String getAuthorization() {
    return this.authorization;
  }

  public void setAuthorization(String authorization) {
    this.authorization = authorization;
  }

  public String getClientId() {
    return this.clientId;
  }

  public String getClientSecret() {
    return this.clientSecret;
  }

}
