package com.rsi.security.common.token.auth;

import java.util.Set;

/**
 * Created by nandipatim on 1/16/19.
 */
public interface ClientInfo {

  String getClientId();

  String getClientSecret();

  Set<String> getScope();

  Set<String> getRegisteredRedirectUri();

  Integer getAccessTokenValiditySeconds();

  Integer getRefreshTokenValiditySeconds();
}
