/*
 * 
 *  Copyright Houghton Mifflin Harcourt 2011
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */

package com.rsi.security.common.token;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.oauth.jsontoken.Checker;

import java.security.SignatureException;

/**
 * @author ohiceadhap
 */
public class RSInsightsTokenClaimsChecker implements Checker {

  String requiredAudience;

  public RSInsightsTokenClaimsChecker(String requiredAudience) {
    this.requiredAudience = requiredAudience;
  }

  @Override
  public void check(JsonObject payload) throws SignatureException {
    if (!isAudienceValid(payload)) {
      throw new SignatureException("Invalid Audience");
    }
  }

  public boolean isAudienceValid(JsonObject payload) {
    if (payload.has("aud")) {
      JsonElement audienceElem = payload.get("aud");
      String audience = audienceElem.getAsString();
      if (requiredAudience.equals(audience)) {
        return true;
      }
    } else {
      return false;
    }
    return false;
  }

}
