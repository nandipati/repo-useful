package com.rsi.security.common.token.auth;

import org.apache.oltu.oauth2.as.issuer.ValueGenerator;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;

/**
 * Created by nandipatim on 1/16/19.
 */
public class SIFClientAuthorization extends SIFAuthorization implements ValueGenerator {
  public static final String DEFAULT_CLIENT_ID = "RSI Player";
  public static final String DEFAULT_CLIENT_SECRET = "RSI Player";

  public SIFClientAuthorization(String authHeader, String authCurrentDateTime) {
    super(authHeader, authCurrentDateTime);
  }

  public SIFClientAuthorization(String userJWT, String defaultClientSecret, String authCurrentDateTime) {
    super(userJWT, defaultClientSecret, authCurrentDateTime);
  }

  public String generateValue() throws OAuthSystemException {
    return super.getAuthorization();
  }

  public String generateValue(String value) throws OAuthSystemException {
    return this.generateValue();
  }
}
