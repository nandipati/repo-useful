/*
 * 
 *  Copyright Houghton Mifflin Harcourt 2013
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */

package com.rsi.security.common.token;

import org.apache.commons.lang.ArrayUtils;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Security Principal to hold identity and the standard set of claims
 * for Riverside Insights platforms.
 *
 * @author ohiceadhap
 */
public class RSIPrincipalImpl implements RSIPrincipal, Serializable {
  private String userName;
  private String guid;
  private String fullName;
  private String schoolId;
  private String districtId;
  private String[] parentOrgs;
  private String stateCode;
  private String countryCode;
  private String[] roles;

  private long issuedAt = Long.MIN_VALUE;
  private long expiresAt = Long.MIN_VALUE;

  private HashMap<String, Object> extensionClaims = new HashMap<String, Object>();


  private static final Map<String, Object> EMPTY_MAP = Collections
          .unmodifiableMap(new HashMap<>());

  /**
   * Unique Id for Serialization.
   */
  private static final long serialVersionUID = -879263022413216219L;

  /**
   * The unique identifier for the principal.
   */
  private final String name;

  /**
   * Map of claims for the Principal.
   */
  private Map<String, Object> claims;

  public RSIPrincipalImpl(final String name) {
    this(name, null);
  }

  public RSIPrincipalImpl(final String name, final Map<String, Object> claims) {
    this.name = name;

    this.claims = claims;
  }

  /**
   * Returns an immutable map of the claims from the JWT.
   */
  @Override
  public Map<String, Object> getClaims() {
    return claims == null || claims.isEmpty() ? EMPTY_MAP : Collections.unmodifiableMap(claims);
  }

  /* Returns the claim with the specified key.
   * @param key the claim to return
   * @ return
   */
  @Override
  public Object getClaim(String key) {
    return this.claims.get(key);
  }

  @Override
  public boolean containsClaim(String key) {
    return this.claims != null && this.claims.containsKey(key);
  }

  @Override
  public void addClaim(final String key, final Object value) {
    if (this.claims == null) {
      this.claims = new HashMap<>(4);
    }
    this.claims.put(key, value);
  }

  @Override
  public String toString() {
    StringBuilder result = new StringBuilder(128);
    result.append("[name: ").append(name).append(", uid:").append(userName).append(", uniqueIdentifier: ");
    result.append(guid).append(", o: ").append(schoolId).append(", dc: ").append(districtId);

//        for (Map.Entry<String,Object> entry : this.claims.entrySet())
//             result.append("claim="+entry.getKey()+":" +entry.getValue()) ;
//
//        for (Map.Entry<String,Object> entry : this.extensionClaims.entrySet())
//            result.append("Extclaim="+entry.getKey()+":" +entry.getValue()) ;

    return result.toString();
  }

  @Override
  public int hashCode() {
    return this.name.hashCode();
  }

  @Override
  public final String getName() {
    return this.name;
  }

  @Override
  public boolean equals(final Object o) {
    if (o == null || !this.getClass().equals(o.getClass())) {
      return false;
    }

    final RSIPrincipalImpl p = (RSIPrincipalImpl) o;

    return this.name.equals(p.getName());
  }

  /**
   * @return the userName
   */
  @Override
  public String getUserName() {
    return userName;
  }

  /**
   * @param userName the userName to set
   */
  @Override
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   * @return the guid
   */
  @Override
  public String getGuid() {
    return guid;
  }

  /**
   * @param guid the guid to set
   */
  @Override
  public void setGuid(String guid) {
    this.guid = guid;
  }

  /**
   * @return the fullName
   */
  @Override
  public String getFullName() {
    return fullName;
  }

  /**
   * @param fullName the fullName to set
   */
  @Override
  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  /**
   * @return the schoolId
   */
  @Override
  public String getSchoolId() {
    return schoolId;
  }

  /**
   * @param schoolId the schoolId to set
   */
  @Override
  public void setSchoolId(String schoolId) {
    this.schoolId = schoolId;
  }

  /**
   * @return the districtId
   */
  @Override
  public String getDistrictId() {
    return districtId;
  }

  /**
   * @param districtId the districtId to set
   */
  @Override
  public void setDistrictId(String districtId) {
    this.districtId = districtId;
  }

  /**
   * @return the parentOrgs
   */
  @Override
  public String[] getParentOrgs() {
    return parentOrgs == null ? new String[0] : parentOrgs.clone();
  }

  /**
   * @param parentOrgs the parentOrgs to set
   */
  @Override
  public void setParentOrgs(String[] parentOrgs) {
    this.parentOrgs = parentOrgs == null ? new String[0] : parentOrgs.clone();
  }

  /**
   * @return the stateCode
   */
  @Override
  public String getStateCode() {
    return stateCode;
  }

  /**
   * @param stateCode the stateCode to set
   */
  @Override
  public void setStateCode(String stateCode) {
    this.stateCode = stateCode;
  }

  /**
   * @return the countryCode
   */
  @Override
  public String getCountryCode() {
    return countryCode;
  }

  /**
   * @param countryCode the countryCode to set
   */
  @Override
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  /**
   * @return the roles
   */
  @Override
  public String[] getRoles() {
    return roles == null ? new String[0] : roles.clone();
  }

  /**
   * @param roles the roles to set
   */
  @Override
  public void setRoles(final String[] roles) {
    this.roles = roles == null ? new String[0] : roles.clone();
  }

  /**
   * Check if the user has the specified role
   *
   * @param role to check for
   * @return true if the user has the role
   */
  @Override
  public boolean isUserInRole(final String role) {
    boolean isInRole = false;
    if (ArrayUtils.contains(roles, role)) {
      isInRole = true;
    }
    return isInRole;
  }

  /**
   * @return the issuedAt
   */
  @Override
  public long getIssuedAt() {
    return issuedAt;
  }

  /**
   * @param issuedAt the issuedAt to set
   */
  @Override
  public void setIssuedAt(long issuedAt) {
    this.issuedAt = issuedAt;
  }

  /**
   * @return the expiresAt
   */
  @Override
  public long getExpiresAt() {
    return expiresAt;
  }

  /**
   * @param expiresAt the expiresAt to set
   */
  @Override
  public void setExpiresAt(long expiresAt) {
    this.expiresAt = expiresAt;
  }

  @Override
  public void addExtensionClaim(final String key, final Object value) {
    this.extensionClaims.put(key, value);
  }

  @Override
  public void removeExtensionClaim(final String key) {
    this.extensionClaims.remove(key);
  }

  @Override
  public Map<String, Object> getExtensionClaims() {
    return extensionClaims.isEmpty() ? EMPTY_MAP : Collections.unmodifiableMap(extensionClaims);
  }
}
