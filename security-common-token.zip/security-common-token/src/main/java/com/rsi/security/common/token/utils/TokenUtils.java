package com.rsi.security.common.token.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.VerifierProviderFactory;
import com.rsi.security.common.token.RSInsightsTokenClaimsChecker;
import com.rsi.security.common.token.JWTPrincipal;
import net.oauth.jsontoken.Checker;
import net.oauth.jsontoken.Clock;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.JsonTokenParser;
import net.oauth.jsontoken.SystemClock;
import net.oauth.jsontoken.crypto.HmacSHA256Signer;
import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import net.oauth.jsontoken.discovery.VerifierProvider;
import net.oauth.jsontoken.discovery.VerifierProviders;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import org.springframework.ldap.support.LdapEncoder;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.util.Map;
import java.util.Set;

public class TokenUtils {

  private static final Logger log = Logger.getLogger(TokenUtils.class);

  public final static String JWT = "JWT";

  public static final String CN = "cn";
  public static final String UID = "uid";
  public static final String UNIQUE_IDENTIFIER = "uniqueIdentifier";
  public static final String O = "o";
  public static final String DC = "dc";
  public static final String ST = "st";
  public static final String COMMA = ",";
  public static final String COMMASPLIT = "(?<!\\\\),";
  public static final String C = "c";
  public static final String EQUALS = "=";
  public static final String EQUALSSPLIT = "(?<!\\\\)=";
  public static final String ROLE_CLAIM = "http://www.imsglobal.org/imspurl/lis/v1/vocab/person";
  public static final String SCOPE_CLAIM = "scope";
  public static final String SUBJECT_CLAIM = "sub";
  public static final String TYPE_HEADER = "typ";
  public final static String EXPIRY_CLAIM = "exp";
  public final static String ISSUED_AT_CLAIM = "iat";
  public final static String PLATFORM_CLAIM = "PlatformId";
  public final static String DOMAIN_CLAIM = "hd";
  public final static String EMAIL_CLAIM = "email";
  public static final String CLIENT_ID_CLAIM = "client_id";
  public static final String COOKIE_DEACTIVATED_KEY = "deactivated";

  private static final String[] standardClaimsToExtract = {
          EXPIRY_CLAIM, ISSUED_AT_CLAIM, PLATFORM_CLAIM, COOKIE_DEACTIVATED_KEY
  };

  /**
   * Encode the supplied RSIPrincipal as a signed JWT. Primarily used for ESS Cookie generation it should be used for
   * any authentication/authorization mechanism where user credntials are required.
   *
   * @param audience                     Indicates the domain of the party being authenticated with this token (referrer domain)
   * @param issuer                       Host granting access
   * @param sharedSecret                 Shared secret between the audience and issuer
   * @param principal                    carries a standard set of claims expected by Riverside Insights platforms
   * @param expiry                       time at which the token and cookie should expire
   * @param additionalPrivateClaimNames  Names of any extra Riverside Insights claims to be added to the token
   * @param additionalPrivateClaimValues Corresponding values of any extra Riverside Insights claims to be added to the token.
   * @return encoded JWT token
   */
  public static String generateJWT(String audience, String issuer, String sharedSecret, RSIPrincipal principal, DateTime expiry, String[] additionalPrivateClaimNames, String[] additionalPrivateClaimValues)
          throws SignatureException, InvalidKeyException {

    if (principal == null) throw new IllegalArgumentException("principal argument cannot be null");

    String signedToken = null;

    HmacSHA256Signer signer = getHmacSHA256Signer(issuer, sharedSecret);

    //Configure JSON token & Header
    JsonToken token = new JsonToken(signer);
    token.getHeader().addProperty(TokenUtils.TYPE_HEADER, TokenUtils.JWT);

    // Add Reserved Claims
    token.setAudience(audience);
    token.setIssuedAt(principal.getIssuedAt() > 0 ? new Instant(principal.getIssuedAt()) : new DateTime(DateTimeZone.UTC).toInstant());

    //Add private claims
    JsonObject payload = token.getPayloadAsJsonObject();
    payload.addProperty(TokenUtils.SUBJECT_CLAIM, TokenUtils.formatSubjectClaim(principal));
    TokenUtils.addClaimsAsArray(TokenUtils.ROLE_CLAIM, principal.getRoles(), payload);

    if (additionalPrivateClaimNames != null && additionalPrivateClaimValues != null) {
      for (int i = 0; i < additionalPrivateClaimNames.length; i++)
        payload.addProperty(additionalPrivateClaimNames[i], additionalPrivateClaimValues[i]);
    }

    TokenUtils.addUnescapedClaims(principal.getClaims(), payload, false);
    TokenUtils.addUnescapedClaims(principal.getExtensionClaims(), payload, true);

    // Add Expiration claim
    token.setExpiration(expiry.toInstant());

    signedToken = token.serializeAndSign();
    return signedToken;
  }

  private static HmacSHA256Signer getHmacSHA256Signer(String issuer, String sharedSecret) throws InvalidKeyException {
    HmacSHA256Signer signer = null;
    try {
      signer = new HmacSHA256Signer(issuer, null, sharedSecret.getBytes("UTF-8"));
    } catch (UnsupportedEncodingException e) {
      log.error("Error loading shared secret");
      throw new InvalidKeyException(e);
    }
    return signer;
  }


  /**
   * Utility method to generate a JWT token using the supplied parameters. This does not rely on a RSIPrincipal parameter
   * so can be used for basic JWT use cases, eg, Authorizatoin header generation.
   *
   * @param audience
   * @param issuer
   * @param sharedSecret
   * @param subject
   * @param expiry
   * @param additionalPrivateClaimNames
   * @param additionalPrivateClaimValues
   * @return encoded JWT token
   * @throws SignatureException
   * @throws InvalidKeyException
   */
  public static String generateJWT(String audience, String issuer, String sharedSecret, String subject, DateTime expiry, String[] additionalPrivateClaimNames, String[] additionalPrivateClaimValues)
          throws SignatureException, InvalidKeyException {

    String signedToken = null;

    HmacSHA256Signer signer = getHmacSHA256Signer(issuer, sharedSecret);

    //Configure JSON token & Header
    JsonToken token = new JsonToken(signer);
    token.getHeader().addProperty(TokenUtils.TYPE_HEADER, TokenUtils.JWT);

    // Add Reserved Claims
    token.setAudience(audience);
    token.setIssuedAt(new DateTime(DateTimeZone.UTC).toInstant());

    //Add private claims
    JsonObject payload = token.getPayloadAsJsonObject();
    payload.addProperty(TokenUtils.SUBJECT_CLAIM, subject);

    if (additionalPrivateClaimNames != null && additionalPrivateClaimValues != null) {
      for (int i = 0; i < additionalPrivateClaimNames.length; i++)
        payload.addProperty(additionalPrivateClaimNames[i], additionalPrivateClaimValues[i]);
    }

    // Add Expiration claim
    token.setExpiration(expiry.toInstant());

    signedToken = token.serializeAndSign();

    return signedToken;
  }


  public static String[] processArray(JsonObject payload, String claimKey) {
    return processArray(payload, claimKey, false);
  }

  /**
   * @param payload
   * @param claimKey
   * @param acceptStringValue a workaround for .Net libraries that convert arrays with length = 1 to strings
   * @return
   */
  public static String[] processArray(JsonObject payload, String claimKey, boolean acceptStringValue) {
    String[] roles = null;
    if (payload.has(claimKey)) {
      JsonElement jsonValue = payload.remove(claimKey);
      if (jsonValue != null) {
        // This should contain a JSON array of roles the user has
        if (jsonValue.isJsonArray()) {
          JsonArray roleElements = jsonValue.getAsJsonArray();
          roles = new String[roleElements.size()];
          int i = 0;
          for (JsonElement roleElement : roleElements) {
            roles[i++] = roleElement.getAsString();
          }
        } else if (acceptStringValue && jsonValue.isJsonPrimitive()) {
          roles = new String[1];
          roles[0] = jsonValue.getAsString();
        }
      }
    }
    return roles;
  }

  /**
   * Parse subject claim and add to Principal
   *
   * @param principal - Security Principal for the user to add sub claim details to
   * @param subject   - Subject claim, in LDAP format
   */
  public static void addUserDetails(RSIPrincipal principal, String subject) {
    // Unfortunately the Java LDAP API didn't exist in Java 1.4, but we only
    // need a simple parse for now
    //sub":"cn=Jane Doe,uid=jdoe,uniqueIdentifier=BDF22694B06963C4E0449C8E990BD8B8,o=00217708,dc=00217708,st=ga"
    // String unescapedSubject = StringEscapeUtils.unescapeJava(subject);

    String[] components = subject.split(COMMASPLIT);
    for (String nameValuePair : components) {
      String[] part = nameValuePair.split(EQUALSSPLIT);
      if (part.length == 2) {
        String name = part[0], value = part[1];

        if (CN.equals(name))

          principal.setFullName(LdapEncoder.nameDecode(value));
        else if (UID.equals(name))
          principal.setUserName(LdapEncoder.nameDecode(value));
        else if (UNIQUE_IDENTIFIER.equals(name))
          principal.setGuid(value);
        else if (O.equals(name))
          principal.setSchoolId(value);
        else if (DC.equals(name))
          principal.setDistrictId(value);
        else if (ST.equals(name))
          principal.setStateCode(value);
        else if (C.equals(name))
          principal.setCountryCode(value);
      }
    }
  }


  /**
   * Example sub":"cn=Jane Doe,uid=jdoe,uniqueIdentifier=BDF22694B06963C4E0449C8E990BD8B8,o=00217708,dc=00217708,st=ga"
   *
   * @param principal
   * @return
   */
  public static String formatSubjectClaim(RSIPrincipal principal) {

    StringBuilder subjectBuilder = new StringBuilder(128);

    if (principal != null) {

      if (principal.getFullName() != null)
        subjectBuilder.append(CN + EQUALS).append(LdapEncoder.nameEncode(principal.getFullName())).append(COMMA);

      if (principal.getUserName() != null)
        subjectBuilder.append(UID + EQUALS).append(LdapEncoder.nameEncode(principal.getUserName())).append(COMMA);

      if (principal.getGuid() != null)
        subjectBuilder.append(UNIQUE_IDENTIFIER + EQUALS).append(principal.getGuid()).append(COMMA);

      if (principal.getSchoolId() != null)
        subjectBuilder.append(O + EQUALS).append(principal.getSchoolId()).append(COMMA);

      if (principal.getDistrictId() != null)
        subjectBuilder.append(DC + EQUALS).append(principal.getDistrictId()).append(COMMA);

      if (principal.getStateCode() != null)
        subjectBuilder.append(ST + EQUALS).append(principal.getStateCode()).append(COMMA);

      if (principal.getCountryCode() != null)
        subjectBuilder.append(C + EQUALS).append(principal.getCountryCode()).append(COMMA);

      if (subjectBuilder.length() > 0) subjectBuilder.deleteCharAt(subjectBuilder.length() - 1);
    }
    return subjectBuilder.toString();
  }


  public static void addClaimsAsArray(String claimKey, String[] values, JsonObject payload) {

    if (claimKey != null && values != null && payload != null) {
      JsonArray roleClaims = new JsonArray();
      for (int i = 0; i < values.length; i++) {
        roleClaims.add(new JsonPrimitive(values[i]));
      }
      payload.add(claimKey, roleClaims);
    }
  }


  public static void addUnescapedClaims(Map<String, Object> claims, JsonObject payload, boolean unescape) {
    if (claims != null && payload != null) {
      for (Map.Entry<String, Object> entry : claims.entrySet()) {
        Object val = entry.getValue();
        if (val != null) {
          String unescapedValue = unescape ? StringEscapeUtils.unescapeJava(val.toString()) : val.toString();
          payload.addProperty(entry.getKey(), unescapedValue);
        }
      }
    }
  }

  /**
   * A wrapper around decodeJWT with sensible defaults
   * @param tokenValue
   * @param audience
   * @param sharedSecret
   * @return
   */
  public static RSIPrincipal decodeJWT(String tokenValue, String audience, String sharedSecret) {
    return decodeJWT(tokenValue, standardClaimsToExtract, new SystemClock(), audience, sharedSecret);
  }



  public static RSIPrincipal decodeJWT(String tokenValue, String[] claimsToExtract, Clock clock, String audience, String sharedSecret) {

    final String[] claims = (claimsToExtract == null) ? standardClaimsToExtract : claimsToExtract;

    RSIPrincipal principal = null;

    VerifierProviders locators = new VerifierProviders();
    Checker tokenChecker = new RSInsightsTokenClaimsChecker(audience);
    JsonTokenParser parser = new JsonTokenParser(clock, locators, tokenChecker);

    VerifierProvider hmacLocator = VerifierProviderFactory.getInstance(SignatureAlgorithm.HS256.name(), sharedSecret);
    locators.setVerifierProvider(SignatureAlgorithm.HS256, hmacLocator);

    try {
      JsonToken token = parser.verifyAndDeserialize(tokenValue);
      JsonObject payload = token.getPayloadAsJsonObject();

      if (payload.has(TokenUtils.SUBJECT_CLAIM)) {
        JsonElement jsonValue = payload.remove(TokenUtils.SUBJECT_CLAIM);
        String subject = jsonValue.getAsString();
        principal = new JWTPrincipal(subject);
        TokenUtils.addUserDetails(principal, subject);
      } else {
        principal = new JWTPrincipal("");
      }
      principal.setRoles(TokenUtils.processArray(payload, TokenUtils.ROLE_CLAIM));

      principal.setIssuedAt(token.getIssuedAt().getMillis());
      payload.remove(TokenUtils.ISSUED_AT_CLAIM);
      principal.setExpiresAt(token.getExpiration().getMillis());
      payload.remove(TokenUtils.EXPIRY_CLAIM);

      Set<Map.Entry<String, JsonElement>> entrySet = payload.entrySet();
      for (Map.Entry<String, JsonElement> entry : entrySet) {
        JsonElement jsonValue = entry.getValue();
        if (jsonValue != null) {
          String key = entry.getKey();
          if (ArrayUtils.contains(claims, key)) {
            principal.addClaim(key, jsonValue.getAsString());
          } else {
            principal.addExtensionClaim(key, jsonValue.getAsString());
          }
        }
      }
    } catch (Exception ex) {
      log.error(ex.getMessage() + "\r\nToken : " + tokenValue);
    }

    return principal;
  }
}
