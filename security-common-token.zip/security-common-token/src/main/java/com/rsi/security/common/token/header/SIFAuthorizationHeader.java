package com.rsi.security.common.token.header;

import org.apache.commons.codec.binary.Base64;

import java.io.UnsupportedEncodingException;

/**
 * Model a SIF Authorization Header
 */
public class SIFAuthorizationHeader {

  public static final java.lang.String SIF_HMAC_AUTH = "SIF_HMACSHA256 " ;
  private static final String UTF_8 = "UTF-8";

  private String decodedHeader = "";
  private String header = "";
  private boolean valid = false;

  public SIFAuthorizationHeader(String authHeader){
    this.header = authHeader;
    this.decodedHeader = decodeHeader(this.header);
  }

  public String getDecodedHeader(){
    return this.decodedHeader;
  }

  public String getHeader(){
    return this.header;
  }

  public boolean isValid(){
    return this.valid;
  }


  private String decodeHeader(String header){
    String decodedHeader = "";
    try {
      if (header != null && header.startsWith(SIF_HMAC_AUTH)) {
        String prefixTrimmed = trimPrefix(header);
        String base64decoded = new String(Base64.decodeBase64(prefixTrimmed), UTF_8);
        decodedHeader = trimSuffix(base64decoded);
        valid = true;
      } else {
        valid = false;
      }
    } catch (UnsupportedEncodingException ex) {
      valid = false;
    }
    return decodedHeader;
  }

  public static String trimPrefix(String input){
    return input.replaceFirst(SIF_HMAC_AUTH, "");

  }

  public static String trimSuffix(String input){
    return input.split(":")[0];
  }
}
