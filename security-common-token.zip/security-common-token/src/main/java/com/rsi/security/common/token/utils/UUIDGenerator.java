package com.rsi.security.common.token.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.UUID;
import org.apache.commons.codec.binary.Hex;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class UUIDGenerator {

  private static final Logger log = Logger.getLogger(UUIDGenerator.class);
  public static final String ALGORITHM = "SHA-256";
  public static final String CHARACTER_SET = "UTF-8";
  public static final String DELIMITER = ".";
  public static final String NAMESPACE = UUIDGenerator.class.getName();
  public static final int BYTES_OUT = 16;
  private static final String ORGANIZATION_PID;

  public UUIDGenerator() {
  }

  public static boolean isValidV4UUID(String uuidString) {
    boolean isValid = false;

    try {
      UUID iae = UUID.fromString(uuidString);
      if(iae.version() == 4 && iae.variant() == 2) {
        isValid = true;
        if(log.isDebugEnabled()) {
          log.debug("Valid UUID: " + uuidString);
        }
      } else if(log.isDebugEnabled()) {
        log.debug("Valid UUID: " + uuidString + ", Invalid Version: " + iae.version() + ", and/or Invalid Variant: " + iae.variant());
      }
    } catch (IllegalArgumentException var3) {
      if(log.isDebugEnabled()) {
        log.debug("Invalid UUID: " + uuidString);
      }
    }

    return isValid;
  }

  public static String forOrganizationPID(String pid) {
    return generateUUID((new StringBuilder(ORGANIZATION_PID)).append(pid));
  }

  protected static String forEntityAndField(String entity, String field, String id) {
    StringBuilder message = (new StringBuilder(NAMESPACE + ".")).append(entity).append(".").append(field).append(".").append(id);
    return generateUUID(message);
  }

  public static String generateUUID(StringBuilder message) {
    if(log.isDebugEnabled()) {
      log.debug("generateUUID - message: " + message);
    }

    byte[] hash = generateHash(message);
    if(log.isDebugEnabled()) {
      log.debug("generateUUID - hash: " + Hex.encodeHexString(hash));
    }

    hash[6] = (byte)(hash[6] & 15 | 64);
    hash[8] = (byte)(hash[8] & 63 | 128);
    String hexDigits = Hex.encodeHexString(Arrays.copyOf(hash, 16));
    String uuid = formatUUID(hexDigits);
    if(log.isDebugEnabled()) {
      log.debug("generateUUID - uuid: " + uuid);
    }

    return uuid;
  }

  public static String formatUUID(String hexDigits) {
    StringBuilder uuid = (new StringBuilder(hexDigits.substring(0, 8))).append('-');
    uuid.append(hexDigits.substring(8, 12)).append('-');
    uuid.append(hexDigits.substring(12, 16)).append('-');
    uuid.append(hexDigits.substring(16, 20)).append('-').append(hexDigits.substring(20, 32));
    return uuid.toString();
  }

  private static byte[] generateHash(StringBuilder message) {
    MessageDigest messageDigest;
    try {
      messageDigest = MessageDigest.getInstance("SHA-256");
    } catch (NoSuchAlgorithmException var4) {
      throw new IllegalStateException(var4);
    }

    if(log.isDebugEnabled()) {
      log.debug("generateHash - messageDigest: " + messageDigest.getAlgorithm() + " " + messageDigest.getDigestLength() + " " + messageDigest.getProvider().toString());
    }

    try {
      messageDigest.update(message.toString().getBytes("UTF-8"), 0, message.length());
    } catch (UnsupportedEncodingException var3) {
      throw new IllegalStateException(var3);
    }

    byte[] hash = messageDigest.digest();
    return hash;
  }

  static {
    ORGANIZATION_PID = NAMESPACE + "." + "ORGANIZATION" + "." + "PID" + ".";
  }
}
