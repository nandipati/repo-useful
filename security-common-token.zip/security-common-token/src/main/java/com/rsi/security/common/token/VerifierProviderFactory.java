/*
 *
 * Copyright Houghton Mifflin Harcourt 2013
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */

package com.rsi.security.common.token;

import com.google.common.collect.Lists;
import net.oauth.jsontoken.crypto.HmacSHA256Verifier;
import net.oauth.jsontoken.crypto.Verifier;
import net.oauth.jsontoken.discovery.VerifierProvider;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Helper class to build the VerifierProviders jsontoken needs
 *
 * @author ohiceadhap
 */
public class VerifierProviderFactory {
  private static final Logger LOG = Logger.getLogger(VerifierProviderFactory.class.getName());

  /**
   * Factory method to create the VerifierProvider.
   *
   * @param algorithm Supported values are "HS256" for symmetric keys
   * @param init      verifier specific initialization information. For RSA contains the cert thumbprint.
   *                  For symmetric keys it contains the shared secret key
   * @return null on error
   */
  public static VerifierProvider getInstance(String algorithm, String init) {
    VerifierProvider provider = null;

    if ("HS256".equals(algorithm)) {
      try {
        final Verifier hmacVerifier = new HmacSHA256Verifier(init.getBytes("UTF-8"));
        provider = new VerifierProvider() {
          public List<Verifier> findVerifier(String signerId, String keyId) {
            return Lists.newArrayList(hmacVerifier);
          }
        };
      } catch (InvalidKeyException ex) {
        LOG.log(Level.SEVERE, null, ex);
      } catch (UnsupportedEncodingException ex) {
        LOG.log(Level.SEVERE, null, ex);
      }
    }

    return provider;
  }
}
