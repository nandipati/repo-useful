/*
 * 
 *  Copyright Houghton Mifflin Harcourt 2013
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */

package com.rsi.security.common.token;

import java.io.Serializable;
import java.util.Map;

/**
 * Security Principal to hold identity (sub) from a JWT and the set of claims
 *
 * @author ohiceadhap
 */
public class JWTPrincipal extends RSIPrincipalImpl implements RSIPrincipal, Serializable {

  /**
   * Unique Id for Serialization.
   */
  private static final long serialVersionUID = -916263022416296219L;

  public JWTPrincipal(final String name) {
    this(name, null);
  }

  public JWTPrincipal(final String name, final Map<String, Object> claims) {
    super(name, claims);
  }

  @Override
  public String toString() {
    return this.getName();
  }

  @Override
  public int hashCode() {
    return this.getName().hashCode();
  }

  @Override
  public boolean equals(final Object o) {
    if (o == null || !this.getClass().equals(o.getClass())) {
      return false;
    }

    final JWTPrincipal p = (JWTPrincipal) o;

    return this.getName().equals(p.getName());
  }
}
