package com.rsi.security.common.token.auth;

/**
 * Created by nandipatim on 1/16/19.
 */
public interface ApiClientAuthorization {

  String getClientId();

  boolean isValid(String var1);

  String getAuthCurrentDateTime();
}
