package com.rsi.security.common.token.utils;

import java.util.Arrays;

/**
 * Created by nandipatim on 4/12/19.
 */
public enum TokenType {

  MAC("SIF_HMACSHA256"),
  BEARER("Bearer");

    private String tokenType;

    private TokenType(String grantType) {
      this.tokenType = grantType;
    }

    public String toString() {
      return this.tokenType;
    }

  }
