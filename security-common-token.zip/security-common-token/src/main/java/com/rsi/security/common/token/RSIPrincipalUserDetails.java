package com.rsi.security.common.token;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

public class RSIPrincipalUserDetails extends RSIPrincipalImpl implements
        UserDetails {

  public RSIPrincipalUserDetails(String name) {
    super(name);
  }

  public RSIPrincipalUserDetails(RSIPrincipal principal) {
    super(principal.getName());
    Set<String> claimNames = principal.getClaims().keySet();
    for (String claimName : claimNames) {
      this.addClaim(claimName, principal.getClaim(claimName));
    }
    Set<String> extensionClaimNames = principal.getExtensionClaims().keySet();
    for (String extensionClaimName : extensionClaimNames) {
      this.addExtensionClaim(extensionClaimName, principal.getExtensionClaims().get(extensionClaimName));
    }
    this.setUserName(principal.getUserName());
    this.setCountryCode(principal.getCountryCode());
    this.setDistrictId(principal.getDistrictId());
    this.setExpiresAt(principal.getExpiresAt());
    this.setFullName(principal.getFullName());
    this.setGuid(principal.getGuid());
    this.setIssuedAt(principal.getIssuedAt());
    this.setParentOrgs(principal.getParentOrgs());
    this.setCountryCode(principal.getCountryCode());
    this.setSchoolId(principal.getSchoolId());
    this.setStateCode(principal.getStateCode());
    this.setRoles(principal.getRoles());
  }

  /**
   *
   */
  private static final long serialVersionUID = -2216326364599629113L;

  public Collection<? extends GrantedAuthority> getAuthorities() {
    String[] strRoles = this.getRoles();
    List<String> roles = Arrays.asList(strRoles);
    List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
    for (String role : roles) {
      GrantedAuthority authority = new SimpleGrantedAuthority(role);
      authorities.add(authority);
    }
    return authorities;
  }

  public String getPassword() {
    return null;
  }

  public String getUsername() {
    return this.getUserName();
  }

  public boolean isAccountNonExpired() {
    return true;
  }

  public boolean isAccountNonLocked() {
    return true;
  }

  public boolean isCredentialsNonExpired() {
    return true;
  }

  public boolean isEnabled() {
    return true;
  }

}
