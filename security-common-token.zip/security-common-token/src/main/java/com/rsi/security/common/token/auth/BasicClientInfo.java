package com.rsi.security.common.token.auth;

import java.util.Set;

/**
 * Created by nandipatim on 1/16/19.
 */
public class BasicClientInfo implements ClientInfo {

  private String clientId;
  private String clientSecret;
  private Set<String> scope;
  private Set<String> registeredRedirectUri;
  private Integer accessTokenValiditySeconds;
  private Integer refreshTokenValiditySeconds;

  public BasicClientInfo() {
  }

  public BasicClientInfo(String clientId) {
    this.clientId = clientId;
  }

  public String getClientId() {
    return this.clientId;
  }

  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  public String getClientSecret() {
    return this.clientSecret;
  }

  public void setClientSecret(String clientSecret) {
    this.clientSecret = clientSecret;
  }

  public Set<String> getScope() {
    return this.scope;
  }

  public void setScope(Set<String> scope) {
    this.scope = scope;
  }

  public Set<String> getRegisteredRedirectUri() {
    return this.registeredRedirectUri;
  }

  public void setRegisteredRedirectUri(Set<String> registeredRedirectUri) {
    this.registeredRedirectUri = registeredRedirectUri;
  }

  public Integer getAccessTokenValiditySeconds() {
    return this.accessTokenValiditySeconds;
  }

  public void setAccessTokenValiditySeconds(Integer accessTokenValiditySeconds) {
    this.accessTokenValiditySeconds = accessTokenValiditySeconds;
  }

  public Integer getRefreshTokenValiditySeconds() {
    return this.refreshTokenValiditySeconds;
  }

  public void setRefreshTokenValiditySeconds(Integer refreshTokenValiditySeconds) {
    this.refreshTokenValiditySeconds = refreshTokenValiditySeconds;
  }

  public int hashCode() {
    boolean prime = true;
    byte result = 1;
    int result1 = 31 * result + (this.clientId == null?0:this.clientId.hashCode());
    return result1;
  }

  public boolean equals(Object obj) {
    if(this == obj) {
      return true;
    } else if(obj == null) {
      return false;
    } else if(this.getClass() != obj.getClass()) {
      return false;
    } else {
      BasicClientInfo other = (BasicClientInfo)obj;
      if(this.clientId == null) {
        if(other.clientId != null) {
          return false;
        }
      } else if(!this.clientId.equals(other.clientId)) {
        return false;
      }

      return true;
    }
  }

  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("BasicClientInfo [clientId=");
    builder.append(this.clientId);
    builder.append(", clientSecret=");
    builder.append(this.clientSecret);
    builder.append(", scope=");
    builder.append(this.scope);
    builder.append(", registeredRedirectUri=");
    builder.append(this.registeredRedirectUri);
    builder.append(", accessTokenValiditySeconds=");
    builder.append(this.accessTokenValiditySeconds);
    builder.append(", refreshTokenValiditySeconds=");
    builder.append(this.refreshTokenValiditySeconds);
    builder.append("]");
    return builder.toString();
  }

}
