/*
 * 
 *  Copyright Houghton Mifflin Harcourt 2013
 * This is unpublished proprietary source code of
 * Houghton Mifflin Harcourt
 * The copyright notice above does not evidence any
 * actual or intended publication of such source code.
 */
package com.rsi.security.common.token;

import java.security.Principal;
import java.util.Map;

/**
 * Security Principal to hold identity and the standard set of claims
 * for Riverside Insights platforms.
 *
 * @author ohiceadhap
 */
public interface RSIPrincipal extends Principal {
  /**
   * Returns an immutable map of the claims from the JWT.
   */
  Map<String, Object> getClaims();

  /* Returns the claim with the specified key.
   * @param key the claim to return
   * @ return
   */
  Object getClaim(String key);

  boolean containsClaim(String key);

  void addClaim(String key, Object value);

  String getName();

  /**
   * @return the userName
   */
  String getUserName();

  /**
   * @param userName the userName to set
   */
  void setUserName(String userName);

  /**
   * @return the guid
   */
  String getGuid();

  /**
   * @param guid the guid to set
   */
  void setGuid(String guid);

  /**
   * @return the fullName
   */
  String getFullName();

  /**
   * @param fullName the fullName to set
   */
  void setFullName(String fullName);

  /**
   * @return the schoolId
   */
  String getSchoolId();

  /**
   * @param schoolId the schoolId to set
   */
  void setSchoolId(String schoolId);

  /**
   * @return the districtId
   */
  String getDistrictId();

  /**
   * @param districtId the districtId to set
   */
  void setDistrictId(String districtId);

  /**
   * @return the parentOrgs
   */
  String[] getParentOrgs();

  /**
   * @param parentOrgs the parentOrgs to set
   */
  void setParentOrgs(String[] parentOrgs);

  /**
   * @return the stateCode
   */
  String getStateCode();

  /**
   * @param stateCode the stateCode to set
   */
  void setStateCode(String stateCode);

  /**
   * @return the countryCode
   */
  String getCountryCode();

  /**
   * @param countryCode the countryCode to set
   */
  void setCountryCode(String countryCode);

  /**
   * @return the roles
   */
  String[] getRoles();

  /**
   * Check if the user has the specified role
   *
   * @param role to check for
   * @return true if the user has the role
   */
  boolean isUserInRole(String role);

  /**
   * @param roles the roles to set
   */
  void setRoles(final String[] roles);

  /**
   * @return the issuedAt
   */
  long getIssuedAt();

  /**
   * @param issuedAt the issuedAt to set
   */
  void setIssuedAt(long issuedAt);

  /**
   * @return the expiresAt
   */
  long getExpiresAt();

  /**
   * @param expiresAt the expiresAt to set
   */
  void setExpiresAt(long expiresAt);

  void addExtensionClaim(final String key, final Object value);

  void removeExtensionClaim(final String key);

  Map<String, Object> getExtensionClaims();
}
