package com.rsi.security.common.token.auth;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by nandipatim on 1/16/19.
 */
public class InMemoryClientInfoStore implements ClientInfoStore {

  private Set<ClientInfo> clients = new HashSet();

  public InMemoryClientInfoStore() {
  }

  public ClientInfo loadClientInfoByClientId(String clientId) {
    if(clientId != null && "".equals(clientId.trim())) {
      throw new IllegalArgumentException("Argument \'clientId\' cannot be blank");
    } else {
      Iterator i$ = this.clients.iterator();

      ClientInfo clientInfo;
      do {
        if(!i$.hasNext()) {
          throw new IllegalArgumentException("Client Info not found");
        }

        clientInfo = (ClientInfo)i$.next();
      } while(!clientId.equals(clientInfo.getClientId()));

      return clientInfo;
    }
  }

  public Set<ClientInfo> getClients() {
    return this.clients;
  }

  public void setClients(Set<ClientInfo> clients) {
    Iterator i$ = clients.iterator();

    ClientInfo clientInfo;
    do {
      if(!i$.hasNext()) {
        this.clients = clients;
        return;
      }

      clientInfo = (ClientInfo)i$.next();
    } while(clientInfo.getClientId() != null && !"".equals(clientInfo.getClientId().trim()));

    throw new IllegalArgumentException("Parameter \'clientId\' cannot be blank");
  }
}
