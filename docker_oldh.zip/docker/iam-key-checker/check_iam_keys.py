#!/usr/bin/env python2.7
"""Retrieves the IAM keys, checks which ones are over a specific age, and sends an event to datadog.

positional arguments:
  days             The number of days required to flag the key as old.
  region           The aws region.
  iam_account      The account used to access iam keys in vault.
  datadog_account  The account used to access the datadog keys in vault.

optional arguments:
  -h, --help       show this help message and exit
"""

import argparse
import os

import datadog
import hvac

from aws_helper import AwsHelper


def check_iam_keys(argv):
    vault = hvac.Client(url=os.environ['VAULT_ADDR'], token=os.environ['VAULT_TOKEN'], verify=False)
    secret = vault.read(argv.iam_account)
    aws = AwsHelper(argv.region, secret['data']['access_key'], secret['data']['secret_key'])
    old_keys = aws.get_access_keys(argv.days)

    if len(old_keys) > 0:
        secret = vault.read(argv.datadog_account)
        datadog.initialize(api_key=secret['data']['api_key'], app_key=secret['data']['app_key'])
        text = '{0} active keys older than {1} days found.\n'.format(len(old_keys), argv.days)
        for key in old_keys:
            text += '\n{0} --- {1}'.format(key['AccessKeyId'], key['UserName'])
        params = {'title': 'iam-key-checker', 'text': text, 'alert_type': 'warning'}
        datadog.api.Event.create(**params)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Retrieves the IAM keys, checks which ones are over a specific age, and sends an event to datadog.')
    parser.add_argument('days', metavar='days', type=int, help='The number of days required to flag the key as old.')
    parser.add_argument('region', metavar='region', help='The aws region.')
    parser.add_argument('iam_account', metavar='iam_account', help='The account used to access iam keys in vault.')
    parser.add_argument('datadog_account', metavar='datadog_account',
                        help='The account used to access the datadog keys in vault.')
    args = parser.parse_args()
    check_iam_keys(args)
