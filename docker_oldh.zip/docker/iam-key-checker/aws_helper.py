"""Contains the AwsHelper class."""

from datetime import datetime

import boto3
import pytz
from retrying import retry


class AwsHelper(object):
    """Wraps functionality of the boto3 library."""

    def __init__(self, region, access_key, secret_key):
        """Creates a new AwsHelper instance.

        region -- The aws region to search in.
        access_key -- The aws access key for reading users and keys.
        secret_key -- The aws secret key for reading users and keys.
        """
        self.client = boto3.client('iam', region_name=region, aws_access_key_id=access_key,
                                   aws_secret_access_key=secret_key)

    @retry(stop_max_attempt_number=5, wait_random_min=5000, wait_random_max=10000)
    def get_all_users(self):
        """Returns all the users of a given account.

        The reason for the retries and wait times is because aws creates a new user that must be propagated and the
        process requires 5-10 seconds according to the aws documentation.
        """
        paginator = self.client.get_paginator('list_users')
        return [x['UserName'] for users in paginator.paginate() for x in users['Users']]

    def get_access_keys(self, age):
        """Returns all the keys of all the users of the given aws account that are over a given age.

        age -- The number of days to compare against the keys' age.
        """
        users = self.get_all_users()
        paginator = self.client.get_paginator('list_access_keys')
        all_keys = [x for user in users for x in paginator.paginate(UserName=user)]
        key_data = [x for key in all_keys for x in key['AccessKeyMetadata']]
        return list(
            x for x in key_data if (datetime.now(pytz.UTC) - x['CreateDate']).days > age and x['Status'] == 'Active')
