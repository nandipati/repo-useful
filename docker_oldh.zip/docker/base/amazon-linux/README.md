Building Amazon Linux base images
---------------------------------

  1. Spin up a new instance running the most recent Amazon Linux version,
     and configure networking so that docker.br.hmheng.io is reachable.

  2. Run `sudo ./build-amazon-linux-image.sh`. If the command succeeds,
     a new image should have been built and pushed to Artifactory.
