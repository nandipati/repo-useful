#!/bin/sh
set -eu

MKIMAGE=/tmp/mkimage-yum.sh
IMAGE=docker.br.hmheng.io/base-amazon-linux
TAG=$(sed 's/^[^0-9]*\([0-9.]*\).*/\1/' </etc/system-release)

if [ -z "$TAG" ]; then
  echo "Failed to parse Amazon Linux version from /etc/system-release" >&2
  exit 1
fi

curl https://raw.githubusercontent.com/docker/docker/c8badcbd26535ff6763c724328debb1282fccb82/contrib/mkimage-yum.sh -o $MKIMAGE
trap 'rm -f $MKIMAGE' 0 1 2 3 9 15

sh $MKIMAGE $IMAGE

docker push $IMAGE:$TAG
