$(document).ready(function() {
     var lock = new Auth0Lock('{AUTH0_CLIENT_ID}', '{AUTH0_DOMAIN}', {
        allowedConnections: ['br-ldap-connector-01']
        , auth: {
          redirect: false
        , responseType: 'token'
        , params: {
          scope: 'openid name email'
        }
      }
   });
    lock.show();
});
