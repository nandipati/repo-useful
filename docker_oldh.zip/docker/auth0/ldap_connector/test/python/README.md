# Auth0 Python Web App Sample

This sample demonstrates how to add authentication to a Python web app using Auth0.

# Running the App
* create .env file with following entries (get values from associated auth0 client via manage.auth0.com portal):
  * `AUTH0_CLIENT_ID=`
  * `AUTH0_DOMAIN=`
  * `AUTH0_CLIENT_SECRET=`
  * `AUTH0_CALLBACK_URL=`
* run `pip install -r requirements.txt` to install the dependencies and run `python server.py`. The app will be served at [http://localhost:3000/](http://localhost:3000/).
* run `python server.py`
* browse to `http://localhost:3000`
* log in with your pubedu credentials
