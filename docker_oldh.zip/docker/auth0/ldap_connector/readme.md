# Auth0 AD/LDAP Connector
## Monitor
* br-ldap-connector-01
  * url: https://hmhco-eng.us.webtask.io/7484d51aa1644f87144ea51528a48cec?connection=br-ldap-connector-01
  * extenstion: https://manage.auth0.com/#/extensions > Auth0 AD/LDAP Connector Health Monitor
