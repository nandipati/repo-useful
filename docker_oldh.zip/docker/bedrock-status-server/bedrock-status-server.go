package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
)

func makeHealthHandler() func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "OK")
	}
}

func runTestServer(port string) {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", makeHealthHandler())
	srv := &http.Server{
		Handler: mux,
		Addr:    fmt.Sprintf(":%s", port),
	}
	log.Fatal(srv.ListenAndServe())
}

func main() {
	var (
		port = flag.String("p", "", "Server listening port")
	)
	flag.Parse()
	if *port == "" {
		fmt.Fprintf(os.Stderr, "missing required -p flag\n")
		os.Exit(2)
	}
	runTestServer(*port)
}
