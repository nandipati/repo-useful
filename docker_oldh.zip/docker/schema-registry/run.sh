#!/bin/bash

CONFIGURATION_FILE="schema-registry-dev.properties"
[ -z "${REGISTRY_PORT}" ] && REGISTRY_PORT="8081"
[ "${ENVIRONMENT}" == "prod" ] && CONFIGURATION_FILE="schema-registry-prod.properties" || ENVIRONMENT="dev"

set -eu

# JVM Perf opts are set automatically: https://github.com/confluentinc/schema-registry/blob/master/bin/schema-registry-run-class#L104
export SCHEMA_REGISTRY_HEAP_OPTS="-Xms1g -Xmx1g"
export EXTRA_ARGS="-Djava.security.auth.login.config=/etc/schema-registry/zookeeper.jaas"

# Only set the hostname on production environment. This way local testing becomes actually possible
[ "${ENVIRONMENT}" == "prod" ] && echo "host.name=$(hostname).ec2.internal" >> /etc/schema-registry/${CONFIGURATION_FILE}

echo "listeners=http://0.0.0.0:${REGISTRY_PORT}" >> /etc/schema-registry/${CONFIGURATION_FILE}

exec /usr/bin/schema-registry-start "/etc/schema-registry/${CONFIGURATION_FILE}"
