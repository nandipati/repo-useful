=# bedrock-locust-master

The bedrock-locust-master is a locust load test server (python's locustio package) that is dockerized and has a specific set of load tests defined. Initially, the one load test was designed to hit the bedrock-test-server.

Note, the master can be run alone w/o any slaves; it will do one slave's-worth of work itself.

How to get running locally:
```
make build
make run
```

Then visit: http://127.0.0.1:8089

By default, this will try to hit the bedrock-test-server, which is expected to be running as a docker container on a mac at it's default port. You can build and run bedrock-test-server per it's instructions (see this repo, docker/bedrock-test-server)

To run against some other server, for example:

```
HOST_UNDER_TEST=https://127.0.0.1:9999 make run
```

See Makefile for further hacking.


### Companion: bedrock-locust-slave

See the neighboring "slave" directory for info on how to run locust in a distributed fashion, with the master locust process is directing the actions of and aggregating the responses from slave locust process.

For more info on locust, see:
 - https://locust.io/
 - https://github.com/locustio/locust
 - https://docs.locust.io/en/latest/
