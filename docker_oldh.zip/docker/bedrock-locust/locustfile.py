import datetime
import logging
import os
from pprint import pprint as pp
import subprocess
import sys
import random
import time

import boto
from gevent.queue import Queue
from gevent.lock import Semaphore
import locust
from locust import HttpLocust, TaskSet, events, InterruptTaskSet, task

logging.basicConfig(stream=sys.stdout, level=logging.INFO)

# TODO(etotten): eliminate need for this global. Can use
# TaskSet's on_start(), but I had trouble with that for some reason
HONOR_TLS = True
if os.environ.get("IGNORE_TLS", False) in ["1", "TRUE", "true"]:
    HONOR_TLS = False


CONFIG = None


def config():
    """
    Builds config dict singleton from env vars. Where env vars are
    not set, the defaults are here.
    """
    global CONFIG
    if not CONFIG:
        CONFIG = {
            'USER_WAIT': int(os.environ.get('USER_WAIT', 1000)),
            'URL_PATH': os.environ.get('URL_PATH', '/size?bytes=11'),
        }
    return CONFIG


LOCUST_LABELS = None


def locust_labels():
    """
    Like config(), except these params are not honored anywhere except
    in the labelling of the run files at the end
    """
    global LOCUST_LABELS
    if not LOCUST_LABELS:
        LOCUST_LABELS = {}
        prefix = "LOCUST_LABEL_"
        for evar, evalue in os.environ.iteritems():
            if evar.startswith(prefix):
                param_name = evar[len(prefix):]
                LOCUST_LABELS[param_name] = evalue
    return LOCUST_LABELS


def size(l):
    global HONOR_TLS
    l.client.get("/size?bytes=10000", verify=HONOR_TLS)


def delay(l):
    global HONOR_TLS
    l.client.get("/delay?millis=50", verify=HONOR_TLS)


class Size(TaskSet):
    tasks = {size: 1}


class BaseTaskSet(TaskSet):
    """
    An abstract class intended to capture any curiosity-specific
    additions (e.g. authenticated users) beyond the typical Locust
    TaskSet features.
    """
    def on_start(self, *args, **kwargs):
        logging.critical("CONFIG OPTIONS: %s" % config())


class SizeHighCardinality(BaseTaskSet):
    @task
    def get(self):
        global HONOR_TLS
        url_fmt = "/size?bytes=10000&rand=%s"
        self.client.get(url_fmt % random.randint(1000000000, 9999999999),
                        verify=HONOR_TLS, name=url_fmt)


class UserDefinedEndpoint(BaseTaskSet):
    """
    Allow the user to specify the a URL_PATH config param that gets
    together with HOST_UT allows for the target of the load tests
    to be easily switched.
    """
    url_path = None

    @task
    def get(self):
        global HONOR_TLS
        self.client.get(self.url_path, verify=HONOR_TLS)

    def on_start(self, *args, **kwargs):
        self.url_path = config()['URL_PATH']


class WebsiteUser(HttpLocust):
    task_set = UserDefinedEndpoint
    max_wait = config()["USER_WAIT"]
    min_wait = config()["USER_WAIT"]


#########################################################################

# Below, we register events w/ locust so that we can collect per-response
# details and then generate a detailed report.

# TODO(etotten): find some more elegant way to share state
# between the handler functions below; globals are yucky.
WORKER_EVENT_QUEUE = Queue()
MASTER_EVENT_QUEUE = Queue()
QUIT_HANDLER_SEMAPHORE = Semaphore()
SLAVES = {}
HATCHED = False
USER_START_TIMES = []


# In master mode, runs on slave each time a request to the server under
# test returns a successful response
def success_handler(request_type=None, response_length=None, name=None,
                    exception=None, **kwargs):
    global WORKER_EVENT_QUEUE
    global MASTER_EVENT_QUEUE
    logging.debug("%s, %s, %s, %s, %s", request_type, response_length, name,
                  exception, kwargs)
    now = datetime.datetime.now()
    ts_end = "%s%s" % (now.strftime('%s'), now.strftime('%f')[0:3])
    ts_start = str(int(ts_end) - int(kwargs['response_time']))
    ev = ['OK', ts_start, ts_end, response_length, kwargs['response_time']]
    WORKER_EVENT_QUEUE.put(ev)


events.request_success += success_handler


# In master mode, runs on slave each time a request to the server under
# test returns a failed response
def failure_handler(request_type=None, response_length=None, name=None,
                    exception=None, **kwargs):
    global WORKER_EVENT_QUEUE
    global MASTER_EVENT_QUEUE
    logging.debug("%s, %s, %s, %s, %s", request_type, response_length, name,
                  exception, kwargs)
    now = datetime.datetime.now()
    ts_end = "%s%s" % (now.strftime('%s'), now.strftime('%f')[0:3])
    ts_start = str(int(ts_end) - int(kwargs['response_time']))
    ev = ['KO', ts_start, ts_end, response_length, kwargs['response_time']]
    WORKER_EVENT_QUEUE.put(ev)


events.request_failure += failure_handler


# Runs on slave when it's time to send a report to the master
def report_to_master_handler(client_id, data, **kwargs):
    global WORKER_EVENT_QUEUE
    global SLAVES
    logging.debug("Report to master handler for client %s, %s", client_id,
                  data)
    evs = []
    # needs to be post spawning
    while not WORKER_EVENT_QUEUE.empty() and len(evs) < 1000:
        evs.append(WORKER_EVENT_QUEUE.get())
    data['events'] = evs
    pp(kwargs)


events.report_to_master += report_to_master_handler


# Runs on master each time each slave sends in a report
def slave_report_handler(client_id, data, **kwargs):
    global MASTER_EVENT_QUEUE
    global SLAVES
    global USER_START_TIMES
    logging.debug("slave report handler for client %s: %s", client_id, data)
    # Handle requests
    for ev in data['events']:
        MASTER_EVENT_QUEUE.put(ev)
    # Handle users
    if client_id not in SLAVES:
        SLAVES[client_id] = {}
    SLAVES[client_id]['user_count'] = data['user_count']
    cur_num_users = sum([s['user_count'] for sid, s in SLAVES.iteritems()])
    num_reg_users = len(USER_START_TIMES)
    logging.warning("USERS: REPORTED:%s, RECENT%s, CLIENT_ID:%s, "
                    "CLIENT_COUNT:%s", cur_num_users, num_reg_users, client_id,
                    data['user_count'])
    if cur_num_users > num_reg_users:
        for num in range(1, cur_num_users - num_reg_users + 1):
            user_num = num_reg_users + num
            user_ts = get_user_timestamp(data)
            MASTER_EVENT_QUEUE.put(['US', user_num, "START", user_ts, user_ts])
            USER_START_TIMES.append((user_num, user_ts))
    elif cur_num_users < num_reg_users:
        for num in range(1, num_reg_users - cur_num_users + 1):
            user_end_ts = get_user_timestamp(data)
            user_num, user_start_ts = USER_START_TIMES.pop()
            MASTER_EVENT_QUEUE.put(['US', user_num, "END", user_start_ts,
                                    user_end_ts])
    # Handle checking for the end of the run
    if HATCHED and cur_num_users < 1:
        events.quitting.fire()
        logging.warn("All slaves appear to be done, so quitting...")
    pp(kwargs)


events.slave_report += slave_report_handler


def get_user_timestamp(data):
    if len(data['events']) > 0:
        return data['events'][0][2]
    else:
        # default to current time
        now = datetime.datetime.now()
        return "%s%s" % (now.strftime('%s'), now.strftime('%f')[0:3])


# Runs on master once all slaves have ramped up to their requested
# total number of users
def hatch_complete_handler(**kwargs):
    global HATCHED
    logging.debug("entering hatch_complete_handler")
    HATCHED = True


events.hatch_complete += hatch_complete_handler


# Runs on master at the end. Can get fired multiple times, so here we
# have some handling to make this function do its work just once.
def quitting_handler(**kwargs):
    global MASTER_EVENT_QUEUE
    global QUIT_HANDLER_SEMAPHORE
    if not QUIT_HANDLER_SEMAPHORE.acquire(blocking=False, timeout=10.0):
        logging.info("abandoning quitting handler; already claimed")
        return
    logging.info("quitting handler starting")
    res_base_dir = "/opt/gatling/results"
    now = datetime.datetime.now()
    ts = "%s000" % now.strftime("%s")
    run_label = build_run_label(ts)
    res_dir = os.path.join(res_base_dir, run_label)
    res_log = "simulation.log"
    os.mkdir(res_dir)
    # This sleep is here due to some race condition, presumably related
    # to using gevent. This is a bit of a hack that seems to work, but
    # probably should be a bit more specific / elegant / etc.
    time.sleep(1)
    # Write the locust percentile and general stats
    locust.stats.write_stat_csvs(
        os.path.join(res_base_dir, res_dir, "locust_stats"))
    res_fq_filename = os.path.join(res_base_dir, res_dir, res_log)
    # Build a simulation log file in the format that gatling expects so
    # that we can use gatling to generate the feature-rich highcharts report
    with open(res_fq_filename, "w") as fh:
        header = ['RUN', 'foo', "", 'bar', ts, " ", "2.0"]
        fh.write("\t".join(header) + "\n")
        while not MASTER_EVENT_QUEUE.empty():
            ev = MASTER_EVENT_QUEUE.get()
            if ev[0] == 'OK' or ev[0] == 'KO':
                rec = ["REQUEST", "Resp", str(ev[4]), "",
                       "baz", ev[1], ev[2], ev[0], " "]
            elif ev[0] == 'US':
                rec = ["USER", "Resp", str(ev[1]), ev[2], ev[3], ev[4]]
            fh.write("\t".join(rec) + "\n")
    logging.info("Wrote log file to disk: %s", res_log)
    # Save artifacts to S3
    if "REPORT_S3_BUCKET" in os.environ and "REPORT_S3_PREFIX" in os.environ:
        prefix = "%s/%s" % (os.environ["REPORT_S3_PREFIX"],
                            now.strftime("%Y/%m/%d"))
        write_file_to_s3(os.environ["REPORT_S3_BUCKET"],
                         prefix,
                         res_dir,
                         res_log)
        # Generate the nice gatling report
        run('. /opt/gatling_env.sh && $GATLING_HOME/bin/gatling.sh -ro %s' % (
            res_dir), cwd="/opt/gatling")
        run('cd %s/..; tar -cvzf %s.tgz %s' % (res_dir, run_label, run_label))
        tgz_file = run_label + ".tgz"
        write_file_to_s3(os.environ["REPORT_S3_BUCKET"],
                         prefix,
                         res_base_dir,
                         tgz_file)


events.quitting += quitting_handler


def build_run_label(ts):
    ret = "run-%s--wait-%s" % (ts, config()['USER_WAIT'])
    for param, value in locust_labels().iteritems():
        ret += "--%s-%s" % (param, value)
    return ret


def write_file_to_s3(bucket, prefix, loc_dir, loc_filename):
    s3_connection = boto.connect_s3(os.environ['AWS_ACCESS_KEY_ID'],
                                    os.environ['AWS_SECRET_ACCESS_KEY'])
    bucket = s3_connection.get_bucket(bucket)
    s3_path = "%s/%s" % (prefix, loc_filename)
    key = boto.s3.key.Key(bucket, s3_path)
    logging.info("Attempting to write file to s3: %s:%s", bucket, s3_path)
    key.set_contents_from_filename(os.path.join(loc_dir, loc_filename))
    logging.info("Wrote file to s3: %s:%s", bucket, s3_path)


def run(cmd, **kwargs):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, **kwargs)
    stdout, stderr = proc.communicate()
    if proc.returncode:
        logging.error("FAIL: cmd[%s] had retcode[%s], stdout[%s], stderr:[%s]",
                      cmd, proc.returncode, stdout, stderr)
        raise InterruptTaskSet(reschedule=False)
    logging.info("OK: cmd[%s] had stdout[%s] stderr[%s]", cmd, stdout, stderr)
