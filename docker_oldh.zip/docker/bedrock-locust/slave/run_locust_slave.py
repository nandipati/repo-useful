"""
run_locust_slave.py: enables a locust slave process find its master process
by looking it up in Zookeeper. It takes a locust slave command (without
the master related params), looks up the master, adds the params to the
command, then executes the command.
"""
import json
import logging
import os
import subprocess
import sys
import time

from kazoo.client import KazooClient


def connect(hosts_str):
    zk = KazooClient(hosts=hosts_str, read_only=True)
    zk.start()
    return zk


def get_member(client, znode_path_str, max_tries=30, try_interval=2):
    attempt = 0
    while attempt < max_tries:
        members = client.get_children(znode_path_str)
        if len(members) < 1:
            print >> sys.stderr, "Waiting for locust master..."
            attempt += 1
            time.sleep(try_interval)
        else:
            print >> sys.stderr, "Found locust %s master(s)" % len(members)
            break
    if len(members) != 1:
        raise RuntimeError("Wrong num of locust masters: %s", len(members))
    member_path_str = "%s/%s" % (znode_path_str, members[0])
    member_znode = client.get(member_path_str)
    return json.loads(member_znode[0])


if __name__ == "__main__":
    logging.basicConfig(stream=sys.stderr, level=logging.INFO)
    cmd = sys.argv[1]
    znode_path = sys.argv[2]
    zclient = connect(os.environ['ZK_HOSTS'])
    member_dict = get_member(zclient, znode_path)
    srv_dict = member_dict['additionalEndpoints']['master-bind']
    cmd = "%s --master-host=%s --master-port=%s" % (
        cmd, srv_dict["host"], srv_dict["port"])
    logging.info("With added arguments, the full command is:[%s]", cmd)
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate()
    logging.info("DONE: cmd[%s] had retcode:[%s] stdout[%s] stderr[%s]",
                 cmd, proc.returncode, stdout, stderr)
