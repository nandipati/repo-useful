## bedrock-locust-slave

The bedrock-locust-slave is a locust load test server that is designed to run with the bedrock-locust-master process (see the neighboring "master" directory for more info).

There is some complexity built into this to facilitate the running of the slave process in aurora and thus is inteded to work with a local locust master or really any locust master that is not deployed in aurora. (The run_locust_slave.py will attempt to contact zookeeper.)

You can, however, run it locally while on the hmh+bedrock VPNs and have it actually talk to the brcoredev zookeepers.

How to get running locally:
```
make build
make run
```

Then run something on the bedrock-locust-master which is launched in aurora and this slave should do its bidding.

For more info on locust, see:
 - https://locust.io/
 - https://github.com/locustio/locust
 - https://docs.locust.io/en/latest/
