## Bedrock Load Testing

Herein lies two different docker-izations of Locust: one for building the master process, one for building the slave process.

This was originally created to loadtest our routing infrastructure (i.e. linkerd + haproxy + namerd), but theoretically could be used for anything, if one was to write more test files like locustfile.py

To build:
 * cd master; make
 * cd slave; make

See the master and slave Makefile's for more detailed info on how to run.

For more info on locust, see:
 - https://locust.io/
 - https://github.com/locustio/locust
 - https://docs.locust.io/en/latest/
