import hudson.model.*;
import jenkins.model.*;


Thread.start {
      sleep 10000
      println "--> setting agent port for jnlp"
      def env = System.getenv()
      int port = env['JENKINS_SLAVE_AGENT_PORT'].toInteger()
      Jenkins.instance.setSlaveAgentPort(port)
      Jenkins.instance.setNumExecutors(0)
      println "--> setting agent port for jnlp... done"

      def location = "http://jenkins."+env['MESOS_ENVIRONMENT']+"."+env['BR_ROLE_NAME']+".brnp.internal"
      jlc = JenkinsLocationConfiguration.get()
      println "--> Setting location to " + location
      jlc.setUrl(location)
      jlc.save()
}
