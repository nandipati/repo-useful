#!groovy

import jenkins.model.*
import hudson.security.*

def instance = Jenkins.getInstance()

if (!instance.isUseSecurity()) {
  println "--> creating initial local user 'admin'"
  println Jenkins.instance.isUseSecurity()

  def hudsonRealm = new HudsonPrivateSecurityRealm(false)
  hudsonRealm.createAccount('admin', 'admin')
  instance.setSecurityRealm(hudsonRealm)

  def strategy = new FullControlOnceLoggedInAuthorizationStrategy()
  strategy.setAllowAnonymousRead(false)
  instance.setAuthorizationStrategy(strategy)
  instance.save()
}
