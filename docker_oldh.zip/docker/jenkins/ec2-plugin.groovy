import hudson.model.*;
import jenkins.model.*;
import hudson.plugins.ec2.*;
import com.amazonaws.services.ec2.model.*;

if ( Jenkins.instance.pluginManager.activePlugins.find { it.shortName == "ec2" } != null ) {
  println "--> setting ec2 plugin";
  SlaveTemplate tmpl;

  def ami = 'ami-0a5c3138a62991599'
  def securityGroups = 'brnpb_jenkins_slave_1x_ec2, brnp.common, brnpb_jenkins_slave_team'
  def subnet = 'subnet-57fdec0e'

  def cc = new CloudCreator(ami, securityGroups, subnet);
  def cloudList = Jenkins.instance.clouds;
  def brCloud = cloudList.getByName("ec2-bedrock"); // Jenkins adds ec2- prefix automatically

  if (brCloud) {
    // Get the existing slave template configuration
    tmpl = cc.slaveTemplateFromSlaveTemplate(brCloud.getTemplates().findAll {it.getDisplayName().startsWith("BR-ami")}[0]);
  } else {
    tmpl = cc.createSlaveTemplate();
  }

  def cloud = cc.getAmazonEc2CloudInstance([tmpl]);

  // avoid duplicate cloud provider on the cloud list
  if ( cloudList.getByName(cloud.name) ) {
    cloudList.remove(cloudList.getByName(cloud.name));
  }
  cloudList.add(cloud);
}

class CloudCreator {
  private String ami;
  private String securityGroups;
  private String subnet;

  CloudCreator(ami, securityGroups, subnet) {
    this.ami = ami;
    this.securityGroups = securityGroups;
    this.subnet = subnet;
  }

  def getAmazonEc2CloudInstance(slaveTemplates) {
    def creds = getKeyForSlave("jenkins-slave-key");
    def ec2Cloud = new AmazonEC2Cloud(
      'bedrock', //cloudName
      false, //useInstanceProfileForCredentials
      'br-jenkins', //credentialsId, The credentials should be in place already
      'us-east-1', //region
      creds.getPrivateKey(), //privateKey
      '100', //instanceCapStr
      slaveTemplates //templates
    );
    return ec2Cloud;
  }

  def getTags() {
    return [
      new EC2Tag('Name', 'jenkins-build-slave-spot'),
      new EC2Tag('cost-center', 'CTGT6160'),
      new EC2Tag('Team', System.getenv()['BR_ROLE_NAME']), // Will be null if it's not set
      new EC2Tag('environment', 'brnpb'),
      new EC2Tag('responsible-party', 'rsarch@hmhco.com'),
      new EC2Tag('salt-role', 'jenkins.slave'), // There's no salt on slave actually, but because this tag is used in many places
      new EC2Tag('cost', 'jenkins')
    ] as List;
  }

  def getKeyForSlave(key_name) {
    return com.cloudbees.plugins.credentials.CredentialsProvider.lookupCredentials(
          com.cloudbees.plugins.credentials.Credentials.class,
          Jenkins.instance,
          null,
          null
    ).find { it.id == key_name }; // The SSH key is coming from credentials.xml
  }

  SlaveTemplate slaveTemplateFromSlaveTemplate(SlaveTemplate tmpl){
    return new SlaveTemplate(
      ami,
      '',
      null,
      securityGroups,
      '',
      tmpl.type,
      false,
      '',
      hudson.model.Node.Mode.NORMAL,
      'BR-ami',
      tmpl.initScript,
      '',
      tmpl.userData,
      tmpl.numExecutors.toString(),
      'ec2-user',
      new UnixData(null, '', '22'),
      tmpl.jvmopts,
      false,
      subnet,
      getTags(),
      '30',
      false,
      '',
      tmpl.iamInstanceProfile,
      false,
      false,
      '5000',
      false,
      '',
      false,
    );
  }

  SlaveTemplate createSlaveTemplate() {
    return new SlaveTemplate(
      ami, //ami
      '', //zone
      null, //spotConfig
      securityGroups, //securityGroups
      '', //remoteFS
      InstanceType.T2Medium, //type
      false, //ebsOptimized
      '', //labels
      hudson.model.Node.Mode.NORMAL, //mode
      'BR-ami', //description
      '', //initScript
      '', //tmpDir
      '', //userData
      '3', //numExecutors
      'ec2-user', //remoteAdmin
      new UnixData(null, '', '22'), //amiType
      '', //jvmopts
      false, //stopOnTerminate
      subnet, //subnetId
      getTags(), //tags
      '30', //idleTerminationMinutes
      false, //usePrivateDnsName
      '100', //InstanceCapStr
      '', //iamInstanceProfile
      false, //useEphemeralDevices
      false, //useDedicatedTenancy
      '5000', //launcTimeoutStr
      false, //associatePublicIp
      '', //customDeviceMapping
      false, //connectBySSHProcess
    );
  }
}
