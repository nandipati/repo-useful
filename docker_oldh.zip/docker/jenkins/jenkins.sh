#! /bin/bash -e

[ ! -d ${JENKINS_HOME} ] && mkdir ${JENKINS_HOME}

if [ ! -f "${JENKINS_HOME}/secrets/slave-to-master-security-kill-switch" ]; then
    mkdir -p "${JENKINS_HOME}/secrets"
    cp /usr/share/ref/slave-to-master-security-kill-switch "${JENKINS_HOME}/secrets/slave-to-master-security-kill-switch"
    cp /usr/share/ref/bootstrap-credentials.xml "${JENKINS_HOME}/credentials.xml"
    aws --region us-east-1 s3 cp s3://bedrock_jenkins_keys/master.key "${JENKINS_HOME}/secrets/master.key"
    aws --region us-east-1 s3 cp s3://bedrock_jenkins_keys/hudson.util.Secret "${JENKINS_HOME}/secrets/hudson.util.Secret"
    chown ${BR_ROLE_NAME}:${BR_ROLE_NAME} -R ${JENKINS_HOME}
fi

if [ -d "${JENKINS_HOME}/init.groovy.d/" ]; then
    echo "Moving initialization scripts in place."
    cp /usr/share/jenkins/ref/init.groovy.d/*.groovy "${JENKINS_HOME}"/init.groovy.d/
fi

: "${JENKINS_HOME:="/var/jenkins_home"}"
touch "${COPY_REFERENCE_FILE_LOG}" || { echo "Can not write to ${COPY_REFERENCE_FILE_LOG}. Wrong volume permissions?"; exit 1; }
echo "--- Copying files at $(date)" >> "$COPY_REFERENCE_FILE_LOG"
find /usr/share/jenkins/ref/ -type f -exec bash -c '. /usr/local/bin/jenkins-support; for arg; do copy_reference_file "$arg"; done' _ {} +

# if `docker run` first argument start with `--` the user is passing jenkins launcher arguments
if [[ $# -lt 1 ]] || [[ "$1" == "--"* ]]; then

  # read JAVA_OPTS and JENKINS_OPTS into arrays to avoid need for eval (and associated vulnerabilities)
  java_opts_array=("-Djenkins.install.runSetupWizard=false")
  while IFS= read -r -d '' item; do
    java_opts_array+=( "$item" )
  done < <([[ $JAVA_OPTS ]] && xargs printf '%s\0' <<<"$JAVA_OPTS")

  jenkins_opts_array=( )
  while IFS= read -r -d '' item; do
    jenkins_opts_array+=( "$item" )
  done < <([[ $JENKINS_OPTS ]] && xargs printf '%s\0' <<<"$JENKINS_OPTS")

  exec java "${java_opts_array[@]}" -jar /usr/share/jenkins/jenkins.war "${jenkins_opts_array[@]}" "$@"
fi

# As argument is not jenkins, assume user want to run his own process, for example a `bash` shell to explore this image
exec "$@"
