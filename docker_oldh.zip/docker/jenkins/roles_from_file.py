import yaml
import sys

if len(sys.argv) != 2:
    sys.exit('Usage: roles_from_file.py /path/to/roles/init.sls')

with open(sys.argv[1], 'r') as f:
    roles = yaml.safe_load(f)
    print ' '.join(['%s,%s' % (x, roles['user']['roles'][x]['id']) for x in roles['user']['roles'].keys()])
