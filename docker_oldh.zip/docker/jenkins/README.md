# Bedrock Jenkins image
Forked from https://github.com/jenkinsci/docker
Dockerfile and startup scripts customized to run on mesos with shared EFS storage.

## Documentation

* [Usage](http://doc-server.prod.hmheng-infra.brnp.internal/src/team-jenkins.html)
* [Administration/Development](http://doc-server-infra.prod.hmheng-infra.brnp.internal/src/team-jenkins.html)
