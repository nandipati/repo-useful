#!/bin/bash
set -eu

function get_roles_with_uids {
    local roles_file="$1"
    python /usr/share/jenkins/roles_from_file.py "${roles_file}"
}

adduser --no-create-home --disabled-password --gecos "" --uid 1008 thermos-exec-bot

for i in $(get_roles_with_uids "$1"); do
    IFS=',' read role uid <<< "${i}"
    adduser --disabled-password --gecos "" --uid "${uid}" "${role}"
done
