# Sphinx docker image

Build image using `./build.sh ITERATION]`. Iteration is meant to be filled
with Jenkins build number:

```sh
$ ./build.sh 123
```

You may also build and push the images in one go with `--push` flag:

```sh
$ ./build.sh --push 123
```

The build script will create and publish:

  - `docker.br.hmheng.io/sphinx:${SPHINX-VERSION}-${ITERATION}-${COMMIT_HASH}`
  - `docker.br.hmheng.io/sphinx:latest`

## Package versions

Versions for `sphinx`, ReadTheDocs theme and `sphinxcontrib-blockdiag` are pinned,
and the version numbers may be bumped by editing `build.sh`.
