#!/bin/sh

PUSH=false
if [ "$1" = "--push" ]; then
  PUSH=true
  shift
fi

set -eu

SPHINX_VERSION=1.5.2
RTD_THEME_VERSION=0.1.10b0
SPHINX_CONTRIB_VERSION=1.5.5
ITERATION="${1:-1}"

COMMIT_HASH="$(git rev-parse HEAD)"

IMAGE=docker.br.hmheng.io/sphinx
IMAGE_VERSION="$SPHINX_VERSION-$ITERATION-$COMMIT_HASH"

docker build -t "$IMAGE:$IMAGE_VERSION" \
       --build-arg "SPHINX_VERSION=$SPHINX_VERSION" \
       --build-arg "RTD_THEME_VERSION=$RTD_THEME_VERSION" \
       --build-arg "SPHINX_CONTRIB_VERSION=$SPHINX_CONTRIB_VERSION" \
       .
docker tag "$IMAGE:$IMAGE_VERSION" "$IMAGE:latest"

if $PUSH; then
  docker push "$IMAGE:$IMAGE_VERSION"
  docker push "$IMAGE:latest"
fi
