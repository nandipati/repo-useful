#!/bin/sh

if [ -z "$1" ]; then
  echo "Usage: $(basename $0) TERRAFORM-VERSION"
  exit 1
fi

VERSION=$1
IMAGE=docker.br.hmheng.io/terraform

docker build -t $IMAGE:$VERSION --build-arg TERRAFORM_VERSION=$VERSION .
docker tag $IMAGE:$VERSION $IMAGE:latest
docker push $IMAGE:$VERSION
docker push $IMAGE:latest
