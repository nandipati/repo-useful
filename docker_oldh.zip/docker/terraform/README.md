# Terraform docker image

Build and push the image using `./build.sh TERRAFORM-VERSION`:

```sh
$ ./build.sh 0.8.6
```

The build script will create and publish:

  - `docker.br.hmheng.io/terraform:$TERRAFORM-VERSION`
  - `docker.br.hmheng.io/terraform:latest`
