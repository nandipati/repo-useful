#!/bin/sh

KAFKA_TOPIC_UI_PORT="${KAFKA_TOPIC_UI_PORT:-8000}"
MAX_BYTES="${MAX_BYTES:-50000}"
RECORD_POLL_TIMEOUT="${RECORD_POLL_TIMEOUT:-5000}"
DEBUG_LOGS_ENABLED="${DEBUG_LOGS_ENABLED:-true}"

cat <<EOF >/kafka-topics-ui/env.js
var clusters = [
   {
     NAME:"Bedrock kafka",
     KAFKA_REST: "${KAFKA_REST_PROXY_URL}",
     MAX_BYTES: "${MAX_BYTES}",
     RECORD_POLL_TIMEOUT: "${RECORD_POLL_TIMEOUT}",
     DEBUG_LOGS_ENABLED: ${DEBUG_LOGS_ENABLED}
   }
]
EOF

# Run the actual software in the background with node
forever /usr/bin/http-server -p ${KAFKA_TOPIC_UI_PORT} /kafka-topics-ui
