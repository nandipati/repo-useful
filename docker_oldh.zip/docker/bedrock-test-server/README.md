## bedrock-test-server

The bedrock-test-server is a little golang app intended for use in load testing or similar situations. It is an http service that allows the client to make requests that speicify the size of the response or the time before getting a response.

How to get running locally:
```
make
make build-docker
make run-docker
```

Example of usage:
```
curl -vvv http://127.0.0.1:8021/size?bytes=100
curl -vvv http://127.0.0.1:8021/delay?millis=1500
curl -vvv http://127.0.0.1:8021/status?code=404
```
