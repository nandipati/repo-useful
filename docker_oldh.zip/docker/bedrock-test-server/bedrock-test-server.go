package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

func makeDelayHandler() func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		millis, ok := r.URL.Query()["millis"]
		if !ok {
			millis = []string{"0"}
		}
		i, _ := strconv.Atoi(millis[0])
		time.Sleep(time.Duration(i) * time.Millisecond)
		fmt.Fprintf(w, "slept:%v", millis)
	}
}

func makeResponseSizeHandler() func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		bytes, ok := r.URL.Query()["bytes"]
		if !ok {
			bytes = []string{"0"}
		}
		i, _ := strconv.Atoi(bytes[0])
		ret := strings.Repeat("#", i)
		fmt.Fprintf(w, ret)
	}
}

func makeStatusHandler() func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		codeParam, ok := r.URL.Query()["code"]
		if !ok {
			codeParam = []string{"200"}
		}
		code, err := strconv.Atoi(codeParam[0])
		if err != nil || code < 100 {
			code = 200
		}
		w.WriteHeader(code)
	}
}

func runTestServer(port string) {
	mux := http.NewServeMux()
	mux.HandleFunc("/delay", makeDelayHandler())
	mux.HandleFunc("/size", makeResponseSizeHandler())
	mux.HandleFunc("/status", makeStatusHandler())
	srv := &http.Server{
		Handler: mux,
		Addr:    fmt.Sprintf(":%s", port),
	}
	log.Fatal(srv.ListenAndServe())
}

func main() {
	var (
		port = flag.String("p", "", "Server listening port")
	)
	flag.Parse()
	if *port == "" {
		fmt.Fprintf(os.Stderr, "missing required -p flag\n")
		os.Exit(2)
	}
	runTestServer(*port)
}
