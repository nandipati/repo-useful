#!/bin/bash

[ -z "${KAFKA_REST_PORT}" ] && KAFKA_REST_PORT="8082"
[ "${ENVIRONMENT}" == "prod" ] || ENVIRONMENT="dev"
set -eu

echo id=kafka-rest-${RANDOM} >> /etc/kafka-rest/kafka-rest.properties
echo listeners=http://0.0.0.0:${KAFKA_REST_PORT} >> /etc/kafka-rest/kafka-rest.properties

# NOTE! There's a bug in kafka-rest that doesn't return the port in response
# so we can just return the LB address for the possible clients.
# This also means that we cannot deploy more than 1 kafka-rest instances until the bug is fixed.
[ "${ENVIRONMENT}" == "prod" ] && echo "host.name=kafka-rest.prod.hmheng-infra.brnp.internal" >> /etc/kafka-rest/kafka-rest.properties

export KAFKAREST_HEAP_OPTS="-Xmx1g"
export KAFKAREST_JVM_PERFORMANCE_OPTS="-XX:MetaspaceSize=96m -XX:+UseG1GC -XX:MaxGCPauseMillis=20 \
                                       -XX:InitiatingHeapOccupancyPercent=35 -XX:G1HeapRegionSize=16M \
                                       -XX:MinMetaspaceFreeRatio=50 -XX:MaxMetaspaceFreeRatio=80 \
                                       -server"

exec /usr/bin/kafka-rest-start /etc/kafka-rest/kafka-rest.properties
