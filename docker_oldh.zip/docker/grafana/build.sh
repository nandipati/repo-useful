#!/bin/bash

PUSH=false
if [ "$1" = --push ]; then
    PUSH=true
    shift
fi

if [ -z "$1" ]; then
    echo "Usage: $(basename $0) GRAFANA-VERSION [ITERATION]"
    exit 1
fi

set -eu

VERSION=$1
ITERATION=${2:-1}
FULL_VERSION=$VERSION-$ITERATION
IMAGE=docker.br.hmheng.io/hmheng-infra/grafana

docker build -t $IMAGE:$FULL_VERSION --build-arg GRAFANA_VERSION=$VERSION .
docker tag $IMAGE:$FULL_VERSION $IMAGE:latest

if $PUSH; then
  docker push $IMAGE:$FULL_VERSION
  docker push $IMAGE:latest
fi
