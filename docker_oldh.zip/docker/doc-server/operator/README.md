# Bedrock documentation server

Serves static website baked into the docker image using nginx.

## Building

```
$ ./build.sh --push
```

The build will create and push:

 - `docker.br.hmheng.io/hmheng-infra/doc-server:COMMIT-HASH`
 - `docker.br.hmheng.io/hmheng-infra/doc-server:latest`
