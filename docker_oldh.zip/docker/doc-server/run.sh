#!/bin/sh

set -eu

if [ -z "$1" ]; then
  echo "Usage: $(basename $0) HTTP-PORT" >&2
  exit 1
fi

HTTP_PORT="$1"

cat >/tmp/nginx.conf <<EOF
user www-data;
daemon off;

error_log /dev/sterr info;

events {
}

http {
  include /etc/nginx/mime.types;

  server {
     listen $HTTP_PORT;
     # Redirect old user documentation
     rewrite ^/src/guide/(.*) http://doc-server.prod.hmheng-infra.brnp.internal/src/\$1 permanent;
     # Redirect old infra documentation
     rewrite ^/src/infra/(.*) http://doc-server-infra.prod.hmheng-infra.brnp.internal/src/\$1 permanent;
     root /var/www/docs;
     access_log /dev/stdout;
  }
}
EOF

nginx -c /tmp/nginx.conf
