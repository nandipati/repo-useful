"""Test all the things!"""
import os
import unittest

import nose
import requests

token = "SIF_HMACSHA256 ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SmxlSEFpT2lJeE5UTTFOVFU0TWpFMklpd2lhV0YwS\WpvaU1UVXdOREF5TWpFMU5pSXNJbWx6Y3lJNklrRWdVMkZ0Y0d4bElFbHpjM1ZsY2lJc0luTjFZaUk2SW1OdVBVcGhibVVnUkc5bExIVnBaRDFxWkc5bExIVnVhWEYxWlVsa1pXNTBhV1pwWlhJOVFrUkdNakkyT1RSQ01EWTVOak5ETkVVd05EUTVRemhGT1Rrd1FrUTRRamdzYnowd05UTTBOakl4TXl4a1l6MHdNREl4Tnpjd09DeHpkRDFuWVN4alBYVnpJaXdpWVhWa0lqb2lRU0JUWVcxd2JHVWdRWFZrYVdWdVkyVWlmUS42aFBDS3U2cUFGR3RtaGdNdjlxQjJGSXpCVWJDbEtHR2tEbWNuQzJtU1o4"  # NOQA

try:
    env = str(os.environ['env'])
except KeyError:
    print 'environment "env" is not set, must be set to dev or prod'
    env = None
    exit(1)
if (env != "dev") & (env != "prod"):
    print 'environment "env" must be set to "dev" or "prod"'
    exit(1)

if env == "prod":
    fall_though_routes_and_codes = [
        ('https://doc-server.prod.hmheng-infra.br.internal/', 200),
        ('https://dmps.prod.hmheng-dmps.br.internal/health', 401),
        ('https://dmps.staging1.hmheng-dmps.br.internal/health', 401),
        ('https://dmps.staging0.hmheng-dmps.br.internal/health', 401),
        ('https://dmps.devel.hmheng-dmps.br.internal/health', 401)]

    fall_though_routes_and_codes_with_token = [
        ('https://doc-server.prod.hmheng-infra.br.internal/', 200),
        ('https://dmps.prod.hmheng-dmps.br.internal/health', 200),
        ('https://dmps.staging1.hmheng-dmps.br.internal/health', 200),
        ('https://dmps.staging0.hmheng-dmps.br.internal/health', 200),
        ('https://dmps.devel.hmheng-dmps.br.internal/health', 200)]

    internal_api_routes_and_codes = [
        ('https://api.br.internal/doc-server/', 200),
        ('https://api.br.internal/dmps/health', 401),
        ('https://api.cert.br.internal/dmps/health', 401),
        ('https://api.int.br.internal/dmps/health', 401),
        ('https://api.dev.br.internal/dmps/health', 401),
        ('https://api.cert.br.internal/bedrock-test-server/size', 200),
        ('https://api.dev.br.internal/bedrock-test-server/size', 200),
        ('https://api.int.br.internal/bedrock-test-server/size', 200)]

    external_api_routes_and_codes = [
        ('https://api.eng.hmhco.com/dmps/health', 401),
        ('https://api.cert.eng.hmhco.com/dmps/health', 401),
        ('https://api.dev.eng.hmhco.com/bedrock-test-server/size', 200)]

    external_api_routes_and_codes_with_token = [
        ('https://api.cert.eng.hmhco.com/dmps/health', 200),
        ('https://api.eng.hmhco.com/dmps/health', 200)]

    internal_external_options = [
        ('https://api.eng.hmhco.com/dmps/health', 204),
        ('https://api.cert.eng.hmhco.com/dmps/health', 204)]

    certPath = '/opt/routing-test/root.pem'
else:
    fall_though_routes_and_codes = [
        ('https://bedrock-test-server-auth.devel.hmheng-infra.brdev.internal/size', 401),
        ('https://bedrock-test-server-auth.staging0.hmheng-infra.brdev.internal/size', 401),
        ('https://bedrock-test-server-auth.staging1.hmheng-infra.brdev.internal/size', 401),
        ('https://bedrock-test-server-auth.prod.hmheng-infra.brdev.internal/size', 401),
        ('https://bedrock-test-server.devel.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.staging0.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.staging1.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.prod.hmheng-infra.brdev.internal/size', 200)]

    fall_though_routes_and_codes_with_token = [
        ('https://bedrock-test-server-auth.devel.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server-auth.staging0.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server-auth.staging1.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server-auth.prod.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.devel.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.staging0.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.staging1.hmheng-infra.brdev.internal/size', 200),
        ('https://bedrock-test-server.prod.hmheng-infra.brdev.internal/size', 200)]

    internal_api_routes_and_codes = [
        ('https://api.cert.brdev.internal/bedrock-test-server/size', 200),
        ('https://api.int.brdev.internal/bedrock-test-server/size', 200),
        ('https://api.dev.brdev.internal/bedrock-test-server/size', 200),
        ('https://api.brdev.internal/bedrock-test-server/size', 200),
        ('https://api.cert.brdev.internal/bedrock-test-server-auth/size', 401),
        ('https://api.dev.brdev.internal/bedrock-test-server-auth/size', 401),
        ('https://api.int.brdev.internal/bedrock-test-server-auth/size', 401),
        ('https://api.brdev.internal/bedrock-test-server-auth/size', 401)]

    external_api_routes_and_codes = [
        ('https://api.dev.engdev.hmhco.internal/bedrock-status-server-auth/size', 401),
        ('https://api.int.engdev.hmhco.internal/bedrock-status-server-auth/size', 401),
        ('https://api.cert.engdev.hmhco.internal/bedrock-status-server-auth/size', 401),
        ('https://api.engdev.hmhco.internal/bedrock-status-server-auth/size', 401)]

    external_api_routes_and_codes_with_token = [
        ('https://api.dev.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.int.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.cert.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.engdev.hmhco.internal/bedrock-status-server-auth/health', 200)]

    internal_external_options = [
        ('https://api.dev.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.int.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.cert.engdev.hmhco.internal/bedrock-status-server-auth/health', 200),
        ('https://api.engdev.hmhco.internal/bedrock-status-server-auth/health', 200)]

    certPath = '/opt/routing-test/dev-root.pem'


def test_generator():
    for route, response_code in fall_though_routes_and_codes:
        yield internal__fall_though_no_tokens, route, response_code
    for route, response_code in internal_api_routes_and_codes:
        yield internal__api, route, response_code
    for route, response_code in external_api_routes_and_codes:
        yield external__api, route, response_code
    for route, response_code in external_api_routes_and_codes_with_token:
        yield external__api_with_token, route, response_code
    for route, response_code in fall_though_routes_and_codes_with_token:
        yield internal__fall_though_with_tokens, route, response_code
    for route, response_code in internal_external_options:
        yield options_calls, route, response_code


def internal__fall_though_no_tokens(route, response_code):
    r = requests.get(route, verify=certPath)
    evaluate_request(r, response_code, route)


def internal__api(route, response_code):
    r = requests.get(route, verify=certPath)
    evaluate_request(r, response_code, route)


def external__api(route, response_code):
    if env == 'dev':
        r = requests.get(route, verify=False)
    else:
        r = requests.get(route)
    evaluate_request(r, response_code, route)


def external__api_with_token(route, response_code):
    headers = {'Authorization': token}
    if env == 'dev':
        r = requests.get(route, headers=headers, verify=False)
    else:
        r = requests.get(route, headers=headers,)
    evaluate_request(r, response_code, route)


def internal__fall_though_with_tokens(route, response_code):
    headers = {'Authorization': token}
    if env == 'dev':
        r = requests.get(route, headers=headers, verify=certPath)
    else:
        r = requests.get(route, headers=headers, verify=certPath)
    evaluate_request(r, response_code, route)


def options_calls(route, response_code):
    if env == 'dev':
        r = requests.options(route, verify=False)
    else:
        r = requests.options(route)
    evaluate_request(r, response_code, route)


def evaluate_request(request, response_code, route):
    assert request.status_code == response_code, ("unexpected response code, got %s expected %s. \n Response Text: %s"
                                                  "\n requested URL: %s" % (
                                                   request.status_code, response_code, request.text, route))

