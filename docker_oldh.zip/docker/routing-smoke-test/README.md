In order for the set of test to run in brcoredev there needs to be specific jobs deployed and dtabs setup.

### Running this test

`docker run docker.br.hmheng.io/io-hmheng-infra/bedrock-smoke-test:2.0.0 bash -c 'env=prod nosetests -v --nocapture /opt/routing-test/routingTest.py'`

### The follow jobs should be deployed:
`hmheng-infra/devel/bedrock-test-server`
`hmheng-infra/staging0/bedrock-test-server`
`hmheng-infra/staging1/bedrock-test-server`
`hmheng-infra/prod/bedrock-test-server`

repo: https://github.com/hmhco/io.hmheng.platform/tree/develop/docker/bedrock-test-server

`hmheng-infra/devel/bedrock-status-server`
`hmheng-infra/prod/bedrock-status-server`

repo: https://github.com/hmhco/io.hmheng.platform/tree/develop/docker/bedrock-status-server

`hmheng-infra/devel/invigilator-bouncer`
`hmheng-infra/prod/invigilator-bouncer`

repo: https://github.com/hmhco/io.hmheng.linkerd-invigilator-bouncer

