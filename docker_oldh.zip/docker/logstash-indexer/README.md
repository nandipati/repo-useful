# docker build
`docker build -t docker.br.hmheng.io/io-hmheng-infra/logstash-indexer:2.2.4`

# aurora command
`aurora update start brnpb-us-east-1/hmheng-infra/devel/logstash-indexer logstash-indexer.aurora --bind redis_host=log.br.hmheng.io --bind es_host=brcore01-elasticsearch-master.br.hmheng.io --bind instance_count=3 --bind tag=2.2.4`
`aurora update start brnpb-us-east-1/hmheng-infra/prod/logstash-indexer logstash-indexer.aurora --bind redis_host=log.br.hmheng.io --bind es_host=brcore01-elasticsearch-master.br.hmheng.io --bind instance_count=3 --bind tag=2.2.4`
