#!/usr/bin/env python

###todo: add acl mirroring once implemented

import argparse
from kazoo import client as zkcli
from kazoo import exceptions as kazoo_exceptions
from time import sleep
import logging
import sys
import threading
from datadog import initialize
from datadog import api

# define arguments
def _args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--source', required=True, help='source znode to watch')
    parser.add_argument('-d', '--dest', required=True, help='destination znode to mirror to')
    parser.add_argument('-H', '--host', '-H', '--host', required=True, action='append', default=[], help='hostname(s) or ip address(es) of zookeeper server(s) (-H host1 -H host2)')
    parser.add_argument('-U', '--username', default=None, help='digest auth username')
    parser.add_argument('-P', '--password', default=None, help='digest auth password')
    parser.add_argument('-D', '--ddapi', default=None, help='datadog api key')
    parser.add_argument('-A', '--ddapp', default=None, help='datadog app key')
    parser.add_argument('-e', '--env', default=None, help='enviornment tag value')
    parser.add_argument('-L', '--loglevel', default='WARNING', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], help='set log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)')
    return parser.parse_args()

# configure logging
def _logconfig(args):
    logging.basicConfig(
        level=getattr(logging, args.loglevel),
        format="[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S", stream=sys.stdout)

# define client
def _zkClient(args):
    credTupleList = []
    if args.username and args.password:
        credString = ("{0}:{1}".format(args.username, args.password))
        credTuple = ('digest', credString)
        credTupleList.append(credTuple)

    zkHosts = ','.join(args.host)
    zk = zkcli.KazooClient(hosts=zkHosts, timeout=10.0, client_id=None, handler=None, default_acl=None,auth_data=credTupleList)

    return zk

def _znodeCreate(client, path, value):
    try:
        client.create(path, value, acl=None, ephemeral=False, sequence=False)
        logging.info("dest: {0} -> successfully created and mirrorred data ({1})".format(path, str(value)))
        return True
    except kazoo_exceptions.KazooException, e:
        logging.warning("dest: {0} -> FAILED to create and mirror data ({1}) -- {2}".format(path, str(value), str(e)))
        return False

def _znodeDelete(client, path):
    try:
        client.delete(path)
        logging.info("path: {0} -> successfully DELETED orphaned dest znode".format(path))
        return True
    except kazoo_exceptions.KazooException, e:
        logging.warning("path: {0} -> FAILED to DELETE orphaned dest znode -- {1}".format(path, str(e)))
        return False

def _znodeSet(client, path, value):
    try:
        client.set(path, value)
        logging.info('path: {0} -> successfully set data value: {1}'.format(path, str(value)))
        return True
    except kazoo_exceptions.KazooException, e:
        logging.warning('path: {0} -> FAILED to set data value: {1} -- {2}'.format(path, str(value), str(e)))
        return False

def _znodeGetValue(client, path):
    try:
        value = client.get(path, watch=None)[0]
        logging.debug('path: {0} -> successfully got data value: {1}'.format(path, str(value)))
        return value
    except kazoo_exceptions.KazooException, e:
        logging.warning('path: {0} -> FAILED to get data value: {1} -- {2}'.format(path, str(value), str(e)))
        return False

def _datadogInit(args):
    options = {
        'api_key': args.ddapi,
        'app_key': args.ddapp
    }
    initialize(**options)

def _datadogEvent(title, text, args):
    if args.ddapi and args.ddapp:
        datadogTags = [args.env,'zookeeper mirror']
        api.Event.create(title=title, text=text, tags=datadogTags)

def _znodeSourceDestIdentical(zk, znodeSource, znodeDest):
    # get source/dest children
    sourceChildren = sorted(zk.get_children(znodeSource))
    destChildren = sorted(zk.get_children(znodeDest))

    # log event finish source/dest children
    logging.debug("source: {0} children are {1}".format(znodeSource, sourceChildren))
    logging.debug("dest: {0} children are {1}".format(znodeDest, destChildren))

    if sourceChildren == destChildren:
        logging.info("source: {0} -> dest: {1} children are in sync {2}".format(znodeSource, znodeDest, sourceChildren))
        return True

    logging.warning("source: {0} -> dest: {1} children are NOT in sync {2} | {3}".format(znodeSource, znodeDest, sourceChildren, destChildren))
    return False

def _znodeSourceDestDataIdentical(zk, znodeSourcePath, znodeDestPath):
    # confirm source/dest data is in sync
    if zk.get(znodeSourcePath, None)[0] == zk.get(znodeDestPath, None)[0]:
        logging.info("source: {0} -> dest: {1} data is in sync".format(znodeSourcePath, znodeDestPath))
        return True

    logging.error("source: {0} -> dest: {1} data is NOT in sync".format(znodeSourcePath, znodeDestPath))
    return False

def _znodeSourceDestDataIdenticalAll(zk, znodeSource, znodeDest):
    # check if all source/dest znodes are in sync
    znodeStatusAll = []
    for sourceChild in sorted(zk.get_children(znodeSource)):
        znodeSourcePath = '/'.join([znodeSource, sourceChild])
        znodeDestPath = '/'.join([znodeDest, sourceChild])
        znodeStatusAll.append(_znodeSourceDestDataIdentical(zk, znodeSourcePath, znodeDestPath))

    if False not in znodeStatusAll:
        return True

    return False

def _znodeWatchedAdd(znodeChild, znodeSourcePath, sourceChildrenDataWatched):
    if znodeChild not in sourceChildrenDataWatched:
        sourceChildrenDataWatched.append(znodeChild)
    if znodeChild in sourceChildrenDataWatched and sourceChildrenDataWatched.count(znodeChild) == 1:
        logging.info("source: {0} -> successfully added {1} to watch list".format(znodeSourcePath, znodeChild))
        return True

    logging.warning("source: {0} -> failed to add {1} to watch list".format(znodeSourcePath, znodeChild))
    return False

def _znodeWatchedRemove(znodeChild, znodeSourcePath, sourceChildrenDataWatched):
    if znodeChild in sourceChildrenDataWatched:
        sourceChildrenDataWatched.remove(znodeChild)
    if znodeChild not in sourceChildrenDataWatched:
        logging.info("source: {0} -> successfully removed {1} from watch list".format(znodeSourcePath, znodeChild))
        return True

    logging.warning("source: {0} -> failed to remove {1} from watch list".format(znodeSourcePath, znodeChild))
    return False

def _znodeStatusCheck(zk, znodeSource, znodeDest, initRun = False):
    # final source/dest check
    if initRun != True:
        _znodeSourceDestIdentical(zk, znodeSource, znodeDest)
        _znodeSourceDestDataIdenticalAll(zk, znodeSource, znodeDest)
    threading.Timer(60, _znodeStatusCheck, [zk, znodeSource, znodeDest]).start()

# watch event functions (dispatch)
def _event_created(client, event, args, watched):
    logging.info('source: {0} -> {1} event triggered: do nothing'.format(event.path, event))
    return True

def _event_deleted(client, event, args, watched):
    logging.info('source: {0} -> {1} event triggered: remove watch & delete dest znode'.format(event.path, event))
    child = event.path.split(args.source + '/')[-1]
    source = '/'.join([args.source, child])
    dest = '/'.join([args.dest, child])
    _znodeWatchedRemove(child, source, watched)
    return _znodeDelete(client, dest)

def _event_changed(client, event, args, watched):
    logging.info('source: {0} -> {1} event triggered: update dest znode'.format(event.path, event))
    child = event.path.split(args.source + '/')[-1]
    source = '/'.join([args.source, child])
    dest = '/'.join([args.dest, child])
    data = _znodeGetValue(client, source)
    logging.info('source: {0} -> data retrieved: {1}'.format(event.path, data))
    return _znodeSet(client, dest, data)

def _event_none(client, data, args, child, watched):
    source = '/'.join([args.source, child])
    dest = '/'.join([args.dest, child])
    _znodeWatchedAdd(child, source, watched)
    if data != _znodeGetValue(client, dest):
        _znodeSet(client, dest, data)
    if data == _znodeGetValue(client, dest):
        logging.info("source: {0} -> dest: {1} data is in sync".format(source, dest))
        return True
    logging.error("source: {0} -> dest: {1} data is NOT in sync".format(source, dest))
    return False

# main function
def main():
    # get/set args
    args = _args()
    znodeSource = args.source
    znodeDest = args.dest

    # configure logging
    _logconfig(args)

    # event dispatch
    dispatch = {
        'CREATED': _event_created,
        'CHANGED': _event_changed,
        'DELETED': _event_deleted,
        'NONE'   : _event_none
    }

    # initialize datadog events if api/app keys are provided
    if args.ddapi and args.ddapp:
        _datadogInit(args)

    #define / start client connection
    zk = _zkClient(args)
    zk.start()
    logging.info('starting mirror of {0} to {1}'.format(znodeSource, znodeDest))

    # defined watched znodes to ensure only a single watch is applied (part1)
    sourceChildrenDataWatched = []

    # set source/dest check loop thread
    _znodeStatusCheck(zk, znodeSource, znodeDest, True)

    # watch znode children
    @zk.ChildrenWatch(znodeSource)
    def get_znode_children(children):

        # get source/dest children
        sourceChildren = sorted(children)
        destChildren = sorted(zk.get_children(znodeDest))

        # log event start source/dest children
        logging.debug("source: {0} children are {1}".format(znodeSource,sourceChildren))
        logging.debug("dest: {0} children are {1}".format(znodeDest, destChildren))

        # defined watched znodes to ensure only a single watch is applied
        sourceChildrenDataWatch = list(set(sourceChildren) - set(sourceChildrenDataWatched))
        logging.info("source: {0} -> existing znode watches: {1}".format(znodeSource, sorted(sourceChildrenDataWatched)))
        logging.info("source: {0} -> new znodes watches: {1}".format(znodeSource, sorted(sourceChildrenDataWatch)))

        # delete orphaned children (if out of sync)
        for destChild in destChildren:
            if len(sourceChildren) >= 1 and destChild not in sourceChildren and destChild not in sourceChildrenDataWatched:
                # delete dest znode
                _znodeDelete(zk, '/'.join([znodeDest, destChild]))

        # check if each unwatched dest znode exists (create if not)
        for sourceChild in sourceChildrenDataWatch:
            znodeSourcePath = '/'.join([znodeSource, sourceChild])
            znodeDestPath = '/'.join([znodeDest, sourceChild])
            if not zk.exists(znodeDestPath):
                znodeData = zk.get(znodeSourcePath)[0]
                _znodeCreate(zk, znodeDestPath, znodeData)

        # set data watch on source children
        for child in sorted(sourceChildrenDataWatch):
            @zk.DataWatch(znodeSource + '/' + child)
            def get_znode_data(data, stat, event):

                if event:
                    return dispatch[event.type](zk, event, args, sourceChildrenDataWatched)
                else:
                    return dispatch['NONE'](zk, data, args, child, sourceChildrenDataWatched)

    # keep connection open
    while True:
        sleep(5)

    # stop client connection
    zk.stop()

if __name__ == "__main__":
    main()
