#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

# Enable required repos
rpm --import https://repo.saltstack.com/yum/amazon/latest/x86_64/archive/2017.7.1/SALTSTACK-GPG-KEY.pub
install -m 0644 -o root -g root /tmp/saltstack-amzn.repo /etc/yum.repos.d/saltstack-amzn.repo
yum-config-manager --enable epel

# Install hmheng repo
install -m 0644 -o root -g root /tmp/hmheng_repo.repo /etc/yum.repos.d/hmheng_repo.repo

# Update packages
yum -y update

# Install required packages
yum -y install \
	salt-master \
	salt-api \
	salt-minion \
	python27-boto \
	python27-boto3 \
	python27-pip \
	python27-pygit2 \
	git \
	rpmdevtools

# Add salt services
chkconfig --add salt-master
chkconfig --add salt-minion
chkconfig --add salt-api

# Ensure salt services are not started on first boot
chkconfig salt-master off
chkconfig salt-minion off
chkconfig salt-api off

# Create folders, copy files in place, set permissions etc.
mkdir -p /etc/salt/master.d
mkdir -p /etc/salt/pki/master
crontab -u root /tmp/root-crontab
install -m 0644 -o root -g root /tmp/master.conf /etc/salt/master.d/master.conf
install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag
install -m 0755 -o root -g root /tmp/update-local-repo.sh /usr/local/bin/update-local-repo.sh
install -m 0755 -o root -g root /tmp/initialize_instance.sh /usr/local/bin/initialize_instance.sh
install -m 0644 -o root -g root /tmp/ca.pem /etc/pki/ca-trust/source/anchors/ca.pem
install -m 0755 -o root -g root /tmp/attach-eni.sh /usr/local/bin/attach-eni.sh
/usr/bin/update-ca-trust extract

# Configure instance.
cat <<'EOF' > /etc/cloud/cloud.cfg.d/11_configure_instance.cfg
runcmd:
 - [ sh, -c, "while ! /usr/local/bin/attach-eni.sh; do echo ENI configuration failed. Retrying after a while; sleep 10; done" ]
 - [bash, -x, /usr/local/bin/initialize_instance.sh]
 - chkconfig salt-master on
 - service salt-master start
 - salt-run fileserver.update
 - sleep 10
 - salt-run saltutil.sync_all
 - sleep 10
 - salt-call saltutil.sync_all
 - sleep 10
 - salt-run saltutil.sync_runners
 - sleep 10
 - timeout 10m bash -c -- "while ! salt-call --retcode-passthrough state.highstate; do sleep 10; done"
EOF
