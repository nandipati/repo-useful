#!/bin/bash
set -eu

export GIT_SSH_COMMAND="ssh -i /root/.ssh/id_hmhdev -o StrictHostKeyChecking=no"
PATH="${PATH}:/usr/local/bin"

function get_keys {
    aws s3 cp s3://platform-terraform-assets/keys/id_deploy_key /root/.ssh/id_hmhdev
    aws s3 cp s3://platform-terraform-assets/keys/id_deploy_key.pub /root/.ssh/id_hmhdev.pub
    chmod 600 /root/.ssh/id_hmhdev*
}

function add_efs_to_fstab {
    echo "efs-salt-master.$(ec2-tag environment).internal:/  /etc/salt/pki/master nfs4 nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 0 0" >> /etc/fstab
}

function mount_efs {
    until mount -a -t nfs4; do
        echo "Still trying to mount"
        sleep 10
    done
}

function create_bare_git_repo {
    git clone --bare git@github.com:hmhco/io.hmheng.platform.git /srv/bedrock.git
    git --git-dir /srv/bedrock.git fetch origin $(ec2-tag salt-git-ref)
}

function clone_git_repo_for_salt {
    git --git-dir /srv/bedrock.git branch --force base FETCH_HEAD
}

function init_minion_config {
    echo "master: $(ec2-tag salt-master)" >> /etc/salt/minion.d/master.conf
    echo "id: $(ec2-tag salt-role)-$(hostname)" >> /etc/salt/minion.d/minion.conf
}

get_keys
add_efs_to_fstab
mount_efs
create_bare_git_repo
clone_git_repo_for_salt
init_minion_config
