#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

# Make and mount filesystem for logs
LOG_DEV="/dev/xvdl"
LOG_DIR="/var/log"
mkfs.ext4 ${LOG_DEV}
mkdir -p ${LOG_DIR}
echo "${LOG_DEV} ${LOG_DIR} ext4 defaults 1 2" | tee -a /etc/fstab
sudo mount ${LOG_DIR}
