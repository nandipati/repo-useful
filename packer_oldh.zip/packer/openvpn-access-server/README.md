# OpenVPN Access Server AMIs

At the moment we use two different AMIs for our OpenVPN AS instances. In
brcoredev, we use 5-user version, and in prod we use 100-user version.

To build 5-user version suitable for dev:

``` sh
$ ./build.sh -t dev $ITERATION
```

To build 100-user version suitable for prod:

``` sh
$ ./build.sh -t prod $ITERATION
```
