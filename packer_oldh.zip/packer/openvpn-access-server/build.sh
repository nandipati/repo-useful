#!/bin/bash

OPENVPN_VERSION=2.1.9

die() {
    echo "$(basename "$0"): fatal: $*"
    exit 1
}

SOURCE_AMI=unknown
while getopts :t: opt; do
    case "$opt" in
        t)
            case "$OPTARG" in
                dev)
                    SOURCE_AMI=ami-6beed47d
                    TYPE=5users
                    ;;
                prod)
                    SOURCE_AMI=ami-29eed43f
                    TYPE=100users
                    ;;
                *)
                    die "Unknown AMI type: '$OPTARG'"
                    ;;
            esac
            ;;
        \?)
            die "Invalid option: -$OPTARG"
            ;;
    esac
done

shift $((OPTIND - 1))

ITERATION=$1

if [ "$SOURCE_AMI" = unknown ] || [ -z "$ITERATION" ]; then
    echo "Usage: $(basename "$0") -t TYPE ITERATION" >&2
    exit 2
fi

# VPC of the artifactory so we can install own packages
SUBNET_ID=$(aws ec2 describe-instances \
	        --filters 'Name=tag:salt-role,Values=artifactory,Name=tag:environment,Values=brcore01' \
	        --query 'Reservations[0].Instances[0].NetworkInterfaces[0].SubnetId' \
	        --output text)

[ $? -eq 0 ] || die "Failed to query subnet ID"

AMI_VERSION="$OPENVPN_VERSION-$TYPE-$ITERATION"

packer build \
       -var source_ami="${SOURCE_AMI}" \
       -var ami_version="${AMI_VERSION}" \
       -var subnet_id="${SUBNET_ID}" \
       base.json
