#!/bin/bash

set -eu

export DEBIAN_FRONTEND=noninteractive

retry() {
    local count=0
    until "$@"; do
        if [ $count -gt 10 ]; then
            break
        fi
        (( count++ ))

        echo "'$*' failed. Retrying..."
        sleep 10
    done
}

retry sudo apt-get update
retry sudo apt-get install -y linux-image-virtual
