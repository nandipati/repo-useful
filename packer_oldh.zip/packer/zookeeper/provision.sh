#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

# Install attach-eni
install -o root -g root /tmp/attach-eni /usr/local/bin/attach-eni

# Install common includes
install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag

install -m 0644 -o root -g root /tmp/ca.pem /etc/pki/ca-trust/source/anchors/ca.pem
/usr/bin/update-ca-trust extract

# Define cloud init config
cat << 'EOF' > /etc/cloud/cloud.cfg.d/10_eni_attach.cfg
bootcmd:
 - [ sh, -c, "while ! /usr/local/bin/attach-eni; do echo ENI configuration failed. Retrying after a while; sleep 10; done" ]
EOF
