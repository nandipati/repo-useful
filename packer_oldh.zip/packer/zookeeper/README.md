## Usage

* OPTIONALLY: Set up `AWS_ACCESS_KEY` and `AWS_SECRET_KEY` environment variables.
* In the project folder run `./build.sh $VERSION_NUMBER` where `$VERSION_NUMBER` is the current iteration.

### E.g
`$ AWS_ACCESS_KEY='foo' AWS_SECRET_KEY='bar' ../build.sh 123`

## Outcome
Packer will generate an AMI with preconfigured:
* [salt-minion](../salt-minion-base)
* [attach-eni](provision.sh)

## See also
[Bedrock documentation on packer](http://doc-server-infra.prod.hmheng-infra.brnp.internal/src/packer.html)
