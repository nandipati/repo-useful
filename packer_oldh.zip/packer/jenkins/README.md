# Building amazon ami with packer
Packer is a simple tool to make reproducable images.

## Installation
On osx the easiest way is to use `brew install packer`
Other methods can be found from: https://www.packer.io/downloads.html

## Usage
Building the ami is very simple. In the packer folder execute
`packer build -var 'source_ami=<ami_id>' -var aws_access_key='<access_key>' -var aws_secret_key='<secret_key>' base.json`

### What happens
Packer will spin up an ebs -backed instance, create temporary keypair and security groups to access it and run the `provision.sh`.

The source ami in use is the latest available (2016.09) amazon ami.
Subnet and vpc requirements are so that the instance needs to be able to access bedrock artifactory from the subnet it's spun up to.
