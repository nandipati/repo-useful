#!/bin/bash

cat <<EOF | sudo tee /etc/yum.repos.d/hmheng.repo
[hmheng]
name=hmheng-repo
baseurl=https://repo.br.hmheng.io/artifactory/hmheng
failovermethod=priority
enabled=1
gpgcheck=0
EOF
sudo yum -y install docker jdk1.8.0_51 builder git
sudo usermod -aG docker ec2-user

# Increase open file limits for all users
cat <<EOD | sudo tee /etc/security/limits.d/90-nofile.conf
* hard nofile 65536
* soft nofile 65536
EOD

sudo mv /tmp/docker.sysconfig /etc/sysconfig/docker
sudo install -m 0644 -o root -g root /tmp/ca.pem /etc/pki/ca-trust/source/anchors/ca.pem
sudo /usr/bin/update-ca-trust extract


sudo cp /etc/pki/ca-trust/source/anchors/ca.pem /tmp/ca.cer
sudo keytool -storepasswd -new bedrock1234321 -keystore /usr/java/jdk1.8.0_51/jre/lib/security/cacerts -storepass changeit && \
  echo "yes" | sudo keytool -import -trustcacerts -file /tmp/ca.cer -alias root-ca -keystore /usr/java/jdk1.8.0_51/jre/lib/security/cacerts -storepass bedrock1234321
sudo rm -f /tmp/ca.cer
