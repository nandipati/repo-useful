#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

# Install named
yum -y -t install bind bind-utils

# Ensure named is off but started on boot
chkconfig named on
service named stop

# Change named uid and gid
groupmod --gid 1007 named
usermod --uid 1007 --gid 1007 named
chown -R named:named /var/run/named
find /var/named -uid 25 -exec chown named {} +
find /var/named -gid 25 -exec chgrp named {} +

# Install attach-eni
install -o root -g root /tmp/attach-eni /usr/local/bin/attach-eni

# Install aws-vpc-dns
install -o root -g root /tmp/aws-vpc-dns /usr/local/bin/aws-vpc-dns

# Convert named.conf template
sed -i \
	-e 's|{{ *hmh_apogee_ip *}}|10.33.7.54|g' \
	-e 's|{{ *hmh_perigee_ip *}}|10.33.20.192|g' \
	-e 's|{{ *rpcsys_ip *}}|155.44.57.211|g' \
	-e 's|{{ *pubedu_hmhaeepdc13_ip *}}|10.198.51.37|g' \
	-e 's|{{ *pubedu_hmhaeepdc14_ip *}}|10.198.51.38|g' \
	-e 's|{{ *pubedu_evnprws04_ip *}}|155.44.108.81|g' \
	-e 's|{{ *pubedu_evnprws06_ip *}}|155.44.108.83|g' \
	/tmp/named.conf
install -o named -g named -m 0644 /tmp/named.conf /etc/named.conf

install -m 0644 -o root -g root /tmp/ca.pem /etc/pki/ca-trust/source/anchors/ca.pem
/usr/bin/update-ca-trust extract

cat << 'EOF' > /etc/cloud/cloud.cfg.d/10_named_init.cfg
bootcmd:
 - echo nameserver $(/usr/local/bin/aws-vpc-dns) > /etc/resolv.conf
 - sed -i -e "s|{{ *vpc_ip *}}|$(/usr/local/bin/aws-vpc-dns)|g" /etc/named.conf
 - chattr +i /etc/resolv.conf
 - sleep 60s
 - [ sh, -c, "while ! /usr/local/bin/attach-eni; do echo ENI configuration failed. Retrying after a while; sleep 10; done" ]
 - service named restart
EOF
