#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

rpm --import https://repo.saltstack.com/yum/amazon/latest/x86_64/archive/2017.7.1/SALTSTACK-GPG-KEY.pub
install -m 0644 -o root -g root /tmp/saltstack-amzn.repo /etc/yum.repos.d/saltstack-amzn.repo
yum-config-manager --enable epel

# Install hmheng repo
install -m 0644 -o root -g root /tmp/hmheng_repo.repo /etc/yum.repos.d/hmheng_repo.repo

# Update packages
yum -y update

yum -y install \
	salt-minion \
	python27-boto \
	python27-boto3 \
	python27-pip \
	rpmdevtools

# Add salt-minion service
chkconfig --add salt-minion

# Ensure salt-minion is not started on first boot
chkconfig salt-minion off

install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag
install -m 0755 -o root -g root /tmp/init-salt-from-tags /usr/local/bin/init-salt-from-tags
install -m 0644 -o root -g root /tmp/minion /etc/salt/minion
install -m 0755 -o root -g root -d /etc/salt/minion.d
install -m 0644 -o root -g root /tmp/returner.conf /etc/salt/minion.d/returner.conf
install -m 0644 -o root -g root /tmp/ca.pem /etc/pki/ca-trust/source/anchors/ca.pem
/usr/bin/update-ca-trust extract

# Install empty crontab for root if it does not exist
crontab -l || echo "# Hello bedrock" | crontab -

# Create salt-configuration file that will be executed during the first boot
cat <<'EOF' > /etc/cloud/cloud.cfg.d/11_configure_salt.cfg
runcmd:
 - timeout 2m bash -x /usr/local/bin/init-salt-from-tags
 - chkconfig salt-minion on
 - service salt-minion start
 - salt-call saltutil.sync_all
 - timeout 10m bash -c -- "while ! salt-call --retcode-passthrough state.highstate; do sleep 10; done" 
EOF
