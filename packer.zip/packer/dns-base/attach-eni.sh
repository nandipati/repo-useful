#!/bin/sh

set -eu

function log () {
    echo "$(date +"%b %e %T") $*"
    logger -- "$(basename $0) - $*"
}

mac=$(curl -sS http://169.254.169.254/latest/meta-data/mac)
log "MAC: $mac"

vpc_id=$(curl -sS http://169.254.169.254/latest/meta-data/network/interfaces/macs/$mac/vpc-id)
log "VPC ID: $vpc_id"

availability_zone=$(curl -sS http://169.254.169.254/latest/meta-data/placement/availability-zone/)
log "Availability zone: $availability_zone"

region=$(echo $availability_zone|sed 's/\([a-z]*-[a-z]*-[0-9]*\).*/\1/')
log "Region: $region"

instance_id=$(curl -sS http://169.254.169.254/latest/meta-data/instance-id)
log "Instance ID: $instance_id"

eni_id=$(aws ec2 describe-network-interfaces\
    --region "$region"\
    --filters Name=availability-zone,Values="$availability_zone"\
              Name=vpc-id,Values="$vpc_id"\
              Name=tag:salt-role,Values=dns.server\
    --query "NetworkInterfaces[*].NetworkInterfaceId"\
    --output text)

log "ENI ID: $eni_id"

if /usr/bin/aws ec2 attach-network-interface --region "$region" --network-interface-id "$eni_id" --instance-id "$instance_id" --device-index 1; then
    log "ENI attachment successful"
    sleep 30
    ifdown eth0
    exit 0 
else
    log "ENI attachment failed" ; exit 1 ; 
fi
