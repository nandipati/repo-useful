#!/bin/sh
ETH0_MAC=$(ip link show eth0 | tail -1 | awk '{print $2}')
curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/"$ETH0_MAC"/vpc-ipv4-cidr-block | sed -e 's/\.[0-9/]*$/.2/'
