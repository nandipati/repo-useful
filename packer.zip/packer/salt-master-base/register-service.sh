#!/bin/bash
set -eu

sleep 30

echo "Registering Salt Master with Consul ..."

IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)

# register_salt-master_host_as_service_in_consul
curl  -X PUT -d \
'{"Name": "salt-master", "Address": "'"$IP_ADDRESS"'","Port": 4505,"Checks": [{"DeregisterCriticalServiceAfter": "15s",   "TCP": "'$IP_ADDRESS':4505", "State":"passing", "Interval": "10s"}]}'  \
http://$IP_ADDRESS:8500/v1/agent/service/register

echo "Registered Salt Master with Consul ..."
