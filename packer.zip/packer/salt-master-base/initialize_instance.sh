#!/bin/bash
set -eu

export GIT_SSH_COMMAND="ssh -i /root/.ssh/id_cndnp -o StrictHostKeyChecking=no"
PATH="${PATH}:/usr/local/bin"

IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)
CONSULCONFIGDIR=/etc/consul.d
HOME_DIR=ec2-user


function get_keys {
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndnp_deploy_key /root/.ssh/id_cndnp
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndnp_deploy_key.pub /root/.ssh/id_cndnp.pub
    chmod 600 /root/.ssh/id_cndnp*
}

function add_efs_to_fstab {
    echo "$(ec2-tag salt-master-efs):/  /etc/salt/pki/master nfs4 nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 0 0" >> /etc/fstab
}

function mount_efs {
    until mount -a -t nfs4; do
        echo "Still trying to mount"
        sleep 10
    done
}

function create_bare_git_repo {
    git clone --bare git@github.com:rsinsights/io.hmheng.riverside-salt.git /srv/cnd.git
    git --git-dir /srv/cnd.git fetch origin $(ec2-tag salt-git-ref)
}

function clone_git_repo_for_salt {
    git --git-dir /srv/cnd.git branch --force base FETCH_HEAD
}

function get_salt_master_ip_value {
    aws ec2 describe-instances --region us-east-1 --instance-ids \
                      $(aws autoscaling describe-auto-scaling-instances --region us-east-1 --output text \
                      --query "AutoScalingInstances[?AutoScalingGroupName=='$(ec2-tag salt-master-autoscaling-group)'].InstanceId") \
                      --query Reservations[0].Instances[0].PrivateIpAddress --output text
}

function init_minion_config {
    sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /etc/salt/master.d/master.conf
    echo "master: $(get_salt_master_ip_value)" >> /etc/salt/minion.d/master.conf
    echo "id: $(ec2-tag salt-role)-$(hostname)" >> /etc/salt/minion.d/minion.conf
}

function install_consul {
  CONSUL_SERVICE_NAME="$(ec2-tag consul_service_name)"
  CONSUL_DNS_SEARCH="$(ec2-tag consul_domain_search)"
  CONSUL_JOIN="provider=aws tag_key=join_tag tag_value=${CONSUL_SERVICE_NAME}-server"
  sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/consul_client.json
  sed -i "s/HOME_DIR/$HOME_DIR/g" /tmp/consul_client.json
  sed -i "s/CONSUL_JOIN/$CONSUL_JOIN/g" /tmp/consul_upstart.conf
  sudo chown root:root /tmp/consul_upstart.conf
  sudo cp /tmp/consul_upstart.conf /etc/init/consul.conf
  sudo chmod 0644 /etc/init/consul.conf
  sudo chown root:root /tmp/consul_client.json
  sudo cp /tmp/consul_client.json $CONSULCONFIGDIR/consul_client.json

  echo "Consul Client service Startup ..."
  sudo initctl start consul || sudo initctl restart consul
}

install_consul
get_keys
add_efs_to_fstab
mount_efs
create_bare_git_repo
clone_git_repo_for_salt
init_minion_config
