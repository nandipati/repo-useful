#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

HOME_DIR=ec2-user
source /tmp/artifactory
ARTIFACT_PROXY=$REPO_PROXY
ARTIFACT_REPO=$REPO_URL

install -m 0644 -o root -g root /tmp/hmheng_repo.repo /etc/yum.repos.d/hmheng_repo.repo
yum-config-manager --enable epel

# Update packages
yum -y update

# Install required packages
yum -y install \
	salt-master \
	salt-api \
	salt-minion \
	python27-boto \
	python27-boto3 \
	python27-pip \
	git \
	rpmdevtools

pip-2.7 install GitPython

# Add salt services
chkconfig --add salt-master
chkconfig --add salt-minion
chkconfig --add salt-api

# Ensure salt services are not started on first boot
chkconfig salt-master off
chkconfig salt-minion off
chkconfig salt-api off

# Install Consul
CONSULVERSION=1.5.1
CONSULDOWNLOAD=${ARTIFACT_REPO}/consul/${CONSULVERSION}/consul_${CONSULVERSION}_linux_amd64.zip
CONSULCONFIGDIR=/etc/consul.d
CONSULDIR=/home/$HOME_DIR/consul

# Consul

curl -L $CONSULDOWNLOAD > consul.zip

echo "Installing Consul ..."
unzip consul.zip >/dev/null
chmod +x consul
sudo mv consul /usr/local/bin/consul

sudo chmod 0755 /usr/local/bin/consul
sudo chown root:root /usr/local/bin/consul
sudo setcap "cap_net_bind_service=+ep" /usr/local/bin/consul

## Configure
mkdir -p $CONSULCONFIGDIR
chmod 755 $CONSULCONFIGDIR
mkdir -p $CONSULDIR
chmod 755 $CONSULDIR

sudo mkdir -p $CONSULDIR/data

# Create folders, copy files in place, set permissions etc.
mkdir -p /etc/salt/master.d
mkdir -p /etc/salt/pki/master
crontab -u root /tmp/root-crontab
install -m 0644 -o root -g root /tmp/master.conf /etc/salt/master.d/master.conf
install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag
install -m 0755 -o root -g root /tmp/update-local-repo.sh /usr/local/bin/update-local-repo.sh
install -m 0755 -o root -g root /tmp/initialize_instance.sh /usr/local/bin/initialize_instance.sh
install -m 0755 -o root -g root /tmp/attach-eni.sh /usr/local/bin/attach-eni.sh
install -m 0755 -o root -g root /tmp/register-service.sh /usr/local/bin/register-service.sh
/usr/bin/update-ca-trust extract

# Configure instance.
cat <<'EOF' > /etc/cloud/cloud.cfg.d/11_configure_instance.cfg
runcmd:
 - [ sh, -c, "while ! /usr/local/bin/attach-eni.sh; do echo ENI configuration failed. Retrying after a while; sleep 10; done" ]
 - [bash, -x, /usr/local/bin/initialize_instance.sh]
 - chkconfig salt-master on
 - service salt-master start --log-level=debug
 - [bash, -x, /usr/local/bin/register-service.sh]
 - chkconfig salt-minion on
 - service salt-minion start --log-level=debug
 - salt-run saltutil.sync_all --log-level=debug
 - salt-call saltutil.sync_all --log-level=debug
 - salt-run saltutil.sync_runners --log-level=debug
 - timeout 10m bash -c -- "while ! salt-call --retcode-passthrough state.highstate; do sleep 10; done"
EOF
