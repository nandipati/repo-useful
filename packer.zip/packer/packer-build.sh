#!/bin/sh

SOURCE_AMI="ami-cfe4b2b0"
AMI_VERSION="2018.03.0"

# VPC of the artifactory so we can install own packages
SUBNET_ID=$(aws ec2 describe-instances \
	--filters 'Name=tag:salt-role,Values=artifactory,Name=tag:environment,Values=cndcorenp' \
	--query 'Reservations[0].Instances[0].NetworkInterfaces[0].SubnetId' \
	--output text)

usage() {
	echo "$0 version_number"
	exit 0
}

if [ -z "$*" ]; then
	usage
fi

VERSION="${1}"

packer build \
	-var source_ami="${SOURCE_AMI}" \
	-var ami_version="${AMI_VERSION}-${VERSION}" \
	-var subnet_id="${SUBNET_ID}" \
	$EXTRA_ARGS \
	base.json