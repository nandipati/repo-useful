#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

echo "Installing dependencies..."

# Install required packages
yum -y install \
  software-properties-common \
  wget

HOME_DIR=ec2-user

# Java

yum -y remove java
yum -y install java-1.8.0-openjdk
JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:bin/java::")

DOCKER_COMP_VERSION=1.22.0
#Light weight shpper for logs.
FILEBEAT_VERSION=6.4.1

CONFIGDIR=/home/$HOME_DIR/config

source /tmp/artifactory
ARTIFACT_PROXY=$REPO_PROXY
ARTIFACT_REPO=$REPO_URL

CONSULVERSION=1.5.1
CONSULDOWNLOAD=${ARTIFACT_REPO}/consul/${CONSULVERSION}/consul_${CONSULVERSION}_linux_amd64.zip
CONSULCONFIGDIR=/etc/consul.d
CONSULDIR=/home/$HOME_DIR/consul

NOMADVERSION=0.9.3
NOMADDOWNLOAD=${ARTIFACT_REPO}/nomad/${NOMADVERSION}/nomad_${NOMADVERSION}_linux_amd64.zip
NOMADCONFIGDIR=/etc/nomad.d
NOMADDIR=/home/$HOME_DIR/nomad

# Consul

curl -L $CONSULDOWNLOAD > consul.zip

echo "Installing Consul ..."
unzip consul.zip >/dev/null
chmod +x consul
sudo mv consul /usr/local/bin/consul

sudo chmod 0755 /usr/local/bin/consul
sudo chown root:root /usr/local/bin/consul
sudo setcap "cap_net_bind_service=+ep" /usr/local/bin/consul

## Configure
mkdir -p $CONSULCONFIGDIR
chmod 755 $CONSULCONFIGDIR
mkdir -p $CONSULDIR
chmod 755 $CONSULDIR

sudo mkdir -p $CONSULDIR/data

# Nomad

echo "Installing Nomad ..."

curl -L $NOMADDOWNLOAD > nomad.zip

## Install
unzip nomad.zip -d /usr/local/bin
chmod +x /usr/local/bin/nomad
chmod 0755 /usr/local/bin/nomad
chown root:root /usr/local/bin/nomad

## Configure
mkdir -p $NOMADCONFIGDIR
chmod 755 $NOMADCONFIGDIR
mkdir -p $NOMADDIR
chmod 755 $NOMADDIR


# rkt
echo "Installing rkt..."

VERSION=1.29.0
DOWNLOAD=${ARTIFACT_PROXY}/download/v${VERSION}/rkt-v${VERSION}.tar.gz

function install_rkt() {
	wget -q -O /tmp/rkt.tar.gz "${DOWNLOAD}"
	tar -C /tmp -xvf /tmp/rkt.tar.gz
	sudo mv /tmp/rkt-v${VERSION}/rkt /usr/local/bin
	sudo mv /tmp/rkt-v${VERSION}/*.aci /usr/local/bin
}

function configure_rkt_networking() {
	sudo mkdir -p /etc/rkt/net.d
    sudo bash -c 'cat << EOT > /etc/rkt/net.d/99-network.conf
{
  "name": "default",
  "type": "ptp",
  "ipMasq": false,
  "ipam": {
    "type": "host-local",
    "subnet": "172.16.28.0/24",
    "routes": [
      {
        "dst": "0.0.0.0/0"
      }
    ]
  }
}
EOT'
}

install_rkt
configure_rkt_networking

sudo rm /tmp/rkt.tar.gz
sudo rm /home/$HOME_DIR/consul.zip
sudo rm /home/$HOME_DIR/nomad.zip

# Add command to run docker-compose
echo "Getting Docker compose"
sudo curl -L ${ARTIFACT_PROXY}/download/$DOCKER_COMP_VERSION/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose

sudo chmod +x /usr/local/bin/docker-compose

echo "Install filebeat $FILEBEAT_VERSION"

wget https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-${FILEBEAT_VERSION}-x86_64.rpm

sudo yum -y install filebeat-6.4.1-x86_64.rpm

install -m 0755 -o root -g root /tmp/initialize-consul-nomad.sh /usr/local/bin/initialize-consul-nomad.sh

echo "creating ...12_configure_consul_nomad_init "

cat <<'EOF' > /etc/cloud/cloud.cfg.d/12_configure_consul_nomad_init.cfg
bootcmd:
# - [ sh, -c, "while ! /usr/local/bin/initialize-consul-nomad.sh; do echo Consul intialization failed.; sleep 10; done" ]
 - [ sh, -c, "/usr/local/bin/initialize-consul-nomad.sh; echo Consul intialization failed." ]
EOF

echo "created ...12_configure_consul_nomad_init "