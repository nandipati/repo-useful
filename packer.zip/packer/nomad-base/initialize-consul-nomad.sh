#!/bin/bash
set -eu
set -o verbose
set -o xtrace
export PS4='+(${BASH_SOURCE}:${LINENO}): ${FUNCNAME[0]:+${FUNCNAME[0]}(): }'

PATH="${PATH}:/usr/local/bin"

function log () {
    echo "$(date +"%b %e %T") $*"
    logger -- "$(basename $0) - $*"
}

# params:
# $1 - full dir name
# $2 - group and owner user id [user[:group]]. Example: "1000:1000"  , "joe:admins"
function create_dir_if_not_exists_and_set_ownership() {
  if [ ! -d "$1" ]; then
      sudo mkdir  $1
      sudo chown -R $2 $1
  fi
}

CONSULCONFIGDIR=/etc/consul.d
NOMADCONFIGDIR=/etc/nomad.d
ISTIOCONFIGDIR=/etc/istio.d

HOME_DIR=ec2-user

# Wait for network
sleep 15

IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)

echo "IP_ADDRESS ${IP_ADDRESS}"

REGION=$(curl --silent http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/.$//')

echo "REGION ${REGION}"

CLUSTER_TAG_VALUE=$(ec2-tag cluster_tag_value)

IS_NOMAD_SERVER=$(ec2-tag is_nomad_server)

GROUP=$(ec2-tag app_group)

ROLE=$(ec2-tag salt-role)

ENVIRONMENT=$(ec2-tag environment)

KERNEL=$(ec2-tag kernel)

NODE_CLASS=$(ec2-tag node-class)

NEXUS_EFS_DIR=$(ec2-tag nexus-efs-mount-dir)

NEXUS_EFS_DNS_NAME=$(ec2-tag nexus-efs-dns-name)

NEXUS_DOCKER_PORT=$(ec2-tag docker-port)

DOCKER_PUSH_PORT=$(ec2-tag docker-push-port)

# Read from the file we created
SERVER_COUNT="$(ec2-tag nomad_node_count)"

# Elastic Search VPC Endpoint
ES_VPC_ENDPOINT="$(ec2-tag cnd_es_vpc_endpoint)"

 CONSUL_SERVICE_NAME="$(ec2-tag consul_service_name)"
 CONSUL_DNS_SEARCH="$(ec2-tag consul_domain_search)"
 CONSUL_JOIN="provider=aws tag_key=join_tag tag_value=${CONSUL_SERVICE_NAME}-server"
 DOMIAN_NAME=$(echo $CONSUL_DNS_SEARCH | sed "s/service.//")

 AWS_DNS_IP=$(ec2-tag aws_dns_ip)

 NOMAD_SERVICE_NAME=$(ec2-tag nomad_service_name)

 ARTIFACT_SERVICE="$(ec2-tag artifact_service_name)"
 ARTIFACT_URL="${ARTIFACT_SERVICE}.${CONSUL_DNS_SEARCH}"
 DOCKER_REPO=${ARTIFACT_URL}:${NEXUS_DOCKER_PORT}
 DOCKER_PUSH_REPO=${ARTIFACT_URL}:${DOCKER_PUSH_PORT}

echo "Consul server primary ${CONSUL_JOIN}"

echo "ARTIFACT_URL ${ARTIFACT_URL}"

# Consul

echo "Configure Consul Client service Startup ..."
sudo mkdir -p $CONSULCONFIGDIR
sudo mkdir -p /etc/service

sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/consul_client.json
sed -i "s/SERVER_COUNT/$SERVER_COUNT/g" /tmp/consul_client.json
sed -i "s/CONSUL_DNS/$DOMIAN_NAME/g" /tmp/consul_client.json
sed -i "s/HOME_DIR/$HOME_DIR/g" /tmp/consul_client.json
sed -i "s/AWS_DNS_IP/$AWS_DNS_IP/g" /tmp/consul_client.json
sed -i "s/REGION/$REGION/g" /tmp/consul_upstart.conf
sed -i "s/CLUSTER_TAG_VALUE/$CLUSTER_TAG_VALUE/g" /tmp/consul_upstart.conf
sed -i "s/CONSUL_JOIN/$CONSUL_JOIN/g" /tmp/consul_upstart.conf
sed -i "s/ARTIFACT_URL/$DOCKER_REPO/g" /tmp/istio-init.yaml
sed -i "s/ARTIFACT_URL/$DOCKER_REPO/g" /tmp/istio-proxy.nomad
sudo chown root:root /tmp/consul_upstart.conf
sudo cp /tmp/consul_upstart.conf /etc/init/consul.conf
sudo chmod 0644 /etc/init/consul.conf
sudo chown root:root /tmp/consul_client.json
sudo cp /tmp/consul_client.json $CONSULCONFIGDIR/consul_client.json

echo "Consul Client service Startup ..."
sudo initctl start consul || sudo initctl restart consul

sleep 10
# Set env vars for tool CLIs
echo "export CONSUL_HTTP_ADDR=$IP_ADDRESS:8500" | tee --append /home/$HOME_DIR/.bashrc
export CONSUL_HTTP_ADDR=$IP_ADDRESS:8500

# Add hostname to /etc/hosts
echo "127.0.0.1 ${IP_ADDRESS}" | tee --append /etc/hosts

# Add Docker bridge network IP to /etc/resolv.conf (at the top)
#echo "nameserver $DOCKER_BRIDGE_IP_ADDRESS" | tee /etc/resolv.conf.new
DOCKER_BRIDGE_IP_ADDRESS=$(ifconfig docker0 2>/dev/null|awk '/inet addr:/ {print $2}'|sed 's/addr://')

echo "DOCKER_BRIDGE_IP_ADDRESS ${DOCKER_BRIDGE_IP_ADDRESS}"
echo "nameserver $IP_ADDRESS" | tee /etc/resolv.conf

# Add search Consul DNS Search at bottom of /etc/resolv.conf
echo "search ${CONSUL_DNS_SEARCH}" | tee --append /etc/resolv.conf

# Move daemon.json to /etc/docker
echo "{\"hosts\":[\"tcp://0.0.0.0:2375\",\"unix:///var/run/docker.sock\"],\"cluster-store\":\"consul://$IP_ADDRESS:8500\",\"cluster-advertise\":\"$IP_ADDRESS:2375\",\"dns\":[\"$IP_ADDRESS\"],\"dns-search\":[\"${CONSUL_DNS_SEARCH}\"],\"metrics-addr\" : \"$IP_ADDRESS:9323\",\"experimental\" : true,\"insecure-registries\":[\"${DOCKER_REPO}\",\"${DOCKER_PUSH_REPO}\"]}" > /home/ec2-user/daemon.json
mkdir -p /etc/docker
mv /home/ec2-user/daemon.json /etc/docker/daemon.json

# this re-try is needed because sometimes docker fails to start 
# TODO fix the docker resart issue, this is a temporary workaround 
for (( i=1; i<=6; ++i)); do
    echo " Trying to start docker. Attempt number =  $i "
    service docker restart && break
    sleep 10
done


echo "Creating a EFS Mount"

sudo mkdir -p $NEXUS_EFS_DIR
sudo mount -t nfs4 $NEXUS_EFS_DNS_NAME:/ $NEXUS_EFS_DIR


if [ "${IS_NOMAD_SERVER}" = true ];
then
  # Nomad
  echo "Configure Nomad Server service Startup ..."
  SERVER_DATA_DIR=$NEXUS_EFS_DIR/nomad-server
  sudo mkdir -p $SERVER_DATA_DIR
  sudo mkdir -p $NOMADCONFIGDIR
  sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/nomad.hcl
  sed -i "s/SERVER_COUNT/$SERVER_COUNT/g" /tmp/nomad.hcl
  sed -i "s/NOMAD_SERVICE_NAME/$NOMAD_SERVICE_NAME/g" /tmp/nomad.hcl
  sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/nomad.hcl
  sed -i "s/NOMAD_SERVICE_NAME/$NOMAD_SERVICE_NAME/g" /tmp/nomad.hcl
  sudo chown root:root /tmp/nomad_upstart.conf
  sudo cp /tmp/nomad_upstart.conf /etc/init/nomad.conf
  sudo chmod 0644 /etc/init/nomad.conf
  sudo chown root:root /tmp/nomad.hcl
  sudo cp /tmp/nomad.hcl $NOMADCONFIGDIR/nomad.hcl
  sed -i "s|ES_VPC_ENDPOINT|$ES_VPC_ENDPOINT|g" /tmp/filebeat.yml
  sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/filebeat.yml
  sudo chown root:root /tmp/filebeat.yml
  sudo cp /tmp/filebeat.yml /etc/filebeat/filebeat.yml
  sudo chmod 0600 /etc/filebeat/filebeat.yml
  echo "Nomad Server service Startup ..."
fi

if [ "${IS_NOMAD_SERVER}" = false ];
then
  #Getting Nomad Server DNS
  NOMADL_DNS="${NOMAD_SERVICE_NAME}.${CONSUL_DNS_SEARCH}"

  PORT=":4647"

  # Nomad Client
  echo "Configure Nomad Client service Startup ..."
  sudo mkdir -p $NOMADCONFIGDIR
  SERVER_DATA_DIR="/home/$HOME_DIR/nomad/data"
  sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/nomad_client.hcl
  sed -i "s/SERVER_COUNT/$SERVER_COUNT/g" /tmp/nomad_client.hcl
  sed -i "s/GROUP/$GROUP/g" /tmp/nomad_client.hcl
  sed -i "s/ROLE/$ROLE/g" /tmp/nomad_client.hcl
  sed -i "s/ENVIRONMENT/$ENVIRONMENT/g" /tmp/nomad_client.hcl
  sed -i "s/NOMAD_IPS/$NOMADL_DNS$PORT/g" /tmp/nomad_client.hcl
  sed -i "s/NODE_CLASS/$NODE_CLASS/g" /tmp/nomad_client.hcl
  sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/nomad_client.hcl
  sed -i "s/NOMAD_SERVICE_NAME/$NOMAD_SERVICE_NAME/g" /tmp/nomad_client.hcl
  sudo chown root:root /tmp/nomad_upstart.conf
  sudo cp /tmp/nomad_upstart.conf /etc/init/nomad.conf
  sudo chmod 0644 /etc/init/nomad.conf
  sudo chown root:root /tmp/nomad_client.hcl
  sudo cp /tmp/nomad_client.hcl $NOMADCONFIGDIR/nomad.hcl
  sed -i "s|ES_VPC_ENDPOINT|$ES_VPC_ENDPOINT|g" /tmp/filebeat.yml
  sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/filebeat.yml
  sudo chown root:root /tmp/filebeat.yml
  sudo cp /tmp/filebeat.yml /etc/filebeat/filebeat.yml
  sudo chmod 0600 /etc/filebeat/filebeat.yml

  echo "Nomad Client service Startup ..."
fi

echo "export NOMAD_ADDR=http://$IP_ADDRESS:4646" | tee --append /home/$HOME_DIR/.bashrc
export NOMAD_ADDR=http://$IP_ADDRESS:4646

sudo initctl start nomad || sudo initctl restart nomad
sleep 30

if [ "${IS_NOMAD_SERVER}" = false ];
then
  PILOT_SERVICE_NAME=$(ec2-tag pilot_service_name)
  PILOT_PORT=$(ec2-tag pilot_port)
  PILOT_URL="${PILOT_SERVICE_NAME}.${CONSUL_DNS_SEARCH}:${PILOT_PORT}"
  SERVICE_CLUSTER="$(ec2-tag istio_proxy_service_cluster)"

   # Running Istio Proxy on

  echo "Configuring nomad job of Istio Proxy"
  sudo mkdir -p $ISTIOCONFIGDIR
  sed -i "s/HOSTNAME/$(hostname)/g" /tmp/istio-proxy.nomad
  sed -i "s/KERNEL/$KERNEL/g" /tmp/istio-proxy.nomad
  sed -i "s/GROUP/$GROUP/g" /tmp/istio-proxy.nomad
  sed -i "s/ROLE/$ROLE/g" /tmp/istio-proxy.nomad
  sed -i "s/ENVIRONMENT/$ENVIRONMENT/g" /tmp/istio-proxy.nomad
  sed -i "s/NODE_CLASS/$NODE_CLASS/g" /tmp/istio-proxy.nomad
  sed -i "s/CONSUL_DNS_SEARCH/$CONSUL_DNS_SEARCH/g" /tmp/istio-proxy.nomad
  sed -i "s/SERVICE_CLUSTER/$SERVICE_CLUSTER/g" /tmp/istio-proxy.nomad
  sed -i "s/PILOT_URL/$PILOT_URL/g" /tmp/istio-proxy.nomad
  sudo chown root:root /tmp/istio-proxy.nomad
  sudo cp /tmp/istio-proxy.nomad $NOMADCONFIGDIR/istio-proxy.nomad
  sudo chown root:root /tmp/istio-init.yaml
  sudo cp /tmp/istio-init.yaml $ISTIOCONFIGDIR/istio-init.yaml

  USER_GROUP="1000:1000"
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/jenkins" USER_GROUP
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/jenkins/cnd-infra" USER_GROUP
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/jenkins/shared-jenkins" USER_GROUP

  USER_GROUP="2000:2000"
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/influxdb" USER_GROUP
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/influxdb/cnd-infra" USER_GROUP


  USER_GROUP="472:472"
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/grafana" USER_GROUP
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/grafana/cnd-infra" USER_GROUP


  USER_GROUP="$HOME_DIR:$HOME_DIR"
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/prometheus" USER_GROUP
  create_dir_if_not_exists_and_set_ownership  "$NEXUS_EFS_DIR/prometheus/cnd-infra" USER_GROUP


  sudo modprobe ip6table_filter

  sudo chmod 0777 /var/run/docker.sock

fi

echo "Starting Filebeat Services ..."
sudo service filebeat restart
echo "Started Filebeat Services ..."

export DOCKER_BRIDGE_IP_ADDRESS=$DOCKER_BRIDGE_IP_ADDRESS

echo "DOCKER_BRIDGE_IP_ADDRESS=$DOCKER_BRIDGE_IP_ADDRESS" | tee --append /home/$HOME_DIR/.bashrc

export IP_ADDRESS=$IP_ADDRESS

echo "IP_ADDRESS=$IP_ADDRESS" | tee --append /home/$HOME_DIR/.bashrc



# start nomad jobs
# this is good to be the last in this file because if a nomad job fails to start initially this scipt will exit and
# if it is last it will not stop other services from starting. Also it can be changed to temprarily disable exit on
# error for this file when starting nomad jobs. Nomad will take care to try restarting the job if the job fails initially due to
# nexus bind down temporarily or other reason.
# if [ "${IS_NOMAD_SERVER}" = false ];
# then
#  echo "Init Istio Proxy"

#  sudo /usr/local/bin/docker-compose -f $ISTIOCONFIGDIR/istio-init.yaml up -d

#  sleep 5

#  echo "Running a nomad job of Istio Proxy"

  # disable exitting on error temporarily
#  set +e
#  sudo /usr/local/bin/nomad job run -address=http://$IP_ADDRESS:4646 /etc/nomad.d/istio-proxy.nomad

  ## Add other nomad jobs here
  
  # bring exit on error back
#  set -e
# fi
