#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

# Make and mount filesystem for logs
LOG_DEV="/dev/xvdl"
LOG_DIR="/var/log"
mkfs.ext4 ${LOG_DEV}
mkdir -p ${LOG_DIR}
echo "${LOG_DEV} ${LOG_DIR} ext4 defaults 1 2" | tee -a /etc/fstab
sudo mount ${LOG_DIR}

# Install saltstack repo
rpm --import https://repo.saltstack.com/yum/amazon/latest/x86_64/archive/2018.3.2/SALTSTACK-GPG-KEY.pub
install -m 0644 -o root -g root /tmp/saltstack-amzn.repo /etc/yum.repos.d/saltstack-amzn.repo
yum-config-manager --enable epel

# Update packages
yum -y update

yum -y install \
	salt-minion \
	python27-boto \
	python27-boto3 \
	python27-pip \
	rpmdevtools

# Add salt-minion service
chkconfig --add salt-minion

# Ensure salt-minion is not started on first boot
chkconfig salt-minion off

install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag
install -m 0755 -o root -g root /tmp/init-salt-from-tags /usr/local/bin/init-salt-from-tags
/usr/bin/update-ca-trust extract

# Create salt-configuration file that will be executed during the first boot
cat <<'EOF' > /etc/cloud/cloud.cfg.d/11_configure_salt.cfg
runcmd:
 - timeout 2m bash -x /usr/local/bin/init-salt-from-tags
 - chkconfig salt-minion on
 - service salt-minion start
 - salt-call saltutil.sync_all
 - timeout 10m bash -c -- "while ! salt-call --retcode-passthrough state.highstate; do sleep 10; done" 
EOF
