## Usage

* OPTIONALLY: Set up `AWS_ACCESS_KEY` and `AWS_SECRET_KEY` environment variables.
* In the project folder run `./build.sh $VERSION_NUMBER` where `$VERSION_NUMBER` is the current iteration.
[AWS]https://www.packer.io/docs/builders/amazon.html

### E.g
`$ AWS_ACCESS_KEY_ID='foo' AWS_SECRET_ACCESS_KEY='bar' ../build.sh 123`

## Outcome
Packer will generate an AMI with preconfigured:
* salt-minion

