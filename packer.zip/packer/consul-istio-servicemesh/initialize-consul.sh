#!/bin/bash
set -eu

PATH="${PATH}:/usr/local/bin"

function log () {
    echo "$(date +"%b %e %T") $*"
    logger -- "$(basename $0) - $*"
}

CONSULCONFIGDIR=/etc/consul.d

HOME_DIR=ec2-user

# Wait for network
sleep 15

IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)

echo "IP_ADDRESS ${IP_ADDRESS}"

REGION=$(curl --silent http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/.$//')

echo "REGION ${REGION}"

CLUSTER_TAG_VALUE=$(ec2-tag cluster_tag_value)

MC_ADDRESS=$(curl --silent http://169.254.169.254/latest/meta-data/mac)

# Read from the file we created
SERVER_COUNT="$(ec2-tag nomad_node_count)"

NOMAD_SERVICE_NAME=$(ec2-tag nomad_service_name)



echo "MC_ADDRESS ${MC_ADDRESS}"

VPC_PRIM_CDIR=$(curl --silent http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MC_ADDRESS}/vpc-ipv4-cidr-block)

echo "VPC_PRIM_CDIR ${VPC_PRIM_CDIR}"

# Read from the file we created
SERVER_COUNT="$(ec2-tag consul_node_count)"

 CONSUL_SERVICE_NAME="$(ec2-tag consul_service_name)"
 CONSUL_DNS_SEARCH="$(ec2-tag consul_domain_search)"
 JOIN_TAG="$(ec2-tag join_tag)"
 CONSUL_JOIN="provider=aws tag_key=join_tag tag_value=${JOIN_TAG}"
 DOMIAN_NAME=$(echo $CONSUL_DNS_SEARCH | sed "s/service.//")
 AWS_DNS_IP=$(ec2-tag aws_dns_ip)
 ARTIFACT_SERVICE="$(ec2-tag artifact_service_name)"
 DOCKER_PORT=$(ec2-tag docker-port)
 ARTIFACT_URL=${ARTIFACT_SERVICE}.${CONSUL_DNS_SEARCH}:${DOCKER_PORT}

echo "DOMIAN_NAME ${DOMIAN_NAME}"

echo "Creating a EFS Mount"

NEXUS_EFS_DIR=$(ec2-tag nexus-efs-mount-dir)

NEXUS_EFS_DNS_NAME=$(ec2-tag nexus-efs-dns-name)

sudo mkdir -p $NEXUS_EFS_DIR
sudo mount -t nfs4 $NEXUS_EFS_DNS_NAME:/ $NEXUS_EFS_DIR

echo "Consul server primary ${CONSUL_JOIN}"

# Write the flags to a temporary file
cat >/tmp/consul_flags << EOF
CONSUL_FLAGS="-server -bootstrap-expect=${SERVER_COUNT} -join=${CONSUL_JOIN} -data-dir=/opt/consul/data"
EOF

  echo "Installing Upstart service..."
  sudo mkdir -p $CONSULCONFIGDIR
  sudo mkdir -p /etc/service

  # Consul
  SERVER_DATA_DIR=$NEXUS_EFS_DIR/consul-server
  sudo mkdir -p $SERVER_DATA_DIR
  sed -i "s/CONSUL_SERVICE_NAME/$CONSUL_SERVICE_NAME/g" /tmp/consul.json
  sed -i "s/CONSUL_DNS/$DOMIAN_NAME/g" /tmp/consul.json
  sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/consul.json
  sed -i "s/SERVER_COUNT/$SERVER_COUNT/g" /tmp/consul.json
  sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/consul.json
  sed -i "s/HOME_DIR/$HOME_DIR/g" /tmp/consul.json
  sed -i "s/AWS_DNS_IP/$AWS_DNS_IP/g" /tmp/consul.json
  sed -i "s/REGION/$REGION/g" /tmp/upstart.conf
  sed -i "s/CLUSTER_TAG_VALUE/$CLUSTER_TAG_VALUE/g" /tmp/upstart.conf
  sed -i "s/CONSUL_JOIN/$CONSUL_JOIN/g" /tmp/upstart.conf

  sudo chown root:root /tmp/upstart.conf
  sudo cp /tmp/upstart.conf /etc/init/consul.conf
  sudo chmod 0644 /etc/init/consul.conf
  sudo chown root:root /tmp/consul.json
  sudo cp /tmp/consul.json $CONSULCONFIGDIR/consul.json
  # Add hostname to /etc/hosts
  echo "127.0.0.1 $(hostname)" | tee --append /etc/hosts
  echo "127.0.0.1 ${CONSUL_JOIN}" | tee --append /etc/hosts

  # Add Docker bridge network IP to /etc/resolv.conf (at the top)
  #echo "nameserver $DOCKER_BRIDGE_IP_ADDRESS" | tee /etc/resolv.conf.new
  DOCKER_BRIDGE_IP_ADDRESS=$(ifconfig docker0 2>/dev/null|awk '/inet addr:/ {print $2}'|sed 's/addr://')

  echo "DOCKER_BRIDGE_IP_ADDRESS ${DOCKER_BRIDGE_IP_ADDRESS}"

  # Move daemon.json to /etc/docker
  echo "{\"hosts\":[\"tcp://0.0.0.0:2375\",\"unix:///var/run/docker.sock\"],\"cluster-store\":\"consul://$IP_ADDRESS:8500\",\"cluster-advertise\":\"$IP_ADDRESS:2375\",\"dns\":[\"$IP_ADDRESS\"],\"dns-search\":[\"$CONSUL_DNS_SEARCH\"],\"metrics-addr\" : \"$IP_ADDRESS:9323\",\"experimental\" : true,\"insecure-registries\":[\"$ARTIFACT_URL\"]}" > /home/ec2-user/daemon.json
  mkdir -p /etc/docker
  mv /home/ec2-user/daemon.json /etc/docker/daemon.json

  # Start Docker

 # this re-try is needed because sometimes docker fails to start
 # TODO fix the docker resart issue, this is a temporary workaround
 for (( i=1; i<=6; ++i)); do
     echo " Trying to start docker. Attempt number =  $i "
     service docker restart && break
     sleep 10
 done

  export CONSUL_HTTP_ADDR=$IP_ADDRESS:8500

  export REGION=$REGION

  echo "REGION=$REGION" | tee --append /home/$HOME_DIR/.bashrc

  export DOCKER_BRIDGE_IP_ADDRESS=$DOCKER_BRIDGE_IP_ADDRESS

  echo "DOCKER_BRIDGE_IP_ADDRESS=$DOCKER_BRIDGE_IP_ADDRESS" | tee --append /home/$HOME_DIR/.bashrc

  export IP_ADDRESS=$IP_ADDRESS

  echo "IP_ADDRESS=$IP_ADDRESS" | tee --append /home/$HOME_DIR/.bashrc

  export VPC_PRIM_CDIR=$VPC_PRIM_CDIR

  echo "VPC_PRIM_CDIR=$VPC_PRIM_CDIR" | tee --append /home/$HOME_DIR/.bashrc

  echo "Consul Client service Startup ..."
  sudo initctl start consul || sudo initctl restart consul

  sleep 5

 echo "Configure Nomad Server service Startup ..."
 NOMADCONFIGDIR=/etc/nomad.d
 SERVER_DATA_DIR=$NEXUS_EFS_DIR/nomad-server
 sudo mkdir -p $SERVER_DATA_DIR
 sudo mkdir -p $NOMADCONFIGDIR

 sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/nomad.hcl
 sed -i "s/SERVER_COUNT/$SERVER_COUNT/g" /tmp/nomad.hcl
 sed -i "s/NOMAD_SERVICE_NAME/$NOMAD_SERVICE_NAME/g" /tmp/nomad.hcl
 sed -i "s|SERVER_DATA_DIR|$SERVER_DATA_DIR|g" /tmp/nomad.hcl
 sudo chown root:root /tmp/nomad_upstart.conf
 sudo cp /tmp/nomad_upstart.conf /etc/init/nomad.conf
 sudo chmod 0644 /etc/init/nomad.conf
 sudo chown root:root /tmp/nomad.hcl
 sudo cp /tmp/nomad.hcl $NOMADCONFIGDIR/nomad.hcl

echo "export NOMAD_ADDR=http://$IP_ADDRESS:4646" | tee --append /home/$HOME_DIR/.bashrc
export NOMAD_ADDR=http://$IP_ADDRESS:4646

sudo initctl start nomad || sudo initctl restart nomad

sleep 10