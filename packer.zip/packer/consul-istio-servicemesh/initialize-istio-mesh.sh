#!/bin/bash
set -eu

PATH="${PATH}:/usr/local/bin"

HOME_DIR=ec2-user

ISTIOVERSION=1.0.0
DOCKER_COMP_VERSION=1.22.0

function log () {
    echo "$(date +"%b %e %T") $*"
    logger -- "$(basename $0) - $*"
}

echo "Setup Istio Service Mesh..."

sudo service docker start

IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)

echo "IP_ADDRESS ${IP_ADDRESS}"

REGION=$(curl --silent http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/.$//')

echo "REGION ${REGION}"

CLUSTER_TAG_VALUE=$(ec2-tag cluster_tag_value)

MC_ADDRESS=$(curl --silent http://169.254.169.254/latest/meta-data/mac)

echo "MC_ADDRESS ${MC_ADDRESS}"

VPC_PRIM_CDIR=$(curl --silent http://169.254.169.254/latest/meta-data/network/interfaces/macs/${MC_ADDRESS}/vpc-ipv4-cidr-block)

echo "VPC_PRIM_CDIR ${VPC_PRIM_CDIR}"

export CONSUL_HTTP_ADDR=$IP_ADDRESS:8500

export REGION=$REGION

export IP_ADDRESS=$IP_ADDRESS

export VPC_PRIM_CDIR=$VPC_PRIM_CDIR

CONSUL_DNS_SEARCH="$(ec2-tag consul_domain_search)"

  # Set env vars for tool CLIs
  echo "export CONSUL_HTTP_ADDR=$IP_ADDRESS:8500" | tee --append /home/$HOME_DIR/.bashrc


sudo chown $HOME_DIR:$HOME_DIR /tmp/istio.yaml

sudo cp /tmp/istio.yaml /home/$HOME_DIR/istio-$ISTIOVERSION/install/consul/istio.yaml

echo "export DOCKER_GATEWAY=172.28.0.1:" | tee --append /home/$HOME_DIR/.bashrc
export DOCKER_GATEWAY=172.28.0.1:

# Add command to run docker-compose
echo "Getting Docker compose"
sudo curl -L https://github.com/docker/compose/releases/download/$DOCKER_COMP_VERSION/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose

sudo chmod +x /usr/local/bin/docker-compose

echo "Starting Istio Service mesh"

/usr/local/bin/docker-compose -f /home/$HOME_DIR/istio-$ISTIOVERSION/install/consul/istio.yaml up -d

sleep 10

/usr/local/bin/kubectl config set-context istio --cluster=istio
/usr/local/bin/kubectl config set-cluster istio --server=http://$IP_ADDRESS:8080
/usr/local/bin/kubectl config use-context istio

/usr/local/bin/docker-compose -f /home/$HOME_DIR/istio-$ISTIOVERSION/install/consul/istio.yaml up -d

# Get instance id's and etcd server ips

  echo "nameserver $IP_ADDRESS" | tee /etc/resolv.conf

  # Add search Consul Dns Search at bottom of /etc/resolv.conf
  echo "search ${CONSUL_DNS_SEARCH}" | tee --append /etc/resolv.conf
