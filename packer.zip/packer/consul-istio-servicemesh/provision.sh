#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -eu

echo "Installing dependencies..."
install -m 0644 -o root -g root /tmp/hmheng_repo.repo /etc/yum.repos.d/hmheng_repo.repo
# Install required packages
yum -y install \
  software-properties-common \
  unzip \
  tree \
  redis-tools \
  jq \
  curl \
  tmux \
  numpy \
  wget \
  jdk1.8.0_181

yum -y remove java
yum -y install java-1.8.0-openjdk

HOME_DIR=ec2-user

JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:bin/java::")

echo "Fetching Consul..."

CONSULVERSION=1.5.1

source /tmp/artifactory
ARTIFACT_PROXY=$REPO_PROXY
ARTIFACT_URL=$REPO_URL

cd /tmp
CONSULDOWNLOAD=${ARTIFACT_URL}/consul/${CONSULVERSION}/consul_${CONSULVERSION}_linux_amd64.zip
CONSULCONFIGDIR=/etc/consul.d
CONSULDIR=/opt/consul

NOMADVERSION=0.9.3
NOMADDOWNLOAD=${ARTIFACT_URL}/nomad/${NOMADVERSION}/nomad_${NOMADVERSION}_linux_amd64.zip
NOMADCONFIGDIR=/etc/nomad.d
NOMADDIR=/home/$HOME_DIR/nomad



# Consul

curl -L $CONSULDOWNLOAD > consul.zip

echo "Installing Consul..."
unzip consul.zip >/dev/null
chmod +x consul
sudo mv consul /usr/local/bin/consul

sudo chmod 0755 /usr/local/bin/consul
sudo chown root:root /usr/local/bin/consul
sudo setcap "cap_net_bind_service=+ep" /usr/local/bin/consul

## Configure
mkdir -p $CONSULCONFIGDIR
chmod 755 $CONSULCONFIGDIR
mkdir -p $CONSULDIR
chmod 755 $CONSULDIR

sudo mkdir -p /opt/consul/data

# Nomad

echo "Installing Nomad ..."

curl -L $NOMADDOWNLOAD > nomad.zip

## Install
unzip nomad.zip -d /usr/local/bin
chmod +x /usr/local/bin/nomad
chmod 0755 /usr/local/bin/nomad
chown root:root /usr/local/bin/nomad

## Configure
mkdir -p $NOMADCONFIGDIR
chmod 755 $NOMADCONFIGDIR
mkdir -p $NOMADDIR
chmod 755 $NOMADDIR

# rkt
echo "Installing rkt..."

VERSION=1.29.0
DOWNLOAD=${ARTIFACT_PROXY}/download/v${VERSION}/rkt-v${VERSION}.tar.gz

function install_rkt() {
	wget -q -O /tmp/rkt.tar.gz "${DOWNLOAD}"
	tar -C /tmp -xvf /tmp/rkt.tar.gz
	sudo mv /tmp/rkt-v${VERSION}/rkt /usr/local/bin
	sudo mv /tmp/rkt-v${VERSION}/*.aci /usr/local/bin
}

function configure_rkt_networking() {
	sudo mkdir -p /etc/rkt/net.d
    sudo bash -c 'cat << EOT > /etc/rkt/net.d/99-network.conf
{
  "name": "default",
  "type": "ptp",
  "ipMasq": false,
  "ipam": {
    "type": "host-local",
    "subnet": "172.16.28.0/24",
    "routes": [
      {
        "dst": "0.0.0.0/0"
      }
    ]
  }
}
EOT'
}

install_rkt
configure_rkt_networking

echo "Installing kubectl..."

curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl

chmod +x ./kubectl

sudo mv ./kubectl /usr/local/bin/kubectl

echo "Installing Helm..."

HELMVERSION=2.10.0
cd /tmp
HELMDOWNLOAD=${ARTIFACT_URL}/helm-v${HELMVERSION}-linux-amd64.zip

# HELM

curl -L $HELMDOWNLOAD > helm.zip

echo "Installing HELM..."
unzip helm.zip >/dev/null
chmod +x ./linux-amd64/helm
sudo mv ./linux-amd64/helm /usr/local/bin/helm

echo "Installing istio..."

ISTIOVERSION=1.0.0

curl -L ${ARTIFACT_PROXY}/download/$ISTIOVERSION/istio-$ISTIOVERSION-linux.tar.gz > istio.tar

tar xvf istio.tar --directory /home/$HOME_DIR

echo "Installed istio..."

rm istio.tar

chmod +x /home/$HOME_DIR/istio-$ISTIOVERSION/bin/istioctl

sudo cp /home/$HOME_DIR/istio-$ISTIOVERSION/bin/istioctl /usr/local/bin/istioctl

echo "export PATH=/home/$HOME_DIR/istio-$ISTIOVERSION/bin:$PATH" | tee --append /home/$HOME_DIR/.bashrc

install -m 0755 -o root -g root /tmp/initialize-consul.sh /usr/local/bin/initialize-consul.sh
install -m 0755 -o root -g root /tmp/initialize-istio-mesh.sh /usr/local/bin/initialize-istio-mesh.sh
install -m 0755 -o root -g root /tmp/service.sh /usr/local/bin/service.sh
install -m 0755 -o root -g root /tmp/ip_tables.sh /usr/local/bin/ip_tables.sh

echo "creating ...12_configure_consul_istio_init "

cat <<'EOF' > /etc/cloud/cloud.cfg.d/12_configure_consul_istio_init.cfg
bootcmd:
# - [ sh, -c, "while ! /usr/local/bin/initialize-consul.sh; do echo Consul intialization failed.; sleep 10; done" ]
# - [ sh, -c, "while ! /usr/local/bin/service.sh; do echo Consul Service start failed.; sleep 10; done" ]
# - [ sh, -c, "while ! /usr/local/bin/initialize-istio-mesh.sh; do echo Istio Service Mesh configuration failed.; sleep 10; done" ]
 - [ sh, -c, "/usr/local/bin/initialize-consul.sh;echo Consul intialization completed." ]
# - [ sh, -c, "/usr/local/bin/service.sh; echo Consul Service start failed." ]
 - [ sh, -c, "/usr/local/bin/initialize-istio-mesh.sh; echo Istio Service Mesh configuration failed." ]
EOF

echo "created ...12_configure_consul_istio_init "

