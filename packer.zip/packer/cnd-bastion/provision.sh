#!/bin/bash
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -e

install -m 0644 -o root -g root /tmp/hmheng_repo.repo /etc/yum.repos.d/hmheng_repo.repo
yum-config-manager --enable epel

# Update packages
yum -y update

# Install required packages
yum -y install \
  software-properties-common \
	python27-pip \
	git \
	rpmdevtools \
	golang \
	packer \
	unzip \
	tree \
	redis-tools \
	jq \
	curl \
	tmux \
	numpy \
	wget \
	docker \
	jdk1.8.0_181

pip-2.7 install GitPython

# Java
yum -y remove java
yum -y install java-1.8.0-openjdk
# yum -y install java-1.8.0-openjdk
# yum -y install docker jdk1.8.0_181 builder git

usermod -aG docker ec2-user

JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:bin/java::")

source /tmp/artifactory
ARTIFACT_PROXY=$REPO_PROXY
ARTIFACT_URL=$REPO_URL

CONSULVERSION=1.5.1
CONSULDOWNLOAD=${ARTIFACT_URL}/consul/${CONSULVERSION}/consul_${CONSULVERSION}_linux_amd64.zip
CONSULCONFIGDIR=/etc/consul.d
CONSULDIR=/opt/consul

VAULTVERSION=0.10.3
VAULTDOWNLOAD=${ARTIFACT_URL}/vault/${VAULTVERSION}/vault_${VAULTVERSION}_linux_amd64.zip
VAULTCONFIGDIR=/etc/vault.d
VAULTDIR=/opt/vault

NOMADVERSION=0.9.3
NOMADDOWNLOAD=${ARTIFACT_URL}/nomad/${NOMADVERSION}/nomad_${NOMADVERSION}_linux_amd64.zip
NOMADCONFIGDIR=/etc/nomad.d
NOMADDIR=/opt/nomad


# Terraform
TERRAFORMVERSION=0.11.13
TERRAFORMDOWNLOAD=${ARTIFACT_URL}/terraform/${TERRAFORMVERSION}/terraform_${TERRAFORMVERSION}_linux_amd64.zip
curl -L $TERRAFORMDOWNLOAD > terraform.zip

## Install
unzip terraform.zip -d /usr/local/bin
chmod 0755 /usr/local/bin/terraform
chown root:root /usr/local/bin/terraform


# Consul

curl -L $CONSULDOWNLOAD > consul.zip

## Install
unzip consul.zip -d /usr/local/bin
chmod 0755 /usr/local/bin/consul
chown root:root /usr/local/bin/consul
mv /usr/local/bin/consul /usr/local/bin/cl_actual

## Configure
mkdir -p $CONSULCONFIGDIR
chmod 755 $CONSULCONFIGDIR
mkdir -p $CONSULDIR
chmod 755 $CONSULDIR

# Vault

curl -L $VAULTDOWNLOAD > vault.zip

## Install
unzip vault.zip -d /usr/local/bin
chmod 0755 /usr/local/bin/vault
chown root:root /usr/local/bin/vault

## Configure
mkdir -p $VAULTCONFIGDIR
chmod 755 $VAULTCONFIGDIR
mkdir -p $VAULTDIR
chmod 755 $VAULTDIR

# Nomad

curl -L $NOMADDOWNLOAD > nomad.zip

## Install
unzip nomad.zip -d /usr/local/bin
chmod 0755 /usr/local/bin/nomad
chown root:root /usr/local/bin/nomad
mv /usr/local/bin/nomad /usr/local/bin/nd_actual

## Configure
mkdir -p $NOMADCONFIGDIR
chmod 755 $NOMADCONFIGDIR
mkdir -p $NOMADDIR
chmod 755 $NOMADDIR

# rkt
echo "Installing rkt..."

VERSION=1.29.0
DOWNLOAD=${ARTIFACT_PROXY}/download/v${VERSION}/rkt-v${VERSION}.tar.gz

function install_rkt() {
	wget -q -O /tmp/rkt.tar.gz "${DOWNLOAD}"
	tar -C /tmp -xvf /tmp/rkt.tar.gz
	sudo mv /tmp/rkt-v${VERSION}/rkt /usr/local/bin
	sudo mv /tmp/rkt-v${VERSION}/*.aci /usr/local/bin
}

function configure_rkt_networking() {
	sudo mkdir -p /etc/rkt/net.d
    sudo bash -c 'cat << EOT > /etc/rkt/net.d/99-network.conf
{
  "name": "default",
  "type": "ptp",
  "ipMasq": false,
  "ipam": {
    "type": "host-local",
    "subnet": "172.16.28.0/24",
    "routes": [
      {
        "dst": "0.0.0.0/0"
      }
    ]
  }
}
EOT'
}

install_rkt
configure_rkt_networking

echo "Installing kubectl..."

curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl

chmod +x ./kubectl

sudo mv ./kubectl /usr/local/bin/kubectl

echo "Installing Helm..."

HELMVERSION=2.10.0
cd /tmp
HELMDOWNLOAD=${ARTIFACT_URL}/helm-v${HELMVERSION}-linux-amd64.zip

# HELM

curl -L $HELMDOWNLOAD > helm.zip

echo "Installing HELM..."
unzip helm.zip >/dev/null
chmod +x ./linux-amd64/helm
sudo mv ./linux-amd64/helm /usr/local/bin/helm


install -m 0755 -o root -g root /tmp/ec2-tag /usr/local/bin/ec2-tag
install -m 0755 -o root -g root /tmp/init-salt-from-tags /usr/local/bin/init-salt-from-tags
install -m 0755 -o root -g root /tmp/initialize_instance.sh /usr/local/bin/initialize_instance.sh
install -m 0755 -o root -g root /tmp/attach-eni.sh /usr/local/bin/attach-eni.sh
install -m 0755 -o root -g root /tmp/cnd-infra-hash /usr/local/bin/cnd-infra-hash
/usr/bin/update-ca-trust extract

# Configure instance.
cat <<'EOF' > /etc/cloud/cloud.cfg.d/12_configure_instance.cfg
runcmd:
 - [ sh, -c, "while ! /usr/local/bin/attach-eni.sh; do echo ENI configuration failed. Retrying after a while; sleep 10; done" ]
 - [bash, -x, /usr/local/bin/initialize_instance.sh]
 - timeout 2m bash -x /usr/local/bin/init-salt-from-tags
 - chkconfig salt-minion on
 - service salt-minion start
 - salt-call saltutil.sync_all
 - service docker start
 - timeout 2m bash -c -- "salt-call --retcode-passthrough state.highstate;"
EOF



