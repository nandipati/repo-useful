#!/bin/bash
set -eu

export GIT_SSH_COMMAND="ssh -i /root/.ssh/id_cndnp -o StrictHostKeyChecking=no"
PATH="${PATH}:/usr/local/bin"
IP_ADDRESS=$(curl http://169.254.169.254/latest/meta-data/local-ipv4)
CONSULCONFIGDIR=/etc/consul.d
HOME_DIR=ec2-user

function get_keys {
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndnp_deploy_key /root/.ssh/id_cndnp
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndnp_deploy_key.pub /root/.ssh/id_cndnp.pub
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndcorecndnp /root/.ssh/tf_sharedkey
    aws s3 cp s3://cnd-terraform-assets/keys/id_cndcorecndnp.pub /root/.ssh/tf_sharedkey.pub
    aws s3 cp s3://cnd-terraform-assets/keys/cndcorenp_tools /root/.ssh/cnd_tools
    aws s3 cp s3://cnd-terraform-assets/keys/cndcorenp_tools.pub /root/.ssh/cnd_tools.pub
    chmod 755 /home/ec2-user/.ssh/authorized_keys
    cat /usr/local/bin/cnd-infra-hash >> /home/ec2-user/.ssh/authorized_keys
    chmod 600 /home/ec2-user/.ssh/authorized_keys
    chmod 600 /root/.ssh/id_cndnp*
    chmod 600 /root/.ssh/tf_sharedkey*
    chmod 600 /root/.ssh/cnd_tools*
    eval `ssh-agent -s`
    ssh-add /root/.ssh/cnd_tools
}

CLOUD_SQUIRREL_BUILD_LOCATION=s3://cnd-terraform-assets/builds/cloud_squirrel
CLOUD_SQUIRREL_CONFIG_DIR=/home/ec2-user/.cs
CLOUD_SQUIRREL_INSTALL_DIR=/usr/local/bin
function install_cloud_squirrel {
    echo "installing cloud squirrel"
    aws s3 cp $CLOUD_SQUIRREL_BUILD_LOCATION/cs  $CLOUD_SQUIRREL_INSTALL_DIR
    sudo chmod go+rx $CLOUD_SQUIRREL_INSTALL_DIR/cs
    mkdir -p $CLOUD_SQUIRREL_CONFIG_DIR
    aws s3 cp $CLOUD_SQUIRREL_BUILD_LOCATION/cs.json   $CLOUD_SQUIRREL_CONFIG_DIR/cs.json
    sudo chmod go+r $CLOUD_SQUIRREL_CONFIG_DIR/cs.json
    echo "done installing cloud squirrel"
}

# params:
# $1 - full dir name
# $2 - group and owner user id [user[:group]]. Example: "1000:1000"  , "joe:admins"
function create_dir_if_not_exists_and_set_ownership() {
  if [ ! -d "$1" ]; then
      sudo mkdir  $1
      sudo chown -R $2 $1
  fi
}


get_keys
install_cloud_squirrel

echo "Creating RCS infrastructure EFS Mount"
EFS_DNS_NAME_RCS_INFRA=$(ec2-tag efs-dns-name-rcs-infra)
RCS_INFRA_EFS_DIR=$(ec2-tag efs-mount-path-rcs-infra)
sudo mkdir -p $RCS_INFRA_EFS_DIR
sudo mount -t nfs4 $EFS_DNS_NAME_RCS_INFRA:/ $RCS_INFRA_EFS_DIR

echo "Creating app01 EFS Mount"
EFS_DNS_NAME_APP01=$(ec2-tag efs-dns-name-app01)
APP01_EFS_DIR=$(ec2-tag efs-mount-path-app01)
sudo mkdir -p $APP01_EFS_DIR
sudo mount -t nfs4 $EFS_DNS_NAME_APP01:/ $APP01_EFS_DIR

LETS_ENCRYPT_DIR="${APP01_EFS_DIR}/letsencrypt"
sudo mkdir -p $LETS_ENCRYPT_DIR
sudo chmod go+rx $LETS_ENCRYPT_DIR

EASYCBM_DIR="${APP01_EFS_DIR}/easycbm"
sudo mkdir -p $EASYCBM_DIR/{dev/rw,uat/rw,prod/rw}
sudo chown ec2-user:ec2-user $EASYCBM_DIR/{dev/rw,uat/rw,prod/rw}

echo " init easyCBM  access logs reports dirs "
sudo mkdir -p $EASYCBM_DIR/easycbm-maintenance/{dev,uat,prod}/access_logs
sudo chmod o+w $EASYCBM_DIR/easycbm-maintenance/{dev,uat,prod}/access_logs
echo " init  easyCBM contacts reports dirs "
sudo mkdir -p $EASYCBM_DIR/easycbm-maintenance/{dev,uat,prod}/custom/eloqua/easyCBM_contacts
sudo chmod o+w $EASYCBM_DIR/easycbm-maintenance/{dev,uat,prod}/custom/eloqua/easyCBM_contacts

echo " init  easycbm admin dirs "
sudo mkdir -p $EASYCBM_DIR/easycbm-admin/{dev,uat,prod}
sudo chmod o+w $EASYCBM_DIR/easycbm-admin/{dev,uat,prod}

CONSUL_SERVICE_NAME="$(ec2-tag consul_service_name)"

sed -i "s/IP_ADDRESS/$IP_ADDRESS/g" /tmp/consul_client.json
sed -i "s/HOME_DIR/$HOME_DIR/g" /tmp/consul_client.json
sed -i "s/CONSUL_JOIN/$CONSUL_SERVICE_NAME/g" /tmp/consul_upstart.conf
sudo chown root:root /tmp/consul_upstart.conf
sudo cp /tmp/consul_upstart.conf /etc/init/consul.conf
sudo chmod 0644 /etc/init/consul.conf
sudo chown root:root /tmp/consul_client.json
sudo cp /tmp/consul_client.json $CONSULCONFIGDIR/consul_client.json

echo "Consul Client service Startup ..."
sudo initctl start consul || sudo initctl restart consul

sleep 30

# register_bastion_host_as_service_in_consul
curl  -X PUT -d \
'{"Name": "bastion", "Address": "'"$IP_ADDRESS"'","Port": 22,"Checks": [{"DeregisterCriticalServiceAfter": "15s",   "TCP": "'$IP_ADDRESS':22", "State":"passing", "Interval": "10s"}]}'  \
http://$IP_ADDRESS:8500/v1/agent/service/register
