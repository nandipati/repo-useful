#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $(basename $0) VERSION"
    exit 1
fi

VERSION="$1"

ITERATION="${ITERATION:=1}"

set -eu

make -e VERSION=${VERSION} -e ITERATION=${ITERATION} -f Makefile
