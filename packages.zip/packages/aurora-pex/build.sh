#!/bin/sh

set -eu


AURORA_VERSION=$1
MESOS_VERSION=$2
ITERATION=${3:-1}

BUILDERS="ubuntu1404 centos66"

build_pex() {
  local image=aurora-pex-$1
  ( cd builder/$1 \
    && docker build -t $image . )

  cp build-pex.sh $2
  docker run --rm -v $2:/tmp/build $image bash -c "cd /tmp/build && ./build-pex.sh $AURORA_VERSION $MESOS_VERSION"
}

[ -d build ] && rm -rf build
mkdir build

for builder in $BUILDERS; do
  [ -d build/pex ] && rm -rf build/pex
  mkdir -p build/pex

  build_pex $builder $(pwd)/build/pex
  sudo mv build/pex/src/dist/thermos_executor.pex build/thermos_executor.$builder-$AURORA_VERSION.pex

  sudo rm -rf build/pex
done

sudo cp build-rpm.sh build
docker run --rm -v $(pwd)/build:/tmp/build docker.br.hmheng.io/base-ubuntu1404 bash -c "cd /tmp/build && ./build-rpm.sh $AURORA_VERSION $ITERATION"
