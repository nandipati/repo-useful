Multi-platform thermos executor RPM
-----------------------------------

This script builds `thermos_executor` PEX files for multiple Linux
distributions. Currently it supports:

  - Ubuntu 14.04
  - Centos 6.6

To build an RPM containing the PEX files, run:

```
./build.sh
```
