#!/bin/sh

set -eu

ROOT=$(pwd)/root
BIN=$ROOT/usr/bin

if [ $# -lt 2 ]; then
  echo "Usage: $(basename $0) AURORA-VERSION ITERATION" >&2
  exit 1
fi

AURORA_VERSION=$1
ITERATION=$2

apt-get update
apt-get install -y ruby ruby-dev build-essential rpm
gem install --no-ri --no-rdoc fpm

mkdir -p $BIN
cp *.pex $BIN

fpm -p aurora-pex-$AURORA_VERSION-$ITERATION.x86_64.rpm \
    -s dir \
    -t rpm \
    --name aurora-pex \
    --version $AURORA_VERSION \
    --iteration $ITERATION \
    --architecture x86_64 \
    --force \
    -C root .


