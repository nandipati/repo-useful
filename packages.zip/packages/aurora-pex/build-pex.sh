#!/bin/sh

set -eu

if [ $# -lt 2 ]; then
  echo "Usage: $(basename $0) AURORA-VERSION MESOS-VERSION" >&2
  exit 1
fi

AURORA_VERSION=$1
MESOS_VERSION=$2

curl -L -o src.tar.gz http://mirror.netinch.com/pub/apache/aurora/$AURORA_VERSION/apache-aurora-$AURORA_VERSION.tar.gz

[ -d src ] && rm -rf src
mkdir src
tar xf src.tar.gz --strip-components 1 -C src

mkdir src/third_party
( cd src/third_party \
  && curl -O -L $(cat /mesos-download-url)/python/mesos.executor-$MESOS_VERSION-py2.7-linux-x86_64.egg \
  && curl -O -L $(cat /mesos-download-url)/python/mesos.native-$MESOS_VERSION-py2.7.egg )

( cd src \
  && ./pants binary src/main/python/apache/aurora/executor:thermos_executor \
  && ./pants binary src/main/python/apache/thermos/runner:thermos_runner \
  && ./build-support/embed_runner_in_executor.py )
