# Monit package for bedrock

Downloads prebuilt binary from mmonit site and packages it into rpm and deb

## Notable targets

### all
	Default target. Creates rpm and deb

### push
	Pushes created packages to artifactory

### docker
	Runs given target inside fpm container. Target can be set via `DOCKER_TARGET` variable 
