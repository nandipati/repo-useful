#!/bin/sh
ldconfig
