#!/bin/sh

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: $(basename $0) LIBNL_VERSION BUILD_ITERATION"
    exit 1
fi


VERSION="$1"
ITERATION="$2"
DIR="libnl$(echo $VERSION|tr . _)"
TARBALL=libnl-$VERSION.tar.gz

set -eu

yum install -y ca-certificates ruby ruby-devel
yum groupinstall -y "Development Tools"

gem install --no-ri --no-rdoc fpm

curl -L -O https://github.com/thom311/libnl/releases/download/$DIR/$TARBALL

test -d libnl-$VERSION && rm -rf libnl-$VERSION
tar xf $TARBALL

cd libnl-$VERSION

./configure --prefix=/usr
make -j2
make install DESTDIR=$(pwd)/build

fpm -p ../libnl3-$VERSION-$ITERATION.x86_64.rpm \
    -s dir \
    -t rpm \
    --name libnl3 \
    --version $VERSION \
    --iteration $ITERATION \
    --architecture x86_64 \
    --after-install ../post-install.sh \
    --force \
    -C build .
