# Unified Thermos Executor

Unified Thermos Executor bundles Thermos Executor with a minimal Python
distribution and the necessary shared libraries for running Python and Thermos
Executor.

## Building

``` sh
$ make
```

The build creates `build/thermos.tar.gz`, which contains Thermos Executor,
Python, and their dependencies. The distribution **must** be extracted to
`/mnt/mesos/sanbox` for it to work.

## Aurora configuration

Aurora must be instructed to add `thermos.tar.gz` to the container Sandbox by
adding the archive to `-thermos-executor-resources` list. The archive must be
extracted before Thermos Executor can be launched, and therefore you must use a
script to extract the archive and to launch thermos (see [run-thermos.sh] for an
example).

## Container image dependencies

  - Thermos runner script
    - `/bin/sh`
    - `id`
    - `tar`
    - `sudo`
    - `sed`
    - `grep`
    - `mkdir`
    - `chown`
    - `chmod`
  - Thermos executor/Thermos runner
    - `bash`
