#!/usr/bin/env python27

import glob
import os
import re
import shutil
import subprocess
import sys

PYTHON = '/usr/bin/python27'
LD_SO  = '/lib64/ld-2.17.so'

NO_RPATH_MODIFICATION = [
    # Patching ld.so leads to segfaults
    r'^ld-linux-x86-64\.so.\d$',
    r'^ld-[\d.]+\.so$',
]

class Root(object):
    def __init__(self, base):
        self.base = base

    def resolve(self, path):
        return os.path.join(self.base, path)

    def lib(self):
        return self.resolve('lib64')

    def bin(self):
        return self.resolve('bin')

    def python_lib(self):
        return os.path.join(self.lib(), 'python2.7')

    def python_dynload(self):
        return os.path.join(self.python_lib(), 'lib-dynload')

    def python_dist_packages(self):
        return os.path.join(self.python_lib(), 'dist-packages')

def unzip(filename, dest_dir):
    subprocess.check_call(['unzip', '-q', filename, '-d', dest_dir])

def patch_interpreter(filename, interpreter):
    subprocess.check_call(['patchelf', '--set-interpreter', interpreter, filename])

def patch_interpreters(filenames, interpreter):
    for filename in filenames:
        patch_interpreter(filename, interpreter)

def patch_rpath(filename, rpath):
    subprocess.check_call(['patchelf', '--set-rpath', rpath, filename])

def patch_rpaths(filenames, rpath):
    def is_excluded(filename):
        return any([re.match(pattern, os.path.basename(filename)) for pattern in NO_RPATH_MODIFICATION])

    for filename in filenames:
        if not is_excluded(filename):
            patch_rpath(filename, rpath)

def list_files(dir, pattern='*'):
    full_pattern = os.path.join(dir, pattern)
    return [filename for filename in glob.glob(full_pattern) if os.path.isfile(filename)]

def ldd(filename):
    output = subprocess.check_output(['ldd', filename])

    deps = []
    for line in output.split('\n'):
        match = re.match(r'\s+[^\s]+\s+=>\s+(/[^\s]+)', line)
        if not match:
            continue
        deps.append(match.group(1))
    return deps

# Find transitive dependencies of executables and shared libraries
def find_deps(roots):
    todo = set(roots)
    seen = set(todo)
    deps = set()

    while len(todo) > 0:
        bin = todo.pop()
        for filename in ldd(bin):
            if not filename in seen:
                todo.add(filename)
                seen.add(filename)

            if not filename in roots:
                deps.add(filename)

    return deps

def install_libs(root, filenames):
    for filename in filenames:
        dest = os.path.join(root.lib(), os.path.basename(filename))
        shutil.copy(filename, dest)

def clean_python_cruf(root):
    # dist-packages contains all sorts of cruft we do not want
    python_dist_packages_dir = os.path.join(root.python_lib(), 'dist-packages')
    shutil.rmtree(root.python_dist_packages())
    os.mkdir(root.python_dist_packages())

def install_python(root):
    shutil.copy(PYTHON, root.bin())
    shutil.copytree('/usr/lib64/python2.7', root.python_lib())
    clean_python_cruf(root)

# Patch files
def patch_installed_files(install_root, container_root):
    # Patch library and executable rpaths so that dynamic linker
    # knows where to look for their dependencies
    patch_rpaths(list_files(install_root.lib()) +
                list_files(install_root.python_dynload(), pattern='*.so') +
                list_files(install_root.bin()),
                container_root.lib())

    # Change interpreter location so that the binaries know where to look
    # for *our* ld.so
    container_ld_so = os.path.join(container_root.lib(), os.path.basename(LD_SO))
    patch_interpreters(list_files(install_root.bin()), container_ld_so)

def patch_thermos_pex(install_root, original_thermos_pex, unpacked_thermos_pex_dir, thermos_shared_objects):
    # Patch Thermos executor archive
    thermos_zip = os.path.join(install_root.bin(), "thermos.zip")
    thermos_bin = os.path.join(install_root.bin(), "thermos")
    # We need to operate with thermos.zip, because zip(1) gets confused when
    # archives do not have '.zip' suffix
    shutil.copy(original_thermos_pex, thermos_zip)

    old_cwd = os.getcwd()
    try:
        os.chdir(unpacked_thermos_pex_dir)
        cmd = ['zip', thermos_zip]
        relative_filenames = [re.sub('^.*/.deps', '.deps', filename) for filename in thermos_shared_objects]
        cmd.extend(relative_filenames)
        subprocess.check_call(cmd)
    finally:
        os.chdir(old_cwd)

    shutil.move(thermos_zip, thermos_bin)

def add_libnss_symlinks(install_root):
    for filename in list_files(install_root.lib(), "libnss_*.so"):
        linkname = os.path.join(install_root.lib(), re.sub('-([\d.]+).so$', '.so.2', os.path.basename(filename)))
        if os.path.isfile(linkname):
            os.unlink(linkname)

        os.symlink(os.path.basename(filename), os.path.join(install_root.lib(), linkname))

def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: build.py THERMOS-PEX-PATH")

    pex = sys.argv[1]
    build_dir = os.path.join(os.getcwd(), 'build')
    pex_dir = os.path.join(build_dir, 'pex')

    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)

    os.makedirs(pex_dir)
    unzip(pex, pex_dir)

    thermos_shared_objects = set()
    for root, dirs, files in os.walk(pex_dir):
        thermos_shared_objects.update([os.path.join(root, filename) for filename in files if filename.endswith('.so')])

    python_shared_objects = set(list_files('/usr/lib64/python2.7/lib-dynload', pattern='*.so'))
    libnss_shared_objects = set(list_files('/lib64', pattern='libnss*.so'))

    ext_libs = set()
    # thermos shared object dependencies come from thermos .pex file
    ext_libs.update(thermos_shared_objects)
    # python shared object dependencies are installed when other python stuff is installed
    # during install_python()
    ext_libs.update(python_shared_objects)
    # python executable is also install_python()
    ext_libs.add(PYTHON)
    # libnss stuff required by libc
    ext_libs.update(libnss_shared_objects)

    # installable libs are files that are not copied to the target file system
    # some other way. For example, python dynamic libraries are copied during
    # install_python()
    installable_libs = find_deps(ext_libs)

    install_root = Root(os.path.join(build_dir, 'thermos'))
    container_root = Root('/mnt/mesos/sandbox/thermos')

    os.makedirs(install_root.bin())
    os.makedirs(install_root.lib())

    shutil.copy(LD_SO, install_root.lib())
    install_libs(install_root, installable_libs)
    install_libs(install_root, libnss_shared_objects)
    install_python(install_root)
    patch_installed_files(install_root, container_root)

    patch_rpaths(thermos_shared_objects, container_root.lib())
    patch_thermos_pex(install_root, pex, pex_dir, thermos_shared_objects)

    add_libnss_symlinks(install_root)

    # Create tarball for distribution
    subprocess.check_call(['tar', 'czf', 'build/thermos.tar.gz', '-C', 'build', 'thermos'])

if __name__ == '__main__':
    main()
