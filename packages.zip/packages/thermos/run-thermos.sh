#!/bin/sh

set -x
set -eu

SANDBOX=/mnt/mesos/sandbox
AURORA_VERSION=0.17.0

run_legacy_thermos() {
    if grep -q "Amazon" /etc/*-release; then
        echo amazon
        rm -f "$SANDBOX/thermos_executor.ubuntu1404-$AURORA_VERSION.pex"
        rm -f "$SANDBOX/thermos_executor.centos66-$AURORA_VERSION.pex"
        "$SANDBOX/thermos_executor" "$@"
    elif grep -q "Ubuntu" /etc/*-release; then
        echo ubuntu
        rm -f "$SANDBOX/thermos_executor"
        rm -f "$SANDBOX/thermos_executor.centos66-$AURORA_VERSION.pex"
        "$SANDBOX/thermos_executor.ubuntu1404-$AURORA_VERSION.pex" "$@"
    elif grep -q "Debian GNU/Linux 8 (jessie)" /etc/*-release; then
        echo "Debian GNU/Linux 8 (jessie)"
        rm -f "$SANDBOX/thermos_executor"
        rm -f "$SANDBOX/thermos_executor.centos66-$AURORA_VERSION.pex"
        "$SANDBOX/thermos_executor.ubuntu1404-$AURORA_VERSION.pex" "$@"
    elif grep -q "CentOS release 6." /etc/*-release; then
        echo centos6
        rm -f "$SANDBOX/thermos_executor"
        rm -f "$SANDBOX/thermos_executor.ubuntu1404-$AURORA_VERSION.pex"
        "$SANDBOX/thermos_executor.centos66-$AURORA_VERSION.pex" "$@"
    fi
}

apply_setuid_fix() {
    echo "non root user detected ($(id)): applying setuid fix as workaround to aurora bug (https://issues.apache.org/jira/browse/AURORA-1237)"

    MESOS_DIR="$(echo "$MESOS_DIRECTORY" | sed 's|/slaves/.*||')"
    JOB_USER="$(id -un)"

    sudo mkdir -p "$MESOS_DIR"
    sudo chown "$JOB_USER:$JOB_USER" "$MESOS_DIR"
    sudo chmod 775 "$MESOS_DIR"
    sudo chown "$JOB_USER:$JOB_USER" -R "$MESOS_SANDBOX"

    # sudo access is granted to job user in dockerfile
    sudo sed -i "/$(id -un)/d" /etc/sudoers
}

if [ "$(id -u)" != 0 ]; then
    apply_setuid_fix
fi

# Enable unified thermos executor only if the task explicitly opts in
if [ -f /.unified-thermos-executor ]; then
    echo "Using unified thermos executor"
    tar xf "$SANDBOX/thermos.tar.gz" -C "$SANDBOX"
    exec "$SANDBOX/thermos/bin/python27" "$SANDBOX/thermos/bin/thermos" "$@"
else
    echo "Defaulting to legacy thermos executor"
    run_legacy_thermos "$@"
fi
