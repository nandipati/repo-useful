#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $(basename $0) VERSION"
    exit 1
fi

VERSION="$1"

TARBALL=linkerd-$VERSION.tgz
ITERATION=${2:-1}

PATH=$PATH:/usr/local/bin
LINKERD_INSTALL_DIR=opt/linkerd/linkerd-$VERSION
PLUGINS_DIR=/tmp/build/$LINKERD_INSTALL_DIR/plugins

set -eu
set -x

# Install stuff
rpm --rebuilddb
yum install -y ruby ruby-devel ca-certificates openssl
yum groupinstall -y "Development Tools"
yum install -y java-1.8.0-openjdk
curl https://bintray.com/sbt/rpm/rpm | tee /etc/yum.repos.d/bintray-sbt-rpm.repo
yum install -y sbt
#yum install -y wget
#wget http://dl.bintray.com/sbt/rpm/sbt-0.13.8.rpm
#yum install -y sbt-0.13.8.rpm
gem install --no-ri --no-rdoc fpm

# Download linkerd tarball and prepare for plugins
curl -L -O https://github.com/linkerd/linkerd/releases/download/$VERSION/$TARBALL
mkdir -p $PLUGINS_DIR

# Build linkerd-zipkin and place jar in plugins
cd linkerd-zipkin
sbt assembly
mv plugins/linkerd-zipkin-1.4.0.jar $PLUGINS_DIR
cd ..
rm -rf linkerd-zipkin

# Build invigilator and place jar in plugins
sbt assembly
cp -r $(pwd)/target/scala-2.12/* $PLUGINS_DIR

# package linkerd and plugins into an rpm
tar xvf $TARBALL -C opt/linkerd

fpm -p linkerd-$VERSION-$ITERATION.x86_64.rpm \
    -s dir \
    -t rpm \
    --name linkerd \
    --version $VERSION \
    --architecture x86_64 \
    --iteration $ITERATION \
    --force \
    $LINKERD_INSTALL_DIR
