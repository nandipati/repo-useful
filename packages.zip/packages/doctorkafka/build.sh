#!/bin/bash
set -eu

apt-get update
apt-get -y install git maven

git clone https://github.com/hmhco/doctorkafka.git

cd doctorkafka

# Skip KafkaClusterManagerTest because it requires access to zookeeper #facepalm
mvn -Dtest='*,!KafkaClusterManagerTest' -DfailIfNoTests=false clean package

# The version is echoed to file to make packaging easier
echo "$(mvn help:evaluate -Dexpression=project.version 2>/dev/null| grep -v -E '(^\[|Down)')" > pom_version
