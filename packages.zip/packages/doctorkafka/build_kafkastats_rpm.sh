#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $(basename $0) BUILD_ITERATION"
    exit 1
fi
ITERATION="$1"

set -eu

VERSION="$(cat doctorkafka/pom_version)"

fpm -p kafkastats-$VERSION-$ITERATION.noarch.rpm \
    -s tar \
    -t rpm \
    --name kafkastats \
    --version $VERSION \
    --iteration $ITERATION \
    --prefix /opt/kafkastats \
    --architecture all \
    --force \
    doctorkafka/kafkastats/target/kafkastats-$VERSION-bin.tar.gz
