Compiling Doctorkafka & Kafkacollector
-----------------------------------------------
Compiling doctorkafka should happen with java8, and since we have a ready made java8 docker image `docker.br.hmheng.io/base-ubuntu:16.04-jdk8`.

Running command `docker run --rm -v $(pwd):/data -w /data docker.br.hmheng.io/base-ubuntu:16.04-jdk8 bash -x build.sh` will give you compiled versions of doctorkafka and kafkacollector under `doctorkafka/[drkafka|kafkastats]/target/`

Packaging Doctorkafka & Kafkacollector
-----------------------------------------------
Doctorkafka requires kafkastats to be running on broker hosts and publishing metrics to a topic where drkafka subscribes. We deploy Doctorkafka to run on mesos/aurora so it will be packaged to a docker image and kafkastats will be packaged as rpm and will be installed to brokers.

## Kafkastats RPM
`docker run --rm -v $(pwd):/data -w /data docker.br.hmheng.io/hmheng-infra/fpm:latest bash -x build_kafkastats_rpm.sh <BUILD_ITERATION>`

## Doctorkafka Docker Image
`docker build -t docker.br.hmheng.io/hmheng-infra/doctorkafka:<version> --build-arg <version>`
