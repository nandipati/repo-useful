#!/bin/sh

set -eu

docker build -t aurora-libs-build .
docker run --rm aurora-libs-build make -C /work publish
