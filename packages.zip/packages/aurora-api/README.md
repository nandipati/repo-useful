Aurora API client libraries
===========================

Building
--------

Run `./build.sh` to build *and* publish the libraries to Artifactory.

Usage
-----

``` python
#!/usr/bin/env python
from apache.aurora.common.cluster import Cluster
from apache.aurora.client.api import AuroraClientAPI

# auth_mechanism String
cluster = Cluster(name='example', scheduler_uri = 'http://10.32.98.187:8081')
api = AuroraClientAPI(cluster, 'user-agent-foo')

for name in api.list_backups().result.listBackupsResult.backups:
    print(name)
```

### Custom authentication

By default, the API client reads its authentication details from `~/.netrc` just
like Aurora CLI tools do. The authentication mechanism may be customized by
registering a new authentication module that provides appropriately configured
`requests.auth.AuthBase` instances for the client to use.

For example, one could make the client to use static username and password
as follows:

``` python
#!/usr/bin/env python
from apache.aurora.common.cluster import Cluster
from apache.aurora.client.api import AuroraClientAPI

from apache.aurora.common.auth.auth_module import AuthModule
from apache.aurora.common.auth.auth_module_manager import register_auth_module
from requests.auth import HTTPBasicAuth

# 1. Define new authentication module
class FixedAuthModule(AuthModule):
    def __init__(self, user, password):
        self.user = user
        self.password = password

    @property
    def mechanism(self):
        return 'FIXED'

    @property
    def failed_auth_message(self):
        return 'Authentication with user \'%s\' failed' % self.user

    def auth(self):
        return HTTPBasicAuth(self.user, self.password)

# 2. Register the module
register_auth_module(FixedAuthModule('hmheng-infra', 'secret'))

# 3. Specify the module to use with auth_mechanism
cluster = Cluster(name='example', scheduler_uri = 'http://10.32.98.187:8081', auth_mechanism='FIXED')
api = AuroraClientAPI(cluster, 'user-agent-foo')

for name in api.list_backups().result.listBackupsResult.backups:
    print(name)
```
