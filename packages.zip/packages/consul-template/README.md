# Consul-template

This packages the [Hashicorp's](https://github.com/hashicorp) [consul-template](https://github.com/hashicorp/consul-template).

The [configuration-file](00_config.hcl) is copied almost directly from the [README](https://github.com/hashicorp/consul-template/blob/master/README.md) which is [licensed](https://github.com/hashicorp/consul-template/blob/master/README.md) under mozilla public license.
