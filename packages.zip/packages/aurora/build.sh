#!/bin/sh

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: $(basename $0) AURORA-VERSION PACKAGING-BRANCH"
    exit 1
fi

VERSION="$1"
PACKAGING_BRANCH="$2"
TOPLEVEL=$(pwd)

set -eu

[ -d build ] && rm -rf build

mkdir build
cd build

git clone -b $PACKAGING_BRANCH https://github.com/apache/aurora-packaging
cd aurora-packaging
git apply $TOPLEVEL/amzn-support.patch.$PACKAGING_BRANCH

curl -O -L http://mirror.netinch.com/pub/apache/aurora/$VERSION/apache-aurora-$VERSION.tar.gz

./build-artifact.sh builder/rpm/amzn apache-aurora-$VERSION.tar.gz $VERSION

mv artifacts/aurora-amzn/dist/rpmbuild/RPMS/x86_64/*.rpm $TOPLEVEL/build
