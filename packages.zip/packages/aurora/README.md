aurora RPM build
----------------

Build the RPM by running `build.sh AURORA_VERSION PACKAGING_BRANCH`:


```
sudo yum install git
sudo ./build.sh 0.16.0 0.16.x
```
