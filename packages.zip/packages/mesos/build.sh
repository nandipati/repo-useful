#!/bin/sh

if [ -z "$1" ]; then
    echo "Usage: $(basename $0) MESOS-VERSION"
    exit 1
fi

MESOS_VERSION="$1"
TOPLEVEL="$(pwd)"

set -eu

yum groupinstall -y "Development Tools"

yum install -y curl \
  ca-certificates \
  python27-devel \
  zlib-devel \
  libcurl-devel \
  openssl-devel \
  cyrus-sasl-devel \
  cyrus-sasl-md5 \
  apr-devel \
  subversion-devel \
  apr-util-devel \
  libevent-devel \
  git \
  ruby \
  ruby-devel \
  gcc72-c++

curl https://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo | sed 's/\$releasever/6/' >/etc/yum.repos.d/epel-apache-maven.repo
yum install -y apache-maven

mkdir /root/.m2
cat >/etc/yum.repos.d/hmheng.repo <<EOD
[hmheng]
name=hmheng
baseurl=https://repo.br.hmheng.io/artifactory/hmheng
gpgcheck=0
enabled=1
priority=5
EOD

# Sets the maven repository to the local artifactory one.
cp settings.xml /root/.m2/

yum install -y libnl3

# build_mesos uses fpm internally
gem install --no-ri --no-rdoc fpm

curl -L -O http://archive.apache.org/dist/mesos/$MESOS_VERSION/mesos-$MESOS_VERSION.tar.gz

test -d mesos-$MESOS_VERSION && rm -rf mesos-$MESOS_VERSION
tar xf mesos-$MESOS_VERSION.tar.gz

cd mesos-$MESOS_VERSION
mkdir build
cd build
../configure --prefix=/usr --enable-ssl --enable-libevent --enable-optimize --with-network-isolator --disable-python-dependency-install
make -j1

git clone https://github.com/mesosphere/mesos-deb-packaging.git
cd mesos-deb-packaging
git checkout 6c1318af40c10756f803b4d70ac75fee921af452
# mesos-deb-packaging does not support Amazon Linux out of the box
git apply $TOPLEVEL/amzn-packaging-support.patch
cd ..

./mesos-deb-packaging/build_mesos --prebuilt --nominal-version $MESOS_VERSION --build-dir $(pwd) --src-dir $(pwd)/..

ORIG=$TOPLEVEL/mesos-$MESOS_VERSION/build/mesos-deb-packaging/pkg.rpm
FINAL=$(rpm -qip $ORIG | sed -n '/^Source RPM/s/^[^:]*: \(.*\)$/\1/p' | sed 's/\.src\./.x86_64./')

mv $ORIG $TOPLEVEL/$FINAL

# Package mesos eggs into a separate RPM so that they can be used to build Aurora
cd $TOPLEVEL
mkdir -p mesos-eggs/usr/share/mesos
cp ./mesos-$MESOS_VERSION/build/src/python/dist/*.egg mesos-eggs/usr/share/mesos

fpm -s fpm -p mesos-eggs-$MESOS_VERSION-1.x86_64.rpm \
    -s dir \
    -t rpm \
    --name mesos-eggs \
    --version $MESOS_VERSION \
    --architecture x86_64 \
    --force \
    -C mesos-eggs .
