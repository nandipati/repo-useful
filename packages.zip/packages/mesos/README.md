mesos RPM build
---------------

Build the RPM using Docker like this:

```
mkdir build
cp *.sh *.patch build
docker run --rm -v $(pwd)/build:/tmp/build docker.br.hmheng.io/base-amazon-linux:2016.03 bash -c 'cd /tmp/build && ./build.sh'
```
