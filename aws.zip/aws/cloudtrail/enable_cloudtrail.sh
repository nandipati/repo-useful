#/bin/bash

# get aws s3 bucket name and account number
read -p "enter name of existing s3 bucket (must have been created by cloudtrail): " S3_BUCKET_NAME

# Create trails in all AWS standard regions with the AWS CLI and Linux.
PROFILE="default"
CLOUDTRAIL_S3_BUCKET="${S3_BUCKET_NAME}"
REGION_FOR_GLOBAL_EVENTS="us-east-1"
regionlist=($(aws ec2 describe-regions --query Regions[*].RegionName --output text))
for region in "${regionlist[@]}"
do
if
[ $region = $REGION_FOR_GLOBAL_EVENTS ]
then
aws --profile $PROFILE --region $region cloudtrail create-trail --name $region --s3-bucket-name $CLOUDTRAIL_S3_BUCKET --include-global-service-events --output table
else
aws --profile $PROFILE --region $region cloudtrail create-trail --name $region --s3-bucket-name $CLOUDTRAIL_S3_BUCKET --no-include-global-service-events --output table
fi
aws --profile $PROFILE --region $region cloudtrail start-logging --name $region --output table
done

