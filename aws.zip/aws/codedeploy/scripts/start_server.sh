#!/bin/sh

set -o errtrace
set -o errexit
set -o nounset 

# start all salt services
for fname in minion master syndic api; do
    [ -f /etc/init.d/salt-${fname} ] && /etc/init.d/salt-${fname} start
done
