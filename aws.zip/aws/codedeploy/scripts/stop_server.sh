#!/bin/sh

set -o errtrace
set -o errexit
set -o nounset 

for fname in api syndic master minion; do
    [ -f /etc/init.d/salt-${fname} ] && /etc/init.d/salt-${fname} stop
done

