#!/bin/sh

set -o errtrace
set -o errexit
set -o nounset 

for fname in minion master syndic api; do
    if [ -f /etc/init.d/salt-${fname} ]; then
        /etc/init.d/salt-${fname} stop && sleep 1 && /etc/init.d/salt-${fname} start
    fi
done
