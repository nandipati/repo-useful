#!/usr/local/bin/python

import argparse
import sys
import logging

from yaml import safe_load, YAMLError
from hvac.exceptions import VaultError
from hvac import Client
from boto3 import client, exceptions
from os import environ
from botocore.exceptions import NoCredentialsError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_roles(role_file):
    stream = file('../saltstack/pillars/users/deployment/init.sls', 'r')

    try:
        data = safe_load(stream)
    except YAMLError, exc:
        logger.info("Error in loading %s file: %s" % (role_file, exc))
        return False

    roles = []
    for role in data['user']['roles']:
        roles.append(role)

    return sorted(roles)


def get_sans(stage, roles, domain, cn):
    sans = []
    for role in roles:
        san = ".".join(["*", stage, role, domain])
        sans.append(san)
    logger.info("%s SAN list: %s" % (cn, sans))
    return sans


def get_cert(path, domain, cn, ttl, sans, exclude_cn_from_sans):
    try:
        response = Client(
            url=environ['VAULT_ADDR'],
            token=environ['VAULT_TOKEN'],
            verify=False                        # to be removed when vault ssl cert is fixed
        ).write(
            '%s/issue/%s' % (path, domain),
            common_name=cn,
            ttl=ttl,
            alt_names=','.join(sans),
            exclude_cn_from_sans=exclude_cn_from_sans
        )
        logger.debug(response)
        logger.info("Success writing certificate request to Vault for %s: %s" % (cn, response['data']['serial_number']))
        return response
    except VaultError, e:
        logger.error("Error writing certificate request to Vault for %s: %s" % (cn, e))
        return False


def acm_import_cert(cert, cn):
    try:
        response = client('acm').import_certificate(
            Certificate=cert['data']['certificate'].encode('utf-8'),
            PrivateKey=cert['data']['private_key'].encode('utf-8'),
            CertificateChain=cert['data']['ca_chain'][0].encode('utf-8')
        )
        logger.debug(response)
        logger.info("Success writing certificate to ACM for %s: %s" % (cn, response['CertificateArn']))
        return response
    except exceptions.Boto3Error, e:
        logger.error("Error importing certificate to ACM for %s: %s" % (cn, e))
    except NoCredentialsError, e:
        logger.error("AWS ACM client auth error: %s" % e)

    return False


def _add_routing_args(subparser):
    subparser.add_argument(
        '-s',
        action='append',
        dest='stage',
        choices=[
            'devel',        # dev
            'staging0',     # int
            'staging1',     # cert
            'staging2',     # certrv
            'staging3',     # prodrv
            'staging4',     # uat
            'staging7',     # cert2
            'prod',         # prod
        ],
        help='Stage to generate certificate for.  Multiple stages can be defined via -stage <stage1> -stage <stage2>.'
    )

    subparser.add_argument(
        '-i',
        dest='int_path',
        choices=['acm_int_br_internal', 'acm_int_brdev_internal'],
        help='Path to the Vault Intermediate that will be signing the certificates'
    )

    subparser.add_argument(
        '-t',
        dest='ttl',
        default=31449600,
        help='TTL (seconds) for certificate to be generated.  Default = 31449600 (364 days)',
    )

    subparser.add_argument(
        '-d',
        choices=['br.internal', 'brdev.internal'],
        dest='domain',
        help='Root domain of certificates to be generated.  ie. br.internal or brdev.internal'
    )

    subparser.add_argument(
        '-r',
        dest='role_file',
        default='../saltstack/pillars/users/deployment/init.sls',
        help='Yaml file containing the roles to be parsed to create certificate SANS.'
    )


def _add_api_args(subparser):
    subparser.add_argument(
        '-s',
        action='append',
        dest='stage',
        choices=[
            'dev',
            'int',
            'cert',
            'certrv',
            'prodrv',
            'uat',
            'cert2',
            'prod',
        ],
        help='Stage to generate certificate for.  Multiple stages can be defined via -stage <stage1> -stage <stage2>.'
    )

    subparser.add_argument(
        '-i',
        dest='int_path',
        choices=['acm_int_br_internal', 'acm_int_brdev_internal', 'acm_int_engdev_hmhco_internal'],
        help='Path to the Vault Intermediate that will be signing the certificates'
    )

    subparser.add_argument(
        '-t',
        dest='ttl',
        default=31449600,
        help='TTL (seconds) for certificate to be generated.  Default = 31536000 (1 year)',
    )

    subparser.add_argument(
        '-d',
        choices=['br.internal', 'brdev.internal', 'engdev.hmhco.internal'],
        dest='domain',
        help='Root domain of certificates to be generated.  ie. br.internal or brdev.internal'
    )


def parse_args():
    parser = argparse.ArgumentParser(
        description='Generate Vault SSL Certificate & Import to ACM',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    subparser = parser.add_subparsers(
        dest='command',
        help='Available SSL Certificate Types'
    )

    routing_parser = subparser.add_parser(
        'routing',
        help='Generate routing wildcard certificate for all stages and roles (ie. *.<stage>.<role>.br.internal)'
    )
    _add_routing_args(routing_parser)

    api_parser = subparser.add_parser(
        'api',
        help='Generate api single site certificate for all stages (ie. api.<stage>.br.internal)'
    )
    _add_api_args(api_parser)

    return parser.parse_args()


def routing(args):
    roles = get_roles(args.role_file)
    for stage in args.stage:
        cn = "%s.role.%s" % (stage, args.domain)
        exclude_cn_from_sans = True
        sans = get_sans(stage, roles, args.domain, cn)
        cert = get_cert(args.int_path, args.domain, cn, args.ttl, sans, exclude_cn_from_sans)

        if cert:
            response = acm_import_cert(cert, cn)
            if not response or response['ResponseMetadata']['HTTPStatusCode'] != 200:
                return 1
    return 0


def api(args):
    for stage in args.stage:
        if stage == 'prod':
            cn = "api.%s" % args.domain
        else:
            cn = "api.%s.%s" % (stage, args.domain)
        logger.info("cn for %s: %s" % (stage, cn))

        cert = get_cert(args.int_path, args.domain, cn, args.ttl, sans=[], exclude_cn_from_sans=False)

        if cert:
            response = acm_import_cert(cert, cn)
            if not response or response['ResponseMetadata']['HTTPStatusCode'] != 200:
                return 1
    return 0


def main():
    dispatch = {
        'routing': routing,
        'api': api,
    }

    args = parse_args()

    try:
        sys.exit(dispatch[args.command](args))
    except KeyError, e:
        logger.error('Missing Key Value for "%s"' % e)


if __name__== "__main__":
    main()
