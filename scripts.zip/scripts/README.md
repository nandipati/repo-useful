# csalt - containerized SaltStack

`csalt` spawns a container for testing Bedrock Salt configuration. The container
must first be started, and it will exist until it is explicitly stopped.

## Usage

0. Build a `csalt` Docker image `cd docker/salt-minion && docker build -t salt-minion .`

1. Spawn a new container and specify `salt_role` to use for that container: `./scripts/csalt start deploy.console`

2. Use `run` command to run `salt-call`: `./scripts/csalt run salt-call state.show_highstate`. Alternatively
   you can open an interactive shell with `./scripts/csalt shell`.
   
3. Kill the running container with `./scripts/csalt stop`

## Runtime environment

The container is configured similarly to Bedrock AWS instances. The most
relevant configuration are the EC2 tag grains:

  * `salt_role`: Set based on the role passed to `csalt start`
  * `environemnt`: Always `local` (consequently `pilla.env.dev` is `true` when running under `csalt`)
  
The remaining configuration may be inspected with `./scripts/csalt run salt-call grains.items`.

## Modifying Salt states to work with csalt

`ec2:tags:environment` grain will always be `local` when running with `csalt1.
