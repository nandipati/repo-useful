# REMEMBER TO SET ONE OF:
# export VAULT_TOKEN=xxx-brcore-token-xxx CONSUL_HTTP_ADDR=https://consul.br.internal
# export VAULT_TOKEN=xxx-brdev-token-xxxx CONSUL_HTTP_ADDR=https://consul.brdev.internal

cat << EOF > sherpa-policy.txt
path "sys/*" {
  capabilities = ["read"]
}

path "hmheng-infra/*" {
  capabilities = ["create", "read", "update", "list"]
}

path "auth/token/*" {
  capabilities = ["create", "read", "update"]
}

path "token/*" {
  capabilities = ["create", "read", "update"]
}
EOF

### All 8 stages
for stg in dev int cert cert2 certrv uat prodrv prod; do for role in sherpa.intl.$stg sherpa.extl.$stg; do echo "----- $role ------"; vault policy write $role sherpa-policy.txt; vault write auth/aws/role/$role auth_type=ec2 policies=bedorck_aws,default,invigilator,$role bound_account_id=711638685743 max_ttl=2764800 ttl=2764800 period=168h bound_region=us-east-1 resolve_aws_unique_ids=true; done; done
