package com.hmhco.lambda.assignment.security;

import com.hmhco.lambda.assignment.AssignmentstatusApplicationTests;
import com.hmhpub.common.token.auth.SIFAuthorization;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

import static org.junit.Assert.assertNotNull;

/**
 * Created by odowdj on 27 June 2016.
 */
@Ignore //due to loading beans from camel context, tests needs to be rewritten
public class AuthorizationServiceImplTest extends AssignmentstatusApplicationTests {

    @Autowired
    private AuthorizationServiceImpl authorizationService;

    @Test
    public void testCreateSIFAuthorization() {
        SIFAuthorization sifAuthorization = authorizationService.createSIFAuthorization();
        assertNotNull(sifAuthorization);
    }

    @Test
    public void testGetHeaders() {
        Map<String, String> headers = authorizationService.getHeaders();
        assertNotNull(headers.get(SIFAuthorization.AUTHORIZATION));
        assertNotNull(headers.get(SIFAuthorization.SIF_AUTH_DATE_HDR));
    }
}