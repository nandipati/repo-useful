package com.hmhco.lambda.assignment.aws.lambda;

import com.amazonaws.util.Base64;
import com.google.gson.Gson;
import com.hmhco.lambda.assignment.service.JsonUtils;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by odowdj on 17 June 2016.
 */
public class LearnosityEventTest {

    private static final Gson gson = new Gson();

    @Test
    public void testEquals() {
        String eventValue = "session-started";
        String sessionId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String activityId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String userId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String time = "2016-06-16 10:52:43";

        String json = "{\"event\":\""+eventValue+"\",\"session_id\":\""+sessionId+"\",\"activity_id\":\""+activityId+"\",\"user_id\":\""+userId+"\",\"time\":\""+time+"\"}";
        LearnosityEvent event1 = gson.fromJson( json, LearnosityEvent.class);
        LearnosityEvent event2 = gson.fromJson( json, LearnosityEvent.class);
        
        Set<LearnosityEvent> learnosityEventSet = new HashSet<>();
        learnosityEventSet.add(event1);
        learnosityEventSet.add(event2);
        
        Assert.assertEquals(1, learnosityEventSet.size());

        String sessionId2 = "e877e8ba-9b2e-4e26-84b0-3f61008954b9";

        String json3 = "{\"event\":\""+eventValue+"\",\"session_id\":\""+sessionId2+"\",\"activity_id\":\""+activityId+"\",\"user_id\":\""+userId+"\",\"time\":\""+time+"\"}";
        LearnosityEvent event3 = gson.fromJson( json3, LearnosityEvent.class);
        learnosityEventSet.add(event3);
        Assert.assertEquals(2, learnosityEventSet.size());
        List<String> sessionIdsInSet = learnosityEventSet.stream().map(LearnosityEvent::getSession_id).collect(Collectors.toList());
        Assert.assertTrue(sessionIdsInSet.contains(sessionId));
        Assert.assertTrue(sessionIdsInSet.contains(sessionId2));

    }
    
    @Test
    public void convertToJson() {
        String eventValue = "session-started";
        String sessionId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String activityId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String userId = "e877e8ba-9b2e-4e26-84b0-3f61008954b8";
        String time = "2016-06-16 10:52:43";

        String json = "{\"event\":\""+eventValue+"\",\"session_id\":\""+sessionId+"\",\"activity_id\":\""+activityId+"\",\"user_id\":\""+userId+"\",\"time\":\""+time+"\"}";
        LearnosityEvent event = gson.fromJson( json, LearnosityEvent.class);
        Assert.assertEquals(event.getEvent(), eventValue);
        Assert.assertEquals(event.getSession_id(), sessionId);
        Assert.assertEquals(event.getActivity_id(), activityId);
        Assert.assertEquals(event.getUser_id(), userId);
        Assert.assertEquals(event.getTime(), time);
        String delay =  JsonUtils.getDelayInfo(event);
        System.out.println(delay);
    }

    @Test
    public void jsonToByteBuffer(){
        String json = "{\"event\":\"session-started\",\"session_id\":\"e877e8ba-9b2e-4e26-84b0-3f61008954b8\",\"activity_id\":\"245895e5-c48a-3b22-afb5-adf74765c4ef\",\"user_id\":\"3e697c46-e706-40e7-8903-3ccc20127ab1\",\"time\":\"2016-06-16 10:52:43\"}";
        byte [] encoded = Base64.encode(json.getBytes());
        System.out.print(new String(encoded));
    }
}