package com.hmhco.lambda.assignment.service;

import com.hmhco.lambda.assignment.AssignmentstatusApplicationTests;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEventTestUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by odowdj on 20 June 2016.
 */
@Ignore
public class AssignmentServiceImplIntegrationTest extends AssignmentstatusApplicationTests {


    @Autowired
    private AssignmentServiceImpl assignmentService;


    @Test
    public void testSetStatus() throws Exception {
        List<LearnosityEvent> learnosityEventList = LearnosityEventTestUtils.generateLearnosityEventList(1);
        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> learnosityEventsGrouped = LearnosityEventTestUtils.convertToMap(learnosityEventList);
        assignmentService.updateActivitiesStatus(Profile.DEV, learnosityEventsGrouped);
    }


}