package com.hmhco.lambda.assignment.service;

import com.hmhco.lambda.assignment.AbstractUnitTest;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEventTestUtils;
import com.hmhco.lambda.assignment.aws.lambda.StatusResponse;
import com.hmhco.lambda.assignment.eventservice.EventServiceImpl;
import com.hmhco.lambda.assignment.parallelc.ParallelcUtils;
import com.hmhco.lambda.assignment.security.AuthorizationServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Created by odowdj on 20 June 2016.
 */
public class AssignmentServiceImplUnitTest extends AbstractUnitTest {

    @Mock
    private AuthorizationServiceImpl authorizationService;

    @Mock
    private EventServiceImpl eventService;

    @Mock
    private ParallelcUtils parallelcUtils;

    @InjectMocks
    private AssignmentServiceImpl assignmentService = new AssignmentServiceImpl();

    @Test(expected = RuntimeException.class)
    public void failLambda_NAResponse() {
        int amount = 6;
        List<LearnosityEvent> learnosityEventList = LearnosityEventTestUtils.generateLearnosityEventList(amount);
        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> learnosityEventMap = LearnosityEventTestUtils.convertToMap(learnosityEventList);
        StatusResponse statusResponse = assignmentService.updateActivitiesStatus(Profile.DEV, learnosityEventMap);
        System.out.println(statusResponse);
        Assert.assertTrue(statusResponse.getMessage().contains("Processed eventtype["));
        verify(eventService,times(2)).publish(eq(Profile.DEV), anyString(), any(List.class)); //twice, once for all start failures and once for all complete failures
    }

    
}