package com.hmhco.lambda.assignment;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
/**
 * Created by odowdj on 27 June 2016.
 */
public class ProfileTest {

    @Test
    public void testFindByFunctionName() {
        String functionName = "rsnp-int-kinesis-hmhone-assessment-status";
        Profile profile = Profile.findByFunctionName(functionName);
        assertEquals(Profile.INT, profile);

        functionName = "rsnp-int-kinesis-hmhone-assessment-status";
        profile = Profile.findByFunctionName(functionName);
        assertEquals(Profile.INT, profile);

        functionName = "rsnp-prod-kinesis-hmhone-assessment-status";
        profile = Profile.findByFunctionName(functionName);
        assertEquals(Profile.PROD, profile);
    }
}