package com.hmhco.lambda.assignment.aws.lambda;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;


public class LearnosityEventTestUtils {
    
    public static Map<LearnosityEvent.EventType, Set<LearnosityEvent>> convertToMap(List<LearnosityEvent> learnosityEventList){
        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> learnosityEventMap = new HashMap<>();
        learnosityEventList.stream().forEach( learnosityEvent -> {
            LearnosityEvent.EventType eventType = learnosityEvent.getEventType();
            Set<LearnosityEvent> learnosityEventsSet = learnosityEventMap.get(eventType);
            if(learnosityEventsSet==null) {
                learnosityEventsSet = new HashSet<>();
            }
            
            learnosityEventsSet.add(learnosityEvent);
            
            learnosityEventMap.put(eventType, learnosityEventsSet);
        } );
        return learnosityEventMap;
    }

    public static List<LearnosityEvent> generateLearnosityEventList(int count) {
        List<LearnosityEvent> learnosityEventList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            LearnosityEvent learnosityEvent = new LearnosityEvent();
            learnosityEvent.setSession_id(UUID.randomUUID().toString());
            LearnosityEvent.EventType eventType = (i % 2 == 0) ? LearnosityEvent.EventType.STARTED : LearnosityEvent.EventType.COMPLETED;
            learnosityEvent.setEvent(eventType.getValue());
            learnosityEvent.setTime("2016-06-16 10:52:43");
            learnosityEventList.add(learnosityEvent);
        }
        return learnosityEventList;
    }
}