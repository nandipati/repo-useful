package com.hmhco.lambda.assignment.eventservice;

import com.google.gson.Gson;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.service.AssignmentServiceResponse;
import org.junit.Test;

import java.util.UUID;

/**
 * Created by odowdj on 06 July 2016.
 */
public class EventPublishRequestTest {

    private final Gson gson = new Gson();

    @Test
    public void testJson() throws Exception {
        LearnosityEvent learnosityEvent = new LearnosityEvent();
        learnosityEvent.setActivity_id("my id");
        learnosityEvent.setEvent(LearnosityEvent.EventType.STARTED.name());
        learnosityEvent.setSession_id(UUID.randomUUID().toString());
        learnosityEvent.setUser_id(UUID.randomUUID().toString());
        AssignmentServiceResponse assignmentServiceResponse = new AssignmentServiceResponse("200", learnosityEvent);
        EventPublishRequest eventPublishRequest = new EventPublishRequest("my_topic", assignmentServiceResponse);
        String body = gson.toJson(eventPublishRequest);
        System.out.println(body);
    }
}