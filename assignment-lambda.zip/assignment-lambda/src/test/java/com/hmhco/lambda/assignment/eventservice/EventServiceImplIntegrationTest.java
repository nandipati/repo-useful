package com.hmhco.lambda.assignment.eventservice;

import com.google.common.collect.Lists;
import com.hmhco.lambda.assignment.AssignmentstatusApplicationTests;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.service.AssignmentServiceImpl;
import com.hmhco.lambda.assignment.service.AssignmentServiceResponse;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.UUID;

@Ignore
public class EventServiceImplIntegrationTest  extends AssignmentstatusApplicationTests {

    @Autowired
    private EventServiceImpl eventService = new EventServiceImpl();
    
    @Test
    public void testHttpsPublish() {
        String sessionId = UUID.randomUUID().toString();
        LearnosityEvent learnosityEvent = new LearnosityEvent();
        learnosityEvent.setSession_id(sessionId);
        learnosityEvent.setActivity_id(UUID.randomUUID().toString());
        learnosityEvent.setEvent(LearnosityEvent.EventType.STARTED.getValue());
        learnosityEvent.setUser_id(UUID.randomUUID().toString());
        learnosityEvent.setTime("2016-06-16 10:52:43");
        String responseError = "SingleTaskResponse [request=TaskRequest [actorMaxOperationTimeoutSec=15, resourcePath=/hmh1assignments/v2/activities/71830696-9a13-4d25-811b-7cebdc330e89/submit, requestContent=, httpMethod=PUT, pollable=false, httpHeaderMap={Authorization=SIF_HMACSHA256 UVhUbnBIbV9EN05lNXJTLmhtaGNvLmNvbTp1SW04M3dud01sR3d6OGJKaUVmRGxJc1h1RmVQd0hDenRLa0x0cFFSQkFzPQo=, authCurrentDateTime=2016-09-12T18:15:57.284Z}, protocol=https, host=API_0, hostUniform=assignment.api.hmhco.com, port=443, sshMeta=null], responseContent=null, receiveTime=2016.09.12.18.16.06.330+0000, receiveTimeInManager=2016.09.12.18.16.06.330+0000, error=true, errorMessage=java.util.concurrent.TimeoutException: No response received after 14000, stackTrace=java.util.concurrent.TimeoutException: No response received after 14000 at com.ning.http.client.providers.jdk.JDKAsyncHttpProvider$AsyncHttpUrlConnection.filterException(JDKAsyncHttpProvider.java:441) " +
                "at com.ning.http.client.providers.jdk.JDKAsyncHttpProvider$AsyncHttpUrlConnection.call(JDKAsyncHttpProvider.java:401) " +
                "at java.util.concurrent.FutureTask.run(FutureTask.java:266) " +
                "at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142) " +
                "at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617) " +
                "at java.lang.Thread.run(Thread.java:745) " +
                ", statusCode=NA, operationTimeMillis=9026, pollingHistoryMap= " +
                "{}]";
        AssignmentServiceResponse assignmentServiceResponse = new AssignmentServiceResponse(HttpStatus.NOT_FOUND.toString(), learnosityEvent, responseError);
        String assignmentEndpoint = AssignmentServiceImpl.START_RESOURCE;
        try{
            eventService.publish(Profile.DEV, assignmentEndpoint, Lists.newArrayList(assignmentServiceResponse,assignmentServiceResponse,assignmentServiceResponse,assignmentServiceResponse));
        }catch(Exception e){
            System.out.println("error: "+e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Done");

    }
}