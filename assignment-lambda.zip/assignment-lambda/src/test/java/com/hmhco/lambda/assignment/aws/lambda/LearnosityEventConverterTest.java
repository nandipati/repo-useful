package com.hmhco.lambda.assignment.aws.lambda;

import com.amazonaws.services.lambda.runtime.events.KinesisEvent;
import com.google.gson.Gson;
import org.junit.Assert;
import org.junit.Test;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by odowdj on 29 June 2016.
 */
public class LearnosityEventConverterTest {

    private final Gson gson = new Gson();

    @Test
    public void checkSessionIds() {
        int recordsAmount = 6;
        List<LearnosityEvent> learnosityEventList = LearnosityEventTestUtils.generateLearnosityEventList(recordsAmount);
        KinesisEvent kinesisEvent = buildKinesisEvent(learnosityEventList);
        

        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> eventsByType = LearnosityEventConverter.getEventsByType(kinesisEvent);

        int verified = 0;

        for (Map.Entry<LearnosityEvent.EventType, Set<LearnosityEvent>> eventTypeSetEntry : eventsByType.entrySet()) {
            LearnosityEvent.EventType eventType = eventTypeSetEntry.getKey();
            Set<LearnosityEvent> learnosityEventsSet = eventTypeSetEntry.getValue();
            //put list of session ids into list...
            List<String> sessionIdList = learnosityEventsSet.stream().map(LearnosityEvent::getSession_id).collect(Collectors.toList());
            for (String sessionId : sessionIdList) {
                for (LearnosityEvent learnosityEvent : learnosityEventList) {
                    if(sessionId.equals(learnosityEvent.getSession_id())){
                        Assert.assertEquals(learnosityEvent.getEventType(), eventType);
                        verified++;
                    }
                }
            }
        }
        Assert.assertEquals(recordsAmount, verified);
    }


    private KinesisEvent buildKinesisEvent(List<LearnosityEvent> learnosityEventList){
        KinesisEvent kinesisEvent = new KinesisEvent();
        List<KinesisEvent.KinesisEventRecord> kinesisEventRecords = new ArrayList<>(learnosityEventList.size());
        for (LearnosityEvent learnosityEvent : learnosityEventList) {
            KinesisEvent.Record kinesisRecord = new KinesisEvent.Record();
            String json = gson.toJson(learnosityEvent);
            kinesisRecord.setData(ByteBuffer.wrap(json.getBytes()));
            KinesisEvent.KinesisEventRecord kinesisEventRecord = new KinesisEvent.KinesisEventRecord();
            kinesisEventRecord.setKinesis(kinesisRecord);
            kinesisEventRecords.add(kinesisEventRecord);
        }
        kinesisEvent.setRecords(kinesisEventRecords);
        return kinesisEvent;
    }
}