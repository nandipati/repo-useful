package com.hmhco.lambda.assignment.eventservice;

import com.google.common.collect.Lists;
import com.hmhco.lambda.assignment.AbstractUnitTest;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.config.EnvConfig;
import com.hmhco.lambda.assignment.config.LambdaConfigUtils;
import com.hmhco.lambda.assignment.parallelc.ParallelcUtils;
import com.hmhco.lambda.assignment.security.AuthorizationServiceImpl;
import com.hmhco.lambda.assignment.service.AssignmentServiceImpl;
import com.hmhco.lambda.assignment.service.AssignmentServiceResponse;
import io.parallec.core.ParallecResponseHandler;
import io.parallec.core.ParallelClient;
import io.parallec.core.ParallelTask;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.UUID;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by odowdj on 29 June 2016.
 */
@Ignore
public class EventServiceImplTest extends AbstractUnitTest {

    @Mock
    private AuthorizationServiceImpl authorizationService;

    @InjectMocks
    private ParallelcUtils parallelcUtils = new ParallelcUtils();

//    @Mock
    private ParallelClient pc = new ParallelClient();

    @InjectMocks
    private EventServiceImpl eventService = new EventServiceImpl();

    @Before
    public void setup(){
        super.setup();
        when(pc.prepareHttpPost(anyString()).execute(any(ParallecResponseHandler.class))).thenReturn(new ParallelTask());
        ReflectionTestUtils.setField(eventService, "parallelcUtils", parallelcUtils);
        ReflectionTestUtils.setField(eventService, "pc", pc);
    }

    @Test
    public void testHttpPublish() {
        String sessionId = UUID.randomUUID().toString();
        LearnosityEvent learnosityEvent = new LearnosityEvent();
        learnosityEvent.setSession_id(sessionId);
        AssignmentServiceResponse assignmentServiceResponse = new AssignmentServiceResponse(HttpStatus.NOT_FOUND.toString(), learnosityEvent);
        String assignmentEndpoint = AssignmentServiceImpl.START_RESOURCE;
        try{
            eventService.publish(Profile.DEV, assignmentEndpoint, Lists.newArrayList(assignmentServiceResponse));
        }catch(Exception e){}


        ArgumentCaptor<EnvConfig> envConfigArgumentCaptor = ArgumentCaptor.forClass(EnvConfig.class);
        ArgumentCaptor<EnvConfig> envConfigArgumentCaptor2 = ArgumentCaptor.forClass(EnvConfig.class);
        try {
            verify(parallelcUtils,times(1)).getRequestProtocol(envConfigArgumentCaptor.capture());
            EnvConfig envConfigArgumentCaptorValue = envConfigArgumentCaptor.getValue();
            EnvConfig envConfig = LambdaConfigUtils.getEnvConfig(Profile.DEV);
            String expectedHost = envConfig.getEventservice().getHost();
            String expectedProtocol = envConfig.getProtocol();
            Assert.assertEquals(expectedHost, envConfigArgumentCaptorValue.getEventservice().getHost());
            Assert.assertEquals(expectedHost, EVENTSERVICE_HOST);
            Assert.assertEquals(expectedProtocol, envConfigArgumentCaptorValue.getProtocol());
            Assert.assertEquals(expectedProtocol, HTTP);

            verify(parallelcUtils,times(1)).getPort(envConfigArgumentCaptor2.capture());
            EnvConfig envConfigArgumentCaptor2Value = envConfigArgumentCaptor2.getValue();
            int expectedPort = envConfig.getPort();
            Assert.assertEquals(expectedPort, envConfigArgumentCaptor2Value.getPort());
            Assert.assertEquals(expectedPort, ParallelcUtils.DEFAULT_HTTP_PORT);
            Assert.assertEquals(EventServiceImpl.TOPIC_AL_ACTIVITYSTART_FAIL, eventService.getTopic(assignmentEndpoint));

        } catch (Exception e) {
            fail();
        }
    }
}