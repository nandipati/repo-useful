package com.hmhco.lambda.assignment;

import com.hmhco.lambda.assignment.config.AssignmentConfig;
import com.hmhco.lambda.assignment.config.EnvConfig;
import com.hmhco.lambda.assignment.config.EventServiceConfig;
import com.hmhco.lambda.assignment.config.LambdaConfigUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.mockito.Matchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * LambdaConfig is a static class, which is why we need to Mock it
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest(LambdaConfigUtils.class)
public class AbstractUnitTest {

    protected static String HTTP = "http";
    protected static String ASSIGNMENT_HOST = "assignment-host";
    protected static String EVENTSERVICE_HOST = "eventservice-host";

    @Rule
    public MockitoRule mockitoRule = MockitoJUnit.rule();

    @Before
    public void setup(){
        PowerMockito.mockStatic(LambdaConfigUtils.class);
        EnvConfig envConfig = new EnvConfig();
        envConfig.setProtocol(HTTP);
        //envConfig.setPort();// don't set port on purpose to test default port logic
        AssignmentConfig assignmentConfig = new AssignmentConfig();
        assignmentConfig.setHost(ASSIGNMENT_HOST);
        EventServiceConfig eventServiceConfig = new EventServiceConfig();
        eventServiceConfig.setHost(EVENTSERVICE_HOST);
        envConfig.setAssignments(assignmentConfig);
        envConfig.setEventservice(eventServiceConfig);
        when(LambdaConfigUtils.getEnvConfig(any(Profile.class))).thenReturn(envConfig);
    }

}