package com.hmhco.lambda.assignment.aws.lambda;

import com.amazonaws.services.lambda.runtime.events.KinesisEvent;
import com.amazonaws.util.Base64;
import com.amazonaws.util.StringUtils;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LearnosityEventConverter {

    private static final Logger log = LoggerFactory.getLogger(LearnosityEventConverter.class);

    private static final Gson gson = new Gson();

    /**
     * Returns a Map with two records, 1 for started and 1 for completed.
     * A record is
     * @param kinesisEvent
     * @return
     */
    public static Map<LearnosityEvent.EventType, Set<LearnosityEvent>> getEventsByType(KinesisEvent kinesisEvent){
        log.debug("+getEventsByType kinesisEvent["+kinesisEvent+"]");
        Set<LearnosityEvent> startedEventsSet = new HashSet<>();
        Set<LearnosityEvent> completedEventsSet = new HashSet<>();
        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> eventsGroupedMap = new HashMap<>();

        if(kinesisEvent!=null){
            log.debug("kinesisEvent.getRecords().size=="+kinesisEvent.getRecords().size());
            for(KinesisEvent.KinesisEventRecord rec : kinesisEvent.getRecords()){
                String encodedStr = StringUtils.fromByteBuffer(rec.getKinesis().getData());
                log.debug("encodedStr["+encodedStr+"]");
                String decodedStr = new String(Base64.decode(encodedStr));
                log.info("decodedStr["+decodedStr+"]");
                try {
                    LearnosityEvent learnosityEvent = gson.fromJson( decodedStr, LearnosityEvent.class);
                    LearnosityEvent.EventType eventType = learnosityEvent.getEventType();
                    log.debug("eventType["+eventType+"] payload["+learnosityEvent.toString()+"]");
                    switch (eventType){
                        case STARTED:
                            startedEventsSet.add(learnosityEvent);
                            break;
                        case COMPLETED:
                            completedEventsSet.add(learnosityEvent);
                            break;
                        default:
                            log.error("ERROR: No logic for learnosityEvent type "+eventType.getValue());
                    }
                } catch (JsonSyntaxException e) {
                    e.printStackTrace();
                    log.error("ERROR: Could not marshal to LearnosityEvent - payload is ["+decodedStr+"]");
                }
            }
            eventsGroupedMap.put(LearnosityEvent.EventType.STARTED, startedEventsSet);
            eventsGroupedMap.put(LearnosityEvent.EventType.COMPLETED, completedEventsSet);
        }
        log.debug("-getEventsByType kinesisEvent["+kinesisEvent+"]");
        return eventsGroupedMap;
    }



}
