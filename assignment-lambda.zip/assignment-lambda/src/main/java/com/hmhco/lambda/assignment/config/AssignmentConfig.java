package com.hmhco.lambda.assignment.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties
public class AssignmentConfig {
    private String host;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    @Override
    public String toString() {
        return "AssignmentConfig{host["+host+"]}";
    }
}
