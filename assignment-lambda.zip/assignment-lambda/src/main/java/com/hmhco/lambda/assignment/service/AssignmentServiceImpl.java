package com.hmhco.lambda.assignment.service;

import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import com.hmhco.lambda.assignment.aws.lambda.StatusResponse;
import com.hmhco.lambda.assignment.config.EnvConfig;
import com.hmhco.lambda.assignment.config.LambdaConfigUtils;
import com.hmhco.lambda.assignment.eventservice.EventServiceImpl;
import com.hmhco.lambda.assignment.parallelc.ParallelcUtils;
import io.parallec.core.ParallelClient;
import io.parallec.core.RequestProtocol;
import io.parallec.core.util.PcConstants;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class AssignmentServiceImpl {
    private static final Logger log = LoggerFactory.getLogger(AssignmentServiceImpl.class);
    private final String SESSION_ID_VAR = "SESSION_ID";
    private final String ACTIVITIES_ENDPOINT = "/v2/activities/";
    public static final String SUBMIT_RESOURCE = "/submit";
    public static final String START_RESOURCE = "/start";
    private final int retryAttempts = 3;
    private final int delay_milliseconds = 5000;
    private final String STATUS_CODE_504_GATEWAY_TIMEOUT = "504 GATEWAY_TIMEOUT";

    private final ParallelClient pc = new ParallelClient();

    @Autowired
    private ParallelcUtils parallelcUtils;

    @Autowired
    private EventServiceImpl eventService;

    /**
     * Action the sessionIds. The action is dependant on the event type
     * @param profile
     * @param learnosityEventsMap
     * @return
     */
    public StatusResponse updateActivitiesStatus(Profile profile, Map<LearnosityEvent.EventType, Set<LearnosityEvent>> learnosityEventsMap){
        log.info("+updateActivitiesStatus profile["+profile+"] learnosityEventsMap["+learnosityEventsMap+"]");
        EnvConfig envConfig = LambdaConfigUtils.getEnvConfig(profile);
        log.info("~updateActivitiesStatus envConfig["+envConfig+"]");
        
        //order is important, execute the learnosityEvents then completed session ids...
        String message = processSessionIds(profile, learnosityEventsMap, envConfig, LearnosityEvent.EventType.STARTED);
        message += processSessionIds(profile, learnosityEventsMap, envConfig, LearnosityEvent.EventType.COMPLETED);
        
        log.info("-updateActivitiesStatus profile["+profile+"] learnosityEventsMap["+learnosityEventsMap+"]");
        return new StatusResponse(message);
    }

    private String processSessionIds(Profile profile, Map<LearnosityEvent.EventType, Set<LearnosityEvent>> eventTypeMap, EnvConfig envConfig, LearnosityEvent.EventType eventType) {
        String lambdaResponseBody = "";
        Set<LearnosityEvent> learnosityEvents = eventTypeMap.get(eventType);
        //Map<SessionId, Learnosity Event assosicated with that Session Id>
        Map<String, LearnosityEvent> sessionId_LearnosityEventMap = (learnosityEvents!=null) ? learnosityEvents.stream().collect(Collectors.toMap(LearnosityEvent::getSession_id, Function.identity())) : null;
        if(!CollectionUtils.isEmpty(sessionId_LearnosityEventMap)){
            putRequest(profile, envConfig, eventType, sessionId_LearnosityEventMap);
            lambdaResponseBody = "Processed eventtype["+eventType.getValue()+"] sessionIds["+sessionId_LearnosityEventMap.keySet()+"]\n";    
        }
        return lambdaResponseBody;        
    }


    private String getStartOrSubmitEndpoint(LearnosityEvent.EventType eventType){
        String assignmentEndpoint;
        switch(eventType) {
            case STARTED:
                assignmentEndpoint = START_RESOURCE;
                break;
            case COMPLETED:
                assignmentEndpoint = SUBMIT_RESOURCE;
                break;
            default:
                log.error("ERROR: Unknown assignmentEndpoint for event type ["+eventType+"]");
                throw new NotImplementedException("Unknown assignmentEndpoint for event type ["+eventType+"]");
        }
        return assignmentEndpoint;
    }

    /**
     * Send PUT request to Resource for the following sessionIdList.
     * Update the sessionIds accordingly to be either Started or Submitted.
     * Errors are logged
     * @param profile
     * @param envConfig
     * @param eventType
     * @param sessionId_LearnosityEventsMap
     */
    private void putRequest(Profile profile, EnvConfig envConfig, LearnosityEvent.EventType eventType, Map<String, LearnosityEvent> sessionId_LearnosityEventsMap) {
        log.info("+putRequest profile["+profile+"] envConfig["+envConfig+"] eventType["+eventType+"]");
        RequestProtocol protocol = parallelcUtils.getRequestProtocol(envConfig);
        String startOrSubmitEndpoint = getStartOrSubmitEndpoint(eventType);
        String assignmentActivityEndpoint = getAssignmentActivityEndpoint(startOrSubmitEndpoint);
        String host = envConfig.getAssignments().getHost();
        int port = parallelcUtils.getPort(envConfig);
       
        List<AssignmentServiceResponse> failedAssignmentResponses = httpPut(sessionId_LearnosityEventsMap, protocol, startOrSubmitEndpoint, assignmentActivityEndpoint, host, port);
        
        for(int i=0; (!failedAssignmentResponses.isEmpty() && i < retryAttempts); i++ ) {
            List<AssignmentServiceResponse> failed_networkIssue_Responses = new ArrayList<>();
            List<AssignmentServiceResponse> failed_OtherResponses = new ArrayList<>();
            Iterator<AssignmentServiceResponse> iterator = failedAssignmentResponses.iterator();
            while(iterator.hasNext()){
                AssignmentServiceResponse failedAssignmentResponse = iterator.next();
                String statusCode = failedAssignmentResponse.getStatusCode();
                boolean networkIssue = (PcConstants.NA.equals(statusCode) || STATUS_CODE_504_GATEWAY_TIMEOUT.equals(statusCode));
                log.debug("networkIssue["+networkIssue+"] statusCode["+statusCode+"] sessionId["+failedAssignmentResponse.getSessionId()+"]");
                if (networkIssue) {
                    failed_networkIssue_Responses.add(failedAssignmentResponse);
                } else {
                    // these are more than like state change errors and there is no point in retrying them again,
                    // so we keep them separate
                    failed_OtherResponses.add(failedAssignmentResponse);
                }
                iterator.remove();
            }
            
            //publish the non network issue errors to fail queue...
            if(!CollectionUtils.isEmpty(failed_OtherResponses)){
                eventService.publish(profile, startOrSubmitEndpoint, failed_OtherResponses);    
            }
            
            
            if (!CollectionUtils.isEmpty(failed_networkIssue_Responses)) {
                log.info("~Waiting " + delay_milliseconds / 1000 + " seconds before retry attempt " + (i + 1) + 
                        " out of " + retryAttempts + " failed_networkIssue_Responses size[" + failed_networkIssue_Responses.size() + "]");
                try {
                    Thread.sleep(delay_milliseconds); // Intentional delay to allow any potential network issues time to recover...
                } catch (InterruptedException e) {
                    log.error("Error calling Thread.sleep(" + delay_milliseconds + "). Exception:" + e.getLocalizedMessage());
                }

                sessionId_LearnosityEventsMap = failed_networkIssue_Responses.stream().collect(Collectors.toMap(AssignmentServiceResponse::getSessionId, AssignmentServiceResponse::getLearnosityEvent));
                failedAssignmentResponses = httpPut(sessionId_LearnosityEventsMap, protocol, startOrSubmitEndpoint, assignmentActivityEndpoint, host, port);
            }
        }

        //These failures should only be network issues io.parallec.core.util.PcConstants.NA (occurs with network timeout issues), 504s, so fail the entire lambda
        if(!CollectionUtils.isEmpty(failedAssignmentResponses)){
            //network issue - fail the entire lambda, so the returns back to the Kinesis Stream indicating
            //that it didn't complete, hence preserving the lambda stream event.
            //The Lambda should try again to process message once again
            List<String> failedSessionIds = failedAssignmentResponses.stream().map(AssignmentServiceResponse::getSessionId).collect(Collectors.toList());
            String errorMessage = "Failing entire Lambda due to NA response code for sessionIds "+failedSessionIds;
            log.error(errorMessage);
            throw new RuntimeException(errorMessage);
        }
        
        log.info("-putRequest profile["+profile+"] envConfig["+envConfig+"] eventType["+eventType+"]");
    }

    /**
     * Executes http put request and returns information on any requests that failed (i.e. any non 200 status responses)
     * 
     * @param sessionId_LearnosityEventMap
     * @param protocol
     * @param startOrSubmitEndpoint
     * @param assignmentActivityEndpoint
     * @param host
     * @param port
     * @return List of failedAssignmentServiceResponses, if any.
     */
    private List<AssignmentServiceResponse> httpPut(Map<String, LearnosityEvent> sessionId_LearnosityEventMap, RequestProtocol protocol, String startOrSubmitEndpoint, String assignmentActivityEndpoint, String host, int port) {
        List<String> sessionIdList = new ArrayList<>(sessionId_LearnosityEventMap.keySet());
        log.info("+httpPut protocol["+protocol+"] host["+host+"] port["+port+"] assignmentActivityEndpoint["+assignmentActivityEndpoint+"] sessionIdList size["+sessionIdList.size()+"] ids"+sessionIdList);
        List<AssignmentServiceResponse> failedAssignmentServiceResponses = new ArrayList<>();
        pc.prepareHttpPut(assignmentActivityEndpoint)
        .setReplaceVarMapToSingleTargetSingleVar(SESSION_ID_VAR, sessionIdList, host)
        .setProtocol(protocol)
        .setHttpHeaders(parallelcUtils.getParallecHeader())
        .setHttpPort(port)
        .setConcurrency(sessionIdList.size()) //concurrent Assignment Requests
        .execute((res, responseContext) -> {
            String responseStr = res.toString();
            String resourcePath = res.getRequest().getResourcePath();
            log.debug( "Api Response ["+ responseStr +"]" );
            int statusCodeInt = res.getStatusCodeInt();
            String sessionId = getSessionId(resourcePath, startOrSubmitEndpoint);
            LearnosityEvent learnosityEvent = sessionId_LearnosityEventMap.get(sessionId);
            String delayInfo = JsonUtils.getDelayInfo(learnosityEvent);
            log.info("Request [" + resourcePath + "] "+ delayInfo);
            switch (statusCodeInt) {
                case HttpStatus.SC_OK:

                    log.info("Request [" + resourcePath + "] successful. ");
                    break;
                case PcConstants.NA_INT:
                    log.error("NA Error: Request is["+resourcePath+"]");
                default:
                    //legitimate failure from Assignments...
                    String statusCode = res.getStatusCode();

                    log.error("AssignmentServiceError: Could not " + assignmentActivityEndpoint + " sessionId["+sessionId+"] statusCode["+statusCode+"] requestDetails["+responseStr+"]");
                    AssignmentServiceResponse assignmentServiceResponse = new AssignmentServiceResponse(statusCode, learnosityEvent, responseStr);
                    failedAssignmentServiceResponses.add(assignmentServiceResponse);
            }
        });
        log.info("-httpPut protocol["+protocol+"] host["+host+"] port["+port+"] assignmentActivityEndpoint["+assignmentActivityEndpoint+"] failedAssignmentServiceResponses"+failedAssignmentServiceResponses+" sessionIdList size["+sessionIdList.size()+"] ids"+sessionIdList);
        return failedAssignmentServiceResponses;
    }

    private String getSessionId(String endpoint, String resource){
        String idStr = endpoint.replaceAll(ACTIVITIES_ENDPOINT, "");
        return idStr.replaceAll(resource, "");
    }


    private String getAssignmentActivityEndpoint(String resource){
        return ACTIVITIES_ENDPOINT+"$"+ SESSION_ID_VAR +resource;
    }







}
