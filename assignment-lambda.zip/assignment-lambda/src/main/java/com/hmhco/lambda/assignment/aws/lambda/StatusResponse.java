package com.hmhco.lambda.assignment.aws.lambda;

/**
 * Created by odowdj on 16 June 2016.
 */
public class StatusResponse {

    private String message;

    public StatusResponse(String message){
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
