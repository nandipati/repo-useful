package com.hmhco.lambda.assignment.eventservice;

import com.google.common.net.HttpHeaders;
import com.google.gson.Gson;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.config.EnvConfig;
import com.hmhco.lambda.assignment.config.LambdaConfigUtils;
import com.hmhco.lambda.assignment.parallelc.ParallelcUtils;
import com.hmhco.lambda.assignment.service.AssignmentServiceImpl;
import com.hmhco.lambda.assignment.service.AssignmentServiceResponse;
import io.parallec.core.ParallecHeader;
import io.parallec.core.ParallelClient;
import io.parallec.core.RequestProtocol;
import io.parallec.core.bean.TaskRequest;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EventServiceImpl {

    private static final Logger log = LoggerFactory.getLogger(EventServiceImpl.class);

    public static final String TOPIC_AL_ACTIVITYSTART_FAIL ="al_activitystart_fail";
    public static final String TOPIC_AL_ACTIVITYSUBMIT_FAIL ="al_activitysubmit_fail";

    public static final String PUBLISH_ENDPOINT = "/eventservice/v1/publish";

    private static final String BODY_VAR = "BODY_VAR";

    private final ParallelClient pc = new ParallelClient();
    private final Gson gson = new Gson();

    @Autowired
    private ParallelcUtils parallelcUtils;

    public void publish(Profile profile, String assignmentEndpoint, List<AssignmentServiceResponse> assignmentServiceResponse){

        String topic = getTopic(assignmentEndpoint);

        List<String> eventMessageBodyList = new ArrayList<>();
        
        for (AssignmentServiceResponse serviceResponse : assignmentServiceResponse) {
            String body = gson.toJson(new EventPublishRequest(topic, serviceResponse));
            eventMessageBodyList.add(body);
        }
        
        EnvConfig envConfig = LambdaConfigUtils.getEnvConfig(profile);
        RequestProtocol requestProtocol = parallelcUtils.getRequestProtocol(envConfig);
        String host = envConfig.getEventservice().getHost();
        int port = parallelcUtils.getPort(envConfig);
        ParallecHeader parallecHeader = parallelcUtils.getParallecHeader();
        parallecHeader.addPair(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        
        log.debug("+postRequest profile["+profile+"] protocol["+requestProtocol+"] host["+host+"] port["+port+"] topic["+topic+"] eventMessageBodyList["+eventMessageBodyList+"]");
        
        try{
            pc.prepareHttpPost(PUBLISH_ENDPOINT)
                    .setProtocol(requestProtocol)
                    .setTargetHostsFromString(host)
                    .setHttpPort(port)
                    .setConcurrency(eventMessageBodyList.size()) //concurrent Requests to event service
                    .setHttpHeaders(parallecHeader)
                    .setHttpEntityBody("$"+BODY_VAR)
                    .setReplaceVarMapToSingleTargetSingleVar(BODY_VAR, eventMessageBodyList, host)
                    .execute((res, responseContext) -> {
                        log.debug( "EventService Response ["+ res.toString()+"]" );
                        TaskRequest request = res.getRequest();
                        if(res.getStatusCodeInt()!= HttpStatus.SC_OK){
                            log.error("Error: Could not publish body["+ request.getPostData()+"] to topic["+topic+"]");
                        }else{
                            log.info("EventServiceRequest ["+ request.getResourcePath()+"] successful." );
                        }
                    });
        }catch(Exception ex){
            //catch the exception as we don't want to terminate the lambda with this exception,
            //we want to log it and keep going
            log.error("An error occured publishing eventMessageBodyList["+eventMessageBodyList+"]");
        }
        
        log.debug("-postRequest profile["+profile+"] protocol["+requestProtocol+"] host["+host+"] port["+port+"] topic["+topic+"] eventMessageBodyList["+eventMessageBodyList+"]");
    }

    public String getTopic(String assignmentEndpoint) {
        String topic = null;
        if(AssignmentServiceImpl.START_RESOURCE.equals(assignmentEndpoint)){
            topic = TOPIC_AL_ACTIVITYSTART_FAIL;
        }else if(AssignmentServiceImpl.SUBMIT_RESOURCE.equals(assignmentEndpoint)){
            topic = TOPIC_AL_ACTIVITYSUBMIT_FAIL;
        }
        return topic;
    }

}
