package com.hmhco.lambda.assignment.service;

import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;

public class AssignmentServiceResponse {

	private String statusCode;
    private final String sessionId;
    private LearnosityEvent learnosityEvent;
    private String responseError;

    public AssignmentServiceResponse(String statusCode, LearnosityEvent learnosityEvent) {
        this.statusCode = statusCode;
        this.learnosityEvent = learnosityEvent;
        this.sessionId = learnosityEvent.getSession_id();
    }
    
    public AssignmentServiceResponse(String statusCode, LearnosityEvent learnosityEvent, String responseError) {
        this(statusCode, learnosityEvent);
        this.responseError = responseError;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getResponseError() {
        return responseError;
    }

    public void setResponseError(String responseError) {
        this.responseError = responseError;
    }

    public LearnosityEvent getLearnosityEvent() {
        return learnosityEvent;
    }

    public void setLearnosityEvent(LearnosityEvent learnosityEvent) {
        this.learnosityEvent = learnosityEvent;
    }
    
    public String getSessionId(){
        return this.sessionId;
    }
}
