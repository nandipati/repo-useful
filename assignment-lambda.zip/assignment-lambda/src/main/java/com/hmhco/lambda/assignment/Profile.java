package com.hmhco.lambda.assignment;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public enum Profile {

    DEV("-dev-"),
    INT("-int-"),
    CERT("-cert-"),
    CERTRV("-certrv-"),
    PROD("-prod-");

    private final String value;

    Profile(String value){
        this.value = value;
    }

    private String getValue() {
        return value;
    }

    private static final Map<String, Profile> functionLookup = new HashMap<>();


    /**
     * Return Profile for a given aws lambda function name.
     * @param functionName
     * @return
     */
    public static Profile findByFunctionName(String functionName) {
        Profile profile = functionLookup.get(functionName);
        if(profile==null && functionName!=null){
            profile = findMatch(functionName);
            functionLookup.put(functionName, profile);
        }
        return profile;
    }

    /**
     * Returns a Profile applicable to a lambda 'functionName'
     * e.g. functionName = abc-int-my-function - returns INT
     * functionName = abc-prod-anotherFunction - returns PROD
     * @param functionName
     * @return DEV by default
     */
    private static Profile findMatch(String functionName){
        if(functionName!=null){
            for (Profile profile : Profile.values()) {
                if (StringUtils.containsIgnoreCase(functionName, profile.getValue())) {
                    return profile;
                }
            }
        }
        return DEV;
    }
    
    @Override
    public String toString() {
        return name().toLowerCase();
    }
    
}
