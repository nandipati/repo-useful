package com.hmhco.lambda.assignment.aws.lambda;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class LearnosityEvent {

    public enum EventType {
        STARTED("session-started"), COMPLETED("session-completed"), RESUMED("session-resumed");
        private final String value;

        private static final Map<String, EventType> lookup = new HashMap<>();

        static {
            for (EventType eventType : EventType.values()) {
                lookup.put(eventType.getValue(), eventType);
            }
        }

        EventType(String value){
            this.value = value;
        }
        
        public String getValue(){
            return this.value;
        }

        public static EventType get(String value){
            return lookup.get(value);
        }
    }

    private transient EventType eventType;
    private String event;
    private String session_id;
    private String activity_id;
    private String user_id;
    private String time;

    public LearnosityEvent(){

    }

    public String getEvent() {
        return event;
    }
    public void setEvent(String event) {
        this.event = event;
        if(StringUtils.isNotBlank(event)){
            eventType = EventType.get(event);
        }
    }

    
    public EventType getEventType(){
        if(eventType==null){
            //potentially eventType may be null and event itself may be set
            //this happends during unmarshalling (Gson.fromJson)
            //if it is, then derive the type
            setEvent(getEvent());
        }
        return eventType;
    }

    public String getSession_id() {
        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public String getActivity_id() {
        return activity_id;
    }

    public void setActivity_id(String activity_id) {
        this.activity_id = activity_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    /**
     * Duplicate Learnosity Events can come in on Kinesis stream, so for example,
     * there could be many session-started for user id "123", even if they have different times etc it doesn't matter, 
     * what is unique, is the session id coupled with the event type. So that's what makes the kinesis event messages distinct.
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LearnosityEvent that = (LearnosityEvent) o;

        if (!event.equals(that.event)) return false;
        return session_id.equals(that.session_id);

    }

    @Override
    public int hashCode() {
        int result = event.hashCode();
        result = 31 * result + session_id.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "LearnosityEvent{ event["+event+"] session_id["+session_id+"] activity_id["+activity_id+"] user_id["+user_id+"] time["+time+"]}";
    }
}
