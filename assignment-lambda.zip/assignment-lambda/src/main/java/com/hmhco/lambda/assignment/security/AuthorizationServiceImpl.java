package com.hmhco.lambda.assignment.security;


import com.hmhpub.common.token.auth.SIFAuthorization;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthorizationServiceImpl {

    @Value("${sifAuthorization.lambda.clientId}")
    private String clientId;
    @Value("${sifAuthorization.lambda.secret}")
    private String secret;

    private final DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

    public SIFAuthorization createSIFAuthorization() {
        String isoAuthCurrentDateTime = dateTimeFormatter.print(DateTime.now());
        return new SIFAuthorization(clientId, secret, isoAuthCurrentDateTime);
    }

    public Map<String, String> getHeaders(){
        SIFAuthorization sifAuthorization = createSIFAuthorization();
        Map<String, String> headers = new HashMap<>();
        headers.put(SIFAuthorization.AUTHORIZATION, sifAuthorization.getAuthorization());
        headers.put(SIFAuthorization.SIF_AUTH_DATE_HDR, sifAuthorization.getAuthCurrentDateTime());
        return headers;
    }

}
