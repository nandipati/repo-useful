package com.hmhco.lambda.assignment.parallelc;

import com.hmhco.lambda.assignment.config.EnvConfig;
import com.hmhco.lambda.assignment.security.AuthorizationServiceImpl;
import io.parallec.core.ParallecHeader;
import io.parallec.core.RequestProtocol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ParallelcUtils {

    private static final Logger logger = LoggerFactory.getLogger(ParallelcUtils.class);

    public static final int DEFAULT_HTTP_PORT = 80;
    public static final int DEFAULT_HTTPS_PORT = 443;

    @Autowired
    private AuthorizationServiceImpl authorizationService;

    /**
     * Returns the port if declared
     * @param envConfig
     * @return port (int), if none exists, default port (80-http/443-https) used by Parallec, is returned
     */
    public int getPort(EnvConfig envConfig) {
        int port = envConfig.getPort();
        if(port<=0){
            port = envConfig.getProtocol().equals(RequestProtocol.HTTPS.toString()) ? DEFAULT_HTTPS_PORT : DEFAULT_HTTP_PORT;
        }
        return port;
    }

    /**
     * Return the http protocol for the specific environment.
     * @param envConfig
     * @return http by default
     */
    public RequestProtocol getRequestProtocol(EnvConfig envConfig) {
        RequestProtocol requestProtocol = RequestProtocol.HTTP;
        try{
            requestProtocol = RequestProtocol.valueOf(envConfig.getProtocol().toUpperCase());
        }catch(Exception ignore){}
        return requestProtocol;
    }


    /**
     * Returns the sif trusted header map that is required for Assignment http requests.
     * @return ParallecHeader
     */
    public ParallecHeader getParallecHeader(){
        Map<String, String> sifHeaders = authorizationService.getHeaders();
        ParallecHeader parallecHeader = new ParallecHeader();
        for (String key : sifHeaders.keySet()) {
            parallecHeader.addPair(key, sifHeaders.get(key));
        }
        return parallecHeader;
    }
}
