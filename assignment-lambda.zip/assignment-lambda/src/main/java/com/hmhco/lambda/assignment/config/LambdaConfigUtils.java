package com.hmhco.lambda.assignment.config;

import com.hmhco.lambda.assignment.Profile;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Component
public class LambdaConfigUtils {

    private static final Map<Profile, EnvConfig> hostLookup = new HashMap<>();

    @Autowired
    private LambdaConfig lambdaConfig;

    @PostConstruct
    private void setup(){
        for(Profile profile : Profile.values()){
            setEnvConfig(profile);
        }
    }

    private void setEnvConfig(Profile profile){
        EnvConfig envConfig = hostLookup.get(profile);
        if(envConfig==null){
            switch(profile){
                case DEV:
                    envConfig = lambdaConfig.getDev();
                    break;
                case INT:
                    envConfig = lambdaConfig.getIntenv();
                    break;
                case CERT:
                    envConfig = lambdaConfig.getCert();
                    break;
                case CERTRV:
                    envConfig = lambdaConfig.getCertrv();
                    break;
                case PROD:
                    envConfig = lambdaConfig.getProd();
                    break;
                default:
                    throw new NotImplementedException("No Configuration for profile "+profile);
            }
            hostLookup.put(profile, envConfig);
        }
    }

    public static EnvConfig getEnvConfig(Profile profile){
        return hostLookup.get(profile);
    }

}
