package com.hmhco.lambda.assignment.config;

import com.google.common.collect.Lists;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

import java.util.List;


@Configuration
@EnableConfigurationProperties({ LambdaConfig.class })
public class ApplicationConfig {

    public static final String APPLICATION_YAML = "application.yaml";

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeholderConfigurerBean(Environment environment) {
        PropertySourcesPlaceholderConfigurer placeholderConfigurer = new PropertySourcesPlaceholderConfigurer();

        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(prepareClassPathResources(environment));
        placeholderConfigurer.setProperties(yaml.getObject());

        return placeholderConfigurer;
    }

    private static ClassPathResource[] prepareClassPathResources(Environment environment) {
        String[] profiles = environment.getActiveProfiles();
        List<ClassPathResource> resources = Lists.newArrayListWithExpectedSize(profiles.length);
        resources.add(new ClassPathResource(APPLICATION_YAML));
        return resources.toArray(new ClassPathResource[resources.size()]);
    }

    @Bean
    public LambdaConfigUtils lambdaConfigUtils(){
        return new LambdaConfigUtils();
    }

}
