package com.hmhco.lambda.assignment.service;

import com.hmhco.lambda.assignment.aws.lambda.LearnosityEvent;
import org.joda.time.DateTime;
import org.joda.time.Instant;
import org.joda.time.Interval;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class JsonUtils {
    
    private static DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Derive the time between now and the time on the learnosity event
     * @param learnosityEvent
     * @return
     */
    public static String getDelayInfo(LearnosityEvent learnosityEvent){
        String delayStr = null;
        String timeStr = learnosityEvent.getTime();
        if(timeStr!=null){
            DateTime time = formatter.parseDateTime(timeStr);
            Instant now = new Instant();
            Period period = new Interval(time, now).toPeriod();
            
            //now.toDateTime()
            delayStr = "Delay between now["+now.toDateTime().toString(formatter)+"] and Learnosity time["+timeStr+"] is "+period.getWeeks()+" weeks, "+ period.getDays() + " days, " + period.getHours() + " hours, " + period.getMinutes() + " minutes, " + period.getSeconds() + " seconds ";
        }
        return delayStr;
    }
    
}
