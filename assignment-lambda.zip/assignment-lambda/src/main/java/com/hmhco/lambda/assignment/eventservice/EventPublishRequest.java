package com.hmhco.lambda.assignment.eventservice;

import com.google.gson.Gson;

public class EventPublishRequest {
    
	private final String topicName;
	private final Object message;

	private final transient Gson gson = new Gson();

	public EventPublishRequest(String topic, Object message) {
		this.topicName = topic;
        //event service requires the message to be stringifyed
		this.message = gson.toJson(message);
	}

    public String getTopicName() {
		return topicName;
	}

	public Object getMessage() {
		return message;
	}
}
