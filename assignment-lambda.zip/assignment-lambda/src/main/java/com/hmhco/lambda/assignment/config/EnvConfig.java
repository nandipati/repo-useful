package com.hmhco.lambda.assignment.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties
public class EnvConfig {

    private String protocol;
    private int port;

    @NestedConfigurationProperty
    private AssignmentConfig assignments;

    @NestedConfigurationProperty
    private EventServiceConfig eventservice;

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public AssignmentConfig getAssignments() {
        return assignments;
    }

    public void setAssignments(AssignmentConfig assignments) {
        this.assignments = assignments;
    }

    public EventServiceConfig getEventservice() {
        return eventservice;
    }

    public void setEventservice(EventServiceConfig eventservice) {
        this.eventservice = eventservice;
    }

    @Override
    public String toString() {
        return "EnvConfig{" +
                "protocol='" + protocol + '\'' +
                ", port=" + port +
                ", assignments=" + assignments +
                ", eventservice=" + eventservice +
                '}';
    }
}
