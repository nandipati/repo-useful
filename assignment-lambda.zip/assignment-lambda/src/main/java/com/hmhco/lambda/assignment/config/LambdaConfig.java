package com.hmhco.lambda.assignment.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

@ConfigurationProperties
public class LambdaConfig {

    @NestedConfigurationProperty
    private EnvConfig dev;

    @NestedConfigurationProperty
    private EnvConfig intenv;

    @NestedConfigurationProperty
    private EnvConfig cert;

    @NestedConfigurationProperty
    private EnvConfig certrv;

    @NestedConfigurationProperty
    private EnvConfig prod;

    public EnvConfig getDev() {
        return dev;
    }

    public void setDev(EnvConfig dev) {
        this.dev = dev;
    }

    public EnvConfig getIntenv() {
        return intenv;
    }

    public void setIntenv(EnvConfig intenv) {
        this.intenv = intenv;
    }

    public EnvConfig getCert() {
        return cert;
    }

    public void setCert(EnvConfig cert) {
        this.cert = cert;
    }

    public EnvConfig getCertrv() {
        return certrv;
    }

    public void setCertrv(EnvConfig certrv) {
        this.certrv = certrv;
    }

    public EnvConfig getProd() {
        return prod;
    }

    public void setProd(EnvConfig prod) {
        this.prod = prod;
    }
}
