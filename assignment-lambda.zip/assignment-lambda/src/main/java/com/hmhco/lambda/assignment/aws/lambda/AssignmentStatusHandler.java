package com.hmhco.lambda.assignment.aws.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.KinesisEvent;
import com.hmhco.lambda.assignment.AssignmentstatusApplication;
import com.hmhco.lambda.assignment.Profile;
import com.hmhco.lambda.assignment.service.AssignmentServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Set;

public class AssignmentStatusHandler implements RequestHandler<KinesisEvent, StatusResponse> {

    private static final Logger logger = LoggerFactory.getLogger(AssignmentStatusHandler.class);

    @Override
    public StatusResponse handleRequest(KinesisEvent kinesisEvent, Context context) {
        logger.info("+handleRequest");

        Map<LearnosityEvent.EventType, Set<LearnosityEvent>> learnosityEventsMap = LearnosityEventConverter.getEventsByType(kinesisEvent);

        AssignmentstatusApplication application = new AssignmentstatusApplication(context);
        AssignmentServiceImpl assignmentService = application.getBean(AssignmentServiceImpl.class);

        logger.debug("~handleRequest learnosityEventsMap["+learnosityEventsMap+"] assignmentService["+assignmentService+"]");

        StatusResponse statusResponse = assignmentService.updateActivitiesStatus(Profile.findByFunctionName(context.getFunctionName()), learnosityEventsMap);

        logger.info("-handleRequest statusResponse["+statusResponse+"]");
        return statusResponse;
    }

}
