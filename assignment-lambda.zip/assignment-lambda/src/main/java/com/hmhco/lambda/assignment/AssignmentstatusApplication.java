package com.hmhco.lambda.assignment;

import com.amazonaws.services.lambda.runtime.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class AssignmentstatusApplication {
    private String LAMBDA_ASSIGNMENT_PACKAGE = "com.hmhco.lambda.assignment";
    private String SPRING_PROFILES_ACTIVE = "spring.profiles.active";
    private static final Logger logger = LoggerFactory.getLogger(AssignmentstatusApplication.class);

    public AssignmentstatusApplication(){}
    public static void main(String[] args) {
        SpringApplication.run(AssignmentstatusApplication.class, args);
    }

    private ApplicationContext applicationContext;

    public AssignmentstatusApplication(Context lambdaContext) {
        Profile profile = Profile.findByFunctionName(lambdaContext.getFunctionName());
        System.setProperty(SPRING_PROFILES_ACTIVE, profile.toString());

        applicationContext = new AnnotationConfigApplicationContext(LAMBDA_ASSIGNMENT_PACKAGE);
        setBean(lambdaContext, "lambdaContext");
    }

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }


    public <T> T getBean(Class<T> clazz) {
        return applicationContext.getAutowireCapableBeanFactory().getBean(clazz);
    }

    public <T> void setBean(T obj, String beanName) {
        applicationContext.getAutowireCapableBeanFactory().initializeBean(obj, beanName);
    }

}
