package com.rsi.metrics.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by nandipatim on 9/8/17.
 */
@RestController
public class HealthController {
  public HealthController() {
  }

  @RequestMapping({"/health"})
  public String health() {
    return "OK";
  }
}
