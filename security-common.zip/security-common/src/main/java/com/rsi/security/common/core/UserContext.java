package com.rsi.security.common.core;

public enum UserContext {
    IOWA("iowa");

    private final String contextId;

    UserContext(String contextId) {
        this.contextId = contextId;
    }

    public String toString() {
        return contextId;
    }

    public static UserContext fromString(String userContextId) {
        UserContext userContextFound = null;

        for (UserContext userContext : UserContext.values()) {
            if (userContext.toString().equalsIgnoreCase(userContextId)) {
                userContextFound = userContext;
                break;
            }
        }

        if (userContextFound == null) {
            throw new IllegalArgumentException("Invalid user contextId string: " + userContextId);
        } else {
            return userContextFound;
        }
    }
}
