package com.rsi.security.common.utils;

/**
 * Created by odowdj on 13/11/2015.
 */
public interface ScopeEvaluator {
    boolean hasScope(String scope);

    boolean hasAnyScope(String... scopes);

    /**
     * Used in PreAuthorize annotations in Controller
     * @return
     */
    boolean hasDefaultScope();

    /**
     * Used in PreAuthorize annotations in Controller
     * @return
     */
    String defaultScope();
}
