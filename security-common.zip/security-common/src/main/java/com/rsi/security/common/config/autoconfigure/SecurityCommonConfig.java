package com.rsi.security.common.config.autoconfigure;

import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.converter.ScopeConverter;
import com.rsi.security.common.utils.ScopeEvaluator;
import com.rsi.security.common.utils.ScopeEvaluatorImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * {@link EnableAutoConfiguration needs to be declared to run Auto-configuration} .
 */
@ComponentScan("com.rsi.security.common")
@Configuration
public class SecurityCommonConfig {

    @Value("${scope.defaultScope:scope_none}")
    private String defaultScope;

    @Bean
    public RSIRoleConverter rsiRoleConverter() {
        return new RSIRoleConverter();
    }

    @Bean
    public ScopeConverter scopeConverter() {
        return new ScopeConverter();
    }

    @Bean(name = "scope")
    public ScopeEvaluator scopeEvaluator() {
        return new ScopeEvaluatorImpl(defaultScope);
    }

}
