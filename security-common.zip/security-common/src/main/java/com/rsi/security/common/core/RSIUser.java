package com.rsi.security.common.core;

import java.util.Set;
import java.util.UUID;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Created by odowdj on 18/11/2015.
 */
public interface RSIUser extends UserDetails {

    UUID getUserGuid();

    void setUserGuid(UUID userGuid);

    UUID getLeaRefId();

    void setLeaRefId(UUID leaRefId);

    UUID getSchoolRefId();

    void setSchoolRefId(UUID schoolRefId);

    Set<String> getScopes();

    UserContext getUserContext();

    void setUserContext(UserContext userContext);

    boolean isIndependentSchool();

    void setIndependentSchool(boolean isIndependentSchool);

    String[] getTokenRoles();

    void setTokenRoles(String[] tokenRoles);

}
