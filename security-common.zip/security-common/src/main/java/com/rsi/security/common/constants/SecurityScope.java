package com.rsi.security.common.constants;

/**
 * Security Scope values
 */
public interface SecurityScope {

    String assessment = "assessment";

}
