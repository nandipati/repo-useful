package com.rsi.security.common.constants;

import org.springframework.http.MediaType;

/**
 * Created by nandipatim on 2/12/19.
 */
public interface RestConstants {
  String VERSION_PARAM_NAME = "1";
  String JSON = MediaType.APPLICATION_JSON_UTF8_VALUE;
  String URLENCODED = MediaType.APPLICATION_FORM_URLENCODED_VALUE;
}
