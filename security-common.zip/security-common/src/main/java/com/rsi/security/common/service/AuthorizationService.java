package com.rsi.security.common.service;

import com.rsi.security.common.controller.view.AuthorizationRequestView;
import com.rsi.security.common.controller.view.AuthorizationView;
import com.rsi.security.common.controller.view.BaseAuthorizationView;
import com.rsi.security.common.token.utils.TokenType;

/**
 * Created by nandipatim on 2/12/19.
 */
public interface AuthorizationService {

  AuthorizationView genrateSIFToken(AuthorizationRequestView requestView);

  BaseAuthorizationView genrateSIFTokenWithTokenType(AuthorizationRequestView requestView , TokenType tokenType);

  AuthorizationView genrateSIFToken(AuthorizationRequestView authorizationRequestView, Boolean skipClientVerification);
}
