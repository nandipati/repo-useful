package com.rsi.security.common.filter;

import com.rsi.security.common.session.filter.AuthorizationHeaderFilter;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

public class RSIAuthorizationHeaderFilter extends AuthorizationHeaderFilter {
    
    private static Logger logger = LoggerFactory.getLogger(RSIAuthorizationHeaderFilter.class);
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            super.doFilter(request, response, chain);
        } catch (Exception e) {
            logger.error("{}: {}", e.getClass().getCanonicalName(), e.getMessage());
            ((HttpServletResponse)response).setStatus(HttpStatus.FORBIDDEN.value());
        }
    }

}
