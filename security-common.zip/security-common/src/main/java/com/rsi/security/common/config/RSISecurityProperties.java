package com.rsi.security.common.config;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ConfigurationProperties(prefix = "rsisecurity")
@Primary
public class RSISecurityProperties {

    @Value("${csrfEnabled:false}")
    private boolean csrfEnabled;

    @Value("${audience:http://www.rsi.com}")
    private String audience;

    @Value("${issuer:https://identity.api.rsi.com}")
    private String issuer;

    @Value("${expireInSecs:31536000}")
    private int expireInSecs;

    @Value("${scope:selfhosted-adaptive}")
    private String scope;

    private Map<String, String> clientStore = new HashMap<>();


    @PostConstruct
    private void setup(){
        //if clientStore is empty, add in the default trusted keys, rsiplayer, trustedapi etc...
        if(clientStore.isEmpty()){
            //Trusted API Token
            clientStore.put("client-id-of-calling-app", "client-ids-secret");
        }
    }

    public boolean isCsrfEnabled() {
        return csrfEnabled;
    }

    public String getAudience() {
        return audience;
    }

    public String getIssuer() {
        return issuer;
    }

    public Map<String, String> getClientStore() {
        return clientStore;
    }

    public void setCsrfEnabled(boolean csrfEnabled) {
        this.csrfEnabled = csrfEnabled;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public void setClientStore(Map<String, String> clientStore) {
        this.clientStore = clientStore;
    }

    public int getExpireInSecs() {
        return expireInSecs;
    }

    public void setExpireInSecs(int expireInSecs) {
        this.expireInSecs = expireInSecs;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }
}
