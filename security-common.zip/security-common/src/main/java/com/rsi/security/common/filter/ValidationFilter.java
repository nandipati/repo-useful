package com.rsi.security.common.filter;

import com.rsi.security.common.token.RSIPrincipal;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class ValidationFilter implements Filter {

  private static final Logger logger = Logger.getLogger(ValidationFilter.class);

  public ValidationFilter() {
  }

  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
    logger.debug("+doFilter");
    HttpServletRequest httpRequest = (HttpServletRequest)request;
    HttpServletResponse httpResponse = (HttpServletResponse)response;
    RSIPrincipal userPrincipal = (RSIPrincipal)httpRequest.getUserPrincipal();
    if(userPrincipal != null) {
      if(logger.isDebugEnabled()) {
        logger.debug("User Authenticated: " + userPrincipal.getGuid());
      }

      filterChain.doFilter(httpRequest, httpResponse);
    } else {
      logger.error("User not authorized");
      httpResponse.sendError(403, "Security token not found");
    }

    logger.debug("-doFilter");
  }

  public void init(FilterConfig filterConfig) throws ServletException {
    logger.debug("AssignmentAPIValidationFilter initialized");
  }

  public void destroy() {
    logger.debug("AssignmentAPIValidationFilter destroyed");
  }

}
