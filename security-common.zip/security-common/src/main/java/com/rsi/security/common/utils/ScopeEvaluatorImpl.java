package com.rsi.security.common.utils;

public class ScopeEvaluatorImpl implements ScopeEvaluator {

    private final String defaultScope;

    public ScopeEvaluatorImpl(String defaultScope) {
        this.defaultScope = defaultScope;
    }

    @Override
    public boolean hasScope(String scope) {
        return hasAnyScope(scope);
    }

    @Override
    public boolean hasAnyScope(String... scopes) {
        if(scopes!=null){
            for (String scope : scopes) {
                if (SecurityUtils.hasScope(scope)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean hasDefaultScope() {
        return hasScope(defaultScope);
    }

    @Override
    public String defaultScope() {
        return defaultScope;
    }
}
