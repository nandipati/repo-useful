package com.rsi.security.common.constants;

/**
 * List of Security Claim names
 */
public interface SecurityClaim {

    String TRUSTED_API = "TrustedAPI";
    String CONTEXT_ID = "contextId";
    String DIST_REFID = "dist_refid";
    String SCHOOL_REFID = "school_refid";
    String SCOPE = "scope";
    String SCHOOL_CATEGORY = "school_category";
    String SCHOOL_CATEGORY_PRIVATE = "private";

}
