package com.rsi.security.common.session.cookie;

import com.rsi.security.common.token.RSIPrincipal;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by nandipatim on 1/16/19.
 */
public interface SessionCookieManager {

  /**
   * Creates a new {@link javax.servlet.http.Cookie} using sessionAttributes obtained via
   * the {@link com.rsi.common.security.session.PlatformSessionManager}.
   * @param principal
   * @return
   */
  Cookie encodeCookie(RSIPrincipal principal, boolean isRequestSecure);

  /**
   * Decode a cookie value into a Map of key:values
   * @param cookie
   * @return
   */
  RSIPrincipal decodeCookie(Cookie cookie);

  /**
   * Creates a new cookie using the same value as the existing cookie but extends the "expires=" date to prolong the
   * session.
   * @param cookie
   * @param resp
   */
  void updateExpiryDate(RSIPrincipal principal, Cookie cookie, HttpServletResponse resp);

  /**
   * Modifies the cookie so that other Platforms will know to treat the cookie as invalid or ignore it.
   * A typical use case would be when the Platform that created the cookie wants performs a logout and must signal
   * this to the other session sharing Platforms. It is assumed this will be done via the addition/modification
   * of a parameter within the cookie.
   * @param cookie
   * @return a new Cookie with invalid properties set.
   */
  Cookie deactivateCookie(Cookie cookie);

  /**
   * Used to determine if the cookie should be treated as invalid. The criteria must be consistent with that
   * which is implemented in {@link #deactivateCookie}. It is assumed this will be done via the addition/modification
   * of a parameter within the cookie.
   * @param principal
   * @return true if the cookie is to be treated as invalid.
   */
  boolean isDeactivated(RSIPrincipal principal);

  /**
   * Provides a mechanism to configure the domain name to set on the cookie. If this is not configured each
   * platform would create a cookie for its specific host server. We most likely want tthe cookie to be applied
   * to a sub-domain. This subdomain can be set here. Implementations are expected to set inside
   * {@link SessionCookieManager}'s encode method.
   * @param domain
   */
  void setDomain(String domain);

  /**
   *  Returns the session cookie from the request.
   * @param req
   * @return the session cookie or NULL if it is not found.
   */
  Cookie getCookie(HttpServletRequest req);


  /**
   * Sets the max age to 0.
   * Sets the path to the same path used during creation.
   * Sets the domain to the same path used during creation.
   * @param cookie
   */
  void deleteCookie(Cookie cookie, HttpServletResponse response);

  public int getSessionTimeoutSecs();

  public void setSessionTimeoutSecs(int sessionTimeoutSecs);
}
