package com.rsi.security.common.session.filter;

import com.rsi.security.common.session.cookie.PlatformSessionManager;
import com.rsi.security.common.session.cookie.SessionCookieManager;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.utils.TokenUtils;
import java.io.IOException;
import java.security.Principal;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class SessionManagementFilter implements Filter {

  private static final Logger log = Logger.getLogger(SessionManagementFilter.class);

  protected PlatformSessionManager sessionManager;

  protected SessionCookieManager cookieManager;


  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

    if (log.isDebugEnabled()) log.debug("Processing request");

    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse resp = (HttpServletResponse) response;

    HttpServletRequestWrapper wrappedRequest = doProcess(req, resp, cookieManager);

    chain.doFilter(wrappedRequest, resp);

    doPostProcess(wrappedRequest, resp, cookieManager);
  }


  /**
   * Process the cookie and manage the platform session.
   * @param req
   * @param resp
   * @param cookieManager Passed in rather than use class member so this method can be used thread safely by MultiDomainSessionManagementFilter.
   * @return HttpServletRequest an updated request containing a RSIUserPrincipal
   * @throws IOException
   * @throws ServletException
   */
  protected HttpServletRequestWrapper doProcess(HttpServletRequest req, HttpServletResponse resp, SessionCookieManager cookieManager) throws IOException, ServletException {

    final RSIPrincipal inboundPrincipal;

    // No existing Session
    if (! sessionManager.isSessionActive(req)) {
      if (log.isDebugEnabled()) log.debug("NO Active Platform session");

      Cookie securityCookie = cookieManager.getCookie(req);

      // Validate cookie and regenerate session if successful
      if (securityCookie != null) {
        if (log.isDebugEnabled()) log.debug("ESS Cookie found");

        if (sessionManager.isApplicationEntryPoint(req)) {

          if (log.isDebugEnabled()) log.debug("This is App Entry Point");
          inboundPrincipal = null;
          cookieManager.deleteCookie(securityCookie, resp);
          if (log.isDebugEnabled()) log.debug("Deleted old Cookie from previous session.");
        }
        else  {
          inboundPrincipal = processCookie(req, resp, securityCookie, true, cookieManager);
        }
      }
      else {
        if (log.isDebugEnabled()) log.debug("NO ESS cookie");
        inboundPrincipal = null;
      }
    }
    // Session exists
    else {
      if (log.isDebugEnabled()) log.debug("Active Platform session found");

      Cookie securityCookie = cookieManager.getCookie(req);

      // No cookie exists, create one
      if (securityCookie == null) {
        if (log.isDebugEnabled()) log.debug("NO Cookie found, creating one");
        inboundPrincipal = createSecureCookie(cookieManager, req, resp);
      }
      // Cookie exists, update expiry
      else {
        if (log.isDebugEnabled()) log.debug("ESS Cookie found. Value = " + securityCookie.getValue());
        // Validate cookie and update expiry if successful. Do not recreate session
        inboundPrincipal = processCookie(req, resp, securityCookie, false, cookieManager);
      }
    }

    HttpServletRequestWrapper wrappedRequest  = new HttpServletRequestWrapper((HttpServletRequest)req)
    {
      @Override
      public String getAuthType() {
        return TokenUtils.JWT;
      }

      @Override
      public Principal getUserPrincipal() {
        return inboundPrincipal;
      }

      @Override
      public String getRemoteUser() {
        final Principal principal = this.getUserPrincipal();

        return (principal != null) ? principal.getName() : null;
      }

      @Override
      public boolean isUserInRole(String role)
      {
        boolean isInRole;
        if (inboundPrincipal != null) {
          isInRole = inboundPrincipal.isUserInRole(role);
        }
        else {
          isInRole = super.isUserInRole(role);
        }
        return isInRole;
      }

    };

    return wrappedRequest;
  }

  /**
   *  This method performs the following actions on the ESS Cookie after normal processing :
   *  - Deactivates the cookie if the platform session is not active.
   *  - Creates a new ESS Cookie if the session is active and no cookie exists
   *  - Compares the current ESS userName with that of the session and updates the ESS cookie if necessary.
   * @param cookieManager
   * @param resp
   * @param wrappedRequest
   */
  protected void doPostProcess(HttpServletRequest wrappedRequest, HttpServletResponse resp, SessionCookieManager cookieManager) {

    if (log.isDebugEnabled()) log.debug("Beginning ESS post processing");

    // Recheck the session and cookie
    Cookie postProcessCookie = cookieManager.getCookie(wrappedRequest);
    boolean isSessionActive = sessionManager.isSessionActive(wrappedRequest);

    // E.g. User logged out, deactivate ESS cookie
    if ( !isSessionActive && postProcessCookie != null) {
      if (log.isDebugEnabled()) log.debug("NO Active Platform session. ESS Cookie found. Value = " + postProcessCookie.getValue());
      cookieManager.deactivateCookie(postProcessCookie);
    }
    // E.g. User logged in
    else if (isSessionActive) {
      // Lets create ESS cookie immediately so it's there for the dashboard/landing page.
      if (postProcessCookie == null) {
        if (log.isDebugEnabled()) log.debug("Platform session active. NO ESS Cookie. Creating one");
        createSecureCookie(cookieManager, wrappedRequest, resp);
      }
      else {
        if (log.isDebugEnabled()) log.debug("Platform session active. ESS Cookie found, Value = " + postProcessCookie.getValue());
        // E.g. Cookie created with User A initially, but possibly re-logged-in as User B on a different Content system, re-create cookie with B credentials
        RSIPrincipal currentESSPrincipal = cookieManager.decodeCookie(postProcessCookie);
        RSIPrincipal currentPlatformSessionPrincipal = sessionManager.getUserPrincipal(wrappedRequest);

        if (currentESSPrincipal != null && currentESSPrincipal != null &&
            !currentPlatformSessionPrincipal.getUserName().equals(currentESSPrincipal.getUserName())) {
          if (log.isInfoEnabled()) log.info("Platform session user no longer matches cookie : " + currentESSPrincipal.getUserName() +"->"+ currentPlatformSessionPrincipal.getUserName() + " updating ESS cookie.");
          createSecureCookie(cookieManager, wrappedRequest, resp, currentPlatformSessionPrincipal);
        }
      }
    }
  }

  /**
   * Creates an ESS Cookie from the session and binds it to the HttpServletResponse.
   * @param cookieManager
   * @param req
   * @param resp
   * @return
   */
  protected RSIPrincipal createSecureCookie(SessionCookieManager cookieManager, HttpServletRequest req, HttpServletResponse resp) {
    return createSecureCookie(cookieManager, req, resp, sessionManager.getUserPrincipal(req));
  }

  /**
   * Use this method if you already have the principal to avoid processing twice
   * @param cookieManager
   * @param req
   * @param resp
   * @param principal
   * @return
   */
  private RSIPrincipal createSecureCookie(SessionCookieManager cookieManager, HttpServletRequest req, HttpServletResponse resp, RSIPrincipal principal) {

    if (principal != null) {
      Cookie securityCookie = cookieManager.encodeCookie(principal, req.isSecure());
      resp.addCookie(securityCookie);
      if (log.isDebugEnabled()) log.debug("ESS cookie added to response.");
    }
    return principal;
  }


  private RSIPrincipal processCookie(HttpServletRequest req, HttpServletResponse resp, Cookie securityCookie, boolean regenerateSession, SessionCookieManager cookieManager)
  {
    RSIPrincipal principal = cookieManager.decodeCookie(securityCookie);

    // Cookie Signature authentication failed, delete cookie
    if (principal == null) {
      if (log.isDebugEnabled()) log.debug("ESS cookie failed validation, deleting");
      cookieManager.deleteCookie(securityCookie, resp);
    }
    else {
      if (!cookieManager.isDeactivated(principal)) {
        if (log.isDebugEnabled()) log.debug("ESS cookie is active");

        if (regenerateSession) {
          if (log.isDebugEnabled()) log.debug("Regenerating Platform session");
          sessionManager.regenerateSession(req, resp, principal);
        }

        cookieManager.updateExpiryDate(principal, securityCookie, resp);
      }
    }
    return principal;
  }

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    log.info("SessionManagement enabled");
  }

  @Override
  public void destroy() {
    log.info("SessionManagement disabled");
  }

  public PlatformSessionManager getSessionManager() {
    return sessionManager;
  }

  public void setSessionManager(PlatformSessionManager sessionManager) {
    this.sessionManager = sessionManager;
  }

  public SessionCookieManager getCookieManager() {
    return cookieManager;
  }

  public void setCookieManager(SessionCookieManager cookieManager) {
    this.cookieManager = cookieManager;
  }
}
