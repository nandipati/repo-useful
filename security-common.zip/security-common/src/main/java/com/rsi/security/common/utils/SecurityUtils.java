package com.rsi.security.common.utils;

import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.core.RSIUserImpl;
import com.rsi.security.common.core.UserContext;
import com.rsi.security.common.core.RSIUser;
import java.util.UUID;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtils {

    public static String getCurrentUsername() {
        RSIUser RSIUser = getCurrentUser();
        return RSIUser == null ? null : RSIUser.getUsername();
    }

    public static UUID getLeaRefId() {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser == null ? null : rsiUser.getLeaRefId();
    }

    public static UUID getSchoolRefId() {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser == null ? null : rsiUser.getSchoolRefId();
    }

    public static UUID getUserGuid() {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser == null ? null : rsiUser.getUserGuid();
    }

    public static boolean isStudent() {
        return hasRole(RSIRoleConverter.ROLE_STUDENT);
    }

    public static boolean isTeacher() {
        return hasRole(RSIRoleConverter.ROLE_TEACHER);
    }

    public static boolean isTrustedApi() {
        return hasRole(RSIRoleConverter.ROLE_TRUSTEDAPI);
    }

    /**
     * User Is District Admin if:
     * role is ADMINISTRATOR and
     * and 
     *      schoolRefId is blank 
     *      OR 
     *          schoolRefId equals districtRefId
     *          AND
     *          user is not belonging to an independent school - (A DA never belongs to an independent school confirmed by DS-159)
     * @return
     */
    public static boolean isDistrictAdmin() {
        UUID schoolRefId = getSchoolRefId();
        UUID leaRefId = getLeaRefId();
        return hasRole(RSIRoleConverter.ROLE_ADMINISTRATOR)
                && (leaRefId!=null)
                && ( (schoolRefId==null) || ( schoolRefId.equals(leaRefId) && isNotIndependentSchool())
        );
    }

    public static boolean isSchoolAdmin() {
        return hasRole(RSIRoleConverter.ROLE_ADMINISTRATOR) && getSchoolRefId() != null;
    }

    public static boolean isDistrictOrSchoolAdmin() {
        return hasRole(RSIRoleConverter.ROLE_ADMINISTRATOR);
    }

    public static boolean isNotIndependentSchool() {
        return !isIndependentSchool();
    }

    public static boolean isIndependentSchool() {
        RSIUser esUser = getCurrentUser();
        return esUser == null ? null : esUser.isIndependentSchool();
    }
    
    public static boolean hasScope(String scope) {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser != null && rsiUser.getScopes().contains(scope);
    }

    public static UserContext getUserContext() {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser == null ? null : rsiUser.getUserContext();
    }

    private static RSIUser getCurrentUser() {
        SecurityContext context = SecurityContextHolder.getContext();
        if (context == null) {
            return null;
        }
        Authentication authentication = context.getAuthentication();
        if (authentication == null) {
            return null;
        }

        Object principal = authentication.getPrincipal();
        if (principal == null || !principal.getClass().isAssignableFrom(RSIUserImpl.class)) {
            return null;
        }

        return (RSIUser) principal;
    }

    private static boolean hasRole(String role) {
        RSIUser rsiUser = getCurrentUser();
        return rsiUser != null && rsiUser.getAuthorities().contains(new SimpleGrantedAuthority(role));
    }
}
