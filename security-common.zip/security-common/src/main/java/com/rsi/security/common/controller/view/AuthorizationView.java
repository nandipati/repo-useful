package com.rsi.security.common.controller.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

import java.util.List;

/**
 * Created by nandipatim on 2/12/19.
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuthorizationView extends BaseAuthorizationView {

  @JsonProperty("auth_current_date_time")
  private String authCurrentDateTime;


}
