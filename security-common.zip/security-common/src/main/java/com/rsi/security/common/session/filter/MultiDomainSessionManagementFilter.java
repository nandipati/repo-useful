package com.rsi.security.common.session.filter;

import com.rsi.security.common.session.cookie.SessionCookieManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class MultiDomainSessionManagementFilter extends SessionManagementFilter {

  private static final Logger logger = Logger.getLogger(MultiDomainSessionManagementFilter.class);

  private List<Pattern> hostPatterns = new ArrayList<Pattern>();

  /**
   * Initialisation method for Spring container.
   */
  public void doInit()
  {
    Set<String> keys = cookieManagerMap.keySet();
    for(String key:keys)
    {
      Pattern pattern = Pattern.compile(key);
      hostPatterns.add(pattern);
    }

  }
  /**
   * This is the map containing the cookiemanagers configured for each platform.
   */
  private Map<String, SessionCookieManager> cookieManagerMap;


  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    //select the correct cookie manager based on the HOST header.
    SessionCookieManager cookieManager = selectCookieManager(request);
    if(cookieManager!=null)
    {
      HttpServletRequest req = (HttpServletRequest) request;
      HttpServletResponse resp = (HttpServletResponse) response;

      HttpServletRequest wrappedRequest = doProcess(req, resp, cookieManager);

      chain.doFilter(wrappedRequest, resp);

      doPostProcess(wrappedRequest, resp, cookieManager);
    }
    else
    {
      logger.warn("No cookie manager could be associated with the incoming request, moving on to next com.rsi.security.common.filter in chain");
      chain.doFilter(request, response);
    }
  }
  /*
   * Extracted this as a method for testability using easy mock.
   */
  public SessionCookieManager selectCookieManager(ServletRequest request) {
    //get the base domain (from the HOST header in the HTTP request).
    String baseDomain = getBaseDomain(request);
    SessionCookieManager selectedCookieManager=null;
    logger.debug("got base domain, it's " + baseDomain);
    if(baseDomain!=null)
    {
      //now get the correct cookieManager
      selectedCookieManager = cookieManagerMap.get(baseDomain);

      logger.debug("Selected the " + baseDomain + " cookie manager, proceeding with doFilter");
    }
    else {
      logger.warn("Can't select a cookie manager");
    }
    return selectedCookieManager;
  }
  /**
   * Returns the base domain from the host header so we can determine the correct Cookie Manager use.
   * @return
   */
  public String getBaseDomain(ServletRequest request){
    String serverName = request.getServerName();
    logger.debug("HOST attribute for matching cookiemanagers: " + serverName);
    String baseDomain=getBaseDomain(serverName);
    return baseDomain;

  }

  /**
   * Matches the request.getServerName() to the patterns in the hostPatterns list.
   * @param serverName
   * @return
   */
  private String getBaseDomain(String serverName){
    for(Pattern p : hostPatterns)
    {

      Matcher matcher = p.matcher(serverName);
      if(matcher.matches())
      {
        return p.pattern();
      }
    }
    logger.warn("Can't match host pattern");
    return null;

  }
  public Map<String, SessionCookieManager> getCookieManagerMap() {
    return cookieManagerMap;
  }
  public void setCookieManagerMap(Map<String, SessionCookieManager> cookieManagerMap) {
    this.cookieManagerMap = cookieManagerMap;
  }
}
