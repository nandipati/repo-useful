package com.rsi.security.common.session.header;

import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.auth.ApiClientAuthorization;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by nandipatim on 1/16/19.
 */
public interface HeaderManager {

  /**
   * Used to extract the Auth header.
   * @param req
   * @return ApiClientAuthorization
   */
  ApiClientAuthorization processAuthHeader(HttpServletRequest req);

  /**
   * Used to extract the Auth header and return a RSIPrincipal.
   * @param req
   * @return
   */
  RSIPrincipal decodeHeader(HttpServletRequest req);

  /**
   *  Decodes a JWT token into a RSIPrincipal
   * @param token
   * @return  RSIPrincipal
   */
  RSIPrincipal decodeToken(String token);

  /**
   * Encodes a RSIPrincipal into a Base 64 encoded JWT token
   * @param principal
   * @param expSeconds
   * @return
   */
  String generateToken(RSIPrincipal principal, int expSeconds);
}
