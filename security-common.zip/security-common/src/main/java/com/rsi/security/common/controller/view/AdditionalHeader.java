package com.rsi.security.common.controller.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import lombok.Data;

/**
 * Created by nandipatim on 4/10/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdditionalHeader implements Serializable{

  private String key;
  private String value;
}
