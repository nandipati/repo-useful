package com.rsi.security.common.utils;

import java.nio.ByteBuffer;
import java.util.UUID;
import org.springframework.util.StringUtils;

/**
 * @author Jonathan O'Donovan
 */
public class UUIDHelper {
    private static final int UUID_NUMBER_OF_DIGITS = 8 + 4 + 4 + 4 + 12;
    private static final String UUID_REGEX = "[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}";
    private static final String UUID_WITHOUT_DASHES_REGEX = "[a-fA-F0-9]{32}";

    public static UUID fromStringHandleEmptyString(String digits) {
        if (StringUtils.isEmpty(digits)) {
            return null;
        } else {
            return fromString(digits);
        }
    }

    public static UUID fromString(String digits) {
        UUID uuid = null;
        if (digits != null) {
            if (UUIDHelper.stringMatchesUUIDRegex(digits)) {
                uuid = UUID.fromString(digits);
            }
            else if (UUIDHelper.stringMatchesUUIDWithoutDashesRegex(digits)) {
                uuid = UUIDHelper.fromStringWithNoDashes(digits);
            }
            else {
                throw new IllegalArgumentException("Invalid UUID string: " + digits);
            }
        }
        return uuid;
    }

    /**
     * Converts byte array to UUID,
     * see http://stackoverflow.com/questions/24408984/convert-bytearray-to-uuid-java
     */
    public static UUID fromByteArray(byte[] bytes) {
        ByteBuffer bb = ByteBuffer.wrap(bytes);
        long high = bb.getLong();
        long low = bb.getLong();
        return new UUID(high, low);
    }

    private static UUID fromStringWithNoDashes(String digits) {
        if (digits.length() != UUID_NUMBER_OF_DIGITS) {
            throw new IllegalArgumentException("Invalid number of digits. "
                    + UUID_NUMBER_OF_DIGITS + " digits expected: " + digits);
        } else {
            return UUID.fromString(digits.replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5"));
        }
    }

    public static boolean stringMatchesUUIDRegex(String string) {
        return string.matches(UUID_REGEX);
    }

    public static boolean stringMatchesUUIDWithoutDashesRegex(String string) {
        return string.matches(UUID_WITHOUT_DASHES_REGEX);
    }


}
