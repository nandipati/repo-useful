package com.rsi.security.common.controller.view;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * Created by nandipatim on 2/12/19.
 */
@Data
public class AuthorizationRequestView {

  @JsonProperty("client_id")
  @NotNull
  private String clientId;

  @JsonProperty("client_secret")
  @NotNull
  private String clientSecret;

}
