package com.rsi.security.common.controller;

import com.rsi.security.common.constants.RestConstants;
import com.rsi.security.common.controller.view.AuthorizationRequestView;
import com.rsi.security.common.controller.view.AuthorizationView;
import com.rsi.security.common.controller.view.BaseAuthorizationView;
import com.rsi.security.common.service.AuthorizationService;
import com.rsi.security.common.token.utils.TokenType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;


/**
 * Created by nandipatim on 2/12/19.
 */

@RestController
@RequestMapping("v{" + RestConstants.VERSION_PARAM_NAME + "}/autorization")
public class AuthorizationController {

  @Autowired
  private AuthorizationService authorizationService;

  @RequestMapping(value = "/getAuthToken", method = RequestMethod.POST, produces = {RestConstants.JSON},
      consumes = {RestConstants.JSON})
  public AuthorizationView getAuthToken(
      @PathVariable(RestConstants.VERSION_PARAM_NAME) String versionNbr,
      @RequestBody @Valid AuthorizationRequestView requestView) {

    return authorizationService.genrateSIFToken(requestView);
  }

  @RequestMapping(value = "/getAuthToken", method = RequestMethod.POST, produces = {RestConstants.JSON,RestConstants.URLENCODED},
      consumes = {RestConstants.URLENCODED})
  public BaseAuthorizationView getAuthTokenUrlEncoding(
      @PathVariable(RestConstants.VERSION_PARAM_NAME) String versionNbr,
      @RequestParam("grant_type") @Valid String grantType,
      @RequestParam("client_id") @Valid String clientId,
      @RequestParam("client_secret") @Valid String clientSecret) {

    AuthorizationRequestView requestView = new AuthorizationRequestView();
    requestView.setClientId(clientId);
    requestView.setClientSecret(clientSecret);
    return authorizationService.genrateSIFTokenWithTokenType(requestView , TokenType.BEARER);
  }

}
