package com.rsi.security.common.converter;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class RSIRoleConverter {

    // SpringSecurity Roles
    public static final String ROLE_TRUSTEDAPI = "ROLE_TRUSTEDAPI";
    public static final String ROLE_PROCTOR = "ROLE_PROCTOR";
    public static final String ROLE_STUDENT = "ROLE_STUDENT";
    public static final String ROLE_TEACHER = "ROLE_TEACHER";
    public static final String ROLE_ADMINISTRATOR = "ROLE_ADMINISTRATOR";

    private static final Logger logger = LoggerFactory.getLogger(RSIRoleConverter.class);
    
    // Maps IDM claims to Spring Security roles.
    private static final Map<String, String> springSecurityRoleMap = new HashMap<String, String>()
    {

        {
            put("ADMINISTRATOR", ROLE_ADMINISTRATOR);
            put("INSTRUCTOR", ROLE_TEACHER);
            put("LEARNER", ROLE_STUDENT);
            put("TEACHER", ROLE_TEACHER);
            put("TRUSTEDAPI", ROLE_TRUSTEDAPI);
            put("PROCTOR", ROLE_PROCTOR);
    }};

    public String getSpringSecurityRole(String tokenRoleName) {
        String springRoleName = springSecurityRoleMap.get(tokenRoleName.toUpperCase());
        
        if (springRoleName == null) {
            throw new RuntimeException("Role : " + tokenRoleName + " is not currently supported");
        }
        
        logger.debug("Assigning role : {} to principal", springRoleName);
        
        return springRoleName;
    }

}
