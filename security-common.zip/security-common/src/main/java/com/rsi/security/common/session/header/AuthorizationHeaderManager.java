package com.rsi.security.common.session.header;

import com.rsi.security.common.session.util.CommonUtils;
import com.rsi.security.common.session.util.SecurityConstants;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.RSIPrincipalImpl;
import com.rsi.security.common.token.auth.ApiClientAuthorization;
import com.rsi.security.common.token.auth.ClientInfo;
import com.rsi.security.common.token.auth.ClientInfoStore;
import com.rsi.security.common.token.auth.SIFAuthorization;
import com.rsi.security.common.token.utils.TokenType;
import com.rsi.security.common.token.utils.TokenUtils;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import net.oauth.jsontoken.Clock;
import net.oauth.jsontoken.SystemClock;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.security.oauth2.provider.NoSuchClientException;

/**
 * Created by nandipatim on 1/16/19.
 */
public class AuthorizationHeaderManager implements HeaderManager {

  private static final Logger log = Logger.getLogger(AuthorizationHeaderManager.class);

  private DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

  private String audience;
  private String issuer;
  private int expireInSecs;
  private String sharedSecret = SecurityConstants.DEFAULT_SHARED_SECRET;
  private static final String ROLE_TRUSTED_API="TrustedAPI";
  private static final String[] standardClaimsToExtract = {
      TokenUtils.EXPIRY_CLAIM,
      TokenUtils.ISSUED_AT_CLAIM,
      TokenUtils.COOKIE_DEACTIVATED_KEY};


  private ClientInfoStore clientInfoStore;

  private Clock clock;

  private Set<String> sharedSecrets;

  public AuthorizationHeaderManager()
  {
    clock = new SystemClock();
  }

  @Override
  public RSIPrincipal decodeHeader(HttpServletRequest req) {
    String clientSecret=null;

    ApiClientAuthorization auth = processAuthHeader(req);

    RSIPrincipal principal;
    final RSIPrincipal finalPrincipal;
    ClientInfo clientInfo = null;
    if (auth != null) {

      if (log.isDebugEnabled()) log.debug("Header found");
      principal = CommonUtils.extractPrincipal(auth.getClientId(), sharedSecret, sharedSecrets , clock, audience);

      if (principal != null) {
        if (log.isDebugEnabled()) log.debug("Principal found : " + principal.toString());

        String clientId = (String)principal.getExtensionClaims().get(TokenUtils.CLIENT_ID_CLAIM);
        try
        {
          clientInfo = clientInfoStore.loadClientInfoByClientId(clientId);
        }
        catch(NoSuchClientException ns)
        {
          log.warn("Client Id not found");
          log.warn(ns.getMessage());
        }
        if(clientInfo!=null)
        {
          clientSecret= clientInfo.getClientSecret();
        }
        if (auth.isValid(clientSecret) ) {
          finalPrincipal=principal;
          return principal;
        }
      }
      else{
        try
        {
          clientInfo = clientInfoStore.loadClientInfoByClientId(auth.getClientId());
        }
        catch(NoSuchClientException ns)
        {
          log.warn("Client Id not found");
          log.warn(ns.getMessage());
        }
        if(clientInfo!=null && auth.isValid(clientInfo.getClientSecret()))
        {
          String authCurrentDateTime = auth.getAuthCurrentDateTime();
           if(authCurrentDateTime != null) {
            if(isTokenExpired(authCurrentDateTime)) {
              return null;
            }
          }
          //we have a client authorization header
          principal = new RSIPrincipalImpl(auth.getClientId());
          principal.addExtensionClaim(TokenUtils.CLIENT_ID_CLAIM, auth.getClientId());
          principal.setRoles(new String[]{ROLE_TRUSTED_API});
          principal.setUserName(auth.getClientId());
          finalPrincipal=principal;
          return finalPrincipal;
        }
      }

    }

    return null;
  }

  @Override
  public RSIPrincipal decodeToken(String token) {
    return TokenUtils.decodeJWT(token, standardClaimsToExtract, clock, audience, sharedSecret);
  }

  @Override
  public String generateToken(RSIPrincipal principal, int expSeconds) {
    String token = "";
    if (principal != null) {
      DateTime expiry = clock.now().toDateTime().plusSeconds(expSeconds);
      try {
        token = TokenUtils.generateJWT(audience, issuer, sharedSecret, principal, expiry, null, null);
      } catch (SignatureException ex) {
        log.error("Cannot Generate token due to signature exception", ex);
      } catch (InvalidKeyException ex) {
        log.error("Cannot Generate token due to invalid key.", ex);
      }
    }
    return token;
  }

  public Boolean isTokenExpired(String generatedTime) {

    if(generatedTime == null)
      return Boolean.TRUE;

    DateTime  dateTime =  dateTimeFormatter.parseDateTime(generatedTime);
    dateTime = dateTime.plusSeconds(expireInSecs);

    if(dateTime.isBeforeNow())
      return Boolean.TRUE;


    return Boolean.FALSE;
  }

  public ApiClientAuthorization processAuthHeader(HttpServletRequest req) {
    String authHeader = req.getHeader(SIFAuthorization.AUTHORIZATION);

    if (authHeader != null) {
      if (authHeader.startsWith(TokenType.MAC.toString())||authHeader.startsWith(TokenType.BEARER.toString())) {
        String authCurrentDateTime = req.getHeader(SIFAuthorization.SIF_AUTH_DATE_HDR);
        return new SIFAuthorization(authHeader, authCurrentDateTime == null ?  "" : authCurrentDateTime);
      }
    }
    return null;
  }

  public String getAudience() {
    return audience;
  }

  public void setAudience(String audience) {
    this.audience = audience;
  }

  public String getIssuer() {
    return issuer;
  }

  public void setIssuer(String issuer) {
    this.issuer = issuer;
  }

  public String getSharedSecret() {
    return sharedSecret;
  }

  public ClientInfoStore getClientInfoStore() {
    return clientInfoStore;
  }

  public void setClientInfoStore(ClientInfoStore clientInfoStore) {
    this.clientInfoStore = clientInfoStore;
  }

  public void setSharedSecret(String sharedSecret) {
    this.sharedSecret = sharedSecret;
  }

  public Set<String> getSharedSecrets() {
    return sharedSecrets;
  }

  public void setSharedSecrets(Set<String> sharedSecrets) {
    this.sharedSecrets = sharedSecrets;
  }

  public int getExpireInSecs() {
    return expireInSecs;
  }

  public void setExpireInSecs(int expireInSecs) {
    this.expireInSecs = expireInSecs;
  }
}
