package com.rsi.security.common.session.cookie;

import com.rsi.security.common.session.util.SecurityConstants;
import com.rsi.security.common.token.RSIPrincipal;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class SessionCookieManagerBase implements SessionCookieManager {

  private static final Logger log = Logger.getLogger(SessionCookieManagerBase.class);

  private String cookieName;
  private String domain;
  private int sessionTimeoutSecs = SecurityConstants.DEFAULT_SESSION_TIMOUT_SECS;

  @Override
  public Cookie encodeCookie(RSIPrincipal principal, boolean isRequestSecure) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public RSIPrincipal decodeCookie(Cookie cookie) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public void updateExpiryDate(RSIPrincipal principal, Cookie cookie, HttpServletResponse resp) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public Cookie deactivateCookie(Cookie cookie) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public boolean isDeactivated(RSIPrincipal principal) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  @Override
  public Cookie getCookie(HttpServletRequest req) {

    Cookie securityCookie = null;

    Cookie[] cookies = req.getCookies();
    if (cookies != null) {
      for(Cookie cookie : req.getCookies()) {
        if (cookie.getName().equals(cookieName)) {
          if (log.isDebugEnabled()) log.debug(cookieName + " found");
          securityCookie = cookie;
          break;
        }
      }
    }
    return securityCookie;
  }

  protected Cookie buildCookie(String value, boolean isRequestSecure)
  {
    Cookie cookie = new Cookie(this.getCookieName(), value);
    if (getDomain() != null && getDomain().length() > 0) cookie.setDomain(getDomain());
    cookie.setMaxAge(sessionTimeoutSecs);
    cookie.setPath("/");
    cookie.setSecure(isRequestSecure);

    return cookie;
  }

  @Override
  public void deleteCookie(Cookie cookie, HttpServletResponse response) {
    if (getDomain() != null && getDomain().length() > 0) cookie.setDomain(getDomain());
    cookie.setMaxAge(0);
    cookie.setPath("/");
    cookie.setSecure(cookie.getSecure());

    response.addCookie(cookie);
  }

  protected StringBuilder generateCookieHeader(Cookie cookie, String expiry) {
    StringBuilder cookieHeaderValue = new StringBuilder(this.getCookieName());
    //Value
    cookieHeaderValue.append(SecurityConstants.COOKIE_FIELD_EQUALS)
        .append(cookie.getValue())
        .append(SecurityConstants.COOKIE_FIELD_DELIMITER);
    // Domain
    if (getDomain() != null && getDomain().length() > 0) {
      cookieHeaderValue
          .append(SecurityConstants.COOKIE_DOMAIN_KEY)
          .append(getDomain())
          .append(SecurityConstants.COOKIE_FIELD_DELIMITER);
    }
    // Expiry Date & path
    cookieHeaderValue
        .append(SecurityConstants.COOKIE_EXPIRES_KEY)
        .append(expiry)
        .append(SecurityConstants.COOKIE_FIELD_DELIMITER)
        .append(SecurityConstants.COOKIE_PATH_KEY);
    // Optional Secure
    if (cookie.getSecure())
      cookieHeaderValue.append(SecurityConstants.COOKIE_FIELD_DELIMITER).append(SecurityConstants.COOKIE_SECURE_KEY);
    return cookieHeaderValue;
  }

  /**
   * @return the cookieName
   */
  protected String getCookieName() {
    return cookieName;
  }

  /**
   * @param cookieName the cookieName to set
   */
  protected void setCookieName(String cookieName) {
    this.cookieName = cookieName;
  }

  @Override
  public void setDomain(String domain) {
    this.domain = domain;
  }

  /**
   * @return the domain
   */
  protected String getDomain() {
    return domain;
  }

  @Override
  public int getSessionTimeoutSecs() {
    return sessionTimeoutSecs;
  }

  @Override
  public void setSessionTimeoutSecs(int sessionTimeoutSecs) {
    this.sessionTimeoutSecs = sessionTimeoutSecs;
  }
}
