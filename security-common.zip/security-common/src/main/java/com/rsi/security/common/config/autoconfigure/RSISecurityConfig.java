package com.rsi.security.common.config.autoconfigure;


import com.rsi.security.common.config.RSISecurityProperties;
import com.rsi.security.common.filter.RSIAuthorizationHeaderFilter;
import com.rsi.security.common.filter.RSIPreAuthenticatedFilter;
import com.rsi.security.common.filter.ValidationFilter;
import com.rsi.security.common.service.RSIUserDetailsService;
import com.rsi.security.common.session.filter.AuthorizationHeaderFilter;
import com.rsi.security.common.session.header.AuthorizationHeaderManager;
import com.rsi.security.common.token.auth.BasicClientInfo;
import com.rsi.security.common.token.auth.ClientInfo;
import com.rsi.security.common.token.auth.InMemoryClientInfoStore;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.servlet.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.security.web.context.SecurityContextPersistenceFilter;

/**
 * This configuration initialises only if the property rsinsightssecurity.enabled has a value "true"
 * If an application has the property "rsisecurity.enabled" has a value equal to true" then
 * this configuration initialises itself and SIF token authorization is active otherwise it's not.
 *
 */
@EnableWebSecurity
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableConfigurationProperties(RSISecurityProperties.class)
@ConditionalOnProperty(name="rsisecurity.enabled", havingValue="true")
public class RSISecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * Key used to decode SIF token
     */
    @Value("${ess.sharedSecret:a5b7RFA/liU/0JNu6n0SWN9kxa9Iop3r0j1Ik+6EScLfMfPEOgNxhk/ig1+h1rmJbiqsD9OWqHRdtsLWpr6A0Fw6xPXZiooAP4cRhHurAcrmvjHTizw3jMxx1E2NZ0wz3YQOqnnc2jGqpMrtnBWrf1mJLnul9is2wZYLf1tl/ks=}")
    private String sharedSecret;

    @Autowired
    SecurityCommonConfig autoConfiguration;

    @Autowired
    private RSISecurityProperties rsiSecurityProperties;

    private Filter authorizationHeaderFilter() {
        AuthorizationHeaderFilter authorizationHeaderFilter = new RSIAuthorizationHeaderFilter();
        authorizationHeaderFilter.setHeaderManager(authorizationHeaderManager());
        return authorizationHeaderFilter;
    }
    
    @Bean
    public AuthorizationHeaderManager authorizationHeaderManager() {
        AuthorizationHeaderManager headerMgr = new AuthorizationHeaderManager();
        headerMgr.setAudience(rsiSecurityProperties.getAudience());
        headerMgr.setIssuer(rsiSecurityProperties.getIssuer());
        headerMgr.setSharedSecret(sharedSecret);
        headerMgr.setExpireInSecs(rsiSecurityProperties.getExpireInSecs());
        headerMgr.setClientInfoStore(getInMemoryClientInfoStore());
        return headerMgr;
    }

    private Filter preAuthenticatedFilter() {
        RSIPreAuthenticatedFilter preAuthenticatedFilter = new RSIPreAuthenticatedFilter();
        preAuthenticatedFilter.setCheckForPrincipalChanges(true);

        try {
            preAuthenticatedFilter.setAuthenticationManager(authenticationManager());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return preAuthenticatedFilter;
    }

    /**
     * Validates a principal exists in the request.
     */
    private Filter validationFilter() {
        return new ValidationFilter();
    }

    @Bean
    public InMemoryClientInfoStore getInMemoryClientInfoStore(){
        InMemoryClientInfoStore store = new InMemoryClientInfoStore();
        store.setClients(getClientInfos());
        return store;
    }

    private Set<ClientInfo> getClientInfos(){
        Set<ClientInfo> setOfClientInfo = new HashSet<>();
        
        for(Map.Entry<String, String> entry: rsiSecurityProperties.getClientStore().entrySet()){
            BasicClientInfo info = new BasicClientInfo(entry.getKey());
            info.setClientSecret(entry.getValue());
            setOfClientInfo.add(info);
        }
        
        return setOfClientInfo;
    }

    @Bean
    public AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService() {
        return new RSIUserDetailsService();
    }

    @Bean
    public PreAuthenticatedAuthenticationProvider preAuthProvider() {
        PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();
        provider.setPreAuthenticatedUserDetailsService(authenticationUserDetailsService());
        return provider;
    }



    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(preAuthProvider());
    }
    
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
    
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers("/api-docs/**") //swagger
            .antMatchers("/docs/**") //swagger
            
			.antMatchers("/v2/api-docs")		//swagger
			.antMatchers("/swagger-resources")	//swagger
      .antMatchers("/swagger-resources/configuration/ui")  //swagger
      .antMatchers("/swagger-resources/configuration/security")   //swagger
			.antMatchers("/swagger-ui.html")	//swagger
			.antMatchers("/webjars/springfox-swagger-ui/**") //swagger
			.antMatchers("/configuration/ui")	//swagger
			.antMatchers("/configuration/com.rsi.security.common.security") //swagger
      .antMatchers("/v*/autorization/getAuthToken").antMatchers("/graphql").antMatchers("/**/graphql")
      .antMatchers("/graphiql").antMatchers("/reporting-api")
      .antMatchers("/health")
      .antMatchers("/metrics")
      .antMatchers("/v1/autorization/getAuthToken").antMatchers("/**/autorization/getAuthToken");;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.addFilterAfter(authorizationHeaderFilter(), SecurityContextPersistenceFilter.class);
        http.addFilterAfter(preAuthenticatedFilter(), authorizationHeaderFilter().getClass());
        http.addFilterAfter(validationFilter(), preAuthenticatedFilter().getClass());
        http.httpBasic().disable();
        
        http.exceptionHandling().authenticationEntryPoint(new Http403ForbiddenEntryPoint());
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        if (!rsiSecurityProperties.isCsrfEnabled()) {
            http.csrf().disable(); //it's on by default...
        }
    }

}