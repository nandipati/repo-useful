package com.rsi.security.common.filter;

import java.io.IOException;
import java.util.Locale;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import org.springframework.http.HttpMethod;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * A com.rsi.security.common.filter to support HTTP method replacing of a POST request to a request utilizing another HTTP method
 * for the case where proxies or HTTP servers would otherwise block that HTTP method.
 * This com.rsi.security.common.filter may be used to replace a POST request with a PATCH , PUT or DELETE request.
 *
 * Replacement will occur if the request method is POST and there exists an a request header "X-HTTP-Method-Override" with a non-empty value. 
 * That value will be the HTTP method that replaces the POST method
 */

public class XHTTPMethodOverrideFilter extends OncePerRequestFilter {

	
	public static final String OVERRIDE_HEADER = "X-HTTP-Method-Override";

	private String overrideHeader = OVERRIDE_HEADER;


	/**
	 * Set the parameter name to look for HTTP methods.
	 * @see #OVERRIDE_HEADER
	 */
	public void setMethodParam(String methodParam) {
		Assert.hasText(methodParam, "'overrideHeader' must not be empty");
		this.overrideHeader = methodParam;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String headerValue = request.getHeader(this.overrideHeader);
		if (HttpMethod.POST.name().equals(request.getMethod()) && StringUtils.hasLength(headerValue)) {
			String method = headerValue.toUpperCase(Locale.ENGLISH);
			HttpServletRequest wrapper = new HttpMethodRequestWrapper(request, method);
			filterChain.doFilter(wrapper, response);
		}
		else {
			filterChain.doFilter(request, response);
		}
	}


	/**
	 * Simple {@link HttpServletRequest} wrapper that returns the supplied method for
	 * {@link HttpServletRequest#getMethod()}.
	 */
	private static class HttpMethodRequestWrapper extends HttpServletRequestWrapper {

		private final String method;

		public HttpMethodRequestWrapper(HttpServletRequest request, String method) {
			super(request);
			this.method = method;
		}

		@Override
		public String getMethod() {
			return this.method;
		}
	}

}
