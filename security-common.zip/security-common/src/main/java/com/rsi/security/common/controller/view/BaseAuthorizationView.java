package com.rsi.security.common.controller.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * Created by nandipatim on 4/12/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseAuthorizationView  implements Serializable {

  @JsonProperty("access_token")
  private String accessToken;

  @JsonProperty("token_type")
  private String tokenType;

  @JsonProperty("expires_in")
  private Integer expiresIn;

  @JsonProperty("scope")
  private String scope;

}
