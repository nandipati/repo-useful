package com.rsi.security.common.session.util;

/**
 * Created by nandipatim on 1/16/19.
 */
public class SecurityConstants {

  public static final String DEFAULT_SHARED_SECRET = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALRiMLAh9iimur8VA7qVvdqxevEuUkW4K+2KdMXmnQbG9Aa7k7eBjK1S+0LYmVjPKlJGNXHDGuy5Fw/d7rjVJ0BLB+ubPK8iA/Tw3hLQgXMRRGRXXCn8ikfuQfjUS1uZSatdLB81mydBETlJhI6GH4twrbDJCR2Bwy/XWXgqgGRzAgMBAAECgYBYWVtleUzavkbrPjy0T5FMou8HX9u2AC2ry8vD/l7cqedtwMPp9k7TubgNFo+NGvKsl2ynyprOZR1xjQ7WgrgVB+mmuScOM/5HVceFuGRDhYTCObE+y1kxRloNYXnx3ei1zbeYLPCHdhxRYW7T0qcynNmwrn05/KO2RLjgQNalsQJBANeA3Q4Nugqy4QBUCEC09SqylT2K9FrrItqL2QKc9v0ZzO2uwllCbg0dwpVuYPYXYvikNHHg+aCWF+VXsb9rpPsCQQDWR9TT4ORdzoj+NccnqkMsDmzt0EfNaAOwHOmVJ2RVBspPcxt5iN4HI7HNeG6U5YsFBb+/GZbgfBT3kpNGWPTpAkBI+gFhjfJvRw38n3g/+UeAkwMI2TJQS4n8+hid0uus3/zOjDySH3XHCUnocn1xOJAyZODBo47E+67R4jV1/gzbAkEAklJaspRPXP877NssM5nAZMU0/O/NGCZ+3jPgDUno6WbJn5cqm8MqWhW1xGkImgRk+fkDBquiq4gPiT898jusgQJAd5Zrr6Q8AO/0isr/xOtfOz+Bs4Io9+dZGSDCA54Lw03eHTNQghS0A==";

  public static int DEFAULT_SESSION_TIMOUT_SECS = 3600;
  public static String COOKIE_DEACTIVATED_KEY = "deactivated";
  public static String COOKIE_DEACTIVATED_VALUE = "1";

  public static final String DEFAULT_COOKIE_EXPIRES_FORMAT = "EEE, dd-MMM-yyyy kk:mm:ss z";
  public static final String UTC = "UTC";

  public static final String COOKIE_DOMAIN_KEY = "Domain=";
  public static final String COOKIE_EXPIRES_KEY = "Expires=";
  public static final String COOKIE_PATH_KEY = "Path=/";
  public static final String COOKIE_SECURE_KEY = "Secure";
  public static final String SET_COOKIE_HEADER = "Set-Cookie";

  public static final String COOKIE_FIELD_DELIMITER = "; ";
  public static final String COOKIE_FIELD_EQUALS = "=";
  public static final String LOCATION = "Location";

}
