package com.rsi.security.common.service;

import com.google.common.collect.Sets;
import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.converter.ScopeConverter;
import com.rsi.security.common.core.RSIUserImpl;
import com.rsi.security.common.core.UserContext;
import com.rsi.security.common.constants.SecurityClaim;
import com.rsi.security.common.core.RSIUser;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.utils.UUIDHelper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

public class RSIUserDetailsService implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {

    @Value("${scope.defaultScope:scope_none}")
    private String defaultScope;

    @Autowired
    private RSIRoleConverter roleConverter;

    @Autowired
    private ScopeConverter scopeConverter;

    @Override
    public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) throws UsernameNotFoundException {
        RSIPrincipal principal = (RSIPrincipal) token.getPrincipal();

        String[] tokenRoles = principal.getRoles();

        Collection<GrantedAuthority> grants = new ArrayList<>();
        String role;
        for (int i = 0; i < tokenRoles.length; i++) {
            role = roleConverter.getSpringSecurityRole(tokenRoles[i]);
            grants.add(new SimpleGrantedAuthority(role));
        }

        String userId = principal.getGuid();
        // In the case of a HmhRoleConverter.ROLE_TRUSTEDAPI the Guid will be null, so fallback to username
        if (StringUtils.isBlank(userId)) {
            userId = principal.getUserName();
        }

        Map<String, Object> extensionClaims = principal.getExtensionClaims();
        Set<String> scopes = new HashSet<>();
        for (String scope : fetchScopes(extensionClaims)) {
            scopes.add(scopeConverter.getScope(scope));
        }

        RSIUser user = new RSIUserImpl(userId, grants, scopes);
        user.setTokenRoles(tokenRoles);


        UUID leaRefId = UUIDHelper.fromString((String) extensionClaims.get(SecurityClaim.DIST_REFID));
        UUID schoolRefId = UUIDHelper.fromString((String) extensionClaims.get(SecurityClaim.SCHOOL_REFID));

        UserContext userContext = getUserContext(extensionClaims);

        // to distinguish district admins from school admins, IDM return a token where schoolRefId is set to equal the leaRefId.
        // however we don't use this logic beyond IDM and we denote district admins in this class by setting the schoolRefId null and only
        // assigning the leaRefId.
        UUID schoolRefIdToSet = leaRefId != null && leaRefId.equals(schoolRefId) ? null : schoolRefId;

        user.setUserGuid(UUIDHelper.fromString(principal.getGuid()));
        user.setLeaRefId(leaRefId);
        user.setSchoolRefId(schoolRefIdToSet);
        user.setUserContext(userContext);
        user.setIndependentSchool(SecurityClaim.SCHOOL_CATEGORY_PRIVATE.equals(extensionClaims.get(SecurityClaim.SCHOOL_CATEGORY)));

        return user;
    }

    private Set<String> fetchScopes(Map<String, Object> extensionClaims) {
        String scope = (String)extensionClaims.get(SecurityClaim.SCOPE);
        if (scope != null) {
            return Sets.newHashSet(scope);
        }
        return Sets.newHashSet(defaultScope);
    }

    private UserContext getUserContext(Map<String, Object> extensionClaims) {
        String contextId = (String) extensionClaims.get(SecurityClaim.CONTEXT_ID);
        return StringUtils.isBlank(contextId) ? null : UserContext.fromString(contextId);
    }
}
