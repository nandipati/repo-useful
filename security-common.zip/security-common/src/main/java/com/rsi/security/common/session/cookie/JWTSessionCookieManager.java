package com.rsi.security.common.session.cookie;

import com.rsi.security.common.session.util.CommonUtils;
import com.rsi.security.common.session.util.SecurityConstants;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.RSIPrincipalImpl;
import com.rsi.security.common.token.utils.TokenUtils;
import java.security.InvalidKeyException;
import java.security.Provider;
import java.security.Security;
import java.security.SignatureException;
import java.util.Set;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import net.oauth.jsontoken.Clock;
import net.oauth.jsontoken.SystemClock;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Created by nandipatim on 1/16/19.
 */
public class JWTSessionCookieManager extends SessionCookieManagerBase implements SessionCookieManager {

  private static final Logger log = Logger.getLogger(JWTSessionCookieManager.class);

  public final static String DEFAULT_COOKIE_NAME = "Authn";

  private String audience = "RSIPlatformId";
  private String issuer = "https://my.hrw.com";
  private String platformId = "https://my.hrw.com";
  private String sharedSecret = SecurityConstants.DEFAULT_SHARED_SECRET;
  private Set<String> sharedSecrets;
  public static final String[] standardClaimsToExtract = { TokenUtils.EXPIRY_CLAIM, TokenUtils.ISSUED_AT_CLAIM, SecurityConstants.COOKIE_DEACTIVATED_KEY,
      TokenUtils.PLATFORM_CLAIM };

  private Clock clock;

  public JWTSessionCookieManager() {
    this.setCookieName(DEFAULT_COOKIE_NAME);
    clock = new SystemClock();
  }

  public JWTSessionCookieManager(Set<String> sharedSecrets) {
    this();
    this.sharedSecrets = sharedSecrets;
  }

  /**
   * This method can be used to initialize any resources required by this
   * Spring bean via adding the <code>init-method="init"</code> com.rsi.security.common.config
   * attribute to this beans declaration. It will install the
   * <code>BouncyCastle</code> Security Provider that is currently required on
   * some JDK environments.
   */
  public void init() {

    log.info("Initialise JWTSessionCookieManager");

    Provider[] providers = Security.getProviders();
    boolean installed = false;

    log.info("Checking installed Security Providers : ");
    for (int i = 0; i < providers.length; i++) {
      Provider provider = providers[i];
      log.info("Found : " + provider.getName());

      if (provider.getClass() == BouncyCastleProvider.class)
        installed = true;
    }

    if (!installed) {
      log.info("BouncyCastle Provider NOT found. Installing at position 1...");
      Security.insertProviderAt(new BouncyCastleProvider(), 1);

      providers = Security.getProviders();

      installed = false;
      log.info("Verifying installation : ");
      for (int i = 0; i < providers.length; i++) {
        Provider provider = providers[i];
        log.info("Found: " + provider.getName());

        if (i == 0 && provider.getClass() == BouncyCastleProvider.class)
          installed = true;
      }
    }
    if (installed)
      log.info("BouncyCastle SUCCESSFULLY installed.");
    else
      log.error("BouncyCastle Provider was NOT installed. Errors may occur while signing ESS cookie...");
  }

  /**
   * This method can be used to clean up any resources by adding
   * <code>destroy-method="cleanup"</code> to the beans declaration. At
   * present, it removes <code>BouncyCastle</code> Security Provider from the
   * running JVM.
   */
  public void cleanUp() {

    log.info("Clean up JWTSessionCookieManager");

    Provider provider = Security.getProvider(BouncyCastleProvider.PROVIDER_NAME);
    if (provider != null) {
      Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME);
      log.info("BouncyCastle SUCCESSFULLY removed");
    } else {
      log.info("BouncyCastle was not installed. Nothing to remove.");
    }
  }

  @Override
  public Cookie encodeCookie(RSIPrincipal principal, boolean isRequestSecure) {
    Instant now = clock.now();
    DateTime expiry = now.toDateTime(DateTimeZone.UTC).plusSeconds(getSessionTimeoutSecs());
    return encodeCookie(principal, isRequestSecure, expiry);
  }

  /**
   * Encode the supplied Principal as a signed JWT
   *
   * @param principal
   *            carries a standard set of claims expected by RSI platforms
   * @param isRequestSecure
   *            set to true if the cookie will be delivered via https
   * @param expiry
   *            time at which the token and cookie should expire
   * @return
   */
  protected Cookie encodeCookie(RSIPrincipal principal, boolean isRequestSecure, DateTime expiry) {
    String signedToken = "";
    try {
      signedToken = TokenUtils.generateJWT(audience, issuer, sharedSecret, principal, expiry, new String[] { TokenUtils.PLATFORM_CLAIM },
          new String[] { getPlatformId() });

    } catch (SignatureException ex) {
      log.error("Unexpected error signing cookie", ex);
    } catch (InvalidKeyException ex) {
      log.error("Unexpected error with shared secret", ex);
    }

    return buildCookie(signedToken, isRequestSecure);
  }

  /**
   * Internal method allowing us to test by passing in a test friendly Clock
   * implementation. API users should use the
   * <code>public RSIPrincipal decodeCookie(Cookie cookie)</code> method.
   *
   * @param cookie
   * @return
   */
  public RSIPrincipal decodeCookie(Cookie cookie) {
    String tokenStr = cookie.getValue();
    RSIPrincipal rsiPrincipal = CommonUtils.extractPrincipal(tokenStr, sharedSecret, sharedSecrets, clock, audience);
    return rsiPrincipal;
  }

  /**
   * Update the expiry on the cookie, and on the exp claim in the JWT
   *
   * @param cookie
   * @param resp
   */
  @Override
  public void updateExpiryDate(RSIPrincipal principal, Cookie cookie, HttpServletResponse resp) {

    if (log.isDebugEnabled())
      log.debug("Updating ESS expiry date");

    if (principal != null) {
      Instant now = clock.now();

      long expiryTimeInSecs = principal.getExpiresAt() / 1000L;
      int currentTimeInSecs = (int) (now.getMillis() / 1000L);

      int timeout = getSessionTimeoutSecs();
      if ((expiryTimeInSecs - currentTimeInSecs) < (timeout / 2)) {
        DateTime expiryTime = now.toDateTime(DateTimeZone.UTC).plusSeconds(timeout);
        Cookie updatedCookie = encodeCookie(principal, cookie.getSecure(), expiryTime);

        DateTimeFormatter fmt = DateTimeFormat.forPattern(SecurityConstants.DEFAULT_COOKIE_EXPIRES_FORMAT);
        StringBuilder cookieHeaderValue = generateCookieHeader(updatedCookie, fmt.print(expiryTime));
        resp.addHeader(SecurityConstants.SET_COOKIE_HEADER, cookieHeaderValue.toString());
      }
    }
  }

  @Override
  public Cookie deactivateCookie(Cookie cookie) {
    RSIPrincipal principal = decodeCookie(cookie);
    if (principal == null) {
      principal = new RSIPrincipalImpl(SecurityConstants.COOKIE_DEACTIVATED_KEY);
    }
    principal.addClaim(SecurityConstants.COOKIE_DEACTIVATED_KEY, SecurityConstants.COOKIE_DEACTIVATED_VALUE);

    return encodeCookie(principal, cookie.getSecure());
  }

  @Override
  public boolean isDeactivated(RSIPrincipal principal) {
    boolean deactivated = true;
    if (principal != null) {
      // If it doesn't contain the magic key "deactived" and isn't expired
      // then it's not deactivated
      if (!principal.containsClaim(SecurityConstants.COOKIE_DEACTIVATED_KEY)) {
        long expiry = principal.getExpiresAt();
        long now = System.currentTimeMillis();
        if (expiry > now) {
          deactivated = false;
        }
      }
    }
    if (log.isDebugEnabled())
      log.debug("ESS " + (deactivated ? "" : " NOT") + "deactivated");
    return deactivated;
  }

  public String getSharedSecret() {
    return sharedSecret;
  }

  public void setSharedSecret(String sharedSecret) {
    this.sharedSecret = sharedSecret;
  }

  /**
   * @return the audience
   */
  public String getAudience() {
    return audience;
  }

  /**
   * @param audience
   *            the audience to set
   */
  public void setAudience(String audience) {
    this.audience = audience;
  }

  /**
   * @return the issuer
   */
  public String getIssuer() {
    return issuer;
  }

  /**
   * @param issuer
   *            the issuer to set
   */
  public void setIssuer(String issuer) {
    this.issuer = issuer;
  }

  /**
   *
   * @return The PlatformId claim value
   */
  public String getPlatformId() {
    return platformId;
  }

  /**
   * Set the PlatformId claim value
   *
   * @param platformId
   */
  public void setPlatformId(String platformId) {
    this.platformId = platformId;
  }

  public void setClock(Clock clock) {
    this.clock = clock;
  }

  public Set<String> getSharedSecrets() {
    return sharedSecrets;
  }

  public void setSharedSecrets(Set<String> sharedSecrets) {
    this.sharedSecrets = sharedSecrets;
  }

}
