package com.rsi.security.common.service;

import com.rsi.security.common.config.RSISecurityProperties;
import com.rsi.security.common.controller.view.AdditionalHeader;
import com.rsi.security.common.controller.view.AuthorizationRequestView;
import com.rsi.security.common.controller.view.AuthorizationView;
import com.rsi.security.common.controller.view.BaseAuthorizationView;
import com.rsi.security.common.token.auth.ClientInfo;
import com.rsi.security.common.token.auth.ClientInfoStore;
import com.rsi.security.common.token.auth.InMemoryClientInfoStore;
import com.rsi.security.common.token.auth.SIFAuthorization;
import com.rsi.security.common.token.utils.TokenType;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.provider.NoSuchClientException;
import org.springframework.stereotype.Service;

import java.util.List;
import org.springframework.util.StringUtils;

/**
 * Created by nandipatim on 2/12/19.
 */
@Service
@Slf4j
public class AuthorizationServiceImpl implements AuthorizationService{

  private DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

  @Autowired
  private RSISecurityProperties rsiSecurityProperties;

  @Autowired
  private InMemoryClientInfoStore inMemoryClientInfoStore;

  @Override
  public AuthorizationView genrateSIFToken(AuthorizationRequestView authorizationRequestView) {

    AuthorizationView authorizationView = getAuthorizationView(authorizationRequestView , TokenType.MAC ,Boolean.TRUE,Boolean.FALSE);

    return authorizationView;
  }

  private AuthorizationView getAuthorizationView(AuthorizationRequestView authorizationRequestView , TokenType tokenType,
                                                 Boolean includeTokenType, Boolean skipClientVerification) {
    String isoAuthCurrentDateTime = dateTimeFormatter.print(DateTime.now());
    String clientId = authorizationRequestView.getClientId();
    String clientSecret = authorizationRequestView.getClientSecret();
    ClientInfo clientInfo = null;
    if(!skipClientVerification) {
      if (inMemoryClientInfoStore != null) {
        try {
          clientInfo = inMemoryClientInfoStore.loadClientInfoByClientId(clientId);
        } catch (NoSuchClientException ns) {
          log.warn("Client Id not found");
          log.warn(ns.getMessage());
        }
      }

      if (clientInfo != null) {
        String secret = clientInfo.getClientSecret();

        if (StringUtils.isEmpty(secret) || !secret.equalsIgnoreCase(clientSecret)) {
          throw new IllegalArgumentException("Client Secret not found");
        }
      }
    }

    SIFAuthorization sifAuthorization = new SIFAuthorization(authorizationRequestView.getClientId(),
        authorizationRequestView.getClientSecret(),isoAuthCurrentDateTime , tokenType , includeTokenType);
    String authorization = sifAuthorization.getAuthorization();

    String authCurrentDateTime = sifAuthorization.getAuthCurrentDateTime();

    AuthorizationView authorizationView = new AuthorizationView();

    authorizationView.setAccessToken(authorization);
    authorizationView.setAuthCurrentDateTime(authCurrentDateTime);
    authorizationView.setExpiresIn(rsiSecurityProperties.getExpireInSecs());

    authorizationView.setScope(rsiSecurityProperties.getScope());
    authorizationView.setTokenType(tokenType.toString());
    return authorizationView;
  }

  @Override
  public AuthorizationView genrateSIFToken(AuthorizationRequestView authorizationRequestView,
                                           Boolean skipClientVerification) {

    AuthorizationView authorizationView = getAuthorizationView(authorizationRequestView , TokenType.MAC ,
        Boolean.TRUE,Boolean.TRUE);

    return authorizationView;
  }

  @Override
  public BaseAuthorizationView genrateSIFTokenWithTokenType(AuthorizationRequestView authorizationRequestView ,
                                                            TokenType tokenType) {

    AuthorizationView authorizationView = getAuthorizationView(authorizationRequestView , tokenType ,Boolean.FALSE,Boolean.FALSE);

    BaseAuthorizationView baseAuthorizationView = new BaseAuthorizationView();

    BeanUtils.copyProperties(authorizationView , baseAuthorizationView);

    return baseAuthorizationView;
  }
}
