package com.rsi.security.common.session.filter;

import com.rsi.security.common.session.header.HeaderManager;
import com.rsi.security.common.token.RSIPrincipal;
import java.io.IOException;
import java.security.Principal;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 * Created by nandipatim on 1/16/19.
 */
public class AuthorizationHeaderFilter  implements Filter {

  private static final Logger log = Logger.getLogger(AuthorizationHeaderFilter.class);

  private HeaderManager headerManager;



  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

    if (log.isDebugEnabled()) { log.debug("Processing request");}

    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse resp = (HttpServletResponse) response;

    HttpServletRequest wrappedRequest = doProcess(req, resp);

    chain.doFilter(wrappedRequest, resp);
  }

  /**
   * Extract the Authorization header and set the user principal on the request, adding the clientId extension claim.
   *
   * @param req
   * @param resp
   * @throws IOException
   * @throws ServletException
   */
  protected HttpServletRequest doProcess(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

    final RSIPrincipal principal = headerManager.decodeHeader(req);

    if (principal != null)
    {
      log.debug("Header decoded");
      HttpServletRequestWrapper wrappedRequest  = new HttpServletRequestWrapper((HttpServletRequest)req)
      {
        @Override
        public Principal getUserPrincipal() {
          return principal;
        }

        @Override
        public String getRemoteUser() {
          final Principal principal = this.getUserPrincipal();
          return (principal != null) ? principal.getName() : null;
        }

        @Override
        public boolean isUserInRole(String role)
        {
          boolean isInRole;
          if (principal != null)
            isInRole = principal.isUserInRole(role);
          else
            isInRole = super.isUserInRole(role);

          return isInRole;
        }
      };
      return wrappedRequest;
    }
    return req;
  }


  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    log.info("Authorization enabled");
  }

  @Override
  public void destroy() {
    log.info("Authorization disabled");
  }

  public HeaderManager getHeaderManager() {
    return headerManager;
  }

  public void setHeaderManager(HeaderManager headerManager) {
    this.headerManager = headerManager;
  }
}
