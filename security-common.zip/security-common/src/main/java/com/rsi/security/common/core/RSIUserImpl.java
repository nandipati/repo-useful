package com.rsi.security.common.core;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class RSIUserImpl extends User implements RSIUser {

    private static final long serialVersionUID = 7220060279272965353L;

    private UUID userGuid;
    private UUID leaRefId;
    private UUID schoolRefId;
    private Set<String> scopes = new HashSet<>();
    private UserContext userContext;
    private boolean isIndependentSchool = false;
    private String[] tokenRoles;

    public RSIUserImpl(String username, Collection<? extends GrantedAuthority> authorities, Set<String> scopes) {
        super(username, "password", authorities);
        this.scopes = scopes;
    }

    @Override
    public UUID getUserGuid() {
        return userGuid;
    }

    @Override
    public void setUserGuid(UUID userGuid) {
        this.userGuid = userGuid;
    }

    @Override
    public UUID getLeaRefId() {
        return leaRefId;
    }

    @Override
    public void setLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
    }

    @Override
    public UUID getSchoolRefId() {
        return schoolRefId;
    }

    @Override
    public void setSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
    }

    @Override
    public Set<String> getScopes() {
        return new HashSet<>(scopes);
    }

    @Override
    public UserContext getUserContext() {
        return userContext;
    }

    @Override
    public void setUserContext(UserContext userContext) {
        this.userContext = userContext;
    }

    @Override
    public boolean isIndependentSchool() {
        return isIndependentSchool;
    }

    @Override
    public void setIndependentSchool(boolean isIndependentSchool) {
        this.isIndependentSchool = isIndependentSchool;
    }

    @Override
    public String[] getTokenRoles() {
        return tokenRoles;
    }

    @Override
    public void setTokenRoles(String[] tokenRoles) {
        this.tokenRoles = tokenRoles;
    }
}
