package com.rsi.security.common.session.cookie;

import com.rsi.security.common.token.RSIPrincipal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by nandipatim on 1/16/19.
 */
public interface PlatformSessionManager {

  /**
   * Used to obtain a standard set of information on the user from the platform
   * that can be used to build a session Cookie. The returned principal may
   * additionally contain some platform private data.
   * @param request
   * @return
   */
  RSIPrincipal getUserPrincipal(HttpServletRequest request);

  /**
   * Creates a new HttpSession using userPrincipal that have been extracted from a session cookie
   * using the <code>com.rsi.com.rsi.security.common.security.session.cookie.SessionCookieManager</code> interface.
   * Recreating a platform session may require attributes to be added to the request as well as to a new HttpSession
   * so the request object is passed as a parameter.
   * @param request
   * @param userPrincipal
   * @return
   */
  HttpSession regenerateSession(HttpServletRequest request, HttpServletResponse response, RSIPrincipal userPrincipal);


  /**
   * Checks the see if the user has an active session. Implementations may examine the HttpSession and/or a set of
   * cookies. This will be Platform specific.
   * @param request
   * @return true is the user's session is active. False otherwise.
   */
  public boolean isSessionActive(HttpServletRequest request);

  /**
   * Used to signal if a request is aimed at the applications entry point or login/landing screen. This is used by the
   * <code>SessionManagementFilter</code> to determine if it should process an existing cookie or delete it.
   * There is a scenario where the user closes the browser without logging out properly. The cookie may still be in place
   * if a new user attempts to log in. The com.rsi.security.common.filter must decide whether to recreate the session based on the cookie or
   * remove it to create a new session. This method should verify if the request is for the entry/login page and return
   * true/false accordingly.
   * Note, Platforms that never create the cookie in the first place (eg., MWS) do not control the session and so will
   * always want to recreate the session. They should always return false.
   * Platforms that initiate the session/create the cookie must add the logic to test the request.
   * @param req
   * @return True if the request if for the entry/login page, false otherwise.
   */
  boolean isApplicationEntryPoint(HttpServletRequest req);
}
