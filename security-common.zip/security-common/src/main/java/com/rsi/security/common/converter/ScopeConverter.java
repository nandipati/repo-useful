package com.rsi.security.common.converter;

import com.google.common.collect.ImmutableMap;
import com.rsi.security.common.constants.SecurityScope;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

//TODO: initialise onConditionOfProperty, also update user details com.rsi.security.common.service to check if this converter is NOT null before using it
public class ScopeConverter {

    public static final String ASSESSMENT_SCOPE = "ASSESSMENT_SCOPE";

    @Value("${scope.defaultScope:scope_none}")
    private String defaultScope;

    //TODO: allow custom scopes to be inject into this map
    private static final Map<String, String> scopeMap = ImmutableMap.of(SecurityScope.assessment, ASSESSMENT_SCOPE);

    public String getScope(String idmScope) {
        if (StringUtils.equals(defaultScope, idmScope)) {
            return defaultScope;
        }

        String scope = scopeMap.get(idmScope);
        return scope != null ? scope : defaultScope;
    }
}
