package com.rsi.security.common.session.util;

import com.rsi.security.common.session.cookie.JWTSessionCookieManager;
import com.rsi.security.common.token.RSIPrincipal;
import com.rsi.security.common.token.utils.TokenUtils;
import java.util.Set;
import net.oauth.jsontoken.Clock;

/**
 * Created by nandipatim on 1/16/19.
 */
public class CommonUtils {

  public static RSIPrincipal extractPrincipal(String tokenStr, String sharedSecret, Set<String> sharedSecrets, Clock clock, String audience) {
    RSIPrincipal principal = null;
    if (sharedSecret != null) {
      principal = TokenUtils.decodeJWT(tokenStr, JWTSessionCookieManager.standardClaimsToExtract, clock, audience, sharedSecret);
    }
    if (principal == null && sharedSecrets != null) {
      for (String secret : sharedSecrets) {
        principal = TokenUtils.decodeJWT(tokenStr, JWTSessionCookieManager.standardClaimsToExtract, clock, audience, secret);
        if (principal != null) break;
      }
    }
    return principal;
  }
}
