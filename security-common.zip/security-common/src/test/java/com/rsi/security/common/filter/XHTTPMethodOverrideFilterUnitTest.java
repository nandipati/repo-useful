package com.rsi.security.common.filter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class XHTTPMethodOverrideFilterUnitTest {
	
	    @Mock
	    private HttpServletRequest servletRequest;
	    @Mock
	    private HttpServletResponse servletResponse;
	    @Mock
	    private FilterChain filterChain;

	    private XHTTPMethodOverrideFilter overrideMethodFilter;

	    @Before
	    public void setup() {
	        MockitoAnnotations.initMocks(this);
	        overrideMethodFilter = new XHTTPMethodOverrideFilter();
	    }

	    @Test
	    public void testDoFilterPATCH() throws Exception {
	        when(servletRequest.getRequestURI()).thenReturn("/dummyRESTEndpoint;contextId=hmof");
			when(servletRequest.getMethod()).thenReturn(HttpMethod.POST.name());
	        when(servletRequest.getHeader(XHTTPMethodOverrideFilter.OVERRIDE_HEADER)).thenReturn(HttpMethod.PATCH.name());
	        overrideMethodFilter.doFilter(servletRequest, servletResponse, filterChain);
	        
	        // Check that method is no longer a POST
	        verify(filterChain).doFilter(argThat(new TunneledRequestArgumentMatcher()), any(HttpServletResponse.class));
	    }
	    
	    @Test
	    public void testDoFilterGET() throws Exception {
	        when(servletRequest.getRequestURI()).thenReturn("/dummyRESTEndpoint;contextId=iowa");
	        when(servletRequest.getMethod()).thenReturn(HttpMethod.GET.name());
	        overrideMethodFilter.doFilter(servletRequest, servletResponse, filterChain);
	        
	        // The request method should not be modified for a GET
	        verify(filterChain).doFilter(argThat(new NonTunneledRequestArgumentMatcher()), any(HttpServletResponse.class));
	    }
	    
	    private class TunneledRequestArgumentMatcher implements ArgumentMatcher<HttpServletRequest> {

				@Override
				public boolean matches(HttpServletRequest httpServletRequest) {
						if (HttpMethod.POST.name().equals(httpServletRequest.getMethod())) {
							return false;
					}
					return true;

				}
			}
	    
	    private class NonTunneledRequestArgumentMatcher implements ArgumentMatcher<HttpServletRequest> {

				@Override
				public boolean matches(HttpServletRequest httpServletRequest) {

					if (HttpMethod.GET.name().equals(httpServletRequest.getMethod())) {
						return true;
					}
					return false;
				}
			}
	    
	    



}
