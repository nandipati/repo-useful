package com.rsi.security.common.utils;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UUIDHelperUnitTest {
    
    private static final String VALID_UUID = "b5213839-4bec-4077-b220-72d3a95561a6";
    private static final String VALID_UUID_WITHOUT_DASHES = "b52138394bec4077b22072d3a95561a6";
    private static final String INVALID_UUID = "XXb5213839-4bec-4077-b220-72d3a95561a6";
    private static final String INVALID_UUID_WITHOUT_DASHES = "XXb52138394bec4077b22072d3a95561a6";

    @Test
    public void testStringMatchesUUIDRegex() throws Exception {
        assertTrue(UUIDHelper.stringMatchesUUIDRegex(VALID_UUID));
    }
    
    @Test
    public void testStringMatchesUUIDRegexInvalid() throws Exception {
        assertFalse(UUIDHelper.stringMatchesUUIDRegex(INVALID_UUID));
    }

    @Test
    public void testStringMatchesUUIDWithoutDashesRegex() throws Exception {
        assertTrue(UUIDHelper.stringMatchesUUIDWithoutDashesRegex(VALID_UUID_WITHOUT_DASHES));
    }

    @Test
    public void testStringMatchesInUUIDWithoutDashesRegex() throws Exception {
        assertFalse(UUIDHelper.stringMatchesUUIDWithoutDashesRegex(INVALID_UUID_WITHOUT_DASHES));
    }
    
}
