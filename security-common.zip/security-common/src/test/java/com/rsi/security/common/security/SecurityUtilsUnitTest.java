package com.rsi.security.common.security;

import com.rsi.security.common.builder.UserBuilder;
import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.core.RSIUser;
import com.rsi.security.common.core.UserContext;
import com.rsi.security.common.utils.SecurityUtils;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.assertj.core.util.Arrays;
import org.junit.Test;
import com.rsi.security.common.utils.SecurityTestUtils;

public class SecurityUtilsUnitTest {

    @Test
    public void testTrustedApiUser() {
        RSIUser user = UserBuilder.trustedApi().build();
        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isTrustedApi()).isTrue();
        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(UserBuilder.DEFAULT_TRUSTED_API_USERNAME);
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isNull();
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isNull();
        Assertions.assertThat(SecurityUtils.getUserGuid()).isNull();

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();
        Assertions.assertThat(SecurityUtils.isTeacher()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testDistrictAdminUser() {
        UUID userId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_ADMINISTRATOR);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(leaRefId)
            .withSchoolRefId(null)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isEqualTo(leaRefId);
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isNull();
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();
        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();
        Assertions.assertThat(SecurityUtils.isTeacher()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testDistrictAdminAndTeacherUser() {
        UUID userId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_ADMINISTRATOR, RSIRoleConverter.ROLE_TEACHER);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(leaRefId)
            .withSchoolRefId(null)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isTeacher()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isEqualTo(leaRefId);
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isNull();
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();
        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testSchoolAdminUser() {
        UUID userId = UUID.randomUUID();
        UUID schoolRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_ADMINISTRATOR);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(null)
            .withSchoolRefId(schoolRefId)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isNull();
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isEqualTo(schoolRefId);
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();
        Assertions.assertThat(SecurityUtils.isTeacher()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testSchoolAdminAndTeacherUser() {
        UUID userId = UUID.randomUUID();
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_ADMINISTRATOR, RSIRoleConverter.ROLE_TEACHER);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(leaRefId)
            .withSchoolRefId(schoolRefId)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isTrue();
        Assertions.assertThat(SecurityUtils.isTeacher()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isEqualTo(leaRefId);
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isEqualTo(schoolRefId);
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testTeacherUser() {
        UUID userId = UUID.randomUUID();
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_TEACHER);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(leaRefId)
            .withSchoolRefId(schoolRefId)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isTeacher()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isEqualTo(leaRefId);
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isEqualTo(schoolRefId);
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();
        Assertions.assertThat(SecurityUtils.isStudent()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testStudentUser() {
        UUID userId = UUID.randomUUID();
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        String[] roles = Arrays.array(RSIRoleConverter.ROLE_STUDENT);

        RSIUser user = UserBuilder.user()
            .withUserId(userId)
            .withLeaRefId(leaRefId)
            .withSchoolRefId(schoolRefId)
            .withRoles(roles)
            .build();

        SecurityTestUtils.authenticateAs(user);

        Assertions.assertThat(SecurityUtils.isStudent()).isTrue();

        Assertions.assertThat(SecurityUtils.getCurrentUsername()).isEqualTo(userId.toString());
        Assertions.assertThat(SecurityUtils.getLeaRefId()).isEqualTo(leaRefId);
        Assertions.assertThat(SecurityUtils.getSchoolRefId()).isEqualTo(schoolRefId);
        Assertions.assertThat(SecurityUtils.getUserGuid()).isEqualTo(userId);

        Assertions.assertThat(SecurityUtils.isSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isDistrictOrSchoolAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isTeacher()).isFalse();
        Assertions.assertThat(SecurityUtils.isDistrictAdmin()).isFalse();
        Assertions.assertThat(SecurityUtils.isTrustedApi()).isFalse();

        SecurityTestUtils.clearSecurityContext();
    }

    @Test
    public void testElaPlanBUser() {
        RSIUser user = UserBuilder.teacher().withUserContext(UserContext.IOWA).build();
        SecurityTestUtils.authenticateAs(user);
        Assertions.assertThat(SecurityUtils.getUserContext()).isEqualTo(UserContext.IOWA);
    }
}
