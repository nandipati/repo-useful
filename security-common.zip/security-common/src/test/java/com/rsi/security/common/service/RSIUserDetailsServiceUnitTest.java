package com.rsi.security.common.service;


import com.rsi.security.common.constants.SecurityClaim;
import com.rsi.security.common.constants.SecurityScope;
import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.converter.ScopeConverter;
import com.rsi.security.common.core.RSIUser;
import com.rsi.security.common.core.UserContext;
import com.rsi.security.common.token.RSIPrincipal;
import java.util.UUID;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

public class RSIUserDetailsServiceUnitTest {

    private static final String TEST_DEFAULT_SCOPE = "testDefaultScope";

    private final RSIUserDetailsService rsiUserDetailsService = new RSIUserDetailsService();

    @Before
    public void setup() {
        ScopeConverter scopeConverter = new ScopeConverter();
        ReflectionTestUtils.setField(scopeConverter, "defaultScope", TEST_DEFAULT_SCOPE);
        ReflectionTestUtils.setField(rsiUserDetailsService, "roleConverter", new RSIRoleConverter());
        ReflectionTestUtils.setField(rsiUserDetailsService, "scopeConverter", scopeConverter);
        ReflectionTestUtils.setField(rsiUserDetailsService, "defaultScope", TEST_DEFAULT_SCOPE);
    }

    @Test
    public void testTrustedApi() {
        UUID schoolRefId = null;
        UUID leaRefId = null;
        UUID userId = null;
        String username = "trustedApi";

        PreAuthenticatedAuthenticationToken token = mockPrincipal(userId, username, leaRefId, schoolRefId);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getUserGuid()).isNull();
        assertThat(user.getLeaRefId()).isNull();
        assertThat(user.getSchoolRefId()).isNull();
        assertThat(user.getUsername()).isEqualTo(username);
    }

    @Test
    public void testDistrictAdmin() {
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = schoolRefId;
        UUID userId = UUID.randomUUID();
        String username = null;

        PreAuthenticatedAuthenticationToken token = mockPrincipal(userId, username, leaRefId, schoolRefId);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getUserGuid()).isEqualTo(userId);
        assertThat(user.getLeaRefId()).isEqualTo(leaRefId);
        assertThat(user.getSchoolRefId()).isNull();
        assertThat(user.getUsername()).isEqualTo(userId.toString());
    }

    @Test
    public void testSchoolAdmin_LeaRefIdProvided() {
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        String username = null;

        PreAuthenticatedAuthenticationToken token = mockPrincipal(userId, username, leaRefId, schoolRefId);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getUserGuid()).isEqualTo(userId);
        assertThat(user.getLeaRefId()).isEqualTo(leaRefId);
        assertThat(user.getSchoolRefId()).isEqualTo(schoolRefId);
        assertThat(user.getUsername()).isEqualTo(userId.toString());
    }

    @Test
    public void testSchoolAdmin_LeaRefIdNull() {
        UUID schoolRefId = UUID.randomUUID();
        UUID leaRefId = null;
        UUID userId = UUID.randomUUID();
        String username = null;

        PreAuthenticatedAuthenticationToken token = mockPrincipal(userId, username, leaRefId, schoolRefId);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getUserGuid()).isEqualTo(userId);
        assertThat(user.getLeaRefId()).isNull();
        assertThat(user.getSchoolRefId()).isEqualTo(schoolRefId);
        assertThat(user.getUsername()).isEqualTo(userId.toString());
    }

    @Test
    public void testStudentWithScope() {
        String username = "student";
        PreAuthenticatedAuthenticationToken token = mockPrincipal(UUID.randomUUID(), username, UUID.randomUUID(), UUID.randomUUID(), SecurityScope.assessment);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getScopes()).containsExactly(ScopeConverter.ASSESSMENT_SCOPE);
    }

    @Test
    public void testRoles() {
        String learnerRole = "Learner";
        PreAuthenticatedAuthenticationToken token = mockPrincipal(UUID.randomUUID(),
                UUID.randomUUID().toString(), UUID.randomUUID(), UUID.randomUUID(),
                SecurityScope.assessment, learnerRole);
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        String[] tokenRoles = user.getTokenRoles();
        assertThat(tokenRoles).hasSize(1);
        for (String tokenRole : tokenRoles) {
            assertThat(learnerRole).isEqualTo(tokenRole);
        }

        //multiple roles against one user....
        String role1 = "Instructor";
        String role2 = "Administrator";
        token = mockPrincipal(UUID.randomUUID(),
                UUID.randomUUID().toString(), UUID.randomUUID(), UUID.randomUUID(),
                SecurityScope.assessment, role1, role2);
        user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        tokenRoles = user.getTokenRoles();
        assertThat(tokenRoles).hasSize(2);
        for (String tokenRole : tokenRoles) {
            boolean match = role1.equals(tokenRole) || role2.equals(tokenRole);
            assertThat(match).isTrue();
        }

    }

    @Test
    public void testStudentWithDefaultScope() {
        String username = "student";
        PreAuthenticatedAuthenticationToken token = mockPrincipal(UUID.randomUUID(), username, UUID.randomUUID(), UUID.randomUUID());
        RSIUser user = (RSIUser) rsiUserDetailsService.loadUserDetails(token);

        assertThat(user.getScopes()).containsExactly(TEST_DEFAULT_SCOPE);
    }

    private PreAuthenticatedAuthenticationToken mockPrincipal(UUID userId, String username, UUID leaRefId, UUID schoolRefId) {
        return mockPrincipal(userId, username, leaRefId, schoolRefId, null);
    }

    private PreAuthenticatedAuthenticationToken mockPrincipal(UUID userId, String username, UUID leaRefId, UUID schoolRefId, String scope, String... roles) {

        RSIPrincipal principal = Mockito.mock(RSIPrincipal.class, Mockito.RETURNS_DEEP_STUBS);
        when(principal.getGuid()).thenReturn(userId == null ? null : userId.toString());
        when(principal.getUserName()).thenReturn(username);
        when(principal.getExtensionClaims().get(SecurityClaim.DIST_REFID)).thenReturn(leaRefId == null ? null : leaRefId.toString());
        when(principal.getExtensionClaims().get(SecurityClaim.SCHOOL_REFID)).thenReturn(schoolRefId == null ? null : schoolRefId.toString());
        when(principal.getExtensionClaims().get(SecurityClaim.SCOPE)).thenReturn(scope);
        when(principal.getExtensionClaims().get(SecurityClaim.CONTEXT_ID)).thenReturn(UserContext.IOWA.name());

        when(principal.getRoles()).thenReturn(ArrayUtils.isEmpty( roles ) ? new String[0] : roles);
        return new PreAuthenticatedAuthenticationToken(principal, "N/A");
    }
}
