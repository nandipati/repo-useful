package com.rsi.security.common.builder;

import com.google.common.collect.Sets;
import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.core.RSIUser;
import com.rsi.security.common.core.RSIUserImpl;
import com.rsi.security.common.core.UserContext;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class UserBuilder {

    public static final String DEFAULT_TRUSTED_API_USERNAME = "trustedAPI";

    private UUID userId;
    private UUID leaRefId;
    private UUID schoolRefId;
    private String[] roles;
    private UserContext userContext;

    public static UserBuilder districtAdmin() {
        return user(
            UUID.randomUUID(),
            UUID.randomUUID(),
            null, // School is null
            RSIRoleConverter.ROLE_ADMINISTRATOR);
    }

    public static UserBuilder schoolAdmin() {
        return user(
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID(),
            RSIRoleConverter.ROLE_ADMINISTRATOR);
    }

    public static UserBuilder teacher() {
        return user(
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID(),
            RSIRoleConverter.ROLE_TEACHER);
    }

    public static UserBuilder student() {
        return user(
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID(),
            RSIRoleConverter.ROLE_STUDENT);
    }

    public static UserBuilder proctor() {
        return user(
            UUID.randomUUID(),
            UUID.randomUUID(),
            UUID.randomUUID(),
            RSIRoleConverter.ROLE_PROCTOR);
    }

    public static UserBuilder trustedApi() {
        return user(null, null, null, RSIRoleConverter.ROLE_TRUSTEDAPI);
    }

    private UserBuilder createUser(UUID userId, UUID leaRefId, UUID schoolRefId, String... roles) {
        this.userId = userId;
        this.leaRefId = leaRefId;
        this.schoolRefId = schoolRefId;
        this.roles = roles;
        return this;
    }

    private static UserBuilder user(UUID userId, UUID leaRefId, UUID schoolRefId, String... roles) {
        return new UserBuilder().createUser(userId, leaRefId, schoolRefId, roles);
    }

    public UserBuilder withUserId(UUID userId) {
        this.userId = userId;
        return this;
    }

    public UserBuilder withLeaRefId(UUID leaRefId) {
        this.leaRefId = leaRefId;
        return this;
    }

    public UserBuilder withSchoolRefId(UUID schoolRefId) {
        this.schoolRefId = schoolRefId;
        return this;
    }

    public UserBuilder withRoles(String... roles) {
        this.roles = roles;
        return this;
    }

    public UserBuilder withUserContext(UserContext userContext) {
        this.userContext = userContext;
        return this;
    }

    public RSIUser build() {
        List<GrantedAuthority> authorities = new ArrayList<>();
        for (String role : roles) {
            authorities.add(new SimpleGrantedAuthority(role));
        }

        String username = userId == null ? DEFAULT_TRUSTED_API_USERNAME : userId.toString();
        RSIUser user = new RSIUserImpl(username, authorities, Sets.newHashSet("scope_none"));
        user.setUserGuid(userId);
        user.setLeaRefId(leaRefId);
        user.setSchoolRefId(schoolRefId);
        user.setUserContext(userContext);
        return user;
    }

    public static UserBuilder user() {
        return new UserBuilder();
    }
}
