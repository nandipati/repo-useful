package com.rsi.security.common.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;


/**
 * Create a Spring Boot environment from Test perspective
 */
@Configuration
//@ComponentScan(basePackages = "com.rsi.com.rsi.security.common.security.common") //might not need this as its specified in the com.rsi.security.common.config
@EnableAutoConfiguration
public abstract class TestContextConfiguration {
    
}
