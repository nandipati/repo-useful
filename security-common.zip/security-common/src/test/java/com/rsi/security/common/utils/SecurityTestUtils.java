package com.rsi.security.common.utils;


import com.rsi.security.common.core.RSIUser;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

public class SecurityTestUtils {

    public static void authenticateAs(RSIUser user) {
        SecurityContextHolder.getContext()
            .setAuthentication(new PreAuthenticatedAuthenticationToken(user, user.getPassword(), user.getAuthorities()));
    }

    public static void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }
}
