# security-common
Reusable Security dependency for Riverside Java/Scala applications
Security Common is a RSI(Riverside Insights) common component that contains SIF Token Authorisation, UserDetails Service and other utility classes
for RSI(Riverside Insights) user objects that can be easily imported to RSI Java applications - it also configurable with properties/yaml files.

### Config file example

### Note :- Security Key has to be in '[key]' as special characters are not allowed with just key or 'key'

```
# Switch off Springs basic auth
security:
  basic:
    enabled: false

scope:
  defaultScope: you_own_app_scope_can_be_anything

#Switch SIF token authorization on or off
hmhsecurity:
  enabled: true
  audience: http://www.rsi.com
  issuer: https://identity.api.rsi.com
  csrfEnabled: false
  expireInSecs: 15552000 #200 days Expiration time in secs
  clientStore:
    '[<security key>]': '<security secret>'
    #Trusted API token for example
    '[xxxxxxxxxxxxxxxxxxxxxxxxxxxx.rsi.com]': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx'
```
The property `rsisecurity.enabled: true` is the most important as when it's set to true the Security Common component with automatically configure itself, otherwise it won't.

### Create a new Client ID and Secret

ClientID - Use any Password Generator and take  **15** characters of this string and prepend it to ".rsi.com"

Secret - Use any Password Generator and take  **49** characters

you can use below java code too.

package testing21;
import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.commons.codec.binary.Base64;

public class TestSecret {

public static void main(String[] args)
{
// Basically the client id should be <client_id>.rsi.com max 25 characters in total
// secret should be max 49 characters

String secret = Base64.encodeBase64URLSafeString(new BigInteger(512, new SecureRandom()).toByteArray()).replace("=", "");
System.out.println(secret);
}

}

Take the first **15** characters of this string and prepend it to ".rsi.com" to produce a 25 character long Client ID.
Generate a second URL safe string and take the first **49** characters as the Client Secret.

Email the client with their new Client ID and Secret.

### Jenkins Jobs and Deployments

Deploy Snapshot http://infra-jenkins.rcsnp.rsiapps.com/job/security-common/job/master/
