CODEX
=====

# Configuration management services.

The purpose of **codex** is to provide a centalized and logical system of configuration management that facilitates
simple and uninterrupted configuration management for spring based applications. More information may be found at: 
[Spring Cloud Config](http://cloud.spring.io/spring-cloud-config/). Additionally configuration is managed via a git 
repository hmhco/codex, this provides profiles and application level configuration details. Other services provided by
the config service are cryptographic services which are back by the AWS KMS key management service. 

See: 
    
  - [AWS KMS](http://aws.amazon.com/kms/)
  - [Spring Cloud Config](http://cloud.spring.io/spring-cloud-config/)


For more information on it's use pleaes see:
    
  - hmhco/assessment-scoring
  - [spring-cloud-config-sample](https://github.com/spring-cloud/spring-cloud-config/tree/master/spring-cloud-config-sample)
