package com.example.demo.bill;

import com.example.demo.bill.config.CafeMenu;
import com.example.demo.bill.model.Bill;
import com.example.demo.bill.service.BillService;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class BillServiceTests {

	@Autowired
	private BillService billService;

/*	@Test
	void contextLoads() {
	}*/

	@Test
	public void getOrderBill(){
		List<CafeMenu> cafeOrder = new ArrayList<>();
		cafeOrder.add(CafeMenu.COFFEE);
        cafeOrder.add(CafeMenu.CHEESE_SANDWITCH);
		cafeOrder.add(CafeMenu.STEAK_SANDWITCH);
		Bill bill = billService.getOrderBill(cafeOrder);
		Assert.assertEquals(bill.getOrderTotal(), BigDecimal.valueOf(8.15));
		Assert.assertEquals(bill.getSubTotal() , BigDecimal.valueOf(7.50));
		Assert.assertEquals(bill.getServiceCharge() , BigDecimal.valueOf( 0.65));
	}
}
