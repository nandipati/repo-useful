package com.example.demo.bill.service;


import com.example.demo.bill.config.CafeMenu;
import com.example.demo.bill.model.Bill;

import java.util.List;

public interface BillService {

    public Bill getOrderBill(List<CafeMenu> purchases);
}
