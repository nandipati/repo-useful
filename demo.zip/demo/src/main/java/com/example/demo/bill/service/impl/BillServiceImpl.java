package com.example.demo.bill.service.impl;

import com.example.demo.bill.config.CafeMenu;
import com.example.demo.bill.model.Bill;
import com.example.demo.bill.service.BillService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Slf4j
@Service
public class BillServiceImpl implements BillService {

    public Bill getOrderBill(List<CafeMenu> purchases){

        if(CollectionUtils.isEmpty(purchases)){
            throw new IllegalArgumentException("Purchases cannot be Empty ..");
        }

/*
        List<CafeMenu> foodPurchases = purchases.stream().filter(p->p.getItemType() == ItemType.FOOD).
                collect(Collectors.toList());
*/
        BigDecimal totalBill = purchases.stream().map(CafeMenu::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add).setScale(2, RoundingMode.CEILING);

        BigDecimal serviceChargeTotal = purchases.stream().map(p->
                p.getPrice().multiply(p.getItemType().getServiceChargePercentage()))
                .reduce(BigDecimal.ZERO, BigDecimal::add).setScale(2, RoundingMode.CEILING);


        BigDecimal orderTotal = totalBill.add(serviceChargeTotal);

        log.info("Service Charge Total -> {} , Total Bill -> {} , Total Bill including Service charge -> {}" , serviceChargeTotal,
                totalBill , orderTotal);

        Bill bill = createBillValueObject(purchases, totalBill, serviceChargeTotal, orderTotal);

        return bill;
    }

    private Bill createBillValueObject(List<CafeMenu> purchases, BigDecimal purchaseTotal, BigDecimal serviceChargeTotal, BigDecimal orderTotal) {
        Bill bill = new Bill();
        bill.setOrders(purchases);
        bill.setSubTotal(purchaseTotal);
        bill.setServiceCharge(serviceChargeTotal);
        bill.setTotalBill(purchaseTotal);
        bill.setOrderTotal(orderTotal);
        return bill;
    }
}
