package com.example.demo.bill.config;

public enum BrewType {

    Cold,
    Hot;
}
