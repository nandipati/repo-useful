# Bedrock documentation

Build it using:

```
make
```

Or to open in a browser directly
```
make view
```
