AWS Resources in Bedrock
========================

Team often times require AWS resources for their application, all of these resources are built in Terraform and live in the `io.hmheng.tf`_ repo.

This repo can be used to create and manage resources such as:

  - Crossaccount roles
  - ElastiCache
  - Kinesis streams
  - KMS keys
  - Relational Database Service (RDS) instances
  - Simple Queue Service (SQS)
  - Simple Notification Service (SNS)
  - And more

For a full list of resources see the `AWS documentation`_ and `Terraform documentation`_

Certain types of resources we do not allow to be created by teams. These are including but not limited to:

  - Elastic Compute Cloud (Ec2) instances
  - Simple Email Service (SES)

If its unclear if a certain resource is allowed or not feel free to ask in the ``#br-technical-services`` slack channel.

.. _AWS documentation: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-template-resource-type-ref.html
.. _Terraform documentation: https://www.terraform.io/docs/providers/aws/
.. _io.hmheng.tf: https://github.com/hmhco/io.hmheng.tf

io.hmheng.tf
------------

.. note:: The resources created in this repo are yours. Although a Bedrock team member must approve and deploy the resource, they are owned by your team. We **do not** and **will not** manage your databases and other resources, but we are always here for help and guidance. This also means we do not manage your backups or restores if required.

Setting up
~~~~~~~~~~

Each role should have their own folder, within that should be a sub-folder for each project. Within each project folder should be a state folder, which holds the Terraform state file for each stage.

For example::

  ├── role (hmheng-infra)
  │   ├── project
  │   │   ├── resource1.tf (my-project-db.tf)
  │   │   ├── resource2.tf (my-project-sqs.tf)
  │   │   ├── resourceN.tf
  │   │   ├── vars.tf
  │   │   ├── states
  │   │   │   ├── dev
  │   │   │   ├── int
  │   │   │   ├── cert
  │   │   │   ├── prod

.. note:: Do not directly edit the files in `state/*/terraform.tfstate` this is the output of running a Terraform apply.


General guidelines
~~~~~~~~~~~~~~~~~~

Start small and go larger if needed. Do not guess what size databases or caches are needed, if it's uncleared start with a small one and go larger once it's needed.
It is much easier to increase the size than to decrease.

Remember most of these resources are not free. Developers should understand what their application needs before development begins and choose the parameters of resources carefully (size and count).

With some resources such as, Relational Database Service (RDS) instance there is an option for ``Auto Minor Version Upgrade`` this should be set to false and if a minor version is needed code should be pushed to the repo, otherwise Terraform will want to downgrade next time it is run.

For policies you should you a data ``aws_iam_policy_document`` and ``aws_iam_policy_attachment`` objects rather than inline policies as this makes it cleaner and easier to debug. See :ref:`bucket access <bucket access>` for examples of this.

Naming conventions
~~~~~~~~~~~~~~~~~~

Simple Queue Service (SQS)
^^^^^^^^^^^^^^^^^^^^^^^^^^
  - queue name

    - ``io_hmheng_<aurora_role>_<stage>_<service_name>_<queue_name>``

      - EXAMPLE 1: io_hmheng_infra_dev_stub-application_incoming
      - EXAMPLE 2: io_hmheng_infra_dev_stub-application_outgoing

Identity and Access Management (IAM)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  - role name

    - ``io.hmheng.<aurora_role>.<stage>.<service_name>.<component>.<location>``

      - EXAMPLE 1: io.hmheng.infra.dev.stub-application.sqs.local
      - EXAMPLE 2: io.hmheng.infra.dev.stub-application.sqs.crossaccount

  - policy name

    - ``io.hmheng.<aurora_role>.<stage>.<service_name>.<component>.<location>``

      - EXAMPLE 1: io.hmheng.infra.dev.stub-application.sqs.local
      - EXAMPLE 2: io.hmheng.infra.dev.stub-application.sqs.crossaccount

Relational Database Service (RDS)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  - database name

    - ``<aurora_role>-<app_name>-<stage>-<service_name>``

      - EXAMPLE 1: hmheng-infra-stub-application-pgsql-dev

ElastiCache
^^^^^^^^^^^
  - Cache name

    - ``<aurora_role>-<service_name>-<stage>``

      - EXAMPLE 1: hmheng-infra-stub-application-redis-dev

security groups
^^^^^^^^^^^^^^^
  - security group name

    - ``<aurora_role>_<stage>_<service_name>_<related_component>``

      - EXAMPLE 1: infra_dev_stub-application_database
      - EXAMPLE 2: infra_dev_stub-application_cache

Resource tagging
----------------

Tagging of resources help tell how much each application cost to run.

.. _required tags:

Required tags
~~~~~~~~~~~~~
``cost`` the value of this tag should be team_project, for example ``cds_eventservice`` or ``idm_cleaver``
``stage`` the value of this tag should be the stage the resource is for such as ``prod`` or ``dev``
``responsible-party`` the value of this tag should be an email address or slack channel for inquiries about resource

Resource that need tag
~~~~~~~~~~~~~~~~~~~~~~

  - Elasticache Cache Cluster
  - Elasticache Snapshot
  - Kinesis
  - RDS DB Instance
  - RDS Event Subscription
  - RDS Option Group
  - RDS Parameter Group
  - RDS Snapshot
  - S3 Bucket

Resource that currently do not support tags
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  - SES
  - SNS
  - SQS (supported coming soon)


Using dynamic variables
~~~~~~~~~~~~~~~~~~~~~~~

Often times a resource will be different in lower stages than in cert and prod. This can be accomplished by using a mapping.
For example, let's say I want a cache that needs to be micro in dev and int but large in cert and prod.
The variable would look like this::

  variable "cache_type" {
     type = "map"
    default = {
         dev = "cache.t2.micro"
         int = "cache.t2.micro"
         cert = "cache.t2.large"
         certrv = "cache.t2.large"
         prodrv = "cache.t2.large"
         prod = "cache.t2.large"
     }
  }

We can then use this variable by referencing ``${lookup(var.cache_type, var.tag_stage)}`` for our cache size.
Even if you're creating a resource for a single stage right now, using variables for things that are likely to change later on will make things easier down the road.

S3 buckets
~~~~~~~~~~

We allow teams to create s3 buckets for file storage as long as they follow our guidelines.

Naming convention
^^^^^^^^^^^^^^^^^

Bucket name should be <team name> such as hmheng-idm
Inside this bucket there should be a path for purpose, example would be s3://hmheng-idm/database-backup/<STAGE>/

Required attributes
^^^^^^^^^^^^^^^^^^^

All buckets are required to have at least these attributes

  - ``region = "us-east-1"`` for now all buckets must be us-east-1
  - ``acl = "private"`` this means it is a non public facing bucket
  - tags, the :ref:`required tags` is also required here
  - lifecycle_rule with expiration, we don't want to keep objects forever in s3 the lifecycle expiration will tell how long to keep objects before they are removed

For more info about creating s3 buckets see the `Terraform S3 documentation`_.

Bucket access
^^^^^^^^^^^^^

For bucket access a role should be created which allows s3 access to the specific bucket. Once this role is created it should be added to the Mesos agent roles found in `terraform variables`_ file.

.. _bucket access:

Example of IAM role policy for this could look like::

  data "aws_iam_policy_document" "s3-policy" {
    statement {
      actions = [
      "s3:*",
    ]
    resources = [
      "arn:aws:s3:::hmheng-infa/grafana/${var.tag_stage}",
      "arn:aws:s3:::hmheng-infa/grafana/${var.tag_stage}/*"
    ]
    }
  }
  
  resource "aws_iam_policy" "infra-grafana-policy" {
      name   = "io.hmheng.infra.${var.tag_stage}.grafana.s3.local"
      path   = "/"
      description = "infra ${var.tag_stage} s3 policy"
      policy = "${data.aws_iam_policy_document.s3-policy.json}"
  }

  resource "aws_iam_policy_attachment" "infra-s3" {
      name  = "infra_${var.tag_stage}_s3"
      roles = [
        "${aws_iam_role.infra-grafana-role.name}",
      ]
      policy_arn = "${aws_iam_policy.infra-grafana-policy.arn}"
  }

  data "aws_iam_policy_document" "infra_assumerole" {
    statement {
      actions = ["sts:AssumeRole"]

      principals {
        type        = "AWS"
        identifiers = ["arn:aws:iam::711638685743:root"]
      }
    }
  }

  resource "aws_iam_role" "infra-grafana-role" {
      name               = "io.hmheng.infra.${var.tag_stage}.s3.local"
      assume_role_policy = "${data.aws_iam_policy_document.infra_assumerole.json}"
  }

.. _Terraform S3 documentation: https://www.terraform.io/docs/providers/aws/r/s3_bucket.html
.. _terraform variables: https://github.com/hmhco/io.hmheng.brts.tf.cluster.base/blob/develop/variables.tf

Format validation
~~~~~~~~~~~~~~~~~

Terraform has a specific format which it expects the resource use, and provides a useful command to format the .tf files.
Once the pull request is ready you should install terraform, for mac it is simple as ``brew install terraform`` see `installing Terraform`_ documentation for more instructions .

Once installed navigate to the directory containing the .tf files and run ``terraform fmt`` this will format the terraform to be uniform.
To run ``terraform fmt`` you do not need a AWS account or AWS keys set, but to run a plan or apply requires keys to the account which resources will target.

.. _installing Terraform: https://www.terraform.io/intro/getting-started/install.html