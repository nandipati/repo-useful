Service Discovery via Sherpa
============================

Services must be discoverable, and addressable. Because of to the ephemeral nature of the nature of tasks running on the
Bedrock platform tasks may (and will) not use the same port or IP address from one update/restart to another, this is
why service discovery is an important part of the ecosystem.

All tasks which run on Aurora use an announcer, the purpose of this is when a task is started Aurora will announce to
Zookeeper the details of the task stored in a znode, meaning the IP address and port which the task is using
(aurora/http port).  The Znodes for Aurora tasks can be found at the Zookeeper path
``/discovery/announcer/<ROLE>/<STAGE>/<APP>``.

This then allows for other services such as Sherpa to read from these znodes and discover the service.

Flow Diagram
------------

.. blockdiag::
   :desctable:

   blockdiag {
     span_width = 80;
     src[label="Source", description="Internal HMH Subnet or Internet Facing"];
     r53[label="D N S", description="Resolve via Route53 hosted internal or internet facing DNS record"]
     albInt[label="A L B (External)", description="Application Load Balancer that accepts internet facing requests and targets
            internet facing Sherpa instance(s)", height=50];
     albExt[label="A L B (Internal)", description="Application Load Balancer that accepts HMH internal requests and targets
                   internal Sherpa instance(s)", height=50];
     sherpa[label="Sherpa", description="Finagle based serverset proxy server that routes request based on hostname or
            path to service based on routing configuration and Thermos announced Znodes", stacked];
     zk[label="Zookeeper", description="Accept Announcements as Znodes, from Thermos Executor, and allow reads from
            Sherpa", stacked];
     dst[label="Destination", description="Aurora job hosted on Mesos Agent instance"];

     group {
       orientation = portrait
       src -> r53 -> albInt, albExt -> sherpa -> dst;
     }

     sherpa -> zk [label = "Reads Mesos Agent host & Aurora job port", fontsize = 10];
     default_group_color = "lightgray"
   }



AWS Application Load Balancer (initial ingress)
-----------------------------------------------

An internal or internet facing AWS Application Load Balancer is the initial ingress for all requests. The Application
Load Balancers are configured with "MultiAZ", to span across each of the 3 us-east-1 availability zones configured for
use by Bedrock BRCORE01 VPC, and have listeners configured for ports 80 and 443 (SSL).

SSL
~~~
All requests sent to Bedrock must use HTTPS, any port 80 requests will be automatically redirected to port 443.

All internal SSL certificates are signed by the Bedrock Vault hosted "Bedrock ACM Internal" intermediate and imported
in to Amazon Certificate Manager.  The "Bedrock ACM Internal" intermediate has been signed by the Bedrock Root CA,
which has been pushed out, with trust, to all HMH user machines (Mac & Windows).  All internet facing SSL certificates
are generated via API call to Amazon Certificate Manager.  The internal or internet facing Applciation Load Balancers
are then able to consume the Amazon Certificate Manager hosted SSL certificates.


Sherpa
------
Sherpa is a proxy server, based on the Twitter maintained Finagle library, that routes requests based on hostname
and/or path to related Apache Aurora scheduled jobs hosted in the Bedrock Mesos cluster.

Sherpa reads the Thermos Executor announced Zookeeper Znodes to retrieve the Mesos Agent hostname(s) as well as the
port number(s) associated with the instance(s) of the Aurora Scheduled job(s) running, then routes traffic to the
appropriate job based on Finagle load balancing configuration.

See `sherpa-repo`_ for more information about Sherpa.

Endpoints
---------

Endpoints are provided by AWS Route53 and point to the internal or external Sherpa Application Load Balancers (ALBs).

Internal
~~~~~~~~

Internal ingress to Sherpa will follow two different patterns:

- ``<application>.<stage>.<role>.br.internal``

Such that application stage and role and exactly how they are found in aurora.
For example, `doc-server`_ which means in aurora there is a tasks which match the role/stage/application-name of the `aurora-task`_


- ``api.<stage>.br.internal`` and  ``api.br.internal``

For internal requests the api endpoint will route both explicitly using path routing.
We also allow for single path to route to any application, such as ``https://api.br.internal/foo`` which can be be mapped to any application.
This must be done explicitly and a request is required to add a new route, path must be unique between applications but can be the same across stages.
To add a new external path open a `Github issue`_

External
~~~~~~~~

- ``api.<stage>.eng.hmhco.com`` and  ``api.eng.hmhco.com``

For external requests the api endpoint will route both explicitly using path routing.
We also allow for single path to route to any application, such as ``https://api.eng.hmhco.com/foo`` which can be be mapped to any application.
This must be done explicitly and a request is required to add a new route, path must be unique between applications but can be the same across stages.
To add a new external path open a `Github issue`_

.. _Github issue: https://github.com/hmhco/io.hmheng.platform/issues
.. _doc-server: https://doc-server.prod.hmheng-infra.br.internal
.. _aurora-task: https://aurora.br.hmheng.io/scheduler/hmheng-infra/prod/doc-server
.. _sherpa-repo: https://github.com/hmhco/sherpa
