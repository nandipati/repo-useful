.. _quota:

How to request for quota
========================

Quota determines how much resources your application can use in production and
cert (meaning preferred tasks) environment. Resources in this case mean how much
CPU time, how much RAM and how much disk space does your application require.

Determining the amount of resources
-----------------------------------

Memory and disk in this scenario are hard limits, so if you request for 4GB of
ram you will receive 4GB of RAM, not a byte more (or less). The same concept
applies to disk size also. CPU resources however are soft limits, and the
concept will be described below.

The rule of thumb anyway is that when calculating the amount of resources your
application requires and multiply it by number of instances your application
has.

.. note::
   It's better to scale horizontally (=more shards) instead of having huge
   individual shard. Large shards cause inefficient cluster resource usage and
   fragmentation, which means it costs more money.

CPU
~~~

Mesos in bedrock is configured to use the Completely Fair Scheduler to provide
predicatble performance. This is effectively a guarantee of resources – you
receive at least what you requested, but if other applications are idling you
might receive all the cpu cycles for your application.

The scheduler gives applications a CPU quota for every 100 ms interval. When an
application uses its quota for an interval, it is throttled for the rest of the
100 ms. Usage resets for each interval and unused quota does not carry over.

For example, an application specifying 4.0 CPU has access to 400 ms of CPU time
every 100 ms. This CPU quota can be used in different ways, depending on the
application and available resources.

The correct way determine the perfect number is to profile your application and
monitor its cpu usage under high loads. If you cannot distribute the load
horizontally the next step would be to start increasing CPU -value.

Memory
~~~~~~

The memory resources are much more straightforward compared to CPU resources.
What you request is what you get. But it also applies in this scenario, don't
request for more memory than your application uses during peak hours. Also keep
in my mind that if your application uses more memory than it requested, it will
be killed.

Disk space
~~~~~~~~~~

Size for the peak usage in here. When running a Java process, add the maximum
size of the Java heap to your disk space requirement, in order to account for an
out of memory error dumping the heap into the application’s sandbox space.

.. note::
   When you have determined the amount of resources you really need, add some
   extra on top the exact value, so that you have at least a little bit of space
   if you figure suddenly that you need to make changes.

Request for quota
-----------------

If you are requesting for initial quota the good rule of thumb is 0.5 CPU 2GB
RAM and "enough" disk.

1. Open an `issue`_
2. Fill in your role to the title.
3. Tell us exactly how much (more) quota you need or the exact value, for
   example:

  - "Please increase RAM by 8GB"
  - "Please set new quota to 1.0 CPU 16GB RAM 20GB DISK"

.. _issue: https://github.com/hmhco/io.hmheng.platform/issues/new?title=Request%20to%20increase%20quota%20for:

Further reading
---------------

- http://aurora.apache.org/documentation/latest/features/resource-isolation/
