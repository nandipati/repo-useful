Updating documentation
======================

This documentation is written in Sphinx_ using ReST_ syntax.




Updating Sphinx documentation
-----------------------------

Updating this documentation is very simple, first checkout fork then checkout the `io.hmheng.plateform`_ repo.
Create a new branch and modify some documentation.


.. _io.hmheng.plateform: https://github.com/hmhco/io.hmheng.platform

Building locally
----------------

Once you have the clone navigate to the docs/users directorie and run ``make view``.
This generates the website and open your default browser to localhost:8080. It will also print any formatting errors
which should be cleaned up before pull requesting changes.


When you are done locally run a ``make clean`` to clean up.


After the changes are good, and no new errors are shown by the make command you can open a pull request to the upstream.
When this PR is approved and merged a jenkins job will kick off and automatically update the running site.

reStructuredText style guide
----------------------------

As we write and review the documentation, we read the source form the
documentation much more than the rendered versions, so keep it tidy and
readable.

``sphinx-build`` emits errors and warnings about incorrect markup, invalid
links, and such. Before submitting a pull request containing documentation
changes, ensure that ``sphinx-build`` is happy.

Headings
~~~~~~~~

ReST_ marks up headings by underlining (and sometimes overlining) the header
with non-alphanumeric characters. ReST has pretty relaxed rules on `marking up
headings`_, but in the interest of readability try to make sure that underlining
is of equal width with the heading. Prefer this::

    A readable heading
    ------------------

over this::

    A legit but ugly heading
    -------------------------------

    Illegal syntax because underlining is too short
    -----

ReST allows you to any non-alphanumeric character to markup headings,
but we've decided to use the following set of characters:

- level 1 headings: ``=``
- level 2 headings: ``-``
- level 3 headings: ``~``
- level 4 headings: ``^``

.. _marking up headings: http://docutils.sourceforge.net/docs/user/rst/quickref.html#section-structure


Sphinx extensions
-----------------

Simple diagrams using blockdiag
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

blockdiag_ extension allows you to embed simple diagrams directly into Sphinx
documentation. For example, the following source code::

    .. blockdiag::

       blockdiag {
         a -> b -> c
       }

will be rendered as:

.. blockdiag::

   blockdiag {
     a -> b -> c
   }

`interactive blockdiag`_ makes it easier and faster to write these diagrams.

.. _blockdiag: http://blockdiag.com
.. _interactive blockdiag: http://interactive.blockdiag.com

Further reading
---------------

- `reStructuredText <http://docutils.sourceforge.net/rst.html>`_
- `reStructuredText quick reference <http://docutils.sourceforge.net/docs/user/rst/quickref.html>`_
- Sphinx_

.. _Sphinx: http://www.sphinx-doc.org/en/stable/
.. _ReST: http://docutils.sourceforge.net/rst.html
