Centralized logging
===================

Bedrock platform provides a centralized logging service, which is implemented
using Elasticsearch_, Logstash_, Kibana_, Timelion_, and Grafana_. Logs produced
by applications running on :ref:`aurora` are indexed in Elasticsearch. The
indexed logs can then be searched and visualized using Kibana, Timelion, and
Grafana.

.. contents::

.. _Elasticsearch: https://www.elastic.co/products/elasticsearch
.. _Logstash: https://www.elastic.co/products/logstash
.. _Kibana: https://www.elastic.co/products/kibana
.. _Timelion: https://www.elastic.co/guide/en/kibana/current/timelion.html
.. _Grafana: https://grafana.com/

Indexing
--------

We index everything that applications running on Aurora print to standard
output or standard error, and store it for three months. We also index logs
from other sources such as AWS Elastic Load Balancers and AWS CloudTrail.

If the log messages are formatted appropriately, we can extract useful
information from them. The extracted data is useful for finding the most
interesting log messages later on. For maximum flexibility it is possible to
output log messages as JSON objects, which are indexed as is.

Recognized log formats
~~~~~~~~~~~~~~~~~~~~~~

Currently we recognize the following formats, which are described in more
detail in the following sections:

  - JSON
  - Line based log messages with and without correlationIDs

We recommend using JSON log format.

JSON
^^^^

JSON log messages are JSON objects, which should be printed as single object per
line. Timestamp must be carried in ``@timestamp`` field, and it must be either
`ISO 8601 timestamp as understood by Joda-Time`_ or milliseconds since epoch.
Elasticsearch refuses to index objects, if any of the field names contain periods
(e.g. ``foo.bar``).

For example, log message formatted as follows::

    {"@timestamp":"2017-05-08T12:00:00Z","message":"hello","level":"INFO","moon_phase":"full"}

Would be interpreted like this:

.. list-table:: JSON log message example
   :header-rows: 1

   * - Field
     - Value
   * - @timestamp
     - 2017-05-08T12:00:00Z
   * - level
     - INFO
   * - message
     - hello
   * - moon_phase
     - full

Log message field names share a single namespace, and values of any given field
should always be of same type. If a log message has a field with a conflicting
type, the message will not be indexed. Current field type mappings can be examined
using `Elasticsearch mapping`_ endpoint::

    http://es.br.hmheng.io:9200/logstash-YYYY.MM.DD/_mapping/aurora

.. _ISO 8601 timestamp as understood by Joda-Time: http://www.joda.org/joda-time/apidocs/org/joda/time/format/ISODateTimeFormat.html#dateOptionalTimeParser--
.. _Elasticsearch mapping: https://www.elastic.co/guide/en/elasticsearch/reference/2.3/mapping.html

Log messages with correlation IDs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

A log message formatted as follows::

     2017-01-01 11:22:33+02:00 TRACE 1072 --- [threadname] com.example.Foo: [correllationId] actually logged message

is parsed using the following `grok pattern`_::

     %{TIMESTAMP_ISO8601:timestamp}%{SPACE}%{LOGLEVEL:loglevel}%{SPACE}%{NUMBER:pid}%{SPACE}---%{SPACE}%{SYSLOG5424SD:threadname}%{SPACE}%{SPACE}%{JAVACLASS:logclass}%{SPACE}:%{SPACE}\[%{GREEDYDATA:correlationId}\]%{SPACE}%{GREEDYDATA:logmessage}

which will extract the following fields from the log message:

.. list-table:: Sprint boot log message example
   :header-rows: 1

   * - Field
     - Value
   * - timestamp
     - 2017-01-01 11:22:33+02:00
   * - level
     - TRACE
   * - pid
     - 1072
   * - threadname
     - threadname
   * - correlationId
     - correlationId
   * - logclass
     - com.example.Foo
   * - logmessage
     - actual log message

Log messages without correllation IDs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

A log message formatted as follows::

     2017-01-01 11:22:33.123 TRACE 1072 --- [thread] this.is.ignored.Foo: actually logged message

is parsed using the following `grok pattern`_::

     (?<timestamp>%{YEAR}-%{MONTHNUM}-%{MONTHDAY} %{TIME})  %{LOGLEVEL:level} %{NUMBER:pid} --- \[(?<thread>[A-Za-z0-9-]+)\] [A-Za-z0-9.]*\.(?<class>[A-Za-z0-9#_]+)\s*:\s+(?<logmessage>.*)

which will extract the following fields from the log message:

.. list-table:: Sprint boot log message example
   :header-rows: 1

   * - Field
     - Value
   * - timestamp
     - 2017-01-01 11:22:33.123
   * - level
     - TRACE
   * - pid
     - 1072
   * - thread
     - thread
   * - logclass
     - Foo
   * - logmessage
     - actual log message

Automatic log metadata
~~~~~~~~~~~~~~~~~~~~~~

Some additional metadata is added to all indexed messages originating from
application running on Aurora. These metadata include role-, application-, and
stage names in addition to various internal IDs.

.. list-table:: Automatically extracted log metadata
   :header-rows: 1

   * - Field
     - Description
   * - containerid
     - Mesos container ID
   * - frameworkid
     - Mesos framework ID
   * - taskid
     - Mesos task ID
   * - user
     - Mesos role (e.g. ``hmheng-infra``)
   * - stage
     - Mesos stage (e.g. ``devel`` or ``int``)
   * - job
     - Aurora job name (e.g. ``kibana``)
   * - job_instance
     - Aurora job instance ID (e.g. ``0``)
   * - job_uuid
     - Aurora job UUID

Raw Mesos stages are automatically formatted to the conventional stage names used in HMH.

.. list-table:: Mesos stage mapping
   :header-rows: 1

   * - Mesos stage
     - Indexed stage
   * - devel
     - devel
   * - staging0
     - int
   * - staging1
     - cert
   * - staging2
     - certrv
   * - staging7
     - cert
   * - staging3
     - prodrv
   * - prod
     - prod

Searching and visualizing
-------------------------

Kibana_ provides a UI for searching and visualizing logs. Kibana provides a
`query language`_ for querying, and allows users to visualize_ query results in
various ways. Visualizations may also be composed into dashboards_.

Kibana related peer-support is provided on ``#kibana_wizards`` channel in HMHCO Slack.

Kibana instance serving all Bedrock users is located at
https://kibana.br.hmheng.io/.

.. _query language: https://www.elastic.co/guide/en/kibana/4.5/discover.html
.. _visualize: https://www.elastic.co/guide/en/kibana/4.5/visualize.html
.. _dashboards: https://www.elastic.co/guide/en/kibana/4.5/dashboard.html

Programmatic access
-------------------

`Elasticsearch API`_ is available at es.br.hmheng.io:9200. Currently it provides
unauthenticated access to all indices. Elaticsearch API usage is subject to guidelines
outlined in :ref:`elasticsearch-team-usage`.

.. _Elasticsearch API: https://www.elastic.co/guide/en/elasticsearch/reference/2.3/docs.html
