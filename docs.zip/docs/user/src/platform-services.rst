Platform services
=================

.. toctree::
   :maxdepth: 2

   centralized-logging
   deploy-nodes
   sherpa
   links-to-platform-services
   metrics
   shared-storage
   team-jenkins
   kafka
