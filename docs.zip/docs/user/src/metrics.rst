Metrics
=======

By exposing metrics for your application, you can enable yourself to
understand how your code is performing and which things are being used
most.

Bedrock enables applications to expose metrics through a
`StatsD <https://github.com/etsy/statsd>`__ interface. Currently,
metrics sent through Bedrock are visible in
`Datadog <https://www.datadoghq.com/>`__.

Though Datadog is acting as primary metrics server, metrics are also
forwarded to `Prometheus <http://prometheus.io/>`__ to save metrics for
historical reference.

What you can track
------------------

StatsD allows you to track a few different types of metrics: counters,
gauges, and timers.

Counters
~~~~~~~~

Counters allow you to track how often events happen over a period of
time. They're great when the *rate of occurrence* of something is
important. Some examples of things you can express with counters:

-  1 person just logged in.
-  We just received data for 374 students.

Gauges
~~~~~~

Gauges are static values that you can change. They're great when the
*current value* of something is important. Some examples of things you
might represent with gauges:

-  There are currently 1,329 active users.
-  We are currently running 12 scoring jobs.

Timers
~~~~~~

Timers track how long something takes. Some examples:

-  It took 631ms to confirm this login.
-  This rostering data import took 10m47s.

How to name metrics
-------------------

Your metrics share a top-level namespace with everyone else's metrics.
Be considerate.

Namespacing is achieved in practice by using periods (``.``).

It is good practice to use an unambiguous prefix for your metrics. For
example, the ``idm-api-adapters`` project might use metric names for
rostering like

-  ``hmh.idm.api_adapters.queue_size``
-  ``hmh.idm.api_adapters.students_imported``
-  ``hmh.idm.api_adapters.import_time``

In these examples, the namespaces are something like this:

-  **``hmh``** signifies that this is HMH software. This separates our
   application metrics from system-level metrics (e.g., ``aws``,
   ``docker``, &c.).
-  **``hmh.idm``** signifies that these belong to the IDM team within
   HMH.
-  **``hmh.idm.api_adapters``** suggests that this data corresponds to
   IDM's API adapters project.

Prometheus supports the following regex for metrics names:
``[a-zA-Z\_:][a-zA-Z0-9\_:]*``.

How to send data
----------------

Sending data to StatsD is super simple. There are `client libraries for
a bunch of
languages <https://github.com/etsy/statsd/wiki#client-implementations>`__;
grab one for your language, and start sending stats!

The application only needs to define the statsd server as localhost:8125
(default statsd port), any metrics sent here from statsd be picked up by
Datadog with no additional work needed.

Things to avoid
---------------

The StatsD interface provided by Bedrock might change over time. You
might see references to the following things in documentation for StatsD
clients and servers, but we might not be able to support them in the
future:

-  Sets
-  Sampling rates (for counters and timers)
-  Histograms (a generalization of timers)

That said, if you have a great use case for one of these things, let us
know!

In general, you should use a generic StatsD client, and *not* a
``dogstatsd`` client. Datadog has added a few extensions to StatsD that,
while really handy, are not compatible with other StatsD
implementations.

Further Reading
---------------

-  `The StatsD repo <https://github.com/etsy/statsd>`__
-  `StatsD's documentation on metric
   types <https://github.com/etsy/statsd/blob/master/docs/metric_types.md>`__
-  `"Measure Anything, Measure
   Everything" <https://codeascraft.com/2011/02/15/measure-anything-measure-everything/>`__:
   Etsy on the origins of StatsD
-  `"Track Every
   Release" <https://codeascraft.com/2010/12/08/track-every-release/>`__:
   Etsy on lining up releases with application metrics.
-  `Datadog's blog post about
   StatsD <https://www.datadoghq.com/blog/statsd/>`__ mentions some
   non-standard StatsD extensions, but is a generally useful overview.
