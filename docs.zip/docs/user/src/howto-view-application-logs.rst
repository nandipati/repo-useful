How to view application logs
============================

After deploying a service to Bedrock, there will be a need to monitor
logs for the deployed application. It is true that the logs are all
available in https://kibana.br.hmheng.io, but sometimes it is necessary
to view the logs in real time for a specific instance of a service. If
that is the case, the following instructions will direct you to the real
time stdout/stderr log viewer for a deployed container instance:

1. Browse to https://aurora.br.hmheng.io
2. Click on Scheduler
3. Click on the role associated with the service you would like to view
   the logs for (ie. hmheng-infra)
4. Click on the stage associated with the service you would like to view
   the logs for (ie. dev,prod,staging0)
5. Click on the name of the service you would like to view the logs for
6. Click on the hostname link that contains the service instance you
   would like to view the logs for
7. Click on stdout or stderr, depending on which log you would like to
   monitor
