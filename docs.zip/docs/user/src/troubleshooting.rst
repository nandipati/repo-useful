Troubleshooting
===============

This page will describe common errors and trouble shooting techniques
for Bedrock

.. contents::

Known Issues
------------

Bedrock isn't perfect, and this section describes some of the known issues.
Other open issues may found from the `Bedrock issue tracker`_.

.. _Bedrock issue tracker: https://github.com/hmhco/io.hmheng.platform/issues

Connection Reset Exception
~~~~~~~~~~~~~~~~~~~~~~~~~~

For HMH hosted services, we have noticed that "Connection Reset" socket
exceptions are thrown intermittently when service to service outbound
calls are being orchestrated from bedrock to an external ELB endpoint
(over the web) rather than an internal elb one. To resolve this issue,
you would need to update the offending target downstream endpoint to its
internal elb endpoint.

Address Already in Use (Resource Exhaustion)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is very rare but whenever it occurs when making an outbound
connection, we believe it is caused by resource exhaustion on bedrock.

Deploying container with same tag
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

If aurora attempts to replace an older image with a new one of the same
the same tag can cause issues. This will only happen when the same slave
is targeted that has the older image. Steaming from a bug in Docker
which stops aurora from removing old container because mount device is
considered busy. You may see a ``38 Killed``-message in logs. We are aware
of the issue and working for a solution. The short term solution is
never deploy containers which has a reused tag.

Jenkins CSS not working
~~~~~~~~~~~~~~~~~~~~~~~

Run the following command in the Jenkins script console. Note that this
must be executed again every time Jenkins is restarted::

  System.setProperty("hudson.model.DirectoryBrowserSupport.CSP",
    "sandbox allow-scripts; style-src 'unsafe-inline' *;script-src 'unsafe-inline' *;")

Aurora
------

FAILED : Task used more memory than requested
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**What it means**: Generally this means that the container trying to be
run doesn't exist. You can confirm this by getting the container image
name from the task config, then try and run docker pull if the message
is "Error image X not found" then the container needs to be built first.

**Solution**: rerun your develop job to ensure the current container
does exist

LOST : Abnormal executor termination
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**What it means**: This can mean your container needs to be built from
the bedrock base container (i.e. ``docker.br.hmheng.io/base-ubuntu:16.04``)

**Solution**: modify docker to have ``FROM docker.br.hmheng.io/base-ubuntu:16.04``

Insufficient resource quota: X quota exceeded by X
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**What it means**: Production quota needs to be increased for user
trying to create Job, you can check user quotas here
https://aurora.br.hmheng.io/quotas

**Solution**: Notify a bedrock team member that your quota needs to be
increased by opening an issue here: https://github.com/hmhco/io.hmheng.platform/issues?q=is%3Aissue+quota+is%3Aclosed

Lost: Container terminated
~~~~~~~~~~~~~~~~~~~~~~~~~~

**What it means**: Lost can mean many different things. If a Task stays in
``ASSIGNED`` or ``STARTING`` for too long, the scheduler forces it into ``LOST``
state. It can also mean that the container took too long to pull.
