How to add a datadog monitor
============================

Datadog is a service that provides easy monitoring and analytics. To create a new monitor, you need to add a new module in the main.tf file. There are four available modules that you can choose from for your datadog monitor.

Warning
-------

Warning is a generic datadog module used to create warnings.

.. code-block::

    module "datadog-warning" {
      source = "modules/datadog/warning/"

      name = "Warning Test"
      type = "metric alert"
      message = "This is a drill"
      query = "avg(last_5m):avg:system.disk.in_use{environment:brnpb,salt-role:salt.master} by {device,host,salt-role} >= 90"
    }

The variables `name`, `type`, `message`, and `query` are required in order to create a monitor. The alerts created with this module will have ``bedrock::WARNING:`` prepended to their name and will report by default to ``slack-bedrock-alerts`` and ``pagerduty-br-infra-warning``.

Critical
--------

Critical is a generic datadog module used to create critical alerts.

.. code-block::

    module "datadog-critical" {
      source = "modules/datadog/critical/"

      name = "Critical Test"
      type = "metric alert"
      message = "This is a drill"
      query = "avg(last_5m):avg:system.disk.in_use{environment:brnpb,salt-role:salt.master} by {device,host,salt-role} >= 90"
    }

The variables `name`, `type`, `message`, and `query` are required in order to create a monitor. The alerts created with this module will have ``bedrock::CRITICAL:`` prepended to their name and will report by default to ``slack-bedrock-alerts`` and ``pagerduty-br-infra``.

Process Check
-------------

Process check is a datadog module used to create alerts responsible for checking if the correct number of of a process's instances are running.

.. code-block::

    module "datadog-process-check" {
      source = "modules/datadog/process_check/"

      process_name = "ProcessCheckTest"
      ok_threshold = "2"
      warning_threshold = "4"
      critical_threshold = "4"
    }

The variables `process_name`, `ok_threshold`, `warning_threshold`, and `critical_threshold` are required in order to create a monitor.
  * **process_name**: The actual name of the process you want to monitor. This name will appear in the title, the query, and the tag "component:[`process_name`]".
  * **ok_threshold**: The number of successes after which to resolve the alert.
  * **warning_threshold**: The number of failures after which to trigger a warning.
  * **critical_threshold**: The number of failures after which to trigger a critical alert.

Elb Health Check
----------------

Elb Health Check is a datadog module used to create alerts that monitor the health of an elastic load balancer.

.. code-block::

    module "datadog-elb-health-check" {
      source = "modules/datadog/elb_health_check/"

      elb_name = "Elb Test"
      monitor_window = "5"
      environment = "test"
      unhealthy_host_count = "2"
    }

The variables `elb_name`, `monitor_window`, `environment`, and `unhealthy_host_count` are required in order to create a monitor.
  * **elb_name**: The actual name of the elb you want to monitor. This name will appear in the title, the query, and the tag "component:[`elb_name`]".
  * **monitor_window**: The amount of minutes to monitor elb for changes.
  * **environment**: The environment that elb belongs to.
  * **unhealthy_host_count**: The amount of unhealthy elb hosts that should trigger the alert.

.. Note:: `escalation_message` is not included as an optional variable. Instead, it will always take the value of `message`.


There are additional optional settings that can be added to fine-tune your monitor. You can find specific details in `terraform <https://www.terraform.io/docs/providers/datadog/r/monitor.html>`_.