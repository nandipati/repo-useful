Reason for outage (RFO)
=======================

To ensure transparity when there are issues or outages for services that the br-technical-services maintain we tend to complete an RFO.
Completing a RFO does not necessarily mean there was an outage or any customer impacting event, but rather is an easy way to communicate any problem we face.

When an RFO is completed we will post it to the #br-technical-services channel in slack. Historical record of past RFOs can be found in `box`_.
If for any reason you would like an RFO to be completed about services or application in the bedrock ecosystem feel free to open an `issue`_.


.. _box: https://hmhco.box.com/v/bedrock-rfo
.. _issue: https://github.com/hmhco/io.hmheng.platform/issues