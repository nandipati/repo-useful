Connectivity with Other Services
--------------------------------

By default, applications running within Bedrock are not able to connect
to HMH services and applications outside of Bedrock.

**If your application needs to connect to something outside of Bedrock,
you must alert the Bedrock team.**

Network configuration is done for each end-point via :ref:`proxy-configuration`.

If the service you need to connect to is running in AWS, please provide
the Bedrock team with the ID of the security group that should be used
to connect to it. If you cannot provide a security group ID, then
providing the IP range within the HMH network that contains the service
is also acceptable.

Please open Pull Request towards `official Bedrock
repository <https://github.com/hmhco/io.hmheng.platform/pulls>`__ with
the following changes requested:

For defining Source network, define your network range (with full CIDR)
into segment "cidr:" in
`options.yaml <https://github.com/hmhco/io.hmheng.platform/blob/develop/aws/cloudformation/options.yaml>`__

For defining Source Security Group, define your Security group into
segment "securityGroup:" in
`options.yaml <https://github.com/hmhco/io.hmheng.platform/blob/develop/aws/cloudformation/options.yaml>`__

For defining Destination, add Source network into "sgElbInCidr" of your
Proxy configuration, with name of Source network which you defined, or
add Source security group name into "sgElbInSg".

PR example for `adding Source
network <https://github.com/hmhco/io.hmheng.platform/pull/879/files>`__

PR example for `adding Security
group <https://github.com/hmhco/io.hmheng.platform/pull/550/files>`__
