Terraform on Prem
=================

Terraform on Premises intends to move towards a self service module and allows for developers to see real world
changes of plans and apply those changes without needing to interact with the Bedrock team. This also allows for all
pull request to be planned automatically allowing for errors to be seen.

Requirements
------------

For all resources created under this self-service model, each team will need to manage these resources within a single
state file. To achieve this, teams will need to create modules for each component and then make calls to these modules
per stage.

Naming
~~~~~~

Each team has an IAM user which has permissions to control only their team's resources. In order to achieve this a strict
naming convention must be followed. If the resource does not follow this pattern TFE will not be able to control it.

policies and roles
^^^^^^^^^^^^^^^^^^
Policies and roles must be named beginning with ``io.hmheng.<ROLE NAME>``

Database
^^^^^^^^
Databases must be named beginning with ``hmheng-<ROLE NAME>``

Security Groups
^^^^^^^^^^^^^^^
Security Groups must be named beginning with ``hmheng-<ROLE NAME>``

Queue (SQS)
^^^^^^^^^^^
Queues must begin with ``io-hmheng-<ROLE NAME>``

S3 bucket
^^^^^^^^^
S3 bucket must be named exactly as role

KMS keys & Aliases
^^^^^^^^^^^^^^^^^^
KMS keys do not use names, but the policy needs to be correct, or we could be locked out of the key.
An example of the key policy is,

code::


  policy = <<EOF
    {
      "Version": "2012-10-17",
      "Id": "key-default-1",
      "Statement": [
        {
          "Sid": "allow_iam_to_assign_permissions_via_policy__required",
          "Effect": "Allow",
          "Principal": {"AWS": [
              "arn:aws:iam::${var.br_aws_account_number}:user/terraform-enterprise/<ROLE>",
              "arn:aws:iam::${var.br_aws_account_number}:root"
          ]},
          "Action": "kms:*",
          "Resource": "*"
        },
        {
          "Sid": "allow_hmheng-math-inventory_config-server_key_usage",
          "Effect": "Allow",
          "Principal": {"AWS": [
            "${aws_iam_role.math-inventory-config-server.arn}"
          ]},
          "Action": [
            "kms:Encrypt",
            "kms:Decrypt",
            "kms:ReEncrypt*"
          ],
          "Resource": "*"
        }
      ]
    }
    EOF
    }

Where <ROLE> must be exatly the same as the aurora role ie hmheng-infra. Note this is not an IAM policy but rather the
policy for the key which exists as part of the ``aws_kms_key`` resource .

For key alias the naming pattern must be ``alias/io-hmheng-<role>*``

ElastiCache
^^^^^^^^^^^
For cache nodes the name needs to be less than 32 characters therefore naming on cache is not as strict, as long as it makes logical sense.
The requirement is that all caches need to have a ``cost`` tag which begins with role name, such as ``hmheng-infra-my-awesome-cache``

We also require all caches to have a ``subnet_group_name`` parameter of  ``brcore01-service``


Modules
-------

In order to achieve a single state file teams must use modules for each of their resource group.
A Generic modules structure may look like this:

code::

  io.hmheng.tf
  ├── role (hmheng-infra)
  │   ├── main.tf
  │   ├── variables.tf
  │   ├── modules
  │   │   ├── v1
  │   │   │   ├──resource1.tf (version1 of resource)
  │   │   │   ├──resource2.tf (version1 of resource)
  │   │   ├── v2
  │   │   │   ├──resource1.tf (version2 of resource)
  │   │   │   ├──resource2.tf (version2 of resource)


With a structure like this all stages can be created with different variables with simple module calls from main.tf .
An example of that would look like

code::

  resource "my-project-dev" {
    source  = "./modules/v1/"

    stage   = "dev"
    db_size = "t2.small"
  }

  resource "my-project-prod" {
    source  = "./modules/v1/"

    stage   = "prod"
    db_size = "t2.large"
  }


User and group authentication
-----------------------------

The pricing of Terraform Enterprise is based partly on seats, meaning number of users. For this reason we are currently
allowing only one user per role. This user will have permissions to plan, apply, edit variables. Once a team has created
a group of resources in the new module they can nominate someone to be the team Terraform Admin. They can then create an
account here https://terraform.eng.hmhco.com/account/new . Then open a Github issue to get this user added to their role.

Addition benefits
-----------------

No more state files in Github. State files can include a lot of sensitive information, using Terraform Enterprise uses a
Atlas backend which stores all the state files securely.

Terraform Enterprise allows for password obscuration, sensitive information no longer needs to be checked into Github.
This is achieved by setting variables in the UI and setting it to sensitive. This means the variable can only be updated
once it is set it can never be read.



