.. _shared-storage:

Shared storage
==============

Some services that are deployed to bedrock may need a storage option to
host files that need to be accessed by other containers running under
the same job name and same job stage. This Bedrock shared storage
feature provides that solution by mounting highly available AWS EFS
(Elastic File System) to the mesos agents with directories separated by
bedrock roles. Each role user will only have access to the services
utilizing shared storage for the role(s) that the user has access to.
This requires the docker container (Dockerfile) to be configured to run
as the role (USER/UID) that is associated with the job to be deployed
(ie. stub-application = hmheng-demo/5001). Failure to configure the
dockerfile with the proper user will prevent role users from accessing
their shared file structure via the deploy console nodes
(``/mnt/efs/service/roles/<bedrock-role>/<aurora-job-name>/<aurora-job-environment>/``).

Instructions
------------

Create Directory via Deploy Console
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. ssh in to deploy console node
   ``ssh <bedrock-role>@deploy.br.hmheng.io``
2. change to directory associated with job role
   ``cd /mnt/efs/service/roles/<bedrock-role>``
3. make a directory for the aurora job name and aurora stage (both
   values must match related values in aurorafile)
   ``mkdir <aurora-job-name>``
   ``mkdir <aurora-job-name>/<aurora-job-environment>``

\* *aurora job environment is used over stage to allow shared storage
directory structure to remain in sync with aurora job keys*

Add Shared Storage Config to Dockerfile
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. add following code block to Dockerfile
2. replace ``<bedrock-role-name>``, ``<bedrock-role-uid>``, and
   ``<inside-container-mount-dir>`` markers with the values associated
   with the job to be deployed (*see `bedrock role
   name/uids <https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls>`__*)
3. Build docker container with Dockerfile and push to docker registry::

    # shared storage config - define bedrock role/id (required)
    ENV BR_ROLE_NAME <bedrock-role-name>
    ENV BR_ROLE_UID <bedrock-role-uid>  
    ENV BR_CNTR_MNT <inside-container-mount-dir>
    
    ##### shared storage config - start - do not alter - any changes may prevent container start/run/mount issues #####
    ENV BR_THRM_NAME thermos-exec-bot
    ENV BR_THRM_UID 1008
    
    # add group/user (must use uid associated with bedrock role)
    RUN groupadd -g ${BR_ROLE_UID} ${BR_ROLE_NAME} && \
        useradd -u ${BR_ROLE_UID} -g ${BR_ROLE_UID} ${BR_ROLE_NAME} && \
        mkdir --parents /home/${BR_ROLE_NAME} && \
        chown ${BR_ROLE_NAME}:${BR_ROLE_NAME} -R /home/${BR_ROLE_NAME} && \
        chmod 775 -R /home/${BR_ROLE_NAME}
    
    # create & grant thermos-exec-bot access to user home folder
    RUN groupadd -g ${BR_THRM_UID} thermos-exec-bot && \
        useradd -u ${BR_THRM_UID} -g ${BR_THRM_UID} ${BR_THRM_NAME} -G ${BR_ROLE_NAME}
    
    # add inner container mount point & permissions
    RUN mkdir ${BR_CNTR_MNT} && \
        chown ${BR_ROLE_NAME}:${BR_ROLE_NAME} -R ${BR_CNTR_MNT}
    
    # workaround for aurora bug (https://issues.apache.org/jira/browse/AURORA-1237) - sudo access is removed during deployment
    RUN echo "${BR_ROLE_NAME}   ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
    
    # switch to non-root user
    USER ${BR_ROLE_NAME}
    
    # shared storage detail
    # - any commands that need to be run as root should be added before shared storage config
    # - any commands that need to be run as job user (ie. hmheng-demo) should be added after shared storage config
    # - get role name/uid values from https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls
    # - BR_CNTR_NT -> inner container directory that will be access by the bedrock service/application being deployed
    ##### shared storage config - end - do not alter - any changes may prevent container start/run/mount issues #####
    
    | see sample
      `Dockerfile <https://github.com/rbaumgartner/io.hmheng.platform/blob/3800280ab5162d7916170633f71ef0bf5f1cc32e/docker/shared_storage/Dockerfile>`__
      used in demo

Add Shared Storage Config to Aurorafile
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

see sample
`aurorafile <https://github.com/rbaumgartner/io.hmheng.platform/blob/3800280ab5162d7916170633f71ef0bf5f1cc32e/docker/shared_storage/shared_storage.aurora>`__
used in demo

Questions
---------

Why does the shared storage volume need to be created via the deploy console before deploying aurora job?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

By default, docker cli volume (``-v <host_mnt>:<container_mnt:<ro/rw>``)
command creates the ``<host_mnt>`` directory on the host as root. There
is not currently a docker volume feature that allows the owner/group of
the created directory to be defined, and for obvious security reasons,
apache aurora does not offer an option to modify the mesos agent via an
aurorafile configuration. If an aurora job that utilizes shared storage
is deployed before the ``<host_mnt>`` folder is created manually via a
user logging in to the deploy console, the ``<host_mnt>`` folder will be
created with root:root permissions and will not be accessible by the
users that log in to the deploy console or by the container that is
deployed via the aurora job (the hmheng-infra team will then need to
delete folder so that it can be created correctly).

Why is so much user/group based configuration required in the Dockerfile?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A `bug <https://issues.apache.org/jira/browse/AURORA-1237>`__ in Apache
Aurora regarding setuid currently exists that prevents the mesos/aurora
sandbox permissions from being defined as the role value in the
aurorafile used to deploy the container. As a workaround, the
configuration defined in the sample shared storage Dockerfile is
required to create the necessary user/group directories with proper
permissions, including ability to sudo. The second piece of the
workaround involves the thermos wrapper script detecting the shared
storage enabled container, updating the permissions of the mesos/aurora
sandbox directories/files, and removing sudo access. Most of the
configuration will be replaced after Apache Aurora implements the fix,
along with new functionality that will automatically add the needed
user/group permissions if the user does not already exist in the
container (see
`detail <https://issues.apache.org/jira/browse/AURORA-1274>`__).
