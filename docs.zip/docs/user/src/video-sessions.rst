Video sessions
==============

Here you can find links to any recorded video sessions held by bedrock team.

Dublin Feb 2017
---------------

- `Beyond the template, aurora file`_

- `influxDB Event Capture and Annotations`_

- `jenkins pipelines`_

- `LinkerD`_

- `Zookeeper`_

- `Persistence storage options`_

- `Bedrock values`_

.. _Beyond the template, aurora file: https://hmhco.box.com/s/a3imcpi0zf1arassowfk42g041acev66
.. _influxDB Event Capture and Annotations: https://hmhco.box.com/s/riyd58pac4jtk1zfhwwhcu7nxwhe9op5
.. _jenkins pipelines: https://hmhco.box.com/s/himb7v991lf6uw8rrt0x0hz8wzkp7aas
.. _LinkerD: https://hmhco.box.com/s/o27makw35r8y59cg61w0wuuh0fpmowrz
.. _Zookeeper: https://hmhco.box.com/s/yfe8g6yoj1ajmtt97dffsfql1bck016e
.. _Persistence storage options: https://hmhco.box.com/s/4taqdxsbzjmfsaef6ajfe3ovxgxglc6q
.. _Bedrock values: https://hmhco.box.com/s/4dsoa3ektvjfuzxh5q2yk60ggmskt3qe