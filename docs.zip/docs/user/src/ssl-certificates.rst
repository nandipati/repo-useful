SSL Certificates
================

All Bedrock SSL Certificates on or after 09/01/2016 are created and
managed in Amazon Certificate Manager (ACM). SSL Certificates prior to
09/01/2016 were ordered by Navisite and will be replaced with a SSL
certificate from ACM after receiving any related renewal requests.


Bedrock root CA
---------------

Bedrock root CA should be installed on every HMH workstation by default.
If by some chance that is not the case it can be fetched manually.

.. code-block:: sh

        curl -1 -k -o bedrock-ca.pem https://vault.br.internal/v1/ca/ca/pem

To test that the certificate is sane

.. code-block:: sh

        openssl x509 -noout -text -in bedrock-ca.pem

Convert ca certificate to windows compatible DER format

.. code-block:: sh

        openssl x509 -in bedrock-ca.pem -outform DER -out bedrock-ca.der

Importing certificate
~~~~~~~~~~~~~~~~~~~~~

On MacOS
^^^^^^^^

.. code-block:: sh

        sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain bedrock-ca.pem

On Windows
^^^^^^^^^^

.. code-block:: sh

        certutil –addstore –f “Root” bedrock-ca.der

On Debian based systems (Ubuntu)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: sh

      sudo install bedrock-ca.pem /usr/local/share/ca-certificates/bedrock-ca.crt
      sudo update-ca-certificates


Requesting a SSL Certificate
----------------------------

1. Open a git
   `issue <https://github.com/hmhco/io.hmheng.platform/issues/new>`__

-  Include the full domain name that needs to be secured via SSL (ie.
   test.dev.br.hmheng.io)

*\* Wildcard certificates can NOT be used for internet facing endpoints*

Operations
----------

1. Take assignment of Git issue and add related card to Kanban board
2. Use AWS ACM cli to set hmheng.io as the validation domain
   ``awsBrDomain='test.br.hmheng.io'``
   ``aws acm request-certificate --domain-name "${awsBrDomain}" --domain-validation-options DomainName=${awsBrDomain},ValidationDomain=hmheng.io``
3. Accept certificate request by clicking on link included in email sent
   to admin.hmheng.io
4. Post arn of new SSL certificate to issue notes and close issue

Non-Bedrock domains
-------------------

For other HMH SSL certificates for domain names in non-Bedrock, please follow
the procedure on the following page:

https://confluence.hmhco.com/pages/viewpage.action?spaceKey=NFR&title=AWS+Certificate+Manager+Certificates
