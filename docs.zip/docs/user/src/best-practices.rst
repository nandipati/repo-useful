Best practices
==============

.. toctree::
   :maxdepth: 2

   elasticsearch-team-usage
