Bedrock Platform
================

An introduction
---------------

The Bedrock Platform is the internal name for the Platform as a Service (PaaS) built on top of Mesos and Aurora. It was designed to be self-service, and allow for developers to be in control of the deployment of applications and resources, while at at the same time decreasing the development time for its end users.
From the traditional one application one server approach this architecture have a large cost benefit allowing many applications to share isolated resources on a single EC2 instance.
The design allows for developers to use the platform without intimate knowledge of how the individual parts work.

What is it
----------

**Increased development speed**: The use of pooled resources allows for teams to deploy new applications without having to request provisioned servers and wait. When a team needs a AWS resource (queues, DBs, streams, ...) they are able to open a pull request and in a short amount of time, have their resources deployed.

**Scalability**: The platform architecture allows for horizontal scaling with little effort. Currently there are 93 instances which host applications with a total of 570+ unique instances of applications running. This could be easily doubled with very little effort.

**Self-Service**: We are consistently moving towards a self-service model. If a team needs to setup a new application they can launch and access their application via linkerd with no direct contact with the bedrock technical service team.

**Highly Available**: Everything is built in set of threes spread across availability zones. The cluster provides enough redundancy that even in the event of an AWS availability zone outage no production applications should be affected.

What is it not
--------------

Not everything fits this pattern. It's intended that applications deployed to this platform are stateless and can handle a restart at any time.

Looking forward
---------------

We will continue to make the platform more self-service, allowing developers to have more control of their environment.