Running an application
======================

Docker
------

Docker enables you to package your application code along with all of
its runtime dependencies.

Bedrock runs your application inside of a Docker container. If your
application runs in a Docker container on your local machine, you can be
reasonably confident that it will run the same way on Bedrock.

For more on the basics of Docker, see `Docker's
introduction <https://docs.docker.com/engine/userguide/containers/dockerizing/>`__.

You will need to ensure that your application can be built into a Docker
container. You will need a ``Dockerfile`` in your repository to enable
this. We hope to have some ``Dockerfile`` examples in the future, but
for now please look at the `Dockerfile reference <https://docs.docker.com/engine/reference/builder/>`__.

The ``FROM`` statement in your ``Dockerfile`` **must** specify one of
the Bedrock base images in order to run on Bedrock. The supported base
images are:

-  ``docker.br.hmheng.io/base-ubuntu:16.04`` A base install of
   Ubuntu 16.04.
-  ``docker.br.hmheng.io/base-ubuntu:16.04-jdk8`` As above,
   but with a preinstalled Java runtime.
-  ``docker.br.hmheng.io/base-centos6:latest`` A base install of
   CentOS 6. *We recommend that you use one of the Ubuntu images unless
   you have a specific requirement for CentOS.*
-  ``docker.br.hmheng.io/base-nodejs:6.2.0`` A base install of Ubuntu 16.04 with preinstalled Nodejs 6.2.0

.. Note:: while Docker Compose is useful for running a local development environment, we cannot support it on Bedrock.

Aurora
------

Your ``.aurora`` file defines your Aurora task which is used to define
the environment, request resources, and announce your application ports
for service discovery. We provide a template ``.aurora`` file to get you
started
`here <https://github.com/hmhco/io.hmheng.platform/blob/develop/aurora/templates/java8/template_java8_01.aurorafile>`__.

::

    CLUSTER_NAME= "<cluster-name>"          # ie. brnpb
    APP_NAME = "<app-name>"                 # ie. idm-idp
    APP_ROLE = "<app-role>"                 # ie. hmheng-idm
    DOCKER_GROUP = "<docker-group>"         # ie. com-hmhco-idm or io-hmheng-demo
    DOCKER_REGISTRY = "docker.br.hmheng.io" # ie. docker.br.hmheng.io
    AWS_REGION = "us-east-1"                # ie. us-east-1

These variables found at the top of the template should be configured for your new application. They must also match what is used by the docker image.
The docker image to pull is built from DOCKER_REGISTRY/DOCKER_GROUP/APP_NAME

  1. CLUSTER_NAME: defines the aurora cluster to deploy to, currently all should be brnpb
  2. APP_NAME: what name the application should use to run in aurora
  3. APP_ROLE: your teams role
  4. DOCKER_GROUP: must match how the image was pushed, used to build the docker image name
  5. DOCKER_REGISTRY: the repo which your image is stored, generally everyone will use docker.br.hmheng.io which is the `artifactory`_ docker repo.
  6. AWS_REGION: which region the aurora cluster is located, currently always use us-east-1

.. _artifactory: https://repo.br.hmheng.io/artifactory/webapp/#/home

Resources
~~~~~~~~~

In the aurora file you must define the amount of resources which the task requires.
This is done with this line
``Resources(cpu=0.5, ram=1 * GB, disk=512 * MB)``

When planning resources one should add approximately 25% overhead for other processes such as garbage collection or log rotation.
For information on how these resources work see :ref:`quota` section of documentation and the `aurora documentation`_

Start small! Application should be profiled for their expected resource usage but it is always a good idea to start with a low number of resources, monitor and then if it requires more add more.
Horizontal scaling, its better to have more small shards (instances) of an application then a few larger shards. This makes the service more high available as well as decreases fragmentation of the cluster.

.. _aurora documentation: http://aurora.apache.org/documentation/latest/features/resource-isolation/

cmdline
~~~~~~~

The cmdline argument in the aurorafile is how aurora starts the application.

example of this would look like::

  cmdline="""export JAVA_HOME=/usr/lib/jvm/java-8-oracle &&"""
          """ java -Xmx750m -Xms512m """
          """ -jar /app.jar"""
          """ --server.port={{thermos.ports[http]}} """

For Java applications we always must set -xmx and -xms values, they should be something around 75% of the ram defined for your application.

Ports
~~~~~

*Static port config should never be used*

When your application needs a port or ports they must be defined from the command line, this can be done by allowing arguments to the jar like the above cmdline example or sed'ing into a config file. Aurora will then assign a available port from the range defined.
The default to use is thermos.ports[http], if you want to use linkerd you must use the http port as the main port. Other wise anything can be used thermos.ports[foo] will give you a random port and call it foo.

thermos.ports[health] if this port is used aurora will automatically use a http healthcheck, which by default will look for /health on the health port for a 200, if any other response code is given the application will be restarted for a failed health check. Healthchecks can be customized by use of aurora `healthchecker object`_.

.. _healthchecker object: http://aurora.apache.org/documentation/latest/reference/configuration/#healthcheckconfig-objects

My first deployment
-------------------

Once the docker container is built and the aurora file is configured you may want to test your configuration before building a jenkins pipeline.
Assuming your public ssh key has been added to the `user deployment`_ pillar in Github, you can ssh into the deploy node using the command ``ssh <your role>@deploy.br.hmheng.io``

Once ssh'd in you can put your aurora file on the machine, and run a test deployment. This is done by running ``aurora update start brnpb-us-east-1/<your role>/<stage>/<application name> /path/to/aurorafile.aurora``
If all goes according to plan you have an application running in aurora! To reach the http endpoint we can use Linkerd to access it by navigating to $APPLICATION.$STAGE.$ROLE.brnp.internal .

.. _user deployment: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls

Jenkins
-------

The next logical step would be to setup a jenkins pipeline for your job.
For some resources to help with this see `this blog article`_ and `this one`_ as well.

.. add link to docs on junkins pipe lining when done

.. _this one: http://blog.br.hmheng.io/2016/06/29/more-pipelining/
.. _this blog article: http://blog.br.hmheng.io/2016/06/07/howto-using-bedrock-jenkins/


Connectivity with Other Services
--------------------------------

By default, applications running within Bedrock are not able to connect
to HMH services and applications outside of Bedrock.

**If your application needs to connect to something outside of Bedrock,
you must alert the Bedrock team.**

If the service you need to connect to is running in AWS, please provide
the Bedrock team with the ID of the security group that should be used
to connect to it. If you cannot provide a security group ID, then
providing the IP range within the HMH network that contains the service
is also acceptable.

Please open Pull Request towards `official Bedrock
repository <https://github.com/hmhco/io.hmheng.platform/pulls>`__ with
the following changes requested:

For defining Source network, define your network range (with full CIDR)
into segment "cidr:" in
`options.yaml <https://github.com/hmhco/io.hmheng.platform/blob/develop/aws/cloudformation/options.yaml>`__

For defining Source Security Group, define your Security group into
segment "securityGroup:" in
`options.yaml <https://github.com/hmhco/io.hmheng.platform/blob/develop/aws/cloudformation/options.yaml>`__

For defining Destination, edit your Proxy file "sgElbInCidr" with name
of Source network which you defined, or "sgElbInSg" with the name of
Source Security Group which you have defined.

Example for `adding Source
network <https://github.com/hmhco/io.hmheng.platform/pull/879/files>`__
