Links to platform services
==========================

Aurora
------

https://aurora.br.hmheng.io

Deploy
------

:ref:`deploy.br.hmheng.io <deploy-nodes>`

Kibana
------

https://kibana.br.hmheng.io

Grafana
-------

https://grafana.br.hmheng.io

Mesos
-----

https://mesos.br.hmheng.io

-  https certificate issues require switching to http for some links

Prometheus
----------

https://prometheus.br.hmheng.io/
