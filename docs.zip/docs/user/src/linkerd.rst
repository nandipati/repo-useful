Service Discovery via Linkerd (DEPRECATED)
==========================================

Services must be discoverable, and addressable. Because of to the ephemeral nature of the nature of tasks running on the Bedrock platform tasks may (and will) not use the same port or IP address from one update/restart to another, this is why service discovery is an important part of the ecosystem.

All tasks which run on Aurora use an announcer, the purpose of this is when a task is started Aurora will announce to Zookeeper the details of the task stored in a znode, meaning the IP address and port which the task is using (aurora/http port).
The Znodes for Aurora tasks can be found at the Zookeeper path ``/discovery/announcer/<ROLE>/<STAGE>/<APP>``.

This then allows for other services such as Linkerd to read from these znodes and discover the service.

Flow Diagram
------------

.. blockdiag::

   blockdiag {
     span_width = 120;
     r53[label="Route 53 (DNS)"]
     nlb[label="Network Load Balancer (NLB)"]
     linkerd1[label="Haproxy Linkerd",stacked]
     linkerd2[label="Mesos agent Linkerd",stacked]
     namerd[label="Namerd",stacked]
     zk[label="Zookeeper",stacked]
     dst[label="Destination"]
     group {
       orientation = portrait
       r53 -> nlb -> linkerd1 -> linkerd2 -> dst;
     }
     linkerd2 <-> namerd [label = "Linkerd addresses out", fontsize = 8];
     group {
       orientation = landscape
     }
     linkerd1 <-> namerd [label = "discovers Mesos Agent Linkerd", fontsize = 5];
     group {
       orientation = landscape
       namerd <-> zk [label = "Service Disco,\ndtab store", fontsize = 8];
     }
     default_group_color = "lightgray"
   }



Haproxy (initial ingress)
-------------------------

Haproxy is the initial ingress for all requests. There is a cluster of 3 internal nodes and 3 external nodes running behind a AWS Network Load Balancer (NLB). The NLB simply forwards 80 and 443 traffic. Haproxy will provide SSL termination for all requests along with heading scrubbing for external requests.

Header manipulation
~~~~~~~~~~~~~~~~~~~
For external requests the follow headers are removed, dtab-local, l5d-ctx-deadline, l5d-ctx-trace, l5d-dtab, l5d-sample.
This is per Linkerd suggested config as allowing these could lead to unwanted access to applications not exposed to the public.

SSL
~~~
All requests sent into Haproxy / Linkerd must use Https, any requests on port 80 will be redirected to 443 automatically.
We have two ways of providing SSL.


First internal, All internal certs are generated and managed though Vault, there is a certificate authority (CA) for each role and then provides single wildcard certificate for all ``*.role.stage.br.internal`` this allows for any application to gain SSL without having to order and issue hundreds of certificates.
All the CA have been signed by the root CA, this allows for a trust chain to be created and allows a single certificate to be installed which provides trust to all endpoint. On the HMH network a copy of the Bedrock root CA has been pushed to all machines, for other applications to use this cert one must pull the cert `curl -k https://vault.br.internal/v1/ca/ca/pem`, this is then put in place to provide trust on the internal certificates.


For external SSL, we have more of traditional approach and which is to have Navisite provide us certs based on a certificate signing request (CSR). From this the private key, certificate, and certificate chain are stored in vault (as secrets) and then pulled to the Haproxy external machine.



Linkerd
-------

Linkerd provides the ability to read from znodes (created by Aurora) and then route traffic to the actual host running the task.
Linkerd is installed on all Mesos agents as well the initial ingress to the system.
The installation on Mesos agents, called the sidecar pattern, is where the service discovery takes place. Using this pattern allows us to have a highly distributed system of routers, equal to the number of Mesos agents (currently 74).
A similar to Aurora, Linkerd can use announcers this allows connection different Linkerd instances based on Zookeeper records.

Dtabs
~~~~~

Linkerd uses Dtabs to define how the requests are routed. The initial ingress on Haproxy is handled by two Dtabs ``haproxy`` for internal and ``haproxy-ext`` for external.
These Dtabs provide context into the request and will route to the appropriate downstream router (sidecar routers).

The internal will identify the request based on domain and route to the right stage router which are announcing to zookeeper.

Example internal dtab: ::

    /host                                   => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-sidecar ;
    /internal/br/dev/api                    => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-dev-api ;
    /internal/br/int/api                    => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-int-api ;
    /internal/br/cert/api                   => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-cert-api ;
    /internal/br/api                        => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-prod-api ;
    /internal/br/hmheng-dmps/devel/dmps     => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/staging1/dmps  => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/staging0/dmps  => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/prod/dmps      => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /host                                   => /$/io.buoyant.http.domainToPath ;
    /http/1.1/*                             => /host ;

What is really happening here? First the the request is transformed to a domain to path routing and based the URL. When a request comes in ``api.
br.internal`` this will be sent to one of the members of the ``/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-dev-api`` znode, meaning one of the 75 sidecar routers.



The sidecar agents are running different routers the reason for this is routing can be done by domain or path, not both. Thus to be able to route based on both we need to first identify the request based on domain with one router then send it a proper path router.
Also for applications to use the same path routing for different stages they use have unique routers.


Here is a bridged explanation of the Mesos agent routers:


  - sidecar
        Routes based on <APP>.<STAGE>.<ROLE>.br.internal
  - plugin
        Uses a custom identifier plugin, see `invigilator`_ for more details
  - api-nonprod
        Api urls, mirrors the external routers for testing in lower stages, for dev -> cert, there is a prod version
  - api-nonprod-ext
        Explicitly routes a single path to a single application, no fall though, there is a prod version

.. _invigilator: https://github.com/hmhco/io.hmheng.linkerd-invigilator


Endpoints
---------

Endpoints are provided by AWS Route53 and point to the NLB.

Internal
~~~~~~~~

Internal ingress to Linkerd will follow two different patterns:

- ``<application>.<stage>.<role>.br.internal``

Such that application stage and role and exactly how they are found in aurora.
For example, `doc-server`_ which means in aurora there is a tasks which match the role/stage/application-name of theg `aurora-task`_

- ``api.<stage>.br.internal`` and  ``api.br.internal``

For internal requests the api endpoint will route both explicitly and implicitly, using path routing.
It will route for all application based on path /role/stage/app for example ``https://api.br.internal/hmheng-infra/prod/doc-server`` would route to the doc-server.
We also allow for single path routing to mirror external usage, such as ``https://api.br.internal/foo`` which can be be mapped to any application. This must be done explicitly and a request is required to add a new route.
When you the api endpoint your application must be able to handel the extra path, ie ``https://api.br.internal/role/stage/app/health`` your application must be able to route this to /health.


External
~~~~~~~~

- ``api.<stage>.eng.hmhco.com`` and  ``api.eng.hmhco.com``

For external requests the api endpoint will route both explicitly using path routing.
We also allow for single path to route to any application, such as ``https://api.br.internal/foo`` which can be be mapped to any application.
This must be done explicitly and a request is required to add a new route, path must be unique between applications but can be the same across stages.
To add a new external path open a `Github issue`_

.. _Github issue: https://github.com/hmhco/io.hmheng.platform/issues
.. _doc-server: https://doc-server.prod.hmheng-infra.br.internal
.. _aurora-task: https://aurora.br.hmheng.io/scheduler/hmheng-infra/prod/doc-server