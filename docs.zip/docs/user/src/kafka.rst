Kafka for teams in bedrock
==========================

Kafka is a distributed streaming platform with three key capabilities:

1) Publish and subscribe to streams of records, similar to a message queue or
   enterprise messaging system.
2) Store streams of records in a fault-tolerant durable way.
3) Process streams of records as they occur.

A basic explanation of kafka: https://sookocheff.com/post/kafka/kafka-in-a-nutshell/


Using Bedrock hosted kafka
--------------------------

As of writing this we are using kafka version 0.11.0 and it supports the new way of
connecting to the kafka cluster. The new way means that one can specify kafka
``bootstrap url``. The bootsrap url in bedrock points to a load balancer that
then balances the connection to some broker, in the reply message the client
(producer/consumer) gets list of broker ip's that are then used to connect to specific
brokers directly. Developer in general don't have to care about this beacuse the
producer / consumer in general takes care of it.

The old way of specifying the zookeeper connectstring with the kafka chroot also works, but
it's deprecated and will be removed in future versions of producer/consumer libraries.

Bedrock kafka bootsrap url: ``kafka.br.internal:9092``

Kafka is accesible from all mesos/aurora hosts.


Topic naming
~~~~~~~~~~~~

Topic naming schema should follow the following pattern: ``<team name>.<environment>.<topic name>``

for example: ``hmheng-infra.prod.awesome-bedrock-topic``

Some teams have opted in specifying the schema also in the topic name:
``<producer role>.<env>.<team discretionary>.[schema.[<schemaname>]]``

for example: ``hmheng-ds.prod.processed-caliper-events.schema.caliper``


Retention policy
~~~~~~~~~~~~~~~~

Default retention policy is 7 days, but a topic can be configured to have different types of
retention policies. So the team is responsible and allowed to change the retention policy for
their own topic(s).


Authentication and ACL's
~~~~~~~~~~~~~~~~~~~~~~~~

Kafka is not a multitenant system by default, and getting it to work proved to be way too much work
at this point. If authentication / ACL's become an issue please open a discussion about it in
``#kafka-eng`` -slack channel and we'll try to find a solution for it.


Team responsiblities
--------------------

Kafka is configured with topic autocreation enabled, which means that the topic doesn't have
to be explicitly created. Topic will be automatically created once publisher publishes the
first message to a topic that doesn't exist.

So team is responsible for creating their topic, but also configuring the topic replication
and partition count. Default replication and partition count is 1, but teams can increase the
values.

* Replication cannot be larger the number of brokers (as of writing this the broker count is 3). 
* The number of partitions depends on the application workloads.
* Topic deletion is currently disabled. Meaning that the topics cannot be deleted. If a topic
  needs to be deleted for some reason, it can be marked for deletion and request from bedrock
  team that the topic has to be gone.

.. note::
   Keep in mind that DECREASING partition count is really hard, but INCREASING partition count
   only takes a second. So start small and keep increasing the partition count until you find
   a good value for your use case.


Supporting services
-------------------

We have deployed few supporting services that make kafka usage easier.


Kafka-topics-ui
~~~~~~~~~~~~~~~

This is a simple topic viewer that can also display the contents of topics. It can be accessed
here: http://kafka-topics-ui.prod.hmheng-infra.brnp.internal/

(In pretty near future we'll start using the new form:
https://kafka-topics-ui.prod.hmheng-infra.br.internal/ )



Kafka schema registry
~~~~~~~~~~~~~~~~~~~~~

Schema registry as the name says is a registry for schemas. Schema registry stores a versioned
history of all schemas and allows the evolution of schemas.

Schema registry can be accessed from here: https://schema-registry.prod.hmheng-infra.br.internal/
(In pretty near future we'll start using the new form:
https://schema-registry.prod.hmheng-infra.br.internal/ )

Schema registry documentation: https://docs.confluent.io/current/schema-registry/docs/index.html


Kafka rest proxy
~~~~~~~~~~~~~~~~

Kafka rest proxy allows applications that only need kafka to do some really small kafka related
actions without actually configuring consumer and installing all libraries and so on. One use case
could for example be sending events from a frontend application that does not have a native
kafka library.

Kafka rest proxy url: http://kafka-rest.prod.hmheng-infra.brnp.internal/
(In pretty near future we'll start using the new form:
https://schema-rest.prod.hmheng-infra.br.internal/ )

Kafka rest proxy documentation: https://docs.confluent.io/current/kafka-rest/docs/intro.html


FAQ
---

Here's a collection of things that seem to cause confusion among developers who use bedrock
and are just starting to use kafka.


Consumer groups
~~~~~~~~~~~~~~~

A thing that seems to cause confusion among users is the group id. Specifying same group id
for N amount of consumers will form a consumer group. `Consumer group`_ will consume the messages
so that only some partitions are assigned to each consumer.

For example, if you have 12 partitions and 3 consumers that form a consumer group, each consumer
will be assigned total of 4 partitions to consume from. If one of the consumers fail a kafka
rebalance will happen and the partitions would be distributed among the two consumers that are
still alive.

Consumer groups are a good thing and developers should use them, especially if not all consumers
have to process all messages.

.. _Consumer group: https://www.confluent.io/blog/tutorial-getting-started-with-the-new-apache-kafka-0-9-consumer-client/


Topic deletion
~~~~~~~~~~~~~~

Topic deletion is disabled at least for now. However, one "delete" a topic by marking it for deletion
and it will be deleted eventually (basically when we go through the topics every now and then and
delete the ones not needed anymore).

The reason why topic deletion is disabled at the moment is that because of the nature of kafka, backing
it up is pretty much impossible. So we want to limit the number of accidental topic deletions to minimum.
