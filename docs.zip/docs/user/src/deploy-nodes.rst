.. _deploy-nodes:

Deploy nodes
============

We do not allow ssh access onto Bedrock application nodes but you can
still ssh onto the Aurora deploy nodes for a number of tasks:

- Aurora command line deploy tasks
- Updating / Viewing :ref:`shared-storage`.

You can login to Aurora Deploy nodes by using username of the role you
are using.

Accessing deploy nodes
----------------------

Use SSH to connect to the deploy nodes

    $ ssh your-role-username@deploy.br.hmheng.io -o StrictHostKeyChecking=no

For example::

    $ ssh hmheng-infra@deploy.br.hmheng.io -o StrictHostKeyChecking=no

Accessing deploy nodes from Jenkins
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

When a role is created the related key will be generated and put onto
the Jenkins instances. For example hmheng-idm has a jenkins key which
will allow for ssh agent to ssh into
``hmheng-idm@brnpb-deploy.br.hmheng.io``.

This same principle applies for manual access, a developer will only be
given ssh access to their teams user(s). This way no one is accidentally
breaking other teams jobs with bad commands.

Gaining access to deploy nodes
------------------------------

Generate public/private ssh key pair (if you don't already have one), if
you are using Linux or MAC, this can be done via command::

    $ ssh-keygen -t rsa

By default, this command will save private/public key pair into
directory called ``.ssh`` inside your home directory (example on MAC:
``/Users/your_username/.ssh/id_rsa``)

`Fork <https://github.com/hmhco/io.hmheng.platform#fork-destination-box>`__
the https://github.com/hmhco/io.hmheng.platform repo.

Update
`/saltstack/pillars/users/deployment/init.sls <https://github.com/daniel-burke-hmh/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls>`__
to add your public ssh key

E.g.

::

            dan_burke: ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQ<SNIP> 

- Your login username should be ``firstname_lastname``.
- Don't include the email address / username associated with the key at the end of the line
- Send a pull request to the BR team

After the pull request has been merged and processed, you will be able to log in to the
deploy nodes using SSH.
