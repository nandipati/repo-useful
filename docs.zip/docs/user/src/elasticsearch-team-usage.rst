.. _elasticsearch-team-usage:

Elasticsearch team usage
========================

Basics
~~~~~~

In Elasticsearch, an index is a collection of documents. Elasticsearch is a distributed search engine, an index is usually split into elements known as shards that are distributed across multiple nodes. Elasticsearch automatically manages the arrangement of these shards.
By default, Elasticsearch creates ten primary shards and one replica for each index. This means that each index will consist of ten primary shards, and each shard will have one copy.

Each search request will touch a copy of every shard in the index, which can cause performance decreases when the shards are competing for the same hardware resources.

Having twenty shards for index makes sense for Logstash index as they are very large, 200G some days. Therefore each shard will hold about 20G of data.

**This pattern does not make sense for small indices.**

For example: team A has an index, index X, which is very small lets say 2Mb. This single index will be split into ten 200Kb chucks. Now when team A wants to run a query on the last 30 days of index X. Elasticsearch will have to query 30 indices each of which have 10 shards meaning 300 queries are made for only 60Mb of data. This overhead kills performance of the cluster.

.. note:: Changing the shard count should be done before the index is created! In the event the index already exists it's better to update the next indices and allow the older larger shard count indices to roll out from the retention policy (90 days).

Todays state of the cluster
~~~~~~~~~~~~~~~~~~~~~~~~~~~

As of today (March 24 2017) in the Bedrock cluster there are 2547 indices with 47686 shards. 504 are under 1Mb in size, 2194 are under 1Gb. All these are considered very small in Elasticsearch terms.
The overhead to query all these very small indices have a huge cluster performance impact.

The vast majority of indices are daily indices. Meaning a new index and shards are created each day.

As well as query performance there are more negative impacts. When the cluster does have problems and looses a node is needs to initializing all the shards. All 47686 of them, this takes hours.

Suggested usage
~~~~~~~~~~~~~~~

Changing the shard count after index is created is not something we want to as requires a re-indexing.

Dev and Int: 1 primary shard with 1 replica shard per primary. This change alone would reduce the shard count by a ton.

Cert and Prod: max of 6 primary shards with 1 replica shard per primary (currently 12 elasticsearch data nodes, any additional primary shards will reduce performance)

To update shard count at index creation, a template must be created for each index prefix that will not use default shard values (1 primary, 1 replica).  See `elasticsearch docs <https://www.elastic.co/guide/en/elasticsearch/reference/2.3/indices-templates.html>`__.

We suggest no teams use daily indices, rather a weekly or monthly index.


Enforcement
~~~~~~~~~~~

Once we give teams a reasonable amount of time to modify their usage, and we have bandwidth these suggestions will start being enforced.

Meaning that:

    - Daily indices will be deleted unless you have provided evidence why these are required

    - Dev and Int indices which have more than 1 primary and 1 replica will be deleted

    - Small indices (<10GB) that have more than N shards will be deleted

    - Unknown indices will be deleted. See :ref:`unknown indices`

More reading
~~~~~~~~~~~~

- `Qbox blog on shards per index`_


.. _Qbox blog on shards per index: https://qbox.io/blog/optimizing-elasticsearch-how-many-shards-per-index
