New Team Request
================

A Bedrock role is required for all teams that require access to deploy to Bedrock.
To request this new team role, please open a git issue via https://github.com/hmhco/io.hmheng.platform/issues/new
with the following information included:

- Team name
  -  "location_abbreviation-component" pattern
     - location abbreviations: dub, bos, evn, mon
     - example: evn-bedrock
  - This will be used to create an aurora user to run job
  - When this is created we will also add the key to jenkins to allow
    jenkins to deploy jobs under that user

- Service detail (used for role approval)
  - Desription of type of applications or services will be deployed under this role
  - Detailed example of at least 1 service to be deployed under this role
    - What does the service do?
    - Does the service have external dependencies?  If so, what are the dependencies?

- Team information

  - List of emails who need access to DataDog (used for monitoring and
    metrics)
  - List of emails for developers who need access to OpenVPN, this is used to reach
    any part of bedrock (logging, metrics, aurora dash, mesos dash, non
    public endpoints, etc...)
  - List of developers who need access to deploy box. We will need their
    RSA 4096 length public key. This is used to ssh into deploy box to do
    things commands such as restarting and killing jobs. (Note You will
    only be given access for your project, for example IDM developers
    will only be able to restart jobs running with hmheng-idm user)
    - see https://www.ssh.com/ssh/keygen/ for information on generating ssh keypair

- Quota

  - provide estimated 'preferred' tier quota in `CPU RAM DISK` format for initial need
      - non-preferred, or `preemptible`, jobs (dev/int) do not consume resources
        from the set quota (see :ref:`quota`)
      - example `1 1GB 10GB` (1 cpu core, 1GB of RAM, 10GB of disk)
      - additional quota can be requested via git issue at later time as needed


Once submitted, the role request will enter approval stage.
Once approved, the role will be created within 2 business days.
A key for jenkins jobs to use will also be added to the https://jenkins.br.hmheng.io credentials key chain.
Creating the aurora role will auto automatically create a shared storage directory for your application to use, see :ref:`shared-storage` for details.

.. _io.hmheng.platform: https://github.com/hmhco/io.hmheng.platform
