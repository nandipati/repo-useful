How to contribute to Bedrock
============================

While there is a dedicated team to maintain and develop the Bedrock platform, we
very much welcome and encourage contributions from the Bedrock platform users. As
of Q1/2017 the central Bedrock repository has contributions from more than 50
Bedrock platform users.

There are many ways of contributing to the Bedrock platform, but this document
deals mainly with contributing code and configuration changes.

Contributing code and configuration changes
-------------------------------------------

Whether you want to use AWS resources in your project, or modify the platform
some other way, at some point you will end up making a `GitHub pull request`_.

Bedrock platform repositories use the basic `GitHub flow`_ [#f1]_; developers
submit pull requests, reviewers and developers work together to ensure that the
pull request is acceptable, and then the pull request is finally merged. After
the pull request has been merged, someone from the Bedrock team will implement
the changes across the infrastructure, and will also try to verify that the
changes actually work [#f2]_.

Often the review is the most time consuming portion of the process. Bedrock team
members work in multiple continents and time zones, and consequently each
review-fix cycle can take a day. Therefore, it makes sense to try to minimize
the time spent in review by making sure that your pull request meets the
minimum expectations.

.. [#f1] The model is more like `GitHub flow`_ with a hint of `GitFlow`_:
   We tend to use ``develop`` branch instead of ``master``.

.. [#f2] As the Bedrock team members know nothing about your applications
   the verification is very shallow, and you're expected to do your own more
   thorough testing.

.. _GitHub pull request: https://help.github.com/articles/about-pull-requests/
.. _GitHub flow: https://guides.github.com/introduction/flow/
.. _GitFlow: http://nvie.com/posts/a-successful-git-branching-model/

Making good pull requests
~~~~~~~~~~~~~~~~~~~~~~~~~

The key to good pull requests is to remember that pull requests are about
communication. You want to make the reviewer understand what you want to achieve,
and explain why it is needed.

When a reviewer begins a review, the first thing they seek is to find out what
is the reason for this pull request. Bedrock team members do not probably know
you, your team, or the applications you are developing, and therefore it is your
job to make her understand the context of your pull request, and then explain
the raison d'être of your pull request in that context.

After the reviewer is satisfied that there is good reason for the pull request
to exist, they will want to make sure that pull request does what it sets out
to do. To make this efficient, it is often helpful to briefly explain what
the pull request aims to accomplish.

The pull request should also make it easy to review the code itself. The most
important thing here is to only include the commits and changes that you
absolutely have to. For example, does your PR need to include merge from
``develop`` to your topic branch? No it doesn't; you can rebase_ you topic
branch against ``develop``. Does your PR need to include a commit that fixes a
previous commit in the same pull request? No it doesn't; you can squash_ the
commits before submitting the PR.

.. _rebase: https://git-scm.com/book/en/v2/Git-Branching-Rebasing
.. _squash: https://git-scm.com/book/en/v2/Git-Tools-Rewriting-History

Making good commits
~~~~~~~~~~~~~~~~~~~

Commits are also about communication, but the most important target of this
communication is not the reviewer, but the hapless developer who ends up reading
your commit message during a hectic debugging session years from now. It will be
easier if the commit is small, focused, and self-contained with a good commit
message.

Size and scope of the commit is a Goldilocks thing; the commit should not be too
small nor too big. It should embody a single logical change that leaves the codebase
in a good, working state. If you find yourself using the word "and" when
accurately describing what your commit does, it might be a good idea to split it
to smaller, more focused commits, and when you need to read multiple tiny
commits to fully undestand a change, you could consider squashing them to a
larger, more atomic commit.

Each commit should have a proper commit message. The message should have title
that describes succinctly what the commit does, followed by a more detailed
explanation of what the commit does and why it is needed. A commit message is
also good place to add links to secondary information sources such as bug
trackers and the like. To gain a better understanding what good commit messages
look like, take a moment to read through some of the `Linux kernel commit messages`_.

It sometimes useful to be able to reach out to the author of a commit, so
make sure that your commit metadata records your name and email address
properly. You can configure these with ``git config``::

  git config --global user.name "My Real Name"
  git config --global user.email "my.email@hmhco.com"

Git makes it really easy to modify, combine, and split commits after they have
been made. Reading a bit about amending commits, and interactive re basing,
and `rewriting history`_ in general makes life a lot easier.

.. _Linux kernel commit messages: https://github.com/torvalds/linux/commits/master
.. _rewriting history: https://git-scm.com/book/en/v2/Git-Tools-Rewriting-History

Pull request checklist
~~~~~~~~~~~~~~~~~~~~~~

Aim to create such pull requests that you can answer "yes" to every question
below.

- Pull requests

  - Is the title descriptive?
  - Does the pull request body contain enough context so that the pull request
    can be understood without being intimately familiar with you, your team, or
    or the applications you're developing?
  - Are all relevant sections of the pull request template filled appropriately?
  - Is the pull request made against ``develop`` branch?
  - Can the pull request be merged without conflicts? (If not,
    rebase your pull request on top of the latest ``develop``)
  - Does the pull request contain only the commits necessary to effect the
    change described in the pull request description?
  - Is the pull request clear of merge commits from ``develop``? (If not,
    rebase your pull request on top of the latest ``develop``)
  - Is the pull request clear of commits that fix issues in other commits this
    pull request? (If not, squash_ the commits together)

- Individual commits

  - Do all commits have a clear, descriptive title?
  - Do all commits have a commit message that describes the commit in enough
    detail and justifies its existence with the necessary vigor?
  - Do all commits record their author's name and email properly?
  - Do all commits record only one logical, self-contained change?
  - Do all commits leave the codebase in working state?
  - Do all commits follow the style and idioms of the content they are changing?

    - When making changes to ``io.hmheng.platform``, consider using the provided
      `precommit hook`_, which validates some style issues among other things.

.. _precommit hook: https://github.com/hmhco/io.hmheng.platform#scriptspre-commit

Further reading
~~~~~~~~~~~~~~~

See :ref:`bedrock-repositories` for a list of repositories, and :ref:`howto-use-aws-resources`
for guidelines on how to use AWS resources in Bedrock.
