New Service Deploy via Cloudformation
=====================================

.. warning::
   This page is now deprecated, for new service discovery model see: http://doc-server.prod.hmheng-infra.brnp.internal/src/linkerd.html#endpoints



As we work towards full AWS component management via Terraform, new service
deployments will continue to require CloudFormation template updates to add the
new ELB, security group, and route53 (DNS) configurations. A pull request needs
to be opened against the `io.hmheng.platform repo
<https://github.com/hmhco/io.hmheng.platform>`__ for all changes, and the
pre-populated PR template needs to be completed before submission. The
io.hmheng.platform repo should be forked to your github user account and the
pull request should be opened from that fork. Please do not create a separate
branch in the io.hmheng.platform repo and open the pull request against it.

.. _proxy-configuration:

Cloudformation - Proxy Template Update
--------------------------------------

Create a new proxy template file named by role
(``/aws/cloudformation/br\_proxy/proxy\_01.py``) and add new service config
for 1 or more stages (see example below) and register this in the
``/aws/cloudformation/br\_proxy.py`` as nestedStack.

``/aws/cloudformation/br\_proxy/proxy\_hmheng-demo01.py``::

    import sys
    sys.path.append('./br_proxy/')
    import base_elb


    # define elb service(s) - max 200 resources per template file (~12 elb config lines)

    ELB_SERVICES={
        'stub-application':
            {
                'dev': {'portProxy': 19010, 'portElb': 80, 'protocolInst': 'http', 'protocolElb': 'http', 'certid': 'default', 'scheme': 'internal', 'deployGroup': ['a','b'], 'health': '/health','appAccess': 'n', 'sgElbInCidr': [], 'sgElbInSg': [], 'snOption': '2', 'sgOption': '2'},
                'int': {'portProxy': 20010, 'portElb': 80, 'protocolInst': 'http', 'protocolElb': 'http', 'certid': 'default', 'scheme': 'internal', 'deployGroup': ['a','b'], 'health': '/health','appAccess': 'n', 'sgElbInCidr': [], 'sgElbInSg': [], 'snOption': '2', 'sgOption': '2'},
                'cert': {'portProxy': 21010, 'portElb': 443, 'protocolInst': 'http', 'protocolElb': 'https', 'certid': 'default', 'scheme': 'internal', 'deployGroup': ['a','b'], 'health': '/health','appAccess': 'n', 'sgElbInCidr': [], 'sgElbInSg': [], 'snOption': '2', 'sgOption': '2'},
                'prod': {'portProxy': 29010, 'portElb': 443, 'protocolInst': 'http', 'protocolElb': 'https', 'certid': 'default', 'scheme': 'internal', 'deployGroup': ['a','b'], 'health': '/health','appAccess': 'n', 'sgElbInCidr': [], 'sgElbInSg': [], 'snOption': '2', 'sgOption': '2', 'elbIdleTimeout': 120}
            },
    }

    # generate cloudformation template - function(elb services, stack description)
    proxy_elb_output = base_elb.proxy_elb_template(ELB_SERVICES,'demo proxy load balancers 01','hmheng-demo','all','all')


    # cfn pyplates generated template
    cft = proxy_elb_output['cft']

Example Service Configuration
-----------------------------

::

    'dev': {
       'portProxy': 19010, 
       'portElb': 80, 
       'protocolInst': 'http', 
       'protocolElb': 'http', 
       'certid': 'default', 
       'scheme': 'internal', 
       'deployGroup': ['a','b'], 
       'health': '/health',
       'appAccess': 'n', 
       'sgElbInCidr': [], 
       'sgElbInSg': [], 
       'snOption': '2', 
       'sgOption': '2'
    }

``/aws/cloudformation/br\_proxy.py``

::

    nestedStacks = ['infra01', 'infra02', ..., 'demo01']

-  ``portProxy`` - This should match what you add to
   ``/saltstack/pillars/finagle/proxy/init.sls``
-  ``portElb`` - The external port exposed on the ELB
-  ``protocolInst`` - The elb protocol. Valid values - http/https
-  ``certid`` - full arn of SSL cert. a cert to be used if https is needed,
   can be 'default' for non-prod, it application is 'internet-facing' a
   cert is REQUIRED cant use default!! To get a cert please open an
   issue in io.hmheng.platform repo, a bedrock team member will get one
   created via ACM (amazon certificate manager)
-  ``scheme`` - whether the elb should be externally available, only
   applicable for prod. Valid values: 'internal/internet-facing'
-  ``deployGroup`` - **Need docs on this**
-  ``health`` - URL elb will use for health check, expects this to return a
   200
-  ``appAccess`` - If your ELB should be made available to other
   ``applications``. Valid values: y/n
-  ``sgElbInCidr`` - . Valid values are defined in
   ``/aws/cloudformation/options.yaml`` **Need details on this**
-  ``sgElbInSg`` - . Valid values are defined in
   ``/aws/cloudformation/options.yaml`` **Need details on this**
-  ``elbIdleTimeout`` - Defaults to 60 seconds if not defined
-  ``snOption`` - should be a value of 2 **Need details on this**
-  ``sgOption`` - should be a value of 2 **Need details on this**

SaltStack - Finagle (proxy) Pillar Update
-----------------------------------------

Update tasks config (starts at line 56) in finagle proxy pillar with
proxy port configurations for new service (see example below)

``/saltstack/pillars/finagle/proxy/init.sls``::

              #010
              - task_id: hmheng-demo/prod/stub-application
                http_port: 29010
                max_request_size: 50
                max_response_size: 50
              - task_id: hmheng-demo/staging1/stub-application
                http_port: 21010
                max_request_size: 50
                max_response_size: 50
              - task_id: hmheng-demo/staging0/stub-application
                http_port: 20010
                max_request_size: 50
                max_response_size: 50
              - task_id: hmheng-demo/devel/stub-application
                http_port: 19010
                max_request_size: 50
                max_response_size: 50

-  ``http_port`` - first two digits identify the environment, by convention
   29:prod, 27:staging7, 22:staging2, 21:staging1, 20:staging0,
   19:devel. Remaining three digits should increment last added service.
-  ``max_request_size`` - values are in MB
-  ``max_response_size`` - values are in MB

Github - Complete Pull Request Template
---------------------------------------

Complete github pull request template and open pull request from your
fork of the io.hmheng.platform repo::

    ###Reason
    Beginning development on a new hmheng-demo service named "stub-application" that needs to be deployed to Bedrock

    ###Implementation
    Run updated proxy cloudformation template
    Run saltstack deployment via codedeploy
    Run envswitch cloudformation template to set user facing route53 endpoints

    ###Verification
    Confirm that endpoints for each defined stage exist and resolve
    Confirm that proxy ports for each defined stage are being listened on in stage associated proxy clusters
    Confirm that appropriate ssl certificates are associated with any https defined stages

    ###Changelog
    Add dev, int, cert, prod proxy/elb configurations for hmheng-demo stub-application service
