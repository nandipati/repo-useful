Team Jenkins
============

Team Jenkins allows individual software teams to customize the jenkins
configuration as they see fit. Teams can install whatever plugins they want,
configure the authentication and other schemes that work best for them.

This document provides instructions about how to get started and also
instructions on how to set backup, some good plugins and so on.

Installation
------------

1. Get `jenkins.aurora`_.
2. Go to deployment server: ``ssh <your-role>@brnpb-deploy.br.hmheng.io``
3. Copy `jenkins.aurora`_ to deployment server.
4. Run aurora deploy: ``aurora update start brnpb-us-east-1/<your_role>/devel/jenkins
   jenkins.aurora --bind tag=<jenkins_version>``
   - Find latest jenkins version from `Artifactory`_. (``2.90-1`` on 2018-01-03)
5. Access your jenkins: ``http://jenkins.devel.<your_role>.brnp.internal``
6. Deploy it to prod (same way as dev, but replace devel with prod).
7. Start using it! (initial username/password is admin/admin)

.. _jenkins.aurora: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/jenkins.aurora
.. _Artifactory: https://repo.br.hmheng.io/artifactory/webapp/#/artifacts/browse/tree/General/docker-prod-local2/jenkins

The idea of having to separate instances of jenkins running (dev and prod) is
the same as anywhere else: you can test possibly breaking changes in safer
environment (dev) and when you've verified that it works, deploy it to prod.

Basic usage
-----------

The basic usage doesn't really require anything else except that you start
creating jobs and start building them. When a build is started Jenkins will
automatically create a build slave that will be terminated if it has been idling
for more than 30 minutes.

Authentication
~~~~~~~~~~~~~~

It is highly recommended to setup at least some sort of authentication besides
the preconfigured ``admin/admin``. The easiest way to setup the authentication
is to use Jenkins' own user database.

Configure Jenkins authentication with Jenkins user database
***********************************************************

1. Go to ``Manage Jenkins`` -> ``Configure global security``
2. Select ``Jenkins' own user database``

.. image:: img/jenkins-auth1.png

3. Select the approriate authorization strategy that suits your needs.
4. Go back to ``Manage Jenkins`` and select ``Manage users``
5. From the left hand side select ``Create user`` and fill in the details.

This way the individual users actions are tracked and it makes the life a lot
easier for everyone else.

Configure Github authentication for Jenkins
*******************************************

If the team is big it might make sense to configure github authentication (or
some other authentication mechanism, where one doesn't have to manage users
by hand).

These steps can be skipped if you already have ``Client ID`` and
``Client Secret``.

.. note::
  You can not move these keys from one jenkins installation to another
  because OAUTH requires ``authorization callback url``, which is tied to the
  specific ``Client ID``.

1. Open an `Github issue`_.
2. State that you would like to use Github authentication for your team jenkins
   and tell us what is your authorization callback url (your application url).
3. Wait until you receive your ``Client ID`` and ``Client Secret``.

Once you have received the required tokens you can configure your Jenkins to use
Github authentication:

1. Go to ``Manage Jenkins`` -> ``Manage Plugins`` and select tab ``Available``.
2. Search for ``GitHub Authentication plugin`` and select it.
3. Scroll to the bottom of the page and select ``Download now and install after
   restart``.
4. Once installation is completed and Jenkins has been restarted go to
   ``Manage Jenkins`` -> ``Configure global security``.
5. Select ``Github Authentication Plugin`` and fill in the data as requested:

.. image:: img/jenkins-auth2.png

6. Select ``Authorization strategy`` that suits best to your needs. At first
it's usually a good idea to start with ``Logged-in users can do anything``.

.. _Github issue: https://github.com/hmhco/io.hmheng.platform/issues/new

Configuring Webhooks from Github to Jenkins
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Jenkins jobs can be triggered automatically from github push events and
pull requests using github webhooks. These webhooks can be configured
to be sent from Github to our proxy app called "gnotify", which will then
relay the http request to your team jenkins aurora service.

There are many options, multiple plugins, and thus multiple ways to do this.
Below are two specific examples of how to get these webhooks working.

.. note:: These examples assume your team jenkins is using Github
   Authentication (see above). If you want to use a local Jenkins database
   for users, then you'll need to make Jenkins API tokens and use those in
   the webhooks.

1. open an `Github issue`_. requesting of the bedrock team that we update
   the gnotify configuration to enable new endpoints for your jenkins.

   - Include the aurora role, stage, and app name of your jenkins service
   - Indicate if you want webhooks for push events and/or pull requests.

2. (Recommended) In the Github UI, create a robot user that will end up being
   the one that sends webhook requests to your Jenkins. This user will need
   to have at least read access to the desired repos, so this user should
   probably be on your Github team or be a collaborator.

3. For the Github user that will send webhooks, in the Github UI, create a
   Personal Access Token via the user's Settings > Developer Settings >
   Personal access tokens. This token will need to have at least "read:org"
   scope for pushes. If you want to use it for pull requests, then it will
   also need the "repo" section checked.

Webhooks for Github Push Events
*******************************

1. Go to your team jenkins UI, navigate to the jenkins pipeline that you want
   to trigger from this pull request, and click Configure.

   - For Pipeline Jenkins jobs:
       - check: GitHub project and set ``Project URL`` formatted like
         this: ``https://github.com/hmhco/io.hmheng.platform.git/``
       - check: GitHub hook trigger for GITScm polling
       - check: Poll SCM (but don't enter a schedule)
       - Under Pipeline, choose ``Pipeline Script from SCM``

         - SCM: Git
         - Repository URL: like this: ``git@github.com:hmhco/io.hmheng.platform.git``
         - Credentials: hmheng-ci
         - Branches to build: ``*/develop`` or ``*/master`` or your desired
           branch to build from
         - Script Path: the file path from top of repo to your pipeline script
         - Ensure NOT CHECKED: ``Lightweight checkout``

.. raw:: html
   <br>

2. Ensure that your job has built at least once. (There is some quirk in
   Jenkins where the job must have at least one run before the triggering
   works correctly.) So, kick it off manually if it hasn't been run yet.

.. raw:: html
   <br>

3. In the Github UI, navigate to the repo that will trigger requests, then
   go to Settings > Webooks and create a webhook with these params:

   - Payload URL: in our response to your ticket, we will provide you with
     the gnotify URL that the hook will need to make requests to. As an
     example, the Bedrock team jenkins push webhook url is:
     ``https://ROBO-BR-WEBHOOK-01:123123123123123@api.eng.hmhco.com/gnotify/hooks/jenkins-prod-hmheng-infra/github-webhook``
   - Content type: use ``application/json``
   - Secret: leave this blank
   - Which events would you like to trigger this webhook?: Select
     ``Just the push event``

Webhooks for Github Pull Requests
*********************************

This is similar to the Push Events section above, but there are some extra
things to do:

1. Install the Jenkins plugin called "GitHub Pull Request Builder"

.. raw:: html
   <br>

2. Go to Jenkins > Manage Jenkins > Configure System

   - Scroll down to the "GitHub Pull Request Builder" section
   - Create a set of Jenkins credentials using your robot username and Personal
     Access Token from the recommended step 2 of the first webhook section
     above.

     - You should test the repository access right there with the features
       labelled "Test Permissions to a Repository", "Test Permissions to a
       Repository", and "Test adding comment to Pull Request"; if these
       don't work, then there's not much point in going on yet.

.. raw:: html
   <br>

3. Configure a Pipeline job in Jenkins:

   - Project url: like ``https://github.com/hmhco/io.hmheng.platform``
   - Check: Build Triggers > GitHub Pull Request Builder

     - select the credentials you added in Configure System above
     - add all the desired Github users to the Admin List
     - Check: ``Use github hooks for build triggering``

   - Configure the Pipeline section like we did for the Push Events sectionu
     above

.. raw:: html
   <br>

4. In the Github UI, navigate to the repo that will trigger requests, then
   go to Settings > Webooks and create a webhook with these params:

   - Payload URL: in our response to your ticket, we will provide you with
     the gnotify URL that the hook will need to make requests to. As an
     example, the Bedrock team jenkins pull request webhook url is:
     ``https://ROBO-BR-WEBHOOK-01:123123123123@api.eng.hmhco.com/gnotify/hooks/jenkins-prod-hmheng-infra/ghprbhook``
   - Content type: use ``application/json``
   - Secret: leave this blank
   - Which events would you like to trigger this webhook? choose ``Let me
     select inividual events`` and check all things with "Pull Request" in
     the title


Webhook Troubleshooting
***********************

It can be tricky to get the combined configuration between Github and Jenkins
to be exactly correct. So, here are a few places to look for evidence
of things working or breaking:

- *Github UI:* See the ``Recent Deliveries`` section under the particular webhook.
  This will allow you to ensure that Github is sending hook requests and
  receiving healty responses from gnotify.

- *Jenkins Log:* see your stderr log in aurora or kibana for your team jenkins.
  There you should at least see if Jenkins is noticing the incoming webhooks
  as well as if there's any helpful error messages or stacktraces.

- *gnotify log:* in kibana for the ``logstash-*`` index pattern, you can search
  for ``gnotify`` to see its logs. This will allow you to see wether gnotify is
  receiving the requests from Github and whether the relaying to your team
  jenkins was successful


Backups
~~~~~~~

There huge amounts of plugins that can be used to backup your jenkins
configuration and this section introduces one of the simplest ones. The most
simple backup is just to copy the data from your EFS mount to safety.

ThinBackup
**********

ThinBackup is an extremely lightweight plugin that backs up your jenkins and job
configuration with the schedule you have specified. It also has a very simple
mechanism to restore the configuration.

1. Go to ``Manage Jenkins`` -> ``Manage Plugins`` and select tab ``Available``.
2. Search for ``ThinBackup`` and select it.
3. Scroll to the bottom of the page and select ``Download now and install after
   restart``.
4. Once installation is completed and Jenkins has been restarted go to
   ``Manage Jenkins`` -> ``ThinBackup`` -> ``Settings``.
5. Below is an example configuration used by hmheng-infra -team. The backups end
   up to EFS -mount which means they are very easily accesible.

.. image:: img/jenkins-backup1.png

6. After running the backup (if you used the path in the example) the backups
   are accesible from deployment servers in
   ``/mnt/efs/service/roles/<role>/jenkins/<environment>/backups``.

You can use the ThinBackup plugin to restore from backup, or you can manually
copy the backed up files on top of the old ones using deploy nodes and reloading
Jenkins configuration.

Advanced usage
--------------

This section tries to cover more advanced topics that you might need when you
start using more advanced features and so on. Also some debugging related
topics.

Accessing deploy consoles from Jenkins slaves
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Jenkins uses ssh keys to authenticate from build slaves to deploy consoles.
Some keys are preconfigured, but not all. So if you don't find a key that you
can use to deploy your applications from jenkins you have to create one.

1. Create ssh keypair and when prompted create a password for the private key.
2. Add the PUBLIC key to your `your role`_ and create pull request of it.
3. Go to your Jenkins main page -> ``Credentials`` -> select ``System`` -store

   - Under ``System`` you can create a new domain or add it to any of the
     existing ones.
   - Once you've selected the domain select ``Add Credentials`` and select the
     ``Kind`` to be ``SSH Username with private key`` and fill the fields
     accordingly.

.. _your role: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls

Accessing Jenkins slaves with SSH
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Because the Jenkins build slaves come and go, and they will go if they've been
idling for more than 30 minutes, doing long debug sessions might require
building a job on the slave every now and then.

.. note::
   These instructions assume that the slave is running and visible in Jenkins.

1. From Jenkins main page go to ``Credentials`` -> ``Jenkins-slave-key``
   -> ``Update``
2. Copy & paste the private key to a file on your local machine
3. Set the key permissions to 600 (``chmod 600 your.key``)
4. Get the IP address of the slave by clicking the slave from the front page
   -> ``Configure`` -> ``Private DNS``
5. Ssh into the slave ``ssh ec2-user@<private dns from previous step> -i
   your.key``
6. You should be logged in. ec2-user has sudo rights.

EC2 instance plugin configuration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

EC2-plugin comes preconfigured (and is reconfigured every boot if some things
need to be changed to follow HMH conventions etc.). But there are a lot of
things that one can change.

The configurations can be modified from ``Manage Jenkins`` -> ``Configure
System`` -> Scroll to the bottom of the page where it says ``Clouds``.

Allowed instance sizes
**********************

Only allowed instance sizes are ``t2.small``, ``t2.medium`` and ``t2.large``.
If you try to use other instance size you will get permission denied exception.

You can change the instance size to ``t2.large`` at max. Use your own
consideration in here. Large costs way more money than medium. But if you know
that your workloads are going to be low you can also use ``t2.small``.

Init script and userdata
************************

If you click the "Advanced" -button at the bottom of the page you should see
more configuration values. The two interesting in the beginning are init script
and userdata.

Init script is a script that is executed once when the slave connects to Jenkins
for the first time. The script is not executed on consecutive runs.

Userdata on the other hand provides a way to customize the instance during boot
even before the ssh daemon or anything is up. Cloud-init is more complicated,
but allows one to customize the instance much more.

IAM instance profile
********************

This is probably the most interesting part when customizing the slave. Basically
it allows Jenkins to pass instance profile during startup to the slave so that
the slave has access to services that it wouldn't otherwise have.

The instance profile looks like ``arn:aws:iam::000000000000:instance-profile/
SampleName``. The next section will cover the steps in creating the actual
instance profile that can be later on passed to the build slave.


Instance profile for build slaves
:::::::::::::::::::::::::::::::::

Creating an instance profile is a must if the instance needs to have access to
specific (AWS) services. The instance profile consists of:

* `Instance profile`_
* AssumeRole -policy
* IAM -policy/policies.

Examples for hmheng-infra teams instance profile can be found `here`_.

If you need your own policy

1. Fork the `io.hmheng.tf`_ -repository
2. Create the instance profile with terraform markup.
3. Create a Pull Request against the develop branch of `io.hmheng.tf`_
   repository.
4. Wait until it gets deployed and you get your instance profile ARN.
5. Configure the instance profile arn to your jenkins.

.. _Instance profile: http://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-ec2_instance-profiles.html
.. _here: https://github.com/hmhco/io.hmheng.tf/blob/develop/hmheng-infra/bedrock/infra-jenkins/infra-jenkins.tf
.. _io.hmheng.tf: https://github.com/hmhco/io.hmheng.tf
