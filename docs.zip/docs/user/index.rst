Bedrock documentation
=====================

Introduction for Bedrock
------------------------

.. toctree::
   :maxdepth: 2

   src/introduction-to-bedrock


Developing for Bedrock
----------------------

.. toctree::
   :maxdepth: 2

   src/howto
   src/platform-services
   src/best-practices
   src/further-reading

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
