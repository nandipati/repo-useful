import sphinx_rtd_theme

project = u'Bedrock'
copyright = u'2017, Houghton Mifflin Harcourt'
author = u'Bedrock Infrastructure Team'
version = '0.0.1'
release = '0.0.1'

extensions = ['sphinxcontrib.blockdiag']
blockdiag_fontpath = '/usr/local/lib/python3.4/dist-packages/sphinx_rtd_theme/static/fonts/Inconsolata.ttf'
blockdiag_html_image_format = 'SVG'

master_doc = 'index'

source_suffix = '.rst'
templates_path = ['_templates']
exclude_patterns = ['_build']
language = 'en'

todo_include_todos = True

needs_sphinx = '1.5.2'

html_theme = 'sphinx_rtd_theme'
html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]
html_static_path = ['_static']
