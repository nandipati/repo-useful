InfluxDB
========

`InfluxDB`_ is a time-series database built to handle high write and query loads. It is used as a backing store for any timestamped data, including infrastructure monitoring, application metrics,
IoT sensor data, and real-time analytics.

Deployment
----------

.. blockdiag::

   blockdiag {
     prometheus[label = "Prometheus"]
     customerapp[label = "Applications", stacked]

     influxdb[label = "InfluxDB"]
     telegrafagent[label = "Telegraf Agents", stacked]

     customerapp -> prometheus -> influxdb <- telegrafagent
   }

It is used as a destination for Prometheus scraper which is scraping metrics from all Production jobs into database “bedrock”.
InfluxDB is also being used by Telegraf clients as a destination for metrics collection such as CPU, memory, disk, disk io, processes, networking, docker, mesos, aurora, and those are stored into database “telegraf”.

Metrics originating from applications are stored into a databases named after the role owning that application (e.g. metrics from hmheng-idm application are stored into hmheng-idm database.)”

Authentication
~~~~~~~~~~~~~~

InfluxDB maintains its own user database. Admin operations are via the InfluxDB HTTP API runs on port 8086.
Currently, we haven’t enabled any authentication.

If user wants to read or write to and from database, the following details should be used:

* database name: ``$ROLE_NAME`` (e.g. "``hmheng_clm``", "``hmheng_idm``", "``bedrock``")
* username: ``$ROLE_NAME`` (e.g. "``hmheng_clm``", "``hmheng_idm``", "``bedrock``")
* password: ``bedrock``

Artifacts
~~~~~~~~~

We have installed InfluxDB from official `HMHENG repository`_.

InfluxDB is deployed into AWS via `InfluxDB Terraform`_

Configuration
~~~~~~~~~~~~~

Instance type for prod (brcore01) is i3.8xlarge which have one root EBS volume and two ephemeral drives.
InfluxDB is configured with those ephemeral drives as following:

* ``/dev/nvme0n1 [1.8T] on /mnt/db``        ->   data
* ``/dev/xvdc [2.0T] on /mnt/influx``       ->   Write Ahead Log, temporary cache for recently written points

.. note::

    Ephemeral drives are deleted if InfluxDB instance is stopped or terminated. But because this is an enterprise
    cluster, meta data is stored on the meta nodes and data is persisted on within the 2.0T EBS drive.

InfluxDB service configuration is done via `InfluxDB config file`_ placed in `InfluxDB Salt`_.

Ports
~~~~~

* ``8086`` InfluxDB API
* ``8089`` Ingress (UDP)
* ``9092`` Kapacitor API


Logs
~~~~

InfluxDB logs to ``/var/log/influxdb/influxd.log``

Backup
~~~~~~

`InfluxDB backup script`_ stores daily snapshots to S3 bucket `br-influxdb-backup`_

Playbook
--------

We will periodically check for version upgrade and perform it.

Data-node upgrade
~~~~~~~~~~~~~~~~~

After the terraform apply. Terminate one of the old data-nodes and instantiate a new one.

Add new data-node to cluster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: sh

        export METANODE="$(consul catalog nodes \
                -service=influxdb-meta \
                -node-meta="environment=brcore01" \
                -node-meta="region=us-east-1" \
                -near="_agent" | sed -n '2p' | awk '{ print $3 }'):8091"
        influxd-ctl -bind "$METANODE" add-data ip-10-35-19-212.ec2.internal:8088


Sync shards to new data-node
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: sh

        export OLD_DATA_NODE="ip-10-35-3-122.ec2.internal:8088"
        export NEW_DATA_NODE="ip-10-35-19-212.ec2.internal:8088"

        export METANODE="$(consul catalog nodes \
                -service=influxdb-meta \
                -node-meta="environment=brcore01" \
                -node-meta="region=us-east-1" \
                -near="_agent" | sed -n '2p' | awk '{ print $3 }'):8091"
        for shard in $(influxd-ctl -bind "$METANODE" show-shards | tail -n +4 | grep -v "${NEW_DATA_NODE}|\*" | awk '{ print $1 }'); do
                influxd-ctl -bind "$METANODE" copy-shard "$OLD_DATA_NODE" "$NEW_DATA_NODE" "$shard"
        done

Remove the old data-node
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: sh

        export METANODE="$(consul catalog nodes \
                -service=influxdb-meta \
                -node-meta="environment=brcore01" \
                -node-meta="region=us-east-1" \
                -near="_agent" | sed -n '2p' | awk '{ print $3 }'):8091"
        influxd-ctl -bind "$METANODE" remove-data -force ip-10-35-3-122.ec2.internal:8088


Meta node upgrade
~~~~~~~~~~~~~~~~~

This is a bit tricky. Old meta-nodes need to be detached from the ASG. After that the new ones can be brought up once the ASG has been marked tainted.

Remove meta-nodes from ASG
^^^^^^^^^^^^^^^^^^^^^^^^^^

The old meta-nodes need to be removed from the autoscaling group. Set the minimum desired capacity to 0 and detach instances.

Terraform apply
^^^^^^^^^^^^^^^

Taint the autoscaling group. And then run apply.

.. code-block:: sh

        terraform taint -module='brcoredev' 'aws_autoscaling_group.influxdb-meta'

Add new meta-node to cluster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

On the old meta-node add new data node to cluster

.. code-block:: sh

        influxd-ctl add-meta ip-10-35-2-171.ec2.internal:8089


Remove the old meta-node
^^^^^^^^^^^^^^^^^^^^^^^^

Once the new meta-nodes have been added. Remove the old meta-nodes on the new meta-node.

.. code-block:: sh

        influxd-ctl remove-meta ip-10-35-2-216.ec2.internal:8091

Terminate old instances
^^^^^^^^^^^^^^^^^^^^^^^

The old instances can now be terminated.

Retention Policy
----------------

Retention policy for all customer's databases is configured for 28 days (or 672h) by default. It is the consumers
responsibility to configure and setup downsampling continuous queries for their retention policies.


.. _InfluxDB config file: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/influxdb/files/etc/influxdb/influxdb.conf
.. _Production InfluxDB in brcore01: http://influxdb.brcore01.internal:8083/
.. _Development InfluxDB in brcoredev: http://influxdb.brcoredev.internal:8083/
.. _InfluxDB backup script: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/influxdb/files/usr/local/bin/influxdb_backup
.. _InfluxDB: https://docs.influxdata.com/influxdb/v1.2/
.. _InfluxDB repository: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/influxdb/init.sls#L5
.. _InfluxDB Salt: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/influxdb/init.sls
.. _InfluxDB Terraform: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/influxdb.tf
.. _br-influxdb-backup: https://console.aws.amazon.com/s3/buckets/br-influxdb-backup/?region=us-east-1&tab=overview
.. _HMHENG repository: http://repo.br.hmheng.io/artifactory/webapp/
