Restoring Aurora From Backup
============================

Manual Backup
-------------

-  su hmheng-infra
-  aurora\_admin scheduler\_backup\_now

   -  this will store a backup to
      /data/aurora/scheduler/backups/scheduler-backup-

Restoring From Backup
---------------------

Preparation:
~~~~~~~~~~~~

-  Stop all scheduler instances
-  Set -mesos\_master\_address to a non-existent zk address. This will
   prevent scheduler from registering with Mesos. i.e:
   -mesos\_master\_address=zk://localhost:2181
-  ensure -max\_registration\_delay - set to sufficiently long interval
   to prevent registration timeout and as a result scheduler suicide.
   i.e: -max\_registration\_delay=360min
-  Make sure -reconciliation\_initial\_delay option is set high enough
   (e.g.: 365days) to prevent accidental task GC. This is important as
   scheduler will attempt to reconcile the cluster state and will kill
   all tasks when restarted with an empty Mesos replicated log.
-  restart scheduler

Cleaning Corrupt Files and Re-Initialize Mesos Replicate 5log: (If Required)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-  Stop all scheduler instances
-  Delete all files under -native\_log\_file\_path on all schedulers
-  run mesos-log initialize --path=<-native\_log\_file\_path> on all
   masters
-  restart scheduler

Restore From Backup
~~~~~~~~~~~~~~~~~~~

-  su hmheng-infra
-  Identify the leading scheduler by: aurora\_admin get\_scheduler
-  Locate the desired backup file, copy it to the leading scheduler and
   stage recovery by running the following command on a leader
   aurora\_admin scheduler\_stage\_recovery scheduler-backup-
-  At this point, the recovery snapshot is staged and available for
   manual verification/modification via aurora\_admin
   scheduler\_print\_recovery\_tasks and
   scheduler\_delete\_recovery\_tasks commands. See aurora\_admin help
   for usage details.
-  Commit recovery. This instructs the scheduler to overwrite the
   existing Mesosreplicated log with the provided backup snapshot and
   initiate a mandatory failover aurora\_admin
   scheduler\_commit\_recovery

Undo Any Changes Made From the Preparation Phase
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-  mesos\_master\_address
-  max\_registration\_delay
-  reconciliation\_initial\_delay
-  restart scheduler
