Bedrock Bot Accounts
====================

+-------------------+------------+-------------------+----------------------------+
| bot account name  | bot        | maintainer email  | bot usage / description    |
|                   | maintainer |                   |                            |
+===================+============+===================+============================+
| ROBO-BR-READ-01   | ryan       | ryan.baumgartner@ | ci.hmheng.io /             |
|                   | baumgartne | hmhpub.com        | jenkins.br.hmheng.io       |
|                   | r          |                   | jenkins agent              |
|                   |            |                   | authentication & git repo  |
|                   |            |                   | scan (READ ONLY)           |
+-------------------+------------+-------------------+----------------------------+
