Packer
======

`Packer <https://www.packer.io/>`__ is a tool for making reproducible images.

Installation
------------

On macOS the easiest way is to use ``brew install packer``
Other methods can be found from: https://www.packer.io/downloads.html

Usage
-----

Building the AMI. In the packer folder execute::

    packer build -var aws_access_key='<access_key>' -var aws_secret_key='<secret_key> -var ami_version=<amazon_ami_version>-<br-version>' base.json

For example::

    packer build -var aws_access_key='<access_key>' -var aws_secret_key='<secret_key> -var ami_version=2016.03.3-1' base.json

How packer works
----------------

Packer will spin up an EBS -backed instance, create temporary keypair and security groups to access it, and run the provisioning.
