Infra related version control repositories
==========================================

.. list-table:: Infrastructure configuration
   :header-rows: 1

   * - Name
     - Description
   * - `io.hmheng.platform`_
     - SaltStack configuration, documentation, and some docker and package builds
   * - `io.hmheng.service-discovery`_
     - linkerd and namerd configuration
   * - `io.hmheng.brts.tf.core.base`_
     - Fast and often changing parts of brcore01/brcoredev terraform configuration
   * - `io.hmheng.brts.tf.core.infra`_
     - Slow and rarely changing parts of brcore01/brcoredev terraform configuration
   * - `io.hmheng.tf`_
     - Team Terraform configuration and our configuration for grafana, kanboard,
       datadog, jenkins, and IAM
   * - `io.hmheng.infra.aws.lambda`_
     - Lambdas for infrastructure automation
   * - `io.hmheng.brts.tf.influxdb`_
     - InfluxDB configuration (users, databases) for teams
   * - `io.hmheng.brts.tf.vault`_
     - Vault configuration (authentication, policies) for teams

.. _io.hmheng.platform: https://github.com/hmhco/io.hmheng.platform
.. _io.hmheng.brts.tf.core.base: https://github.com/hmhco/io.hmheng.brts.tf.core.base
.. _io.hmheng.brts.tf.core.infra: https://github.com/hmhco/io.hmheng.brts.tf.core.infra
.. _io.hmheng.service-discovery: https://github.com/hmhco/io.hmheng.service-discovery
.. _io.hmheng.tf: https://github.com/hmhco/io.hmheng.tf
.. _io.hmheng.brts.tf.influxdb: https://github.com/hmhco/io.hmheng.brts.tf.influxdb
.. _io.hmheng.infra.aws.lambda: https://github.com/hmhco/io.hmheng.infra.aws.lambda
.. _io.hmheng.brts.tf.vault: https://github.com/hmhco/io.hmheng.brts.tf.vault

Services hosted on Aurora
-------------------------

.. list-table:: Services hosted on Aurora
   :header-rows: 1

   * - Name
     - Description
   * - `io.hmheng.infra.config-service`_
     - Configuration service
   * - `io.hmheng.druid`_
     - Prototype `druid`_ deployment

.. _io.hmheng.infra.config-service: https://github.com/hmhco/io.hmheng.infra.config-service
.. _io.hmheng.druid: https://github.com/hmhco/io.hmheng.druid
.. _druid: http://druid.io/

Misc
----

.. list-table:: Misc repositories
   :header-rows: 1

   * - Name
     - Description
   * - `io.hmheng.linkerd-invigilator`_
     - linkderd authentication plugin
   * - `io.hmheng.lifecycle`_
     - A tool for efficiently lifecycling mesos/elasticsearch/... clusters
   * - `io.hmheng.buildscripts`_
     - A tool for common CI tasks (builder)
   * - `io.hmheng.infra.amazon-selinux-policy`_
     - A slightly patched SELinux base policy
   * - `io.hmheng.infra.docker-selinux-policy`_
     - A bespoke docker SELinux policy

.. _io.hmheng.linkerd-invigilator: https://github.com/hmhco/io.hmheng.linkerd-invigilator
.. _io.hmheng.lifecycle: https://github.com/hmhco/io.hmheng.lifecycle
.. _io.hmheng.buildscripts: https://github.com/hmhco/io.hmheng.buildscripts
.. _io.hmheng.infra.amazon-selinux-policy: https://github.com/hmhco/io.hmheng.infra.amazon-selinux-policy
.. _io.hmheng.infra.docker-selinux-policy: https://github.com/hmhco/io.hmheng.infra.docker-selinux-policy
