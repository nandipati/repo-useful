Deployed applications
=====================

hmheng-cds
----------

- arvo

  -  http://arvo.dev.br.hmheng.io
  -  http://arvo.int.br.hmheng.io
  -  https://arvo.cert.br.hmheng.io
  -  https://arvo.br.hmheng.io
   
- cds-metadatapipeline

  - http://cds-metadatapipeline.dev.br.hmheng.io
  - http://cds-metadatapipeline.int.br.hmheng.io
  - https://cds-metadatapipeline.cert.br.hmheng.io
  - https://cds-metadatapipeline.certrv.br.hmheng.io
  - https://cds-metadatapipeline.prodrv.br.hmheng.io
  - https://cds-metadatapipeline.br.hmheng.io

- cds-onesearch

  - http://cds-onesearch.dev.br.hmheng.io
  - http://cds-onesearch.int.br.hmheng.io
  - https://cds-onesearch.cert.br.hmheng.io
  - https://cds-onesearch.certrv.br.hmheng.io
  - https://cds-onesearch.prodrv.br.hmheng.io
  - https://cds-onesearch.br.hmheng.io

- cds-asa

  - http://cds-asa.dev.br.hmheng.io
  - http://cds-asa.int.br.hmheng.io
  - https://cds-asa.cert.br.hmheng.io
  - https://cds-asa.certrv.br.hmheng.io
  - https://cds-asa.prodrv.br.hmheng.io
  - https://cds-asa.br.hmheng.io

- hmhoneui

  - http://hmhoneui.dev.br.hmheng.io
  - http://hmhoneui.int.br.hmheng.io
  - https://hmhoneui.cert.br.hmheng.io
  - https://hmhoneui.br.hmheng.io

- performance-task

  - http://performance-task.dev.br.hmheng.io
  - http://performance-task.int.br.hmheng.io
  - https://performance-task.cert.br.hmheng.io
  - https://performance-task.br.hmheng.io

- grid

  - http://grid.dev.br.hmheng.io
  - http://grid.dev.br.hmheng.io
  - https://grid.cert.br.hmheng.io

- content-provider

  - http://content-provider.dev.br.hmheng.io
  - http://content-provider.int.br.hmheng.io
  - https://content-provider.cert.br.hmheng.io
  - https://content-provider.br.hmheng.io

- content-configuration

  - http://content-configuration.dev.br.hmheng.io
  - http://content-configuration.int.br.hmheng.io
  - https://content-configuration.cert.br.hmheng.io
  - https://content-configuration.br.hmheng.io

hmheng-clm
----------

- oac

  - http://oac.dev.br.hmheng.io/swagger-ui.html
  - http://oac.int.br.hmheng.io/swagger-ui.html
  - http://oac.cert.br.hmheng.io/swagger-ui.html
  - http://oac.br.hmheng.io/swagger-ui.html

- hmh-policy

  - http://hmh-policy.dev.br.hmheng.io
  - http://hmh-policy.int.br.hmheng.io
  - https://hmh-policy.cert.br.hmheng.io
  - https://hmh-policy.br.hmheng.io

- clm-entitlements

  - http://entitlements.dev.br.hmheng.io
  - http://entitlements.int.br.hmheng.io
  - https://entitlements.cert.br.hmheng.io
  - https://entitlements.br.hmheng.io

hmheng-cds
----------

- eventservice

  - http://eventservice.dev.br.hmheng.io
  - http://eventservice.int.br.hmheng.io
  - https://eventservice.cert.br.hmheng.io
  - https://eventservice.certrv.br.hmheng.io
  - https://eventservice.br.hmheng.io

hmheng-content-pipeline
-----------------------

- content-pipeline-agent

  - http://content-pipeline-agent.dev.br.hmheng.io

- content-pipeline-publish

  - http://content-pipeline-publish.dev.br.hmheng.io

hmheng-core-services
--------------------

- assignmentapi-async

  - http://assignmentapi-async.dev.br.hmheng.io
  - http://assignmentapi-async.int.br.hmheng.io
  - https://assignmentapi-async.cert.br.hmheng.io
  - https://assignmentapi-async.certrv.br.hmheng.io

- notification-service

  - http://notification-service.dev.br.hmheng.io
  - http://notification-service.int.br.hmheng.io
  - https://notification-service.cert.br.hmheng.io
  - https://notification-service.cert2.br.hmheng.io
  - https://notification-service.br.hmheng.io

hmheng-demo
-----------

-  http://stub-application.dev.br.hmheng.io

hmheng-idm
----------

- config-idm

  - https://config-idm.cert.br.hmheng.io
  - https://config-idm.br.hmheng.io

- hmh-identity-provider

  - http://hmh-identity-provider.dev.br.hmheng.io
  - http://hmh-identity-provider.int.br.hmheng.io
  - https://hmh-identity-provider.cert.br.hmheng.io
  - https://hmh-identity-provider.br.hmheng.io

- template-converters

  - http://idm-template-converters.dev.br.hmheng.io
  - http://idm-template-converters.int.br.hmheng.io
  - https://idm-template-converters.cert.br.hmheng.io
  - https://idm-template-converters.certrv.br.hmheng.io
  - https://idm-template-converters.cert2.br.hmheng.io
  - https://idm-template-converters.br.hmheng.io

- idm-ebr

  - http://idm-ebr.dev.br.hmheng.io
  - http://idm-ebr.int.br.hmheng.io
  - https://idm-ebr.cert.br.hmheng.io
  - https://idm-ebr.cert2.br.hmheng.io
  - https://idm-ebr.br.hmheng.io

- ids-grid-api

  - http://idm-ids-grid-api.dev.br.hmheng.io
  - http://idm-ids-grid-api.int.br.hmheng.io
  - https://idm-ids-grid-api.cert.br.hmheng.io

- idp

  - http://idm-idp.dev.br.hmheng.io
  - http://idm-idp.int.br.hmheng.io
  - https://idm-idp.cert.br.hmheng.io
  - https://idm-idp.certrv.br.hmheng.io
  - https://idm-idp.cert2.br.hmheng.io
  - https://idm-idp.br.hmheng.io

- basal-import-tc

  - http://idm-basal-import-tc.dev.br.hmheng.io
  - http://idm-basal-import-tc.int.br.hmheng.io
  - https://idm-basal-import-tc.cert.br.hmheng.io
  - https://idm-basal-import-tc.certrv.br.hmheng.io
  - https://idm-basal-import-tc.cert2.br.hmheng.io
  - https://idm-basal-import-tc.br.hmheng.io

- basal-import-hmof

  - http://idm-basal-import-hmof.dev.br.hmheng.io
  - http://idm-basal-import-hmof.int.br.hmheng.io
  - https://idm-basal-import-hmof.cert.br.hmheng.io
  - https://idm-basal-import-hmof.certrv.br.hmheng.io
  - https://idm-basal-import-hmof.cert2.br.hmheng.io
  - https://idm-basal-import-hmof.br.hmheng.io

- hmh-access

  - http://hmh-access.dev.br.hmheng.io
  - http://hmh-access.int.br.hmheng.io
  - https://hmh-access.cert.br.hmheng.io
  - https://hmh-access.certrv.br.hmheng.io
  - https://hmh-access.cert2.br.hmheng.io
  - https://hmh-access.br.hmheng.io

- import-workers

  - http://idm-import-workers.dev.br.hmheng.io
  - http://idm-import-workers.int.br.hmheng.io
  - https://idm-import-workers.cert.br.hmheng.io
  - https://idm-import-workers.certrv.br.hmheng.io
  - https://idm-import-workers.cert2.br.hmheng.io
  - https://idm-import-workers.br.hmheng.io

- api-adapters

  - http://idm-api-adapters.dev.br.hmheng.io
  - http://idm-api-adapters.int.br.hmheng.io
  - https://idm-api-adapters.cert.br.hmheng.io
  - https://idm-api-adapters.certrv.br.hmheng.io
  - https://idm-api-adapters.br.hmheng.io

- admin-tool

  - http://admin-tool.dev.br.hmheng.io
  - http://admin-tool.int.br.hmheng.io
  - https://admin-tool.cert.br.hmheng.io
  - https://admin-tool.certrv.br.hmheng.io
  - https://admin-tool.cert2.br.hmheng.io
  - https://admin-tool.br.hmheng.io

- homf-api

  - http://idm-hmof-api.dev.br.hmheng.io
  - http://idm-hmof-api.int.br.hmheng.io
  - https://idm-hmof-api.cert.br.hmheng.io
  - https://idm-hmof-api.certrv.br.hmheng.io
  - https://idm-hmof-api.br.hmheng.io

- ids

  - http://idm-ids.dev.br.hmheng.io/
  - http://idm-ids.int.br.hmheng.io/
  - https://idm-ids.cert.br.hmheng.io/
  - https://idm-ids.br.hmheng.io/

- user-api

  - http://idm-user-api.dev.br.hmheng.io/
  - http://idm-user-api.int.br.hmheng.io/

hmheng-support-ops
------------------

- knewton-update-tool

  - https://knewton-update-tool.cert.br.hmheng.io
  - https://knewton-update-tool.br.hmheng.io

hmheng-infra
------------

- kibana

  - https://kibana.br.hmheng.io

- grafana

  - https://grafana.br.hmheng.io

- zipkin

  - https://tracing.cert.br.hmheng.io
  - https://tracing.br.hmheng.io

hmheng-report
-------------

- reporting-config

  - https://report-config-server.cert.br.hmheng.io
  - https://report-config-server.cert.br.hmheng.io

- reporting-api

  - http://reporting-api.dev.br.hmheng.io
  - http://reporting-api.int.br.hmheng.io
  - https://reporting-api.cert.br.hmheng.io
  - https://reporting-api.br.hmheng.io

- reporting-aggregator

  - http://aggregator-processor.dev.br.hmheng.io
  - https://aggregator-processor.int.br.hmheng.io
  - https://aggregator-processor.cert.br.hmheng.io
  - https://aggregator-processor.br.hmheng.io

hmheng-score
------------

- scoring-api

  - http://scoring-api.dev.br.hmheng.io
  - http://scoring-api.int.br.hmheng.io
  - https://scoring-api.cert.br.hmheng.io
  - https://scoring-api.br.hmheng.io

Role unlisted
-------------

- flink-pipeline

  - http://flink-pipeline.dev.br.hmheng.io
  - http://flink-pipeline.int.br.hmheng.io
  - https://flink-pipeline.cert.br.hmheng.io
  - https://flink-pipeline.certrv.br.hmheng.io
  - https://flink-pipeline.br.hmheng.io
