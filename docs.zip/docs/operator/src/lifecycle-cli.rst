Lifecycler command line interface
=================================

Lifecycler CLI is a tool that can communicate with lifecycle service REST API.
The idea is to be able to easily schedule instances to be lifecycled but also
make it easy to to view logs for example.

At this point cli is the only implementation and there is no plans to add huge
amounts of features to it in the future, because the development in the future
should happen on the web ui, which in turn should have more of these features.

If you're more interested about the lifecycle service, it's documented
in :ref:`lifecycle-service`.

Deployment
----------

Lifecycle cli can be installed to any machine that has python installed to it.
By default the cli tool is installed to the same machine where the actual
lifecycle service is running.

Running lifecycle CLI locally
*****************************

This is probably the most common use case. Currently the only way to get the
lifecycle service is to download the pex or rpm from `jenkins`_.

After you've downloaded the pex one should be able to execute it (given that
python 2.7 is available on local machine).

.. _jenkins: http://jenkins.prod.hmheng-infra.brnp.internal/job/br-lifecycle-service-rpm/

CLI Usage
---------

Cli has a very basic interface :code:`./lifecycle <verb> [options]` and the help gives
following instructions:

    .. code::

     usage: lifecycle [-h] [-r HOST] [-u USERNAME] [-p PASSWORD]
                      {schedule,list,get,ack,delete,stop} ...
     
     HMH lifecycle service CLI
     
     positional arguments:
       {schedule,list,get,ack,delete,stop}
                             Available lifecycling components
         schedule            Schedule instances for lifecycling
         list                List lifecycler jobs, lists all if no filters are
                             given
         get                 Get information of individual instance(s)
         ack                 Acknowledge failed run.
         delete              Delete job from lifecycler service. Running jobs
                             cannot be deleted.
         stop                Cancel a running job
     
     optional arguments:
       -h, --help            show this help message and exit
       -r HOST               Lifecycler REST API URL (default:
                             http://127.0.0.1/jobs)
       -u USERNAME           Lifecycler API username (default: None)
       -p PASSWORD           Lifecycler API password (default: None)


for example scheduling an instance to be lifecycled on in brcore01 when running
the cli locally:
:code:`./lifecycle -r http://lifecycle.brcore01.internal/jobs -u username -p password schedule i-123456789`.
This will cause the instance in question to be scheduled for lifecycling. If there is no queue
the lifecycling process will start almost immediately.

And to view the progress of the lifecycling job:
:code:`./lifecycle -r http://lifecycle.brcore01.internal/jobs -u username -p password get i-123456789 -l`.

One needs to have vpn to brcore01 bastion host in order to run any lifecycling commands.


Recommended configurations
**************************

Because it's pretty inconvenient to write the username and password every time the cli
supports :code:`$HOME/.netrc` configuration and the following configuration is suggested:

    .. code::

     machine lifecycle.brcore01.internal
       login <username>
       password <password>
     machine lifecycle.brcoredev.internal
       login <username>
       password <password>

So after :code:`.netrc` has been configured properly one can emit the username and password from
cli options. The server is still required, because it's a matter of safety that one explicitly defines
are the instances lifecycled from prod or dev. If one logs in to the lifecycle machine with ssh also
the server can be omitted.
