.. _namerd:

Namerd
======

Namerd is a service for managing Linkerd name delegation (dtabs i.e. routing).

Request flow diagram
--------------------

.. blockdiag::

   blockdiag {
     span_width = 120;
     app[label="Application"]
     req1[label="Request"]
     req2[label="Request"]
     linkerd[label="Linkerd"]
     namerd[label="Namerd",stacked]
     zk[label="Zookeeper",stacked]
     dst[label="Destination"]
     group {
       orientation = portrait
       app -> req1 -> linkerd -> req2 -> dst;
     }
     linkerd <-> namerd [label = "server set in,\nAddress out", fontsize = 8];
     group {
       orientation = landscape
       namerd <-> zk [label = "Service Disco,\ndtab store", fontsize = 8];
     }
     default_group_color = "lightgray"
   }


Deployment
----------

Repo
~~~~
All namerd related code is stored in the `service discovery`_ repo.

Aurora deploy
~~~~~~~~~~~~~

Namerd is built from a `Dockerfile`_ and deployed to `aurora`_ .

There is a `jenkins job`_ to do this deployment.

One can also build the docker container manually by running ``docker build --build-arg NAMERD_VERSION= .`` For example ``docker build --build-arg NAMERD_VERSION=0.9.0 .``

.. note:: if no version is specified default is 0.9.0

Find the latest release `here`_ .

Downstream collaborator
-----------------------

:ref:`linkerd`
~~~~~~~~~~~~~~~

Linkerd uses Namerd to handle service discovery by storing dtabs and using namerd for service discovery.
Using Namerd means a small cluster of jobs need to talk directly to the service discovery backends (zookeeper) instead of every linkerd instance.
By storing dtabs in Namerd instead of hardcoding them in the Linkerd configs, it ensures that routing policy is in sync across the instances and gives you one central place when you need to make changes.

In the event that namerd is unavailable linkerd caches routes. This is only effective for previously existing services; a new deployment or change in serverset will make these caches obsolete.

Upstream collaborator
---------------------

:ref:`zk`
~~~~~~~~~~

Zookeeper has two uses in the model.

First, for use as service discovery to applications using the announcer ``znode`` to discover the actual IP and port of the aurora tasks.

Second, it is used as persistence storage for ``dtabs``. This allows for updates to ``dtabs`` to be done without having to push code or restart the Namerd service.


.. _service discovery: https://github.com/hmhco/io.hmheng.service-discovery
.. _Dockerfile: https://github.com/hmhco/io.hmheng.service-discovery/blob/develop/config/namerd/docker/Dockerfile
.. _aurora: https://aurora.br.hmheng.io/scheduler/hmheng-infra/prod/namerd
.. _jenkins job: http://http://jenkins.prod.hmheng-infra.brnp.internal/job/namerd-docker-image/
.. _here: https://github.com/linkerd/linkerd/releases