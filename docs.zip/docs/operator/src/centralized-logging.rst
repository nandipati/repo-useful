.. _centralized-logging:

Centralized Logging
===================

Application Logs
----------------

Mesos Sandboxes
~~~~~~~~~~~~~~~

-  Holds application level log files. They can be spread across many
   Mesos Agents or instances. There will also be many sandboxes for each
   Mesos Agent.

ElasticSearch (ES)
~~~~~~~~~~~~~~~~~~

Elastic Search is a search server. It provides a distributed, full-text
search engine with an HTTP web interface and schema-free JSON
documents.Currently implemented a 3 master 3 data node setup with one in
each availability zone.

-  Logstash agents running on all ES instances, will then read from the
   redis queue (FIFO) and move logs into ES cluster.

-  Currently the ES cluster is indexing 10 shards per index, with one
   replication shard for each primary shard.

Kibana
~~~~~~

https://kibana.br.hmheng.io/app/kibana \* open source data visualization
platform that allows you to interact with your data through powerful
graphics that can be combined into custom dashboards

Instance Logging
----------------

-  Logstash service will be running on all EC2 instances, this will
   collect system metrics such as /var/log/messages, syslogs, etc...
-  Elastic load balancers (ELB) logs will pulled from S3 buckets on salt
   master, then pushed to redis to be index by Elasticseach. The ELB
   logs are published at 5 minute intervals

Logstash
~~~~~~~~

The preferred grok pattern is::

    "%{TIMESTAMP\_ISO8601:timestamp}%{SPACE}%{LOGLEVEL:loglevel}%{SPACE}%{NUMBER:pid}%{SPACE}---%{SPACE}%{SYSLOG5424SD:threadname}%{SPACE}%{SPACE}%{JAVACLASS:logclass}%{SPACE}:%{SPACE}[%{GREEDYDATA:correlationId}]%{SPACE}%{GREEDYDATA:logmessage}"

Diagram
~~~~~~~

.. figure:: https://github.com/hmhco/io.hmheng.platform/blob/develop/docs/images/hmheng_io_logstash_rev_2.01.png
   :alt: 

