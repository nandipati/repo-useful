LDAP Access via Okta
=====================

Overview
--------

The Bedrock platform consists of many components that require some form
of authentication.  Prior to Okta, authentication for each componenent
was managed and maintained separately (ie. artifactory, openvpn, vault,
etc...).  Bedrock is now integrated with Okta, which allows PUBEDU users to
authenticate with their existing PUBEDU credentials through Bedrock components.
The benefits to this include forced password rotation,
centralized account status management (active/disabled), and ability to
contact HMH Service Desk for assistance with credentials (locked out,
lost password, etc...).

New "Bedrock Role" Security Group Request
------------------------------------------

Overview
~~~~~~~~

A "bedrock role" security group is a standard security group that is
used to provide its members access to Bedrock components, services, or
a suite of services. A "bedrock role" security group must be created
as part of the "New Bedrock Role" creation procedure.  All PUBEDU users
associated with this role should be added to this group.

The request for this security group is to be submitted via
TRAM by following the process defined in the "Process" section. Please
be sure to complete all required fields in the TRAM form.

Process
~~~~~~~

1. log in to https://trams.hmhco.com with your PUBEDU credentials
2. select "create new request"
3. enter "required by" date and click "next"
4. select "Privileged and Shared Accounts" and click "next"
5. select "Windows Account" then "New Windows Security Group"
6. add a value for the required security group fields:

-  Domain: ``PUBEDU``
-  Security Group Name:
   ``br_role_<bedrock-role>`` (ie. ``br_role_hmheng-demo``)
-  Servers / Systems names: ``NA`` (user/group membership only)
-  People to add to security group when created: ``user1,user2,user3``
   (must be comma delimited)
-  Application associated to security group:
   ``bedrock <bedrock-role> role`` (ie. ``bedrock hmheng-demo role``)
-  What is the specific business reason for requesting this account?

   -  This Bedrock role security group will contain
      members that need access to Bedrock components associated with
      the ``<bedrock-role>`` role (ie. artifactory, openvpn, vault, etc...).

-  Are there any sensitive tasks performed by this account such as
   database changes or user additions?

   -  ``No``

-  When should this account expire?

   -  leave blank

-  Notes

   -  ``Please display this security group as "br_role_<bedrock-role>"``
   -  ``Please add this new security group as a member of the existing "br_role_hmheng" security group``

7. Click "next" > "submit"

Post Submission
~~~~~~~~~~~~~~~

After submitting the form with the details from the "Process" section,
your manager will be contacted via email for approval. Once approved,
the Account Management team will create the requested "Bedrock Role"
security group and notify you once it is available for use. Please
contact account.requests@hmhco.com for any updates.



New "Bedrock ADMIN Role" Security Group Request
------------------------------------------

Overview
~~~~~~~~

A "Bedrock ADMIN Role" security group is a standard security group that is
used to provide its members ADMIN access to Bedrock components, services, or
a suite of services. A "Bedrock ADMIN Role" security group must be created
as part of the "New Bedrock Role" creation procedure.  Only ADMIN level PUBEDU
users associated with this role should be added to this group (ie. manager/lead).

The request for this security group is to be submitted via
TRAM by following the process defined in the "Process" section. Please
be sure to complete all required fields in the TRAM form.

Process
~~~~~~~

1. log in to https://trams.hmhco.com with your PUBEDU credentials
2. select "create new request"
3. enter "required by" date and click "next"
4. select "Privileged and Shared Accounts" and click "next"
5. select "Windows Account" then "New Windows Security Group"
6. add a value for the required security group fields:

-  Domain: ``PUBEDU``
-  Security Group Name:
   ``br_role_<bedrock-role>_admin`` (ie. ``br_role_hmheng-demo_admin``)
-  Servers / Systems names: ``NA`` (user/group membership only)
-  People to add to security group when created: ``user1,user2,user3``
   (must be comma delimited)
-  Application associated to security group:
   ``bedrock <bedrock-role> role`` (ie. ``bedrock hmheng-demo role``)
-  What is the specific business reason for requesting this account?

   -  This Bedrock role security group will contain
      members that need ADMIN level access to Bedrock components associated
      with the ``<bedrock-role>`` role (ie. artifactory, openvpn, vault,
      etc...).

-  Are there any sensitive tasks performed by this account such as
   database changes or user additions?

   -  ``No``

-  When should this account expire?

   -  leave blank

-  Notes

   -  ``Please display this security group as "br_role_<bedrock-role>"``

7. Click "next" > "submit"

Post Submission
~~~~~~~~~~~~~~~

After submitting the form with the details from the "Process" section,
your manager will be contacted via email for approval. Once approved,
the Account Management team will create the requested "Bedrock Role"
security group and notify you once it is available for use. Please
contact account.requests@hmhco.com for any updates.