Team Jenkins
============

.. note::
   These ara Team Jenkins operating documentation. For general instuctions see `user guide`_

.. _user guide: ../guide/team-jenkins.html

Team Jenkins is an approach to allow teams to run their own Jenkins instances on
mesos cluster. This allows teams to install whatever plugins they wish to and
also have full control on how the instance itself is configured.

Deployment
----------

.. blockdiag::

  blockdiag {
    orientation = portrait;
    mesos[label="mesos",stacked]
    aurora[label="aurora"]
    docker[label="docker container"]
    efs[label="efs folder"]
    user[label="user", shape=actor]
    aws[label="aws", shape=cloud]
    instance[label="build slave", shape=roundedbox]

    aurora -> mesos [label=schedules, fontsize="8"];
    user -> aurora [label=issues, fontsize="8"]
    mesos -> docker [label=starts];
    docker -> efs [label=mounts];
    jenkins -> efs [label=uses];
    user -> jenkins [label=accesses, fontsize="8"];
    jenkins -> aws [label=uses];
    aws -> instance [label=launches, style=dotted, folded];
    jenkins -> instance [label=uses];
  }



Artifacts
~~~~~~~~~

Jenkins image build is a little complicated due to docker limitations and its
placement in the folder structure. Currently the image has to be built in the
``io.hmheng.platform`` -repository root.

The docker image build itself can be executed with command::

  tar --create docker/jenkins/ saltstack/pillars/users/deployment/init.sls \
  --transform 's,.*/,,' | docker build -t docker.br.hmheng.io/jenkins:<version> \
  --build-arg JENKINS_VERSION=<JENKINS_VERSION> \
  --build-arg JENKINS_SHA=<JENKINS_SHA> -

The command itself creates a tar package of ``docker/jenkins`` and the required
``deployment/init.sls`` and sends it to docker daemon. The reason why it needs
to be done this way is due to docker limitations and we don't really want to
have multiple copies of the same file. Also symlinks are not supported with
docker.

The JENKINS_SHA is required for many reasons, but mainly because we want to be
sure that the downloaded JAR -package is the one we think it is. The SHA's can
be fetched from:
https://repo.jenkins-ci.org/public/org/jenkins-ci/main/jenkins-war

Configuration
~~~~~~~~~~~~~

Jenkins configuration is automated with groovy. One scripts basically configures
one portion of jenkins:

* `basic-security.groovy`_ Configures the basic
  security unless it has already been set. This means that if users have
  changed the security the script will not run again. If users have disabled
  the security it will enable it during the next boot.
* `ec2-plugin.groovy`_ configures the ec2-plugin
  that is used to launch build slaves.
* `init.groovy`_ configures the basic jenkins stuff
  and has to bee run on every boot. It sets the following things:

 * JNLP port (as assigned by thermos)
 * Number of executors on the master (the master cannot run any builds!)
 * Jenkins location, this is required for reverse proxy to work.

.. _basic-security.groovy: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/basic-security.groovy
.. _ec2-plugin.groovy: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/ec2-plugin.groovy
.. _init.groovy: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/init.groovy

Storage
~~~~~~~

Team Jenkins approach relies heavily on EFS -mounts to be available on mesos
agents, because the specific folder is mounted as a volume to the container.
The folder structure from the mount point onwards is
``service/roles/<role>/jenkins/<environment>`` for example
``service/roles/hmheng-infra/jenkins/prod``

Networking
~~~~~~~~~~

Jenkins needs a port for JNLP to be open, because the connection between the
slave and master is established so that first the jenkins master logs into the
slave with ssh, copies the the slave-agent -jar and launches. The slave-agent
uses JNLP to communicate with jenkins.

The  port is set with an environment variable during the launch and the port
is assigned by thermos.
From: `jenkins.aurora  <https://github.com/hmhco/io.hmheng.platform/blob/
develop/docker/jenkins/jenkins.aurora>`_::

  jenkins_process = Process(
    name="Run Jenkins",
    cmdline="""
            export JENKINS_OPTS=--httpPort={{thermos.ports[http]}} &&
            export JENKINS_SLAVE_AGENT_PORT={{thermos.ports[jnlp]}} &&
            export JENKINS_HOME=%s &&
            export JAVA_OPTIONS=-Xmx2048m &&
            export MESOS_ENVIRONMENT={{profile.environment}}
            .
            .
            .
            /bin/bash /usr/local/bin/jenkins.sh
            """ % (JENKINS_HOMEDIR, getpass.getuser())
    ).bind(profile=profile)

Playbook
--------

Since this is an application running on top of mesos the deployment itself
happens exactly the same way than any other application running on mesos. So
basically just schedule team-jenkins instance using aurora and jenkins aurora
-file located in `jenkins.aurora`_.

In deployment console one could deploy jenkins to dev environment with:
``aurora update start brnpb-us-east-1/hmheng-demo/devel/jenkins jenkins.aurora
--bind tag=2.90-1``
which would deploy jenkins version 2.90-1 to hmheng-demo accounts development
environment.

.. _jenkins.aurora: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/jenkins.aurora

Jenkins job to deploy Jenkins
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

There is a jenkins running for hmheng-infra account on mesos. That Jenkins has
a job that can build the jenkins image, push it to docker registry (artifactory)
and deploy it to hmheng-infra dev environment.
http://jenkins.prod.hmheng-infra.brnp.internal/job/jenkins-docker-image/

Jenkins service discovery
~~~~~~~~~~~~~~~~~~~~~~~~~

When writing this (2017-03-21) the deployed jenkins instances can
be discovered using linkerd with pattern:
jenkins.<environment>.<role>.brnp.internal for example:
http://jenkins.prod.hmheng-infra.brnp.internal

Updating jenkins
~~~~~~~~~~~~~~~~

Generate sha1sum:

.. code-block:: sh

        JENKINS_VERSION=2.60.2; curl -s -o- "https://repo.jenkins-ci.org/public/org/jenkins-ci/main/jenkins-war/${JENKINS_VERSION}/jenkins-war-${JENKINS_VERSION}.war" | sha1sum

With the version number and generated sha1sum update the `Dockerfile`_ and use `Jenkins job`_ to deploy generated image to artifactory.

.. _Dockerfile: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/jenkins/Dockerfile
.. _Jenkins Job: http://jenkins.prod.hmheng-infra.brnp.internal/job/jenkins-docker-image/
