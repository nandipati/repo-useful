LDAP and Auth0 Access
=====================

Overview
--------

Identity management often utilizes a central credential store such as
LDAP to manage access to developed applications/services and related
tools (ie. artifactory, openvpn, etc...). Bedrock hosts an Auth0 AD/LDAP
connector with access to the PUBEDU domain that allows PUBEDU users to
authenticate with their existing PUBEDU credentials through Auth0
configured connections. Each configured Auth0 connection contains a
rule, or set of rules, that limits user access based on PUBEDU security
group membership. The benefits to this include forced password rotation,
centralized account status management (active/disabled), and ability to
contact HMH Service Desk for assistance with credentials (locked out,
lost password, etc...).

New "Service Suite" Security Group Request
------------------------------------------

Overview
~~~~~~~~

A "service suite" security group is a standard security group that is
used to provide its members access to multiple services, or a suite of
services. The "service suite" security group should only be used for a
group/suite of similar services (ie. idm) that a developer would need
access to. The request for this security group is to be submitted via
TRAM by following the process defined in the "Process" section. Please
be sure to complete all required fields in the TRAM form.

Process
~~~~~~~

1. log in to https://trams.hmhco.com with your PUBEDU credentials
2. select "create new request"
3. enter "required by" date and click "next"
4. select "Privileged and Shared Accounts" and click "next"
5. select "Windows Account" then "New Windows Security Group"
6. add a value for the required security group fields:

-  Domain: ``PUBEDU``
-  Security Group Name: ``br_service-suite_<suite-name>`` (ie.
   br\_service-suite\_idm-dev)
-  Servers / Systems names: ``NA`` (user/group membership only)
-  People to add to security group when created: ``user1,user2,user3``
   (must be comma delimited)
-  Application associated to security group:
   ``br_service-suite_<suite-name>`` (ie.
   br\_hmheng-demo\_stub-application)
-  What is the specific business reason for requesting this account?

   -  The ``<suite-name>`` service suite security group will contain
      members that need Auth0 access to more than one service to perform
      daily development tasks. This prevents the developer from having
      to submit multiple TRAM access requests to be added to the
      security group associated with each individual service security
      group.

-  Are there any sensitive tasks performed by this account such as
   database changes or user additions?

   -  ``No``

-  When should this account expire?

   -  leave blank

-  Notes

   -  ``Please display this security group as "br_service-suite_<suite-name>"``

7. Click "next" > "submit"

Post Submission
~~~~~~~~~~~~~~~

After submitting the form with the detail from the "Process" section,
your manager will be contacted via email for approval. Once approved,
the Account Management team will create the requested "service suite"
security group and notify you once it is available for use. Please
contact account.requests@hmhco.com for any updates.

New Service Security Group Request
----------------------------------

Overview
~~~~~~~~

Any new service that will utilize a LDAP connection through Auth0 must
be associated with a PUBEDU security group prior to use. If a "service
suite" security group is to be added as a member of the requested
security group, add the "service suite" security group name to the comma
delimited list in the ``People to add to security group when created``
form field. The request for this security group is to be submitted via
TRAM by following the process defined in the "Process" section. Please
be sure to complete all required fields in the TRAM form.

Process
~~~~~~~

1. log in to https://trams.hmhco.com with your PUBEDU credentials
2. select "create new request"
3. enter "required by" date and click "next"
4. select "Privileged and Shared Accounts" and click "next"
5. select "Windows Account" then select "New Windows Security Group"
6. add a value for the required security group fields:

-  Domain: ``PUBEDU``
-  Security Group Name: ``br_service_<bedrock-role>_<service-name>``
   (ie. br\_hmheng-demo\_stub-application)
-  Servers / Systems names: ``NA`` (user/group membership only)
-  People to add to security group when created:
   ``user1,user2,user3,service_suite_security_group_name`` (must be
   comma delimited)
-  Application associated to security group:
   ``br_service_<bedrock-role>_<service-name>`` (ie.
   br\_hmheng-demo\_stub-application)
-  What is the specific business reason for requesting this account?

   -  The ``<service-name>`` requires the ability to utilize an Auth0
      AD/LDAP connection for PUBEDU account based authentication for
      developer access to the service. The creation of the requested
      security group will provide the necessary access to associated
      members.

-  Are there any sensitive tasks performed by this account such as
   database changes or user additions?

   -  ``No``

-  When should this account expire?

   -  leave blank

-  Notes

   -  ``Please display this security group as "br_service_<bedrock-role>_<service-name>"``

7. Click "next" > "submit"

Post Submission
~~~~~~~~~~~~~~~

After submitting the form with the detail from the "Process" section,
your manager will be contacted via email for approval. Once approved,
the Account Management team will create the requested security group and
notify you once it is available for use. Please contact
account.requests@hmhco.com for any updates.

New User Access Request
-----------------------

Overview
~~~~~~~~

If a user's PUBEDU account is not included in the origin service or
"service suite" security group request, a user must request to be added
as a member of the needed security group or groups. The request for this
user access is to be submitted via TRAM by following the process defined
in the "Process" section below.

Process
~~~~~~~

1. log in to https://trams.hmhco.com with your PUBEDU credentials
2. select "create new request"
3. enter "required by" date and click "next"
4. select "Standard Accounts" and click "next"
5. select "Windows Account"
6. add a value for the required fields:

-  Notes

   -  ``please add my PUBEDU account <PUBEDU_USERNAME> to the <service_security_group_1>, <service_security_group_2>, <service_suite_security_group_1> security group(s)``
      (security group list must be comma delimited)

7. Click "next" > "submit"

Post Submission
~~~~~~~~~~~~~~~

After submitting the form with the detail from the "Process" section,
your manager will be contacted via email for approval. Once approved,
the Account Management team will add the user as a member of the
requested security group(s) and notify you once it is available for use.
Please contact account.requests@hmhco.com for any updates.
