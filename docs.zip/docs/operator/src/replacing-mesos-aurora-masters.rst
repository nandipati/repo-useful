Replacing Mesos/Aurora Masters
==============================

Procedure
---------

When replacing Mesos/Aurora master nodes the standard procedure is to shut an old one down and then let a new one take its place.
With a quorum of 5 the failure tolerance is 2, as long as 3 masters remain active Mesos and Aurora will continue to function. We should aim to have 4 out of 5 masters active at all times during the replacement.

Begin by testing in the inactive VPC (brnpa/brnpb)

  1. Stop one old master by running ``service monit stop && service salt-minion stop`` and then ``stop mesos-master && stop aurora-scheduler``
  2. From the salt-master run ``find /var/cache/salt/master/minions/ -type f -name mine.p ! -newermt '-5 min' -exec bash '-c' 'rm -rf "$(dirname "{}")"' ';'`` this will ensure that the mine data is not out of date for old masters
  3. Verify the replication log has caught up by following the :ref:`log verification`
  4. Navigate to <IP>:5050 and ensure it redirects to current Mesos master
  5. Navigate to <IP>:8081 and ensure it redirects to current Aurora master
  6. In Mesos ensure Aurora scheduler called ``TwitterScheduler`` is registered
  7. Repeat step 1-6 for remaining Master until all are replaced

.. _log verification:

Log verification
----------------

When replacing masters one must ensure the replication log has caught up before adding more new masters. There is useful metrics to help with this.
For Mesos to ensure the replication log is caught up you can view ``<IP>:5050/metrics/snapshot`` in theses metrics there is a ``registrar log recovered`` gauge, when this metric equals ``1`` the replication log is up to date.
For Aurora there is a similar metric which can be found at ``<IP>:9191/metrics/snapshot`` which is also called ``registrar log recovered`` and should also equal ``1`` when the replication log is up to date.

