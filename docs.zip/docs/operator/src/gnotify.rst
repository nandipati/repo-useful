Gnotify
========

`Gnotify`_ is a little Bedrock-developed golang app that acts as a reverse
proxy to allow particular internal URLs to be hit from the outside. It
listens on a configured path and forwards the request to the configured
endpoints.

Gnotify's primary intent is for the relaying of webhooks from sources like
github and slack to internal URLs.


Adding Endpoints to Gnotify
---------------------------

Gnotify reloads its configuration live from consul's kv store whenever the
relevant key in the store is changed. So, to add external endpoints that
Gnotify will relay to internal ones, you just need to update the toml-based
conf stored in consul. Here are the steps:

 1. We're going to update consul, so set a couple of env vars in your shell:

   .. code::

      export CONSUL_HTTP_ADDR=https://consul.br.internal CONSUL_HTTP_SSL_VERIFY=false

 2. Pull the current conf for prod:

   .. code::

      consul kv get gnotify/prod/conf | base64 -D > before.toml; cp before.toml after.toml

 2. Edit the after.toml file and add the sections:

    Below is a typical example for adding gnotify paths to allow Github
    webhooks to trigger jobs in Jenkins. In this example, we're adding
    two paths, one for github push events and another for github pull
    request events:

   .. code::

      [[receivers]]
        # reading inventory - github push events - prod
        path = "/hooks/jenkins-prod-hmheng-reading-inventory/github-webhook"
        methods = ["POST"]
        [[receivers.forwarders]]
          endpoint = "http://jenkins.prod.hmheng-reading-inventory.brnp.internal/github-webhook/"
          method = "POST"

      [[receivers]]
        # reading inventory - github pull requests - prod
        path = "/hooks/jenkins-prod-hmheng-reading-inventory/ghprbhook"
        methods = ["POST"]
        [[receivers.forwarders]]
          endpoint = "http://jenkins.prod.hmheng-reading-inventory.brnp.internal/ghprbhook/"
          method = "POST"

 3. Upate the consul kv store with the new value (base64 encoded):

   .. code::

      cat after.toml | base64 | consul kv put gnotify/prod/conf -

 4. Test the new Gnotify paths to see that they are forwarding to the
    expected endpoints (here, we use the endpoints from the above example):

   .. code::

      curl -vvv -XPOST https://api.eng.hmhco.com/gnotify/hooks/jenkins-devel-hmheng-math-inventory/github-webhook
      curl -vvv -XPOST https://api.eng.hmhco.com/gnotify/hooks/jenkins-devel-hmheng-math-inventory/ghprbhook

   ...the response should be a 200 with output indicating that Gnotify
   relayed the notification.


