Graphing Salt Dependencies
==========================

Creating a dependency graph out of salt highstate is very simple, but it
requires a some packages.

Dependencies
------------

-  Graphviz
-  ``brew install graphviz``
-  salt\_state\_graph
-  ``pip install salt_state_graph``
-  pydot
-  ``pip install pydot``

NOTE!
~~~~~

It's usually a bad idea to install the python packages globally, so
instead of installing the globally on your machine, create a virtual
environment and install the packages there

::

    cd ~
    virtualenv temp_env
    . temp_env/bin/activate
    pip install salt_state_graph
    pip install pydot

If you want to exit or disable the virtualenv just type ``deactivate``

Getting the graph from a salt minion
------------------------------------

Salt can show it's current highstate graph with ``state.show_highstate``
so because you're probably going to run these commands on your own
machine using something like:

``ssh <host> sudo salt-call state.show_highstate --out json``

This will generate a state graph in json format, which the tool
salte\_state\_graph can convert into dot -format.

Creating a dot graph in pdf
---------------------------

So now you have the state graph in json format, let's convert it to dot
format and generate a pdf graph out of it:

``ssh <host> sudo salt-call state.show_highstate --out json | salt_state_graph | dot -Tpdf -o graph.pdf``

Now you can just open the file ``open graph.pdf``.
