Adding a Role for a New Team
============================

When a new team is added to Bedrock's infrastructure, there are a few things
todo to set them up:

Linux user, ssh keys, EFS mount
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 - See: repo: io.hmheng.platform, /saltstack/pillars/users/deployment/init.sls
 - Add a dictionary under user:roles for the team
    - increment the "id"
    - add the ssh_public_keys for each member that would like to be able to
      sudo to their team's unix user on the deploy console instance. NOTE:
      ensure that any trailing comments on the ssh key are removed (i.e.
      the line should end with the long encrypted string)
    - Generate random passwords for the aurora_security_pw and
      zookeeper_security_pw fields

You'll need to PR this, merge, and then run a highstate on the deploy-console
box to see the user, EFS mount, and ssh keys get succesfully created.

AWS ACM certificates
~~~~~~~~~~~~~~~~~~~~

When a new team is added the script to import certs from vault to AWS must be run. This must be run before creating new teams internal routes.

 - Navigate to io.hmheng.platform repo, add new role to salt pillar saltstack/pillars/users/deployment.sls
 - from the io.hmheng.platform/scripts directory run

dev:

.. code-block:: bash

   ./vault_to_acm.py routing -s devel -s staging0 -s staging1 -s staging2 -s staging3 -s staging4 -s staging7 -s prod -i acm_int_brdev_internal -d brdev.internal

prod:

.. code-block:: bash

   ./vault_to_acm.py routing -s devel -s staging0 -s staging1 -s staging2 -s staging3 -s staging4 -s staging7 -s prod -i acm_int_br_internal -d br.internal


DNS entry for internal routes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Note you MUST run the acm certificates script prior to creating the DNS records.

For the "fall-through" routing addresses of the team's aurora jobs to route
through sherpa, there needs to be a DNS record.

 - See repo io.hmheng.brts.tf.core.base, modules/sherpa/internal_route53.tf
 - Add a module call to ../route53-alias-lb just like all the other teams

You'll need to PR this, merge, and then apply this change through terraform.


Vault role for certs
~~~~~~~~~~~~~~~~~~~~

The team will need certificates for each stage of it's domain for the
above routes to work under TLS. So we need a vault backend that can
issue certs from team-level intermeiate cert (which is ultimately issued
from our bedrock root cert).

Our current method for generating these vault entities is to use a copy
of the the script below. So:

 - hop on a vault machine, :code:`sudo su -`
 - find the vault token - the secret of all secrets - ask Patrick :)
 - copy the bash script below to a file, say /tmp/add-new-team.sh
 - run the bash script w/ vault token set:

.. code-block:: bash
   export VAULT_ADDR=https://vault.br.internal VAULT_TOKEN=<TOKEN> VAULT_SKIP_VERIFY=1
   bash /tmp/add-new-team.sh <TEAM-NAME>


.. code-block:: bash

    TEAM_NAME=$1
    if [ -z "$TEAM_NAME" ]; then
        echo "expecting team-name to be bassed as argument"
        exit
    fi
    ROOT_PATH=ca
    for role in $TEAM_NAME; do
        export INTR_PATH="ca-${role}"
        export DOMAIN=br.internal
        export UNDER_DOM=${role}.${DOMAIN}
        vault unmount ${INTR_PATH}
        vault mount -path=${INTR_PATH} pki
        vault mount-tune -max-lease-ttl=8760h ${INTR_PATH}
        vault write ${INTR_PATH}/config/urls issuing_certificates=https://vault.br.internal/v1/${INTR_PATH}/ca crl_distribution_points=https://vault.br.internal/v1/${INTR_PATH}/crl
        /usr/local/bin/http --verify=no POST ${VAULT_ADDR}/v1/${INTR_PATH}/intermediate/generate/internal X-Vault-Token:$VAULT_TOKEN common_name=${UNDER_DOM} | jq -r .data.csr > ${UNDER_DOM}.csr
        /usr/local/bin/http --verify=no POST ${VAULT_ADDR}/v1/${ROOT_PATH}/root/sign-intermediate X-Vault-Token:$VAULT_TOKEN ttl="8760h" csr=@${UNDER_DOM}.csr |  jq -r .data.certificate > ${UNDER_DOM}.crt
        vault write ${INTR_PATH}/intermediate/set-signed certificate=@${UNDER_DOM}.crt
        for STAGE in devel 'test' prod staging{0..7}; do
            vault write ${INTR_PATH}/roles/${STAGE} allowed_domains="${STAGE}.${UNDER_DOM}" \
                allow_subdomains=true \
                server_flag=true \
                client_flag=true \
                allow_ip_sans=true \
                allow_glob_domains=true \
                ttl=336h \
                max_ttl=8760h
        done
        echo "Intermediate CA cert:"
        openssl x509 -in ${UNDER_DOM}.crt -noout -subject -issuer
    done


NOW, we need to update the vault policies for the routing.intl.* roles. They
are the same, but since we have salt roles for prod (.pr) and nonprod (.np),
we have two vault policies to update:

 - run :code:`vault read /sys/policy/routing.intl.pr > routing.intl.txt`
 - edit routing.intl.txt
    - remove the leading few lines and part of the line
      right up until :code:`path "sys/* {` - but keep that part. The file should
      start with line one being `path "sys/*" {`.
    - Note the path entries that start with 'ca-hmheng-'; you'll be making another
      one of those. Copy one of those and add it to the list. Here's an example
      of one:

      .. code-block:: bash

         path "ca-hmheng-ch/issue/*" {
           capabilities = ["create", "read", "update", "list"]
         }

  - save the file, then run :code:`vault policy-write routing.intl.np routing.intl.txt`
  - read again to ensure it saved: :code:`vault read /sys/policy/routing.intl.np`
  - now update the other policy :code:`vault policy-write routing.intl.pr routing.intl.txt`
  - read that one again too :code:`vault read /sys/policy/routing.intl.pr`


LASTLY, go run a highstate on one of the routing.intl.* boxes and
see that the keepsake salt states are able to pull certs for this new team
successfully.

Building a new Jenkins image
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Most new teams first goal is to deploy a Jenkins instance, when a new team is created a new Jenkins container must be built.
This is because there is a dependency on the linux user existing in the Jenkins image.

To build a new jenkins image just go to the `jenkins job`_ and follow the instructions there.


.. _jenkins job: http://jenkins.prod.hmheng-infra.brnp.internal/job/jenkins-docker-image/

Adding new jenkins key
~~~~~~~~~~~~~~~~~~~~~~

In order for jenkins to deploy job a key must be added. This can be done by generating a rsa key 4096 length with a 96 character passphrase.
``ssh-keygen -b 4096``
The public key should be added to the saltstack/pillars/users/deployment/init.sls pillar file in salt.
The private key and key phrase should be added to the Jenkins credentials settings.

.. note:: adding a new jenkins ssh key is not something bedrock team needs to do, users can and should PR their own keys.

Mesos quota for prod/cert jobs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The team will presumably want to launch some aurora jobs in prod and cert
stages; in order to do this, they will need to have some quota configured
for them.

This may not be immediately necessary, but in many cases the teams will
already have a sense of what they'll need for ram, cpu, and disk.

To add quota:

 - hop on a mesos master box, :code:`sudo su - hmheng-infra`
 - :code:`aurora_admin set_quota brnpb-us-east-1 <TEAM-NAME> <NUM-CORES> <RAM> <DISK>`

...specific example of that last command:
 - :code:`aurora_admin set_quota brnpb-us-east-1 hmheng-ch 1 4G 20G`

