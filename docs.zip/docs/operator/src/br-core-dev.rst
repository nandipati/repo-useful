brcoredev
=========
    
Br core dev is Bedrock Core Development environment. Bedrock core on the
other hand is a collection of "static" applications (zookeeper,
databases, elasticsearch, etc.) that are required by applications
running on top of bedrock platform.

The implementation behind the scenes is relatively simple: brcoredev is
just a VPC in Amazon data centers, where the contents of
``terraform-infra`` and ``terraform-base`` can be deployed with
terraform.

Jenkins job
-----------

There is a job in Jenkins meant to easily deploy your pull request. The
job can be found
`here <https://jenkins.br.hmheng.io/job/tf-brcoredev-apply/>`__.

In the job click build now and fill in which PR you want to apply. The
job does following things:

#. Destroy existing brcoredev (will ask for your confirmation)
#. Terraform apply DNS from develop branch
#. Wait until DNS is working
#. Terraform apply salt-master
#. Terraform apply rest from develop
#. Terraform plan & ask for confirmation
#. Terraform apply your pull request on top the existing develop

   - Note, this step will recreate the salt-master because the salt-master useradata will get changed.

For example, if you're testing some changes with salt you can just
continue pushing those changes to your PR, and they will get
automatically updated to the salt-master. You can also continue
developing the terraform parts with btf, so that you don't have to
recreate everything from scratch.

Known limitations and/or problems:

- In some cases the salt-minions cannot automatically reconnect to the newly
  created salt-master. This can be fixed by restarting the minion on the instances
  you're interested in.

BTF
---

btf is a wrapper tool meant to make usage of terraform a little bit more
straightforward. Terraform itself doesn't provide an easy way to manage
multiple environments so "btf" tries to make usage of it simpler. It
also downloads the required configuration files, sets up the remote
statefile location, sets the environment variables and so on.

BTF Usage
~~~~~~~~~

BTF Help:

::

    BTF Tool is a bedrock terraform wrapper that makes switching
    between terraform environments (terraform-infra, terraform-base etc.)
    easier.

    Usage: ../btf {shell, plan, apply..}

    Positional Arguments:
      {shell, push}

      shell          Start BTF shell.
      push           Push tfvars to S3 bucket.


    Optional Arguments:
      -c config_file Use specific configuration instead of the default
                     btf.conf.
      -e KEY=VAL     Specify additional key-value pairs for terraform.
      -f             Enable force mode and use your local tfvars.

    Examples:
    Start btf shell (ie. being in folder br-infra -folder)
      ../btf shell

    Run terraform plan inside BTF shell
      ../btf plan

    Run changes with your local tfvars
      ../btf -f plan

    Apply changes with specific configuration
      ../btf -c btf-prod.conf apply

The idea is to use the tool relatively in the part of the terraform
configuratin that you're working on. So if you're working on
``terraform-base`` change your current working directory to it and type
``../btf``.

By default the config file to be used is btf.conf, which contains the
configuration for BR Core Development environment!

Accessing brcoredev environment
-------------------------------

Because of licenses and many other things the brcoredev uses "vanilla"
openvpn instead of the enterprise version. So if you need to access the
brcoredev environment instances with ie. ssh you need to configure your
local openvpn client.

When ``../btf apply`` is executed for ``terraform-base`` and the
terraform run is succesful the output in the end will be something like
this:

::

    Outputs:

    iam_br_components = brcoredev
    internal_route53_zone = Z2WE9HS0OQDNPW
    openvpn-vanilla-id = i-38c6152e
    openvpn_vanilla_ip = 52.20.106.93
    saltmaster_ip = 10.100.2.107

In there the thing to notice is the ``openvpn_vanilla_ip``. This is the
ip of the bastion host of brcoredev. Don't take the one displayed in the
example, because it's quite probable that it is different!

The other stuff that are required for configuring the openvpn client
are:

::

    terraform-base/vpn
    ├── openvpn
    │   ├── ca.crt
    │   └─── client
    │       ├── client.conf
    │       ├── my-cert.crt
    │       └── my-cert.key

The client.conf is the configuration file for openvpn cli client.

Viscosity openvpn client for OSX
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is an configuration example for viscosity openvpn client, but there
are many many alternatives for it. Some better and some worse.

But this is the way to configure viscosity to connect to your brcoredev
bastion host and route the traffic through it so that you can access all
the instances with ie. ssh.

General: Remote Server: ``openvpn_vanilla_ip`` from the previous steps
Port: 1194 Protocol: UDP Device: tun

Authentication: Type: SSL/TLS Client CA: ``ca.crt`` from previous step
Cert: ``my-cert.crt`` from previous step Key: ``my-key.key`` from
previous step

These same instructions apply also for other clients.
