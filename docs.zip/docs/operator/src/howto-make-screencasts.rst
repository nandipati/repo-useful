How to record screen casts
==========================

Command line tool asciinema_  screen casts are quite simple to record.

.. _asciinema: https://asciinema.org/

.. raw:: html

   <asciinema-player src="../../_static/casts/how_to_make_screen_cast.json"></asciinema-player>
