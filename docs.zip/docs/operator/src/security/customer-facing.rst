Customer Facing Security Details
================================
The security information included in this document is
customer facing and is approved to be used in reply to customer
requests, RFIs, or questionnaires.


Overview of Hosted Service Platform and Infrastructure
------------------------------------------------------
The platform utilizes Apache Mesos to abstract CPU, memory,
and storage away from 1 to n AWS EC2 instances into a single pool of
resources.  Those resources are then consumed, or accepted, by jobs
created and maintained by the Apache Aurora scheduler.

An Apache Aurora job consists of an Aurorafile template that defines the
job's task(s), instance count, resources, and other parameters.  The Aurorafile
template is called by the Aurora update or job command used to start the job.

Once started, the job will bring up 1 to n job instances that run inside a
Docker container hosted by one of the n (>60) Mesos agent nodes.  Each of the Mesos
agent nodes is booted with the Amazon Linux operating system with Docker and Mesos agent
services.

Each job instance is wrapped in a Docker container so that the containers can coexist, with isolation,
on the Mesos agent nodes.  Docker allows multiple containers, from same or different job, to run on the same
compute instance without the ability to access resources or content provided by another Docker container on
the same instance.

.. image:: img/br_application_flow_v2.png

The image above displays the application data flow from Internet, through AWS Application Load Balancer (SSL), to proxy
cluster, and finally to application's Docker container hosted on Mesos agent.  The proxy nodes monitor health of the application
Docker containers and direct traffic accoridingly.  This allows one or more of the application job instances to be taken down
for maintenance or troubleshooting without impacting the user experience.

.. image:: img/br_environment_map_cus_v3.png

The image above displays the subnet layout of the prod/non-prod elb/proxy, Zookeeper master, Mesos master and Mesos agent nodes across 3 AWS availability zones
in the us-east-1 region.  The dotted line wrapping the ec2 instance or instances object represents the instances being in autocscaling
groups for easy scaling and automatic instance replacement on failure.

The Zookeeper master nodes maintain master election with quorum of 3 across the 5 nodes shown in the diagram above.  The Mesos master nodes
in the same diagram are directed to Zookeeper for master election, also with a quorum of 3.

The bastion host is the only entry point for ssh and other maintenance access to the platform.  All login attempts and activity
on the bastion host are logged and monitored.

System Level Security
---------------------

SSH
~~~

- access

  - non-deploy role compute (EC2) instances

    - restricted to current Engineering team members (<10 users)
    - require log in to bastion host prior to obtaining ssh access

  - deploy role compute (EC2) instances

    - restricted to development role team members

      - allows Apache Aurora job deploy access
      - allows shared storage access based on role team membership (ie. role A can only access role A based storage)

- keys

  - private key management

    - generated per user (>= 4096 bit)
    - no multiuser or shared keys
    - stored locally on users machine with restricted permissions

  - public key management

    - maintained on compute (EC2) instances via SaltStack orchestration (confirmed once a hour)
    - in process of implementing ldap integration (public key check against ldap prior to login)


Cryptography
~~~~~~~~~~~~

- TLS

  - allowed protocols

    - 1.2 (preferred)
    - 1.1 (currently allowed for browser compatibility)
    - 1.0 (currently allowed for browser compatibility)

  - allowed ciphers

    - ECDHE-ECDSA-AES128-GCM-SHA256
    - ECDHE-RSA-AES128-GCM-SHA256
    - ECDHE-ECDSA-AES128-SHA256
    - ECDHE-RSA-AES128-SHA256
    - ECDHE-ECDSA-AES128-SHA
    - ECDHE-RSA-AES128-SHA
    - ECDHE-ECDSA-AES256-GCM-SHA384
    - ECDHE-RSA-AES256-GCM-SHA384
    - ECDHE-ECDSA-AES256-SHA384
    - ECDHE-RSA-AES256-SHA384
    - ECDHE-RSA-AES256-SHA
    - ECDHE-ECDSA-AES256-SHA
    - AES128-GCM-SHA256
    - AES128-SHA256
    - AES128-SHA
    - AES256-GCM-SHA384
    - AES256-SHA256
    - AES256-SHA

- Encryption Key Management / Storage

  - S3 (AWS)
  - KMS (AWS)
  - Config (codex)
  - Vault (hashicorp)

Patching
~~~~~~~~
Platform operating system level patching occurs at image level with replacement.  No platform compute instances are patched directly.

- Timeline by Type

  - Critical:  24 hours
  - Important: next AMI build (<30 days)
  - Medium:    next AMI build (<30 days)
  - Low:       next AMI build (<30 days)

- Process

  #. Receive alert or notification of vulnerability
  #. Build new Image/AMI with latest patches applied
  #. Test new Image/AMI against all platform roles & confirm functionality
  #. Replace all existing instances with new Image/AMI

Availablity
-----------
Disaster Recovery
~~~~~~~~~~~~~~~~~
All platform resources are defined and built via Hashicorp Terraform Enterprise.  The Terraform templates are tested frequently,
including daily development environment builds and destroys, to confirm functionality.  In the event of a disaster
(ie. full AWS VPC or region loss) the Terraform templates will be used to recreate vpc in another AWS region in less than
1 hour.

We are currently in the process of deploying the platform cross AWS region and cross provider (ie. AWS & Google Cloud).

High Availability
~~~~~~~~~~~~~~~~~
At least 5 instances(s) exist for all platform role types, allowing a quorum of 3 to be maintained.  This will allow 1 of 3 AWS
availablity zones to fail without impacting application availablility or performance.  In the case of AWS availability zone failure,
or similar, the Aurora Scheduler will notice the failing instances and automatically begin to bring up job instances on compute instances
hosted in the healthy availability zones.

Reliability
~~~~~~~~~~~
Key Service Level Agreements and Metrics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Logging, Monitoring & Alerting
------------------------------

Logging
~~~~~~~
- logs for platform compute resources (EC2) are monitored and shipped via Logstash to Elasticsearch
- stderr/stdout logs for all Apache Aurora scheduled jobs are monitored and shipped via Logstash to Elasticsearch
- original log files are shipped to s3 and retained for at least 3 years
- log entries shipped to elasticsearch are retained in elasticsearch for 90 days for quick query via Elasticsearch or Kibana
- system level events logged

  - network
  - system
  - health
  - startup
  - shutdown
  - logon success/failure

Monitoring
~~~~~~~~~~
- Datadog

  - utilizes agent on compute (EC2) instances
  - utilizes AWS role access for other AWS resources (RDS, Cache, SQS, SNS, etc...)
  - warning & critical level monitors defined for all resources

- Telegraph

  - installed/running on all compute (EC2) instances
  - ships metrics to influxdb cluster

Alerting
~~~~~~~~
Datadog, Kapacitor, and Service level triggers utilize Pagerduty for alerting.  Critical level alerts notify on call technician(s)
based on defined rotation.  Unacknowledged incidents are automatically escalated to next level.

Shared Storage Permissions
--------------------------
Some platform hosted applications utilize NFS mounted volumes for short term persistent storage.  A parent folder
for each platform team role is provided and the related development team manages the child folders and related permissions.

*Please consult with related dev team for security details about shared storage for specific application/service*
