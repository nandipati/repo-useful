Backups
=======

Generic EC2 volume backups
--------------------------

`ebs-snapshot`_ lambda takes EBS snapshot once a day. The lambda only snapshots
volumes of instances with an appropriate ``environment`` tag, and
``lambda_task`` tag set to ``backup``. Currently `ebs-snapshot is configured`_
to run in ``brcore01`` and ``brnpb``.

`ebsexpire`_ runs once a day as well, and removes expired snapshots. Currently
the lambda is `configured`_ to keep 30 daily snapshots for each instance.

.. _ebs-snapshot: https://github.com/hmhco/io.hmheng.infra.aws.lambda/blob/develop/src/ebs-snapshot/ebssnapshot.py
.. _ebs-snapshot is configured: https://github.com/hmhco/io.hmheng.infra.aws.lambda/blob/develop/terraform/ebs-snapshot.tf
.. _ebsexpire: https://github.com/hmhco/io.hmheng.infra.aws.lambda/blob/develop/src/ebs-snapshot/ebsexpire.py
.. _configured: https://github.com/hmhco/io.hmheng.infra.aws.lambda/blob/develop/terraform/ebs-snapshot.tf

Service specific backups
------------------------

Service backups are discussed in within the service specific chapters.
