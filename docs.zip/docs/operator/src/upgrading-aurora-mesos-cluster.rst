Upgrading Aurora Mesos cluster
==============================

.. _pre-reqs:

Prerequisites
-------------
0. Read change logs
~~~~~~~~~~~~~~~~~~~
    - `Mesos change log`_
    - `Aurora change log`_

Identify any breaking changes, deprecations, or useful changes.

1. Build RPM for Mesos, Aurora, and Aurora-pex
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    - `Aurora Jenkins RPM build`_
    - `Mesos Jenkins RPM build`_
    - `Aurora Pex RPM build`_

Upon completion of these build all necessary RPM should have built and push to `Artifactory`_ . They will automatically be available on all instances running in bedrock VPC.
To confirm the existence of these packages you can run ``yum list available mesos*`` or ``yum list available aurora*``

2. Setup salt state for new deployment group
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Verify all Mesos master and agents are using the same ``deployment-group`` tag.
- You will now need to update several different files in the `io.hmheng.platform`_ repo, those are including but not limited to:

    1. `pillar/aurora`_
        - scheduler:version
        - thermos_executor_resources
        - thermos_executor:version
        - thermos_observer:version
        - thermos_observer:pex_version
        - tools:version
    2. `pillar/mesos`_
        - mesos:deployments:<deployment-group>:version
    3. `states/aurora/template/usr/bin/thermos-executor-wrapper`_
        - pex file
    4. `states/aurora/template/usr/lib/aurora/bin/aurora-scheduler`_
        - classpath

For example of previous done upgrades see `here`_ .

Now you should have salt code which can handle both versions of mesos and aurora, depending on ``deployment-group`` tag.

Testing
-------

1. Ensure all ``deployment-group`` tags are set to original value, this value is not as important as the new ``deployment-group``. The new tag must be unique meaning not in use by instances currently.

2. SSH into all mesos-master nodes, as well as one or two mesos-agents

    - on master nodes note the PID of ``mesos-master``, ``aurora-scheduler``, by running ``status mesos-master && status aurora-schedule``

        - getting these PIDs can also be done from the salt master by running ``salt -G 'ec2:tags:salt-role:mesos.master*' cmd.run 'status mesos-master && status aurora-schedule'``
    - on agent nodes note the PID of ``mesos-slave`` by running ``status mesos-slave``
    - save these PIDs for later

3. Deploy changes created in step 2 of prerequisites

    - run a highstate on masters and agents
    - ensure the PIDs did not change for any ``mesos-master``, ``aurora-scheduler``, or ``mesos-slave processes``

4. Identify the current leading Mesos master by checking the `UI`_. The server on the left tells the leading master

5. Upgrade masters, the order does not matter, but the leader Mesos master from step 4 should be done last

    1. change the tag for deployment-group on the first to be upgraded
    2. run ``salt-call state.highstate``
    3. run ``restart mesos-master``
    4. run ``status mesos-master && status aurora-schedule``
    5. wait a few moments
    6. rerun ``status mesos-master && status aurora-schedule``
    7. ensure PID's are not flapping (i.e. the PIDs stay the same)

6. Rerun step 5 for other 3 non-leading nodes

7. Check again on 4 upgraded nodes no PID's have changed since highstate

8. Repeat step 5 for last node, the elected master

.. _UI: https://brnpa-mesos.br.hmheng.io/#/

Verification
------------

You may need to wait a few minutes after completing step 8 of testing before moving on to validation. During this time a new master is getting elected.

1. `mesos-master`_ UI is active and reachable

    - all tasks are still active
    - all frameworks are active

2. `aurora-scheduler`_ UI is active and reachable

    - all tasks are still active

3. again check no PIDs are flapping

4. if all above look good move on to agents

Mesos Agents
------------

Create new agent deployment with new deployment group, in terraform that is done by creating a new definition of `mesos agent module`_ , in cloudformation it is done by adding a new entry `agentClasses`_

1. deploy new agents

2. ensure agents join master

3. check to ensure agents pid not flapping

If all new agents join without issue we can move onto removing old agents.

1. drain agents 1 availability zone at a time

2. ensure all jobs start no pending tasks

3. remove old autoscaling groups

New flag discovery
------------------

Discover new aurora flags
~~~~~~~~~~~~~~~~~~~~~~~~~

1. run ``/usr/lib/aurora/bin/aurora-scheduler``

2. update `pillar`_ with new flag(s)

    - even if flag is not in use should be added here with value of ``none``

3. if any flags were removed they should be removed from salt

    - if removed flags have value of ``none`` they can easily be removed, otherwise you must be more careful and should to retest fresh deployment to ensure no unexpected restarts

Discover new Mesos flags
~~~~~~~~~~~~~~~~~~~~~~~~

1. run ``mesos-master —help``

2. update the `mesos pillar`_ with new flags

    - any new flags can be added to ``parameters_inactive``

3. if any flags were removed they should be removed from salt

    - if removed flags are part of ``parameters_inactive`` they can easily be removed, otherwise you must be more careful and should to retest fresh deployment to ensure no unexpected restarts

Deployment
----------

If all testing looks good you can move on to deployment to active cluster.
Rerun the Testing, Verification, and Mesos Agent steps for active cluster.


.. warning:: Test, test, and test some more. Mesos and Aurora are the heart of the bedrock platform any changes should be well tested before deployments as any unforeseen problems could cause major outages

Clean up
~~~~~~~~

Clean up any if statements created in :ref:`pre-reqs`.


Common/Known issues
-------------------

Upgrading multiple version of Aurora
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

If upgrading through more then one aurora version the restore of snapshot may try to use incompatible version.
Issue is `tracked here`_ . Workaround is if needing to upgrade multiple times is either by manually starting snapshot or setting dlog_snapshot_interval to a low time frame.

Aurora UI blank or showing incorrect info
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Clear browser cache.

Mesos UI showing "No master elected" when there is
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ensure the browser is up to date, try with other browsers.

.. _tracked here: https://issues.apache.org/jira/browse/AURORA-1812
.. _io.hmheng.platform: https://github.com/hmhco/io.hmheng.platform
.. _pillar/aurora: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/aurora/init.sls
.. _pillar/mesos: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/mesos/init.sls
.. _states/aurora/template/usr/bin/thermos-executor-wrapper: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/aurora/template/usr/bin/thermos-executor-wrapper
.. _states/aurora/template/usr/lib/aurora/bin/aurora-scheduler: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/aurora/template/usr/lib/aurora/bin/aurora-scheduler
.. _here: https://github.com/hmhco/io.hmheng.platform/pull/1274
.. _pillar: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/aurora/init.sls
.. _mesos pillar: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/mesos/init.sls
.. _mesos agent module: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-cluster/mesos-agent-base.tf
.. _agentClasses: https://github.com/hmhco/io.hmheng.platform/blob/develop/aws/cloudformation/br_mesosagent.py
.. _Aurora Jenkins RPM build: http://jenkins.prod.hmheng-infra.brnp.internal/job/aurora-rpm/
.. _Mesos Jenkins RPM build: http://jenkins.prod.hmheng-infra.brnp.internal/job/mesos-rpm/
.. _Aurora Pex RPM build: http://jenkins.prod.hmheng-infra.brnp.internal/job/aurora-pex-rpm/
.. _Artifactory: https://repo.br.hmheng.io
.. _Aurora change log: https://github.com/apache/aurora/blob/master/CHANGELOG
.. _Mesos change log: https://github.com/apache/mesos/blob/master/CHANGELOG
.. _mesos-master: https://brnpa-mesos.br.hmheng.io/#/
.. _aurora-scheduler: https://brnpa-aurora.br.hmheng.io/