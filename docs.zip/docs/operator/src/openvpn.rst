OpenVPN
=======

OpenVPN is used to access Bedrock development and production environments.

Development
~~~~~~~~~~~

Uses vanilla OpenVPN. `terraform <https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/openvpn-vanilla.tf>`_


Production
~~~~~~~~~~

Uses `OpenVPN Access Server <https://docs.openvpn.net/>`_. `salt-state <https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/openvpn-mp>`_ `terraform <https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/openvpn-as.tf>`_

Playbook
--------

.. note::

        OpenVPN AS server can be accessed via the OpenVPN network's gateway ip-address. For example `172.27.224.1`

Resetting Google Authenticator
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SSH to salt-master and execute following as ``root``:

.. code:: sh

          openvpn-reset-google-authenticator user.name

Alternatively, you can execute following directly on an OpenVPN server:

.. code:: sh

        /usr/local/openvpn_as/scripts/sacli -u user.name GoogleAuthRegen

Getting lost client config
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: sh

        /usr/local/openvpn_as/scripts/sacli --user user.name GetUserlogin > user.name.ovpn
