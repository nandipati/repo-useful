.. _linkerd:

Sherpa
======

Deployment
----------

Sherpa is a service installed from an RPM. Upstart is watching the service to ensure it stays running.


RPM
~~~

Sherpais built using ``fpm``, from the `sherpa repo`_ To build a new Sherpa RPM run the `jenkins job`_

Logs
~~~~

Logs for Sherpa can be found on the machine under ``/var/log/sherpa/``. Currently only dev and int stages have logging enabled

Config
~~~~~~

The config is also stored in io.hmheng.platform repo under `sherpa pillar`_


- The main Terraform configuration lives in `sherpa module.tf`_
- Saltstack configuration is split into `sherpa pillar`_ and `sherpa state`_

Configurable routes
^^^^^^^^^^^^^^^^^^^

To add a new route in sherpa one must update the `sherpa pillar`_.

This is broken down into stage as well as path and host based routes.

Example config of a stage looks like

.. code-block:: bash

    sherpa.intl.dev:
      host-routes:
         - "bedrock-test-server-brtest.dev.br.hmheng.io  ,hmheng-infra/devel/bedrock-test-server"
         - "bedrock-test-server-auth.devel.hmheng-infra.brdev.internal  ,hmheng-infra/devel/bedrock-test-server,invig"
      path-routes:
        api.dev.brdev.internal:
          - "bedrock-test-server        ,hmheng-infra/devel/bedrock-test-server "
          - "bedrock-test-server-auth   ,hmheng-infra/devel/bedrock-test-server,invig"
          - "bedrock-test-server-no-eat ,hmheng-infra/devel/bedrock-test-server,no-eat-path


The host-routes take 2 arguments ``domain , Serverset``
Which translates to this domain maps to this Serverset, it also takes an optional argument invig which if enable will validate
the JWT token in the Authentication header.

The other configuration option is the path-routes.
This takes at least two arguments ``path, Serverset``
In the above example we configure the domain api.dev.brdev.internal with two paths /bedrock-test-server mapping to hmheng-infra/devel/bedrock-test-server
As well as bedrock-test-server-auth which maps to the same place but also validates the JWT token in the Authentication header.
The path based routing also takes the optional argument ``no-eat-path`` this will override the default action of consuming the leading segment before it reaches the application.

.. _sherpa repo: https://github.com/hmhco/sherpa
.. _jenkins job: http://jenkins.prod.hmheng-infra.brnp.internal/job/sherpa-rpm/
.. _sherpa pillar: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/sherpa/init.sls
.. _sherpa module.tf: https://github.com/hmhco/io.hmheng.brts.tf.core.base/tree/develop/modules/sherpa
.. _sherpa state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/sherpa


Internal
^^^^^^^^

The ALB (application load balancer) will take in two different patterns:

- ``api.<stage>.br.internal`` and prod ``api.br.internal``

For internal requests the api endpoint will route both explicitly and implicitly, using path routing.
We also allow for single path routing to mirror external usage, such as ``https://api.br.internal/foo`` which can be be mapped to any application. This must be done explicitly and a request is required to add a new route.
When you the api endpoint your application must be able to handel the extra path, ie ``https://api.br.internal/foo/health`` your application must be able to route this to /health


- ``<application>.<stage>.<role>.br.internal``

Application stage and role and exactly how they are found in aurora.
For example, this site is `doc-server`_ which means is aurora there is a tasks which match the `aurora-task`_

External
^^^^^^^^

- ``api.<stage>.eng.hmhco.com`` and prod ``api.eng.hmhco.com``

For external requests the api endpoint will route both explicitly using path routing.
We also allow for single path to route to any application, such as ``https://api.br.internal/foo`` which can be be mapped to any application. This must be done explicitly and a request is required to add a new route.


.. _doc-server: https://doc-server.prod.hmheng-infra.br.internal
.. _aurora-task: https://aurora.br.hmheng.io/scheduler/hmheng-infra/prod/doc-server
