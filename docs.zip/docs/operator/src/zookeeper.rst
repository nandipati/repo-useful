.. _zk:

Zookeeper
=========

Service / Application Use
-------------------------

Overview
~~~~~~~~

Some Bedrock hosted services will require the use of zookeeper to
maintain configurations or any other values across the multiple
containers associated with each aurora job. It is important that these
services only have the ability to access the znodes that the service
requires access to, so that no other znodes could be impacted by
mistake. This service level znode configuration secures each znode at
the role level and then allows the service user to manage the child
znodes.

Znode Structure
~~~~~~~~~~~~~~~

| BASE
| ``/service/<role>/<stage>/<application>``

| EXAMPLES
| ``/service/hmheng-demo/dev/stub-application``
| ``/service/hmheng-demo/int/stub-application``
| ``/service/hmheng-demo/cert/stub-application``
| ``/service/hmheng-demo/prod/stub-application``

Base Znodes
~~~~~~~~~~~

The ``/service/<role>`` znodes have already been created for all roles
listed in the users.deployment
`pillar <https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls>`__
and are watched by saltstack orchestration to ensure that each znode
remains present with the proper ACL.

| ACL = [READ,CREATE,ADMIN)
| SCHEME = digest

Child Znodes
~~~~~~~~~~~~

Any ``/service/<role>`` child znode is managed by the related dev team
and is not watched by saltstack orchestration. This means that it is up
to each service user to ensure that the proper ACL is created and
associated with each new znode that the service requires. It is also
recommended to configure the service to create/manage the znode/ACL. If
this is not possible, client access to zookeeper service is available
when connected to Bedrock OpenVPN.

| ACL = [READ,CREATE,DELETE,ADMIN)
| SCHEME = digest

Authentication
~~~~~~~~~~~~~~

The password string for each Bedrock role is defined in the
users.deployment
`pillar <https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/users/deployment/init.sls>`__
file as ``zookeeper_security_pw``. The username is the role (ie.
hmehng-demo). The service client must utilize the zookeeper "digest" ACL
scheme to connect to a zookeeper server (ie.
hmehng-demo:alkdjflajksdflkj).

Zookeeper Server Endpoints
~~~~~~~~~~~~~~~~~~~~~~~~~~

A ``read/write`` and ``read only`` set of zookeeper server endpoints
exist in Bedrock. The rw set is directed to the actual zookeeper server
nodes, where the ro set is directed to the zookeeper observer nodes. It
is important to configure your service to point read only traffic at the
ro set of endpoints for performance reasons.

Files containing the up to date rw & ro set endpoints are automatically
placed in the sandbox of every aurora job/container instance. Any
services that utilize zookeeper should be configured to retrieve the
zookeeper endpoints from those files.

| ZOOKEEPER ENDPOINT FILES
| ``/mnt/mesos/sandbox/zk_ensemble_rw`` -> zookeeper servers
  (read/write)
| ``/mnt/mesos/sandbox/zk_ensemble_ro`` -> zookeeper observers (read
  only)

\* if the files do not currently exist in the aurora sandbox, please
restart the aurora job (this is a new feature)

ACL Permissions Definitions
~~~~~~~~~~~~~~~~~~~~~~~~~~~

-  CREATE: you can create a child node
-  READ: you can get data from a node and list its children.
-  WRITE: you can set data for a node
-  DELETE: you can delete a child node
-  ADMIN: you can set permissions

ACL Scheme Definitions
~~~~~~~~~~~~~~~~~~~~~~

-  world: has a single id, anyone, that represents anyone.
-  auth: doesn't use any id, represents any authenticated user.
-  digest: uses a username:password string to generate MD5 hash which is
   then used as an ACL ID identity. Authentication is done by sending
   the username:password in clear text. When used in the ACL the
   expression will be the username:base64 encoded SHA1 password digest.
-  host: uses the client host name as an ACL ID identity. The ACL
   expression is a hostname suffix. For example, the ACL expression
   host:corp.com matches the ids host:host1.corp.com and
   host:host2.corp.com, but not host:host1.store.com.
-  ip: uses the client host IP as an ACL ID identity. The ACL expression
   is of the form addr/bits where the most significant bits of addr are
   matched against the most significant bits of the client host IP.

REFERENCE
~~~~~~~~~

-  https://zookeeper.apache.org/doc/r3.1.2/zookeeperProgrammers.html#sc\_ZooKeeperAccessControl

Playbook
~~~~~~~~

Common administrative tasks.

Upgrade/Lifecycle
'''''''''''''''''

This should be done sequentially. Upgrade the needed node one by one, and
restart ``zookeeper-server`` service and other dependant Java services to
handle the IP address change::

        # On salt.brcore01.internal and salt.brnpb.internal
        salt -G 'ec2:tags:salt-role:*zookeeper*' cmd.run 'service zookeeper-server restart && sleep 10' -b 1
        # On salt.brcore01.internal if the observers are updated
        salt -G 'ec2:tags:salt-role:*load-balancer*' cmd.run 'service linkerd restart && sleep 10' -b 1
