Image Independent Thermos Executor Hack
=======================================

(The following assumes Mesos 0.28.2 and Aurora 0.15.0 running on Amazon
Linux 2016.03)

Aurora uses a shim called Thermos Executor to manage all processes. The
executor runs inside the Docker containers, and therefore, in order to
use Docker containers in Aurora, you will need to have a compatible
Thermos Executor binary for each Docker base image, and all containers
must have Python 2.7 and all Mesos dependencies installed. This means a
lot of busywork, and it also artificially limits the selection of usable
Docker base images.

This hack tries to isolate the executor and its dependencies from the
Docker image, by forcing Thermos Executor to locate its dependencies
from a chroot-like directory hierarchy. To make this happen, we will
need the aforementioned chroot, Thermos Executor compatible with that
chroot, and a wrapper script that configures Linux dynamic linker to use
the chroot.

Should this work reliably, we will be able to use all Docker containers
that include ``/bin/sh``, ``/bin/bash`` (Aurora requirement), and
``tar``. The downside is slightly longer container startup time, because
it will now involve copying 100MB compressed chroot to the mesos
sandbox, and uncompressing the same into a 300MB directory (it should be
possible to pare this down, but I don't know if it is worth it).

Implementation
--------------

We will produce a directory containing the chroot, ``thermos_executor``,
and the wrapper script:

::

    - /usr/local/lib/thermos
      |- thermos_executor
      |- thermos-chroot.tar.gz
      `- run-thermos

We will then configure Aurora to copy all of these to
``/mnt/mesos/sandbox`` during container startup, and to execute
``/mnt/mesos/run-thermos`` instead of ``thermos_executor``.
``run-thermos`` will unpack the chroot, talk sternly to Linux dynamic
linker, and then it will finally execute ``thermos_executor``.

Thermos Executor Binary
~~~~~~~~~~~~~~~~~~~~~~~

We use ``/usr/bin/thermos_executor`` from our Aurora 0.15.0 RPM, and
place it to ``/usr/local/lib/thermos`` to keep all related things
together.

Thermos Executor Dependencies
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The easiest way to produce a chroot compatible with our Thermos
Executor, is to build a Amazon Linux 2016.03 Docker image with Python
2.7 and Mesos installed.

When Aurora starts a container, this chroot will make its way to
``/mnt/mesos/sandbox/thermos``, and our wrapper script will use
``/mnt/mesos/sandbox/thermos/usr/bin/python2.7`` to execute
``thermos_executor``. For this to work, Linux dynamic linker *must* be
convinced to load libc and all other libraries from the chroot.
Unfortunately, the dynamic linker is tightly coupled to libc, and to use
libc from the chroot, we must first convince ``python2.7`` to use the
dynamic linker from our chroot.

``.interp`` section of Linux ELF executables points to the dynamic
linker, and so we use `patchelf <https://nixos.org/patchelf.html>`__ to
modify ``python2.7`` to user the linker from our chroot.

First we build ``patchelf``:

.. code:: sh

    $ curl -O https://nixos.org/releases/patchelf/patchelf-0.9/patchelf-0.9.tar.gz
    $ tar xf patchelf-0.9.tar.gz
    $ cd patchelf-0.9
    $ ./configure && make

Then we build a docker image with Mesoss and ``python2.7`` patched with
``patchelf``:

.. code:: sh

    $ cp patchelf-0.9/src/patchelf .
    $ cat >Dockerfile
    FROM docker.br.hmheng.io/base-amazon-linux:2016.03

    RUN yum install -y ca-certificates \
        && printf "\
    [hmheng]\n\
    name=hmheng\n\
    baseurl=https://repo.br.hmheng.io/artifactory/hmheng\n\
    gpgcheck=0\n\
    enabled=1\n\
    priority=5\n\
    " >/etc/yum.repos.d/hmheng.repo \
        && yum install -y mesos

    ADD patchelf /patchelf
    RUN /patchelf --set-interpreter /mnt/mesos/sandbox/thermos/lib64/ld-2.17.so /usr/bin/python2.7
    ^D

    $ docker build -t thermos .

Finally, we turn the image into a tarball:

.. code:: sh

    $ docker create --name thermos thermos:latest
    $ docker export thermos | gzip >/usr/local/lib/thermos/thermos-chroot.tar.gz

Wrapper Script
~~~~~~~~~~~~~~

The wrapper script merely unpacks the chroot to
``/mnt/mesos/sandbox/thermos``, configures Linux dynamic linker to look
for libraries from our chroot, and finally executes ``thermos_executor``
using ``python2.7`` from the chroot.

.. code:: sh

    $ cat >/usr/local/lib/thermos/run-thermos
    #!/bin/sh

    SANDBOX=/mnt/mesos/sandbox
    ROOT=$SANDBOX/thermos

    mkdir $ROOT
    tar xf $SANDBOX/thermos-chroot.tar.gz -C $ROOT

    export LD_PRELOAD=$ROOT/lib64/libc.so.6
    export LD_LIBRARY_PATH=$ROOT/lib64:$ROOT/usr/lib64:$ROOT/usr/lib
    $ROOT/usr/bin/python2.7 $SANDBOX/thermos_executor "$@"

Aurora Scheduler Configuration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Aurora scheduler must be told to copy our files to the sandbox, and to
execute ``run-thermos`` instead of ``thermos_executor``, so
``/etc/sysconfig/aurora-scheduler`` must be modified to add the
following stanzas to the ``AURORA_FLAGS`` array:

.. code:: sh

      -thermos_executor_path=/usr/local/lib/thermos/run-thermos
      -thermos_executor_resources=/usr/local/lib/thermos/thermos-chroot.tar.gz,/usr/local/lib/thermos/thermos_executor

Related Work in Upstream
------------------------

Mesos and Aurora developers are working on fixing this issue by using
proper isolation instead of dirty dynamic linker manipulation. See:

-  `AURORA-1690: Allow for isolating the executor's filesystem from the
   task's <https://issues.apache.org/jira/browse/AURORA-1690>`__
-  `MESOS-5753: Command executor should use mesos-containerizer launch to launch user
   task. <https://issues.apache.org/jira/browse/MESOS-5753>`__
