Kafka
=====

Kafka is a distributed streaming platform with three key capabilities:

1) Publish and subscribe to streams of records, similar to a message queue or
   enterprise messaging system.
2) Store streams of records in a fault-tolerant durable way.
3) Process streams of records as they occur.

At HMH we currently have one kafka kluster with 3 brokers. The cluster is shared
between all teams and in the future might require splitting into multiple kafka
clusters due to lack of proper multitenancy.

Bedrock team is responsible for managing the brokers. Producers, consumers,
connectors, streamsand so on are on teams responsibility at least for now.


Deployment
----------

.. blockdiag::

  blockdiag {
    broker[label="kafka broker",stacked]
    lb[label="load balancer"]
    zk[label="zookeeper",stacked]
    user[label="user", shape=actor]
    consumer[label="consumer"]
    producer[label="producer"]

    producer -> broker [label=uses, fontsize="8"];
    consumer -> broker [label=uses, fontsize="8"];
    consumer -> lb [label=bootstrap, fontsize="8"];
    producer -> lb [label=bootstrap, fontsize="8"];
    user -> lb [label=defines, fontsize="8"];

    lb -> broker [label=9092, fontsize="8"];
    broker -> zk [label=2181, fontsize="8"];
  }


The usage works so that all producers and consumers connect via a single endpoint
which is a load balancer that listens on port 9092. The bootstrap urls are returned
to the producer/consumer during the handshake.


Artifacts
---------
We use confluent repositories for installing their bundled version of kafka and some of the
tools. The reason originally to install the bundle was that there were missing dependencies
for the kafka package and getting them sorted is quite a bit of work.


Configuration
-------------

Kafka depends on following configuration items:

* ``znode creation`` /service/hmheng-infra/<region>/environment/kafka znode needs to exist 
  before kafka can run

* ``broker id`` the broker id's are managed with a broker id management script. The reason
  is that we need a system to reuse broker id's if for example an individual broker is lost.
  This is handled by a `reserve broker id`_ -script that uses zookeeper locking mechanism
  to make sure that two nodes don't take the same broker id.

* `/etc/kafka/server.properties`_ this is kafka main configuration file.

* `/etc/kafka/zookeeper.jaas`_ zookeeper jaas authentication file. Kafka zookeeper client uses the
  credentials written to this file to authenticate itself against zookeeper.

* `/etc/init/kafka.conf`_ Kafka upstart script

.. _reserve broker id: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/kafka/files/usr/local/bin/reserve-broker-id

.. _/etc/kafka/zookeeper.jaas: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/kafka/templates/etc/kafka/zookeeper.jaas

.. _/etc/kafka/server.properties: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/kafka/templates/etc/kafka/server.properties

.. _/etc/init/kafka.conf: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/kafka/files/etc/init/kafka.conf

.. note::

   Kafka configuration consists of two separate configuration items regarding on how the broker
   binds to a specific port and what broker address is delivered to the producer/consumer. ``listeners``
   define the port(s) kafka itself binds to and ``advertised.listeners`` is the configuration
   that is written to zookeeper and that is delivered to clients. This way also the old style
   clients can connect to kafka by defining the zookeeper connectstring with kafka chroot.


Networking
----------

Kafka network configuration:

Ingress (Users access kafka via these ports):

* ``9092``: This is the main port kafka listens for consumers and producers

Egress (Kafka needs access to these services on specified ports):

* ``2181``: Zookeeper
* ``2888``: Zookeeper
* ``3888``: Zookeeper


Internal service discovery
--------------------------

Kafka uses zookeeper to internally discover other kafka nodes. The addresses that are
advertised for consumers and producers are defined in `/etc/kafka/server.properties`_.


Logs
----

Logs are stored on each broker to ``/var/log/kafka/``. The logs are splitted into multiple
different files.


Metrics
-------

Metrics are published through JMX and collected by datadog and are visible via datadog UI.


Monitoring
----------

Kafka is monitored by `kafka health check`_ that monitors individual kafka brokers but also the
cluster as whole. `Doctorkafka`_ does load balancing and rebalancing of partitions on ie. broker
failure situations.

Doctorkafka UI is visible in: http://doctorkafka.prod.hmheng-infra.brnp.internal/

.. _kafka health check: https://github.com/andreas-schroeder/kafka-health-check
.. _Doctorkafka: https://github.com/pinterest/doctorkafka


Backups
-------

Backing up kafka commit logs is pretty much impossible, so it relies heavily on replication.
Topic creators (users) are required to define replication factor and number of partitions.

For production data the replication should not be less than 3.
