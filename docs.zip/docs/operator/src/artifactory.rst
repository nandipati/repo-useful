Artifactory
===========

Artifactory hosts all repositories used in Bedrock. Most of the repositories are
used only during builds, but docker.br.hmheng.io and other docker repositories
are also used to provide container images for Aurora/Mesos.

Deployment
----------

.. blockdiag::

   blockdiag {
     repo[label="repo.br.hmheng.io"]
     docker[label="docker.br.hmheng.io"]
     docker-ext[label="docker-ext.br.hmheng.io"]

     art[label="artifactory",stacked]

     s3[label="artifacts (S3)", shape="flowchart.database"]
     rds[label="postgresql (RDS)", shape="flowchart.database"]
     efs[label="cache, ha conf (EFS)", shape="flowchart.database"]

     repo, docker, docker-ext -> art -> efs, rds, s3;

     group elb {
       label = "load balancers"
       repo, docker, docker-ext
     }

     group storage {
       label = "storage"
       rds, s3, efs
     }

     default_group_color = "lightgray"
   }

There are three HTTP/HTTPS load balancers in front of Artifactory one for each
public endpoint. The requests coming from load balancers are routed through
Nginx to artifactory.

Artifactory runs in `HA configuration`_ with three instances running in
different availability zones. Currently the instances are not managed by an AWS
auto scaling group.

Artifactory uses shared EFS file system for storing clusterwide configuration
files, while node specific configuration is stored on the instance root volume.
Actual artifacts are stored in S3, and they are cached on the shared EFS file
system. Artifact metadata is stored in a PostgreSQL database provided by AWS
RDS.

Artifactory is deployed to ref:`core-network`.

.. _HA configuration: https://www.jfrog.com/confluence/display/RTF/Artifactory+High+Availability

Upstream collaborators
~~~~~~~~~~~~~~~~~~~~~~

Most of the repositories are used during both automatic and manual
builds:

- ref:`shared-jenkins`
- ref:`team-jenkins`
- ref:`bastion`

Some repositories (notably docker.br.hmheng.io) are also used to
to run applications on top of ref:`aurora`.

ref:`hmheng-yum-mirror` lambda mirrors ``hmheng`` YUM repository to S3.

Authentication
~~~~~~~~~~~~~~

Artifactory maintains its own user database, and an account may be created to
anyone able to connect to the Bedrock bastion.

All repositories (e.g. docker.br.hmheng.io) provide read/write anonymous access,
and currently this is the predominant way to use artifactory.

Artifacts
~~~~~~~~~

Artifactory is deployed using Terraform and Saltstack. Artifactory binaries are
hosted in `hmheng YUM repository`_. of brcore01 Artifactory(!), with the
exception of PostgreSQL JDBC driver, which currently lives in
``io.hmheng.platform`` repository.

- Terraform configuration lives in `artifactory.tf`_
- Saltstack configuration is split into `artifactory pillar`_ and `artifactory state`_
- `PostgreSQL JDBC driver`_

.. _hmheng YUM repository: https://repo.br.hmheng.io/artifactory/webapp/#/artifacts/browse/tree/General/hmheng
.. _artifactory.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/artifactory.tf
.. _artifactory pillar: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/pillars/artifactory
.. _artifactory state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/artifactory
.. _PostgreSQL JDBC driver: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/__files__/postgresql-42.0.0.jar

Configuration
~~~~~~~~~~~~~

Artifactory reads its initial global configuration from a file, which it then
stores in to the database, and the database is used from that point onwards. See
`configuration files`_ section of Artifactory documentation for details.

Some configuration files remain even after that step so that Artifactory can
find the database containing the main configuration among other things. Some
of those configuration files are stored locally on each node, and some of the
configuration is stored on the network file system shared among all nodes.

``/var/opt/jfrog/artifactory/etc`` contains locally stored configuration files,
and they include:

``ha-node.properties``
  Artifactory `HA configuration`_

``/mnt/efs/artifactory/cluster_home/ha-etc`` contains clusterwide configuration files,
and they include:

``cluster.properties``
  Clusterwide security token

``storage.properties``
  Storage and database configuration

The split between node specific configuration and shared configuration is elaborated
in Artifactory `HA installation and setup`_ instructions

.. _configuration files: https://www.jfrog.com/confluence/display/RTF/Configuration+Files
.. _HA installation and setup: https://www.jfrog.com/confluence/display/RTF/HA+Installation+and+Setup

Logs
~~~~

Artifactory node specific log files are located in
``/var/opt/jfrog/artifactory/logs``. At the moment they are not shipped to our
centralized log server.


Licenses
~~~~~~~~

We currently have three artifactory licenses, and they must be renewed yearly
around September.

Artifactory stores the licenses internally, and they're distributed among artifactory nodes by `Cluster License Manager`_.

The license files are stored in `inside artifactory SaltStack state`_.

.. _Cluster License Manager: https://www.jfrog.com/confluence/display/RTF/HA+Installation+and+Setup#HAInstallationandSetup-ClusterLicenseManagement
.. _inside artifactory SaltStack state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/artifactory/

Backups
~~~~~~~

We keep 10 days worth of daily snapshots of the main PostgreSQL database, and no
other backups are kept.
