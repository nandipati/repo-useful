.. _elasticsearch:
.. index:: single: Service; Elasticsearch

Elasticsearch
=============

.. contents::

.. index:: single: Logstash; indexers

Deployment
----------

.. blockdiag::

   blockdiag {
     master_elb[label = "es-masters"]
     agent_elb[label = "es-agents"]

     master[label="master node", stacked]
     agent[label="agent node", stacked]

     logstash[stacked]

     master <-> agent

     master_elb -> master
     agent_elb -> agent <- redis

     redis <- logstash
     redis <- elb2ls
     redis <- ct2ls

     group elbs {
       label = "ELBs"
       master_elb, agent_elb
     }

     group nodes {
       label = "ASGs"
       orientation = "portrait"
       master, agent
     }

     default_group_color = "lightgray"
   }

Our deployment has two kinds of Elasticsearch nodes: master nodes and agent
nodes. Master nodes manage the cluster state, and the agent nodes store the
data, index the data, and make it quaryable. There are separate ELBs and
auto scaling groups for both node types.

All agent nodes run Logstash indexers which pull logs from a Redis queue,
and the queue is used by multiple log producers. This is covered in more depth
in :ref:`centralized-logging`.

If Logstash fails to write documents to an Elasticsearch index, it will store
the failed documents and the error message into a `dead letter queue`_ at
``/var/lib/logstash/dead_letter_queue``. The files may then be copied to a
more convenient location, and processed using Logstash `dlq input plugin`_.

.. note::

   Currently there are two different Redis instances in use. ``log.brcore01.internal``
   is the current one, and there is also legacy ``log.brnpb.intenal`` which is going
   away Real Soon Now.

.. index:: single: Authentication; Elasticsearch

.. _dead letter queue: https://www.elastic.co/guide/en/logstash/5.6/dead-letter-queues.html
.. _dlq input plugin: https://www.elastic.co/guide/en/logstash/5.6/plugins-inputs-dead_letter_queue.html

Downstream collaborators
~~~~~~~~~~~~~~~~~~~~~~~~

Elasticsearch is mainly used for aggregating logs, and querying and visualizing
those logs. Some application running on Bedrock platform also use Elasticsearch
for purposes unknown.

The direct downstream in case of log aggregation are the :ref:`logstash` indexer
processes running on each Elasticsearch agent node. The log aggregation pipeline
is discussed in depth in :ref:`centralized-logging`.

Querying and visualization of stored data is done using :ref:`kibana` and
:ref:`grafana`.

We do not track which applications running on Bedrock platform use Elasticsearch
at the moment, but we do know :ref:`what indices they use <application-index-groups>`.

Additionally, :ref:`curator` takes care of backups and enforces retention
policies at the index level.

Authentication
~~~~~~~~~~~~~~

At the moment Elasticsearch is open to anyone capable of connecting to it, such
as Mesos agents, Jenkins slaves, and Bedrock OpenVPN users.

.. index:: single: Artifacts; Elasticsearch

Artifacts
~~~~~~~~~

Elasticsearch is deployed using Terraform and SaltStack. Elasticsearch binaries
are fetched directly from `elastic.co`_ YUM repository, and Elasticsearch
plugins are installed using the `built-in plugin management facilities`_.

- Terraform configuration split into multiple files

  - Master node configuration lives in `elasticsearch-master.tf`_
  - Agent node configuration lives in `elasticsearch-agent.tf`_
  - Redis configuration lives in `elasticsearch-redis.tf`_

- SaltStack configuration is split into `elasticsearch pillar`_ and `elasticsearch state`_.
  Configuration differences between master- and agent nodes are so small that they are
  handled inline based on instance EC2 tags.

- Logstash indexers running on agent nodes are installed and configured from `logstash state`_,
  which configures Logstash differently when operating on a host with Elasticsearch EC2 tags.

.. _elastic.co: https://www.elastic.co/
.. _built-in plugin management facilities: https://www.elastic.co/guide/en/elasticsearch/plugins/2.3/plugin-management.html
.. _elasticsearch-master.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/elasticsearch-master.tf
.. _elasticsearch-agent.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/elasticsearch-agent.tf
.. _elasticsearch-redis.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/elasticsearch-redis.tf
.. _elasticsearch pillar: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/pillars/elasticsearch
.. _elasticsearch state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/elasticsearch
.. _logstash state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/logstash

.. index:: single: Configuration; Elasticsearch

Configuration
~~~~~~~~~~~~~

Elasticsearch has two sources of configuration. When Elasticsearch is starting
up, it will read its configuration from a static configuration file, and stores
it into the cluster-wide configuration store. The configuration stored into the
cluster-wide configuration store may be modified at runtime, and those changes
may be optionally persisted. Currently, we prefer to use the static
configuration files for most of the configuration, and we use the cluster-wide
configuration store only for transient configuration changes.

Elasticsearch static configuration is located at ``/etc/elasticsearch``. It is split into
general settings (``elasticsearch.yml``) and logging configuration (``logging.yml``).
See Elasticsearch documentation on `Elasticsearch settings`_ for further information.

Cluster-wide configuration store is manipulated using the `Cluster Update Settings API`_.

.. _Elasticsearch settings: https://www.elastic.co/guide/en/elasticsearch/reference/2.3/setup-configuration.html#settings
.. _Cluster Update Settings API: https://www.elastic.co/guide/en/elasticsearch/reference/2.3/cluster-update-settings.html

.. index:: single: Networking; Elasticsearch

Networking
~~~~~~~~~~

Elasticsearch public APIs and endpoints use HTTP/HTTPS and they are exposed through
the agent and master ELBs. Port 9200 accepts HTTP and port 443 accepts HTTPS.

The nodes use port 9300 to communicate among themselves by using `Transport protocol`_.

.. _Transport protocol: https://www.elastic.co/guide/en/elasticsearch/reference/2.3/modules-transport.html

Internal service discovery
~~~~~~~~~~~~~~~~~~~~~~~~~~

Elasticsearch nodes use `AWS Cloud Plugin`_ to locate each other. The current
configuration uses the value of ``stack-name`` EC2 tag to identify EC2 instances
that belong to each cluster.

.. _AWS Cloud Plugin: https://www.elastic.co/guide/en/elasticsearch/plugins/2.3/cloud-aws.html

.. index:: single: Logs; Elasticsearch

Logs
~~~~

Elasticsearch writes its logs into ``/var/log/elasticsearch``, and a script is
periodically executed to back up rotated logs to ``s3://$ENVIRONMENT-logs/``.

.. index:: single: Metrics; Elasticsearch

Metrics
~~~~~~~

:ref:`telegraf` collects wide variety of `Elasticsearch metrics`_ and makes them
:ref:`available in influxdb <influxdb>`. A haphazard visualization of core metrics is
available in `grafana`_.

.. _Elasticsearch metrics: https://github.com/influxdata/telegraf/tree/master/plugins/inputs/elasticsearch#measurements--fields
.. _grafana: http://grafana.br.hmheng.io/dashboard/db/ville-aine-es-testing

.. index:: single: Backups; Elasticsearch

Backups
~~~~~~~

:ref:`curator` takes daily snapshots of all indices and stores them to ``s3://br-elasticsearch``.

Index ownership
---------------

Index group is a set of of indices with dates, stage indicators (``-dev``,
``-int``, ...) and other cruft removed.

.. _application-index-groups:

Application index groups
~~~~~~~~~~~~~~~~~~~~~~~~

.. list-table:: Elasticsearch indices used in applications
   :header-rows: 1

   * - Index group
     - Contact persons
   * - batchjobstore
     - Siva Ekambaram
   * - batchexecutionstore
     - Siva Ekambaram
   * - errorstore
     - Siva Ekambaram
   * - pmt-metrics
     - Siva Ekambaram
   * - userevent-pipeline
     - Kevin McGarry
   * - userevents
     - Kevin McGarry
   * - hmh-ids-queue
     - Alan Hayes, Jay Allen
   * - hmh-ids
     - Alan Hayes, Jay Allen
   * - testbatches
     - Siva Ekambaram
   * - testbatcherrors
     - Siva Ekambaram
   * - testbatchcounts
     - Siva Ekambaram
   * - idma_legacy_plaforms
     - Siva Ekambaram

Infrastructure index groups
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. list-table:: Infrastructure related elasticsearch indices
   :header-rows: 1

   * - Index group
     - Contact persons
   * - zipkin
     - #infra-team
   * - logstash
     - #infra-team
   * - .marvel-es-data-1
     - #infra-team
   * - .marvel-es-data
     - #infra-team
   * - kibana-4-cloudbees
     - #infra-team
   * - .kibana
     - #infra-team

.. _unknown indices:

Index groups of unknown origin
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. list-table:: Elasticsearch indices of unknown origin
   :header-rows: 1

   * - Index group
     - Contact persons
   * - metrics
     - Unknown
   * - spark
     - Unknown
   * - hoaa-testingevents
     - Unknown
   * - hoaa-studentassignment
     - Unknown

Playbook
--------

Resolving mapping conflicts
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Begin by extracting clean JSON from logstash dead letter queue:

  1. Collect `dead letter queue`_ files from Elasticsearch data nodes. The dead letter queue
     is located at ``/var/lib/logstash/dead_letter_queue``. Copy the files from that directory
     and place them into a local directory ``data/``.
  2. Run ``scripts/logstash-read-dead-letters | tee output.txt``. The scripts does not terminate
     by itself; you have to terminate it with ctrl-c after the processing has stopped.
  3. Scan ``output.txt`` for errors
  4. Process the data with ``jq``: ``grep ^{ output.txt|jq . >output.json``

You can now use the clean JSON to identify the reason for the conflicts with
``jq .__metadata.dead_letter_queue.reason <output.json``.

Now that reason for the conflict is clear, you can identify both sides of the conflict. Elasticsearch
contains documents that adhere to the current mapping, and the dead letter queue contains documents
that do not. For example, if the mapping conflict concerns field ``response``, then you can find
the documents using that field using Elasticsearch ``exists`` query:

.. code-block: shell

   http 'es.br.hmheng.io:9200/<logstash-{now%2fd}>/_search' size==1 \
      <<< '{"query": {"exists" : { "field" : "response" }}}'

You can identify the other side of the conflict by visually inspecting ``output.json``. If
the source is an application hosted on Aurora (and it usually is), then you can identify the
source of conflicts with ``jq .taskid <output.json``.
