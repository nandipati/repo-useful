Playbook Entries
================

Herein lies some help for dealing with common monitoring alerts or other
problems.


Monitoring Alerts
~~~~~~~~~~~~~~~~~


SNAPSHOT PARTIAL::elasticsearch curator snapshot failed
-------------------------------------------------------

  * This means that the backup process for elasticsearch had issues. Since it
    says "PARTIAL", one or more of the many indicies failed during the dailly
    snapshot procedure.
     * This often can be addressed with a simple re-run of the aurora cron job.
     * Even if that doesn't happen, if the next day's snapshot succeeds,
       then we're all good as the missed backup will likely be moot at that point.
  * To re-run the aurora job, ssh to the deploy.console box and execute:

    .. code::

     sudo su - hmheng-infra
     aurora cron start brnpb-us-east-1/hmheng-infra/prod/elasticsearch-curator

  * If you're curious as to which indicies failed and what the failures were,
    from your local box you can run:

    .. code::

       curl https://es.br.hmheng.io/_snapshot/es5_s3_backup/_all?filter_path=snapshots.snapshot,snapshots.state,snapshots.failures | jq
