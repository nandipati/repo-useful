Deployed application details
============================

Production
----------

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| prod                | hmheng-cds      | hmheng-cds/ | 29011 | performan |
|                     |                 | prod/perfor |       | ce-task.b |
|                     |                 | mance-task  |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-cds      | hmheng-cds/ | 29012 | grid.br.h |
|                     |                 | prod/grid   |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-cds      | hmheng-cds/ | 29023 | hmhoneui. |
|                     |                 | prod/hmhone |       | br.hmheng |
|                     |                 | ui          |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-cds      | hmheng-cds/ | 29024 | arvo.br.h |
|                     |                 | prod/arvo   |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-clm      | hmheng-clm/ | 29017 | hmh-polic |
|                     |                 | prod/hmh-po |       | y.br.hmhe |
|                     |                 | licy        |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-clm      | hmheng-clm/ | 29022 | entitleme |
|                     |                 | prod/clm-en |       | nts.br.hm |
|                     |                 | titlements  |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-clm      | hmheng-clm/ | 29032 | eventserv |
|                     |                 | prod/???    |       | ice.br.hm |
|                     |                 |             |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-clm      | hmheng-clm/ | 29033 | flink-pip |
|                     |                 | prod/???    |       | eline.br. |
|                     |                 |             |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-core-ser | hmheng-core | 29016 | notificat |
|                     | vices           | -services/p |       | ion-servi |
|                     |                 | rod/notific |       | ce.br.hmh |
|                     |                 | ation-servi |       | eng.io    |
|                     |                 | ce          |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-demo     | hmheng-demo | 29010 | stub-appl |
|                     |                 | /prod/stub- |       | ication.d |
|                     |                 | application |       | ev.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29002 | idm-idp.b |
|                     |                 | prod/idp    |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29003 | idm-templ |
|                     |                 | prod/templa |       | ate-conve |
|                     |                 | te-converte |       | rters.br. |
|                     |                 | rs          |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29004 | idm-impor |
|                     |                 | prod/import |       | t-workers |
|                     |                 | -workers    |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29005 | idm-basal |
|                     |                 | prod/basal- |       | -import-t |
|                     |                 | import-tc   |       | c.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29006 | idm-basal |
|                     |                 | prod/basal- |       | -import-h |
|                     |                 | import-hmof |       | mof.br.hm |
|                     |                 |             |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29007 | hmh-acces |
|                     |                 | prod/hmh-ac |       | s.br.hmhe |
|                     |                 | cess        |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29008 | idm-api-a |
|                     |                 | prod/api-ad |       | dapters.b |
|                     |                 | apters      |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29013 | admin-too |
|                     |                 | prod/admin- |       | l.br.hmhe |
|                     |                 | tool        |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29014 | idm-hmof- |
|                     |                 | prod/hmof-a |       | api.br.hm |
|                     |                 | pi          |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29015 | idm-ids.b |
|                     |                 | prod/ids    |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-idm      | hmheng-idm/ | 29019 | config-id |
|                     |                 | prod/config |       | m.br.hmhe |
|                     |                 | -idm        |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-infra    | hmheng-infr | 29000 | kibana.br |
|                     |                 | a/prod/kiba |       | .hmheng.i |
|                     |                 | na          |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-infra    | hmheng-infr | 29021 | tracing.b |
|                     |                 | a/prod/zipk |       | r.hmheng. |
|                     |                 | in          |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-infra    | hmheng-infr | 29025 | n/a       |
|                     |                 | a/prod/logs |       |           |
|                     |                 | tash-http-e |       |           |
|                     |                 | vent-indexe |       |           |
|                     |                 | r           |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-support  | hmheng-supp | 29020 | knewton-u |
|                     |                 | ort/prod/kn |       | pdate-too |
|                     |                 | ewton-updat |       | l.br.hmhe |
|                     |                 | e-tool      |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-score    | hmheng-scor | 29036 | scoring-a |
|                     |                 | e/prod/scor |       | pi.br.hmh |
|                     |                 | ing-api     |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| prod                | hmheng-report   | hmheng-repo | 29035 | reporting |
|                     |                 | rt/prod/sco |       | -api.br.h |
|                     |                 | ring-api    |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-cds      | hmheng-cds/ | 20011 | performan |
|                     |                 | staging0/pe |       | ce-task.i |
|                     |                 | rformance-t |       | nt.br.hmh |
|                     |                 | ask         |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+

Devel
-----

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| devel               | hmheng-cds      | hmheng-cds/ | 19011 | performan |
|                     |                 | devel/perfo |       | ce-task.d |
|                     |                 | rmance-task |       | ev.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-cds      | hmheng-cds/ | 19012 | grid.dev. |
|                     |                 | devel/grid  |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-cds      | hmheng-cds/ | 19023 | hmhoneui. |
|                     |                 | devel/hmhon |       | dev.br.hm |
|                     |                 | eui         |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-cds      | hmheng-cds/ | 19024 | arvo.dev. |
|                     |                 | devel/arvo  |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-clm      | hmheng-clm/ | 19017 | hmh-polic |
|                     |                 | devel/hmh-p |       | y.dev.br. |
|                     |                 | olicy       |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-clm      | hmheng-clm/ | 19022 | entitleme |
|                     |                 | devel/clm-e |       | nts.dev.b |
|                     |                 | ntitlements |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-clm      | hmheng-clm/ | 19032 | eventserv |
|                     |                 | devel/???   |       | ice.dev.b |
|                     |                 |             |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-clm      | hmheng-clm/ | 19033 | flink-pip |
|                     |                 | devel/???   |       | eline.dev |
|                     |                 |             |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-content- | hmheng-cont | 19026 | content-p |
|                     | pipeline        | ent-pipelin |       | ipeline-a |
|                     |                 | e/devel/con |       | gent.dev. |
|                     |                 | tent-pipeli |       | br.hmheng |
|                     |                 | ne-agent    |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-content- | hmheng-cont | 19027 | content-p |
|                     | pipeline        | ent-pipelin |       | ipeline-p |
|                     |                 | e/devel/con |       | ublish.de |
|                     |                 | tent-pipeli |       | v.br.hmhe |
|                     |                 | ne-publish  |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-core-ser | hmheng-core | 19016 | notificat |
|                     | vices           | -services/d |       | ion-servi |
|                     |                 | evel/notifi |       | ce.dev.br |
|                     |                 | cation-serv |       | .hmheng.i |
|                     |                 | ice         |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-core-ser | hmheng-core | 19018 | assignmen |
|                     | vices           | -services/d |       | tapi-asyn |
|                     |                 | evel/assign |       | c.dev.br. |
|                     |                 | mentapi-asy |       | hmheng.io |
|                     |                 | nc          |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-demo     | hmheng-demo | 19010 | stub-appl |
|                     |                 | /devel/stub |       | ication.d |
|                     |                 | -applicatio |       | ev.br.hmh |
|                     |                 | n           |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19002 | idm-idp.d |
|                     |                 | devel/idp   |       | ev.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19003 | idm-templ |
|                     |                 | devel/templ |       | ate-conve |
|                     |                 | ate-convert |       | rters.dev |
|                     |                 | ers         |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19004 | idm-impor |
|                     |                 | devel/impor |       | t-workers |
|                     |                 | t-workers   |       | .dev.br.h |
|                     |                 |             |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19005 | idm-basal |
|                     |                 | devel/basal |       | -import-t |
|                     |                 | -import-tc  |       | c.dev.br. |
|                     |                 |             |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19006 | idm-basal |
|                     |                 | devel/basal |       | -import-h |
|                     |                 | -import-hmo |       | mof.dev.b |
|                     |                 | f           |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19007 | hmh-acces |
|                     |                 | devel/hmh-a |       | s.dev.br. |
|                     |                 | ccess       |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19008 | idm-api-a |
|                     |                 | devel/api-a |       | dapters.d |
|                     |                 | dapters     |       | ev.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19013 | admin-too |
|                     |                 | devel/admin |       | l.dev.br. |
|                     |                 | -tool       |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19014 | idm-hmof- |
|                     |                 | devel/hmof- |       | api.dev.b |
|                     |                 | api         |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-idm      | hmheng-idm/ | 19015 | idm-ids.d |
|                     |                 | devel/ids   |       | ev.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-infra    | hmheng-infr | 29009 | grafana.b |
|                     |                 | a/devel/gra |       | r.hmheng. |
|                     |                 | fana        |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-techops  | hmheng-tech | 19028 | n/a       |
|                     |                 | ops/devel/e |       |           |
|                     |                 | asycbm      |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-techops  | hmheng-tech | 19029 | n/a       |
|                     |                 | ops/devel/e |       |           |
|                     |                 | asycbm-admi |       |           |
|                     |                 | n           |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-score    | hmheng-scor | 19036 | scoring-a |
|                     |                 | e/devel/sco |       | pi.dev.br |
|                     |                 | ring-api    |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| devel               | hmheng-report   | hmheng-repo | 19035 | reporting |
|                     |                 | rt/devel/sc |       | -api.dev. |
|                     |                 | oring-api   |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+

Int
---

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| staging0            | hmheng-cds      | hmheng-cds/ | 20012 | grid.dev. |
|                     |                 | staging0/gr |       | int.hmhen |
|                     |                 | id          |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-cds      | hmheng-cds/ | 20023 | hmhoneui. |
|                     |                 | staging0/hm |       | int.br.hm |
|                     |                 | honeui      |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-cds      | hmheng-cds/ | 20024 | arvo.int. |
|                     |                 | staging0/ar |       | br.hmheng |
|                     |                 | vo          |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-clm      | hmheng-clm/ | 20017 | hmh-polic |
|                     |                 | staging0/hm |       | y.int.br. |
|                     |                 | h-policy    |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-clm      | hmheng-clm/ | 20022 | entitleme |
|                     |                 | staging0/cl |       | nts.int.b |
|                     |                 | m-entitleme |       | r.hmheng. |
|                     |                 | nts         |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-clm      | hmheng-clm/ | 19032 | eventserv |
|                     |                 | staging0/?? |       | ice.int.b |
|                     |                 | ?           |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-clm      | hmheng-clm/ | 19033 | flink-pip |
|                     |                 | staging0/?? |       | eline.int |
|                     |                 | ?           |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-core-ser | hmheng-core | 20016 | notificat |
|                     | vices           | -services/s |       | ion-servi |
|                     |                 | taging0/not |       | ce.int.br |
|                     |                 | ification-s |       | .hmheng.i |
|                     |                 | ervice      |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-core-ser | hmheng-core | 20018 | assignmen |
|                     | vices           | -services/s |       | tapi-asyn |
|                     |                 | taging0/ass |       | c.int.br. |
|                     |                 | ignmentapi- |       | hmheng.io |
|                     |                 | async       |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-demo     | hmheng-demo | 20010 | stub-appl |
|                     |                 | /staging0/s |       | ication.i |
|                     |                 | tub-applica |       | nt.br.hmh |
|                     |                 | tion        |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20002 | idm-idp.i |
|                     |                 | staging0/id |       | nt.br.hmh |
|                     |                 | p           |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20003 | idm-templ |
|                     |                 | staging0/te |       | ate-conve |
|                     |                 | mplate-conv |       | rters.int |
|                     |                 | erters      |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20004 | idm-impor |
|                     |                 | staging0/im |       | t-workers |
|                     |                 | port-worker |       | .int.br.h |
|                     |                 | s           |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20005 | idm-basal |
|                     |                 | staging0/ba |       | -import-t |
|                     |                 | sal-import- |       | c.int.br. |
|                     |                 | tc          |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20006 | idm-basal |
|                     |                 | staging0/ba |       | -import-h |
|                     |                 | sal-import- |       | mof.int.b |
|                     |                 | hmof        |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20007 | hmh-acces |
|                     |                 | staging0/hm |       | s.int.br. |
|                     |                 | h-access    |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20008 | idm-api-a |
|                     |                 | staging0/ap |       | dapters.i |
|                     |                 | i-adapters  |       | nt.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20013 | admin-too |
|                     |                 | staging0/ad |       | l.int.br. |
|                     |                 | min-tool    |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20014 | idm-hmof- |
|                     |                 | staging0/hm |       | api.int.b |
|                     |                 | of-api      |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-idm      | hmheng-idm/ | 20015 | idm-ids.i |
|                     |                 | staging0/id |       | nt.br.hmh |
|                     |                 | s           |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-score    | hmheng-scor | 20036 | scoring-a |
|                     |                 | e/staging0/ |       | pi.int.br |
|                     |                 | scoring-api |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging0            | hmheng-report   | hmheng-repo | 20035 | reporting |
|                     |                 | rt/staging0 |       | -api.int. |
|                     |                 | /scoring-ap |       | br.hmheng |
|                     |                 | i           |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+

Cert
----

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| staging1            | hmheng-cds      | hmheng-cds/ | 21011 | performan |
|                     |                 | staging1/pe |       | ce-task.c |
|                     |                 | rformance-t |       | ert.br.hm |
|                     |                 | ask         |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-cds      | hmheng-cds/ | 21012 | grid.cert |
|                     |                 | staging1/gr |       | .br.hmhen |
|                     |                 | id          |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-cds      | hmheng-cds/ | 21023 | hmhoneui. |
|                     |                 | staging1/hm |       | cert.br.h |
|                     |                 | honeui      |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-cds      | hmheng-cds/ | 21024 | arvo.cert |
|                     |                 | staging1/ar |       | .br.hmhen |
|                     |                 | vo          |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-clm      | hmheng-clm/ | 21017 | hmh-polic |
|                     |                 | staging1/hm |       | y.cert.br |
|                     |                 | h-policy    |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-clm      | hmheng-clm/ | 21022 | entitleme |
|                     |                 | staging1/cl |       | nts.cert. |
|                     |                 | m-entitleme |       | br.hmheng |
|                     |                 | nts         |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-clm      | hmheng-clm/ | 19032 | eventserv |
|                     |                 | staging1/?? |       | ice.cert. |
|                     |                 | ?           |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-clm      | hmheng-clm/ | 19033 | flink-pip |
|                     |                 | staging1/?? |       | eline.cer |
|                     |                 | ?           |       | t.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-core-ser | hmheng-core | 21016 | notificat |
|                     | vices           | -services/s |       | ion-servi |
|                     |                 | taging1/not |       | ce.certrv |
|                     |                 | ification-s |       | .br.hmhen |
|                     |                 | ervice      |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-core-ser | hmheng-core | 21018 | assignmen |
|                     | vices           | -services/s |       | tapi-asyn |
|                     |                 | taging1/ass |       | c.cert.br |
|                     |                 | ignmentapi- |       | .hmheng.i |
|                     |                 | async       |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-demo     | hmheng-demo | 21010 | stub-appl |
|                     |                 | /staging1/s |       | ication.c |
|                     |                 | tub-applica |       | ert.br.hm |
|                     |                 | tion        |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21002 | idm-idp.c |
|                     |                 | staging1/id |       | ert.br.hm |
|                     |                 | p           |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21003 | idm-templ |
|                     |                 | staging1/te |       | ate-conve |
|                     |                 | mplate-conv |       | rters.cer |
|                     |                 | erters      |       | t.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21004 | idm-impor |
|                     |                 | staging1/im |       | t-workers |
|                     |                 | port-worker |       | .cert.br. |
|                     |                 | s           |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21005 | idm-basal |
|                     |                 | staging1/ba |       | -import-t |
|                     |                 | sal-import- |       | c.cert.br |
|                     |                 | tc          |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21006 | idm-basal |
|                     |                 | staging1/ba |       | -import-h |
|                     |                 | sal-import- |       | mof.cert. |
|                     |                 | hmof        |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21007 | hmh-acces |
|                     |                 | staging1/hm |       | s.cert.br |
|                     |                 | h-access    |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21008 | idm-api-a |
|                     |                 | staging1/ap |       | dapters.c |
|                     |                 | i-adapters  |       | ert.br.hm |
|                     |                 |             |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21013 | admin-too |
|                     |                 | staging1/ad |       | l.cert.br |
|                     |                 | min-tool    |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21014 | idm-hmof- |
|                     |                 | staging1/hm |       | api.cert. |
|                     |                 | of-api      |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21015 | idm-ids.c |
|                     |                 | staging1/id |       | ert.br.hm |
|                     |                 | s           |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-idm      | hmheng-idm/ | 21019 | config-id |
|                     |                 | staging1/co |       | m.cert.br |
|                     |                 | nfig-idm    |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-infra    | hmheng-infr | 21021 | tracing.c |
|                     |                 | a/staging1/ |       | ert.br.hm |
|                     |                 | zipkin      |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-infra    | hmheng-infr | 21025 | n/a       |
|                     |                 | a/staging1/ |       |           |
|                     |                 | logstash-ht |       |           |
|                     |                 | tp-event-in |       |           |
|                     |                 | dexer       |       |           |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-support  | hmheng-supp | 21020 | knewton-u |
|                     |                 | ort/staging |       | pdate-too |
|                     |                 | 1/knewton-u |       | l.cert.br |
|                     |                 | pdate-tool  |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-score    | hmheng-scor | 21036 | scoring-a |
|                     |                 | e/staging1/ |       | pi.cert.b |
|                     |                 | scoring-api |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging1            | hmheng-report   | hmheng-repo | 21035 | reporting |
|                     |                 | rt/staging1 |       | -api.cert |
|                     |                 | /scoring-ap |       | .br.hmhen |
|                     |                 | i           |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+

CertRV
------

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| staging2            | hmheng-core-ser | hmheng-core | 22018 | assignmen |
|                     | vices           | -services/s |       | tapi-asyn |
|                     |                 | taging2/ass |       | c.certrv. |
|                     |                 | ignmentapi- |       | br.hmheng |
|                     |                 | async       |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22002 | idm-idp.c |
|                     |                 | staging2/id |       | ertrv.br. |
|                     |                 | p           |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22003 | idm-templ |
|                     |                 | staging2/te |       | ate-conve |
|                     |                 | mplate-conv |       | rters.cer |
|                     |                 | erters      |       | trv.br.hm |
|                     |                 |             |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22004 | idm-impor |
|                     |                 | staging2/im |       | t-workers |
|                     |                 | port-worker |       | .certrv.b |
|                     |                 | s           |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22005 | idm-basal |
|                     |                 | staging2/ba |       | -import-t |
|                     |                 | sal-import- |       | c.certrv. |
|                     |                 | tc          |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22006 | idm-basal |
|                     |                 | staging2/ba |       | -import-h |
|                     |                 | sal-import- |       | mof.certr |
|                     |                 | hmof        |       | v.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22007 | hmh-acces |
|                     |                 | staging2/hm |       | s.certrv. |
|                     |                 | h-access    |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22008 | idm-api-a |
|                     |                 | staging2/ap |       | dapters.c |
|                     |                 | i-adapters  |       | ertrv.br. |
|                     |                 |             |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22013 | admin-too |
|                     |                 | staging2/ad |       | l.certrv. |
|                     |                 | min-tool    |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22014 | idm-hmof- |
|                     |                 | staging2/hm |       | api.certr |
|                     |                 | of-api      |       | v.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-idm      | hmheng-idm/ | 22015 | idm-ids.c |
|                     |                 | staging2/id |       | ertrv.br. |
|                     |                 | s           |       | hmheng.io |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-clm      | hmheng-clm/ | 22032 | eventserv |
|                     |                 | staging2/?? |       | ice.certr |
|                     |                 | ?           |       | v.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-clm      | hmheng-clm/ | 22033 | flink-pip |
|                     |                 | staging2/?? |       | eline.cer |
|                     |                 | ?           |       | trv.br.hm |
|                     |                 |             |       | heng.io   |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-score    | hmheng-scor | 22036 | scoring-a |
|                     |                 | e/staging2/ |       | pi.certrv |
|                     |                 | scoring-api |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging2            | hmheng-report   | hmheng-repo | 22035 | reporting |
|                     |                 | rt/staging2 |       | -api.cert |
|                     |                 | /scoring-ap |       | rv.br.hmh |
|                     |                 | i           |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+

Cert2
-----

+---------------------+-----------------+-------------+-------+-----------+
| Environment Stage   | Aurora Role     | Zookeeper   | Inter | Hostname  |
|                     |                 | Server Set  | nal   |           |
|                     |                 |             | Port  |           |
+=====================+=================+=============+=======+===========+
| staging7            | hmheng-core-ser | hmheng-core | 27016 | notificat |
|                     | vices           | -services/s |       | ion-servi |
|                     |                 | taging7/not |       | ce.cert2. |
|                     |                 | ification-s |       | br.hmheng |
|                     |                 | ervice      |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27002 | idm-idp.c |
|                     |                 | staging7/id |       | ert2.br.h |
|                     |                 | p           |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27003 | idm-templ |
|                     |                 | staging7/te |       | ate-conve |
|                     |                 | mplate-conv |       | rters.cer |
|                     |                 | erters      |       | t2.br.hmh |
|                     |                 |             |       | eng.io    |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27004 | idm-impor |
|                     |                 | staging7/im |       | t-workers |
|                     |                 | port-worker |       | .cert2.br |
|                     |                 | s           |       | .hmheng.i |
|                     |                 |             |       | o         |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27005 | idm-basal |
|                     |                 | staging7/ba |       | -import-t |
|                     |                 | sal-import- |       | c.cert2.b |
|                     |                 | tc          |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27006 | idm-basal |
|                     |                 | staging7/ba |       | -import-h |
|                     |                 | sal-import- |       | mof.cert2 |
|                     |                 | hmof        |       | .br.hmhen |
|                     |                 |             |       | g.io      |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27007 | hmh-acces |
|                     |                 | staging7/hm |       | s.cert2.b |
|                     |                 | h-access    |       | r.hmheng. |
|                     |                 |             |       | io        |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27008 | idm-api-a |
|                     |                 | staging7/ap |       | dapters.c |
|                     |                 | i-adapters  |       | ert2.br.h |
|                     |                 |             |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27013 | admin-too |
|                     |                 | staging7/ad |       | l.certrv. |
|                     |                 | min-tool    |       | br.hmheng |
|                     |                 |             |       | .io       |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27014 | idm-hmof- |
|                     |                 | staging7/hm |       | api.certr |
|                     |                 | of-api      |       | v.br.hmhe |
|                     |                 |             |       | ng.io     |
+---------------------+-----------------+-------------+-------+-----------+
| staging7            | hmheng-idm      | hmheng-idm/ | 27015 | idm-ids.c |
|                     |                 | staging7/id |       | ert2.br.h |
|                     |                 | s           |       | mheng.io  |
+---------------------+-----------------+-------------+-------+-----------+
