.. _linkerd:

Linkerd (DEPRECATED)
====================

Deployment
----------

Linkerd is a service installed from an RPM. Monit is watching the service to ensure it stays running.


RPM
~~~

Linkerd does not offer a RPM install so we have built our own using ``fpm``. To build a new Linkerd RPM run the `jenkins job`_
To find the current `linkerd releases`_

Logs
~~~~

Logs for Linkerd can be found on the machine under ``/var/log/linkerd/linkerd.log``

Config
~~~~~~

The config is also stored in io.hmheng.platform repo under `config.yaml`_


- The main Terraform configuration lives in `linkerd.tf`_
- The endpoints for active cluster lives in `linkerd-role-endpoints.tf`_
- Saltstack configuration is split into `linkerd pillar`_ and `linkerd state`_

.. _linkerd releases: https://github.com/linkerd/linkerd/releases/
.. _jenkins job: http://jenkins.prod.hmheng-infra.brnp.internal/job/linkerd-rpm/
.. _linkerd.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-cluster/linkerd.tf
.. _linkerd-role-endpoints.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/linkerd-role-endpoints.tf
.. _linkerd pillar: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/pillars/linkerd/init.sls
.. _linkerd state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/linkerd
.. _config.yaml: https://github.com/hmhco/io.hmheng.platform/blob/develop/saltstack/states/linkerd/files/etc/linkerd/config.yaml

Haproxy
~~~~~~~

Haproxy is the initial ingress for all requests. Haproxy will provide SSL termination for all requests along with heading scrubbing for external requests.

All requests sent into Haproxy / Linkerd must use Https, any requests on port 80 will be redirected to 443 automatically.

Internal
^^^^^^^^

The NLB (network load balancer) will take in two different patterns:

- ``api.<stage>.br.internal`` and prod ``api.br.internal``

For internal requests the api endpoint will route both explicitly and implicitly, using path routing.
It will route for all application based on path /role/stage/app for example ``https://api.br.internal/hmheng-infra/prod/doc-server`` would route to the doc-server.
We also allow for single path routing to mirror external usage, such as ``https://api.br.internal/foo`` which can be be mapped to any application. This must be done explicitly and a request is required to add a new route.
When you the api endpoint your application must be able to handel the extra path, ie ``https://api.br.internal/role/stage/app/health`` your application must be able to route this to /health


- ``<application>.<stage>.<role>.br.internal``

Application stage and role and exactly how they are found in aurora.
For example, this site is `doc-server`_ which means is aurora there is a tasks which match the `aurora-task`_

External
^^^^^^^^

- ``api.<stage>.eng.hmhco.com`` and prod ``api.eng.hmhco.com``

For external requests the api endpoint will route both explicitly using path routing.
We also allow for single path to route to any application, such as ``https://api.br.internal/foo`` which can be be mapped to any application. This must be done explicitly and a request is required to add a new route.


.. _doc-server: https://doc-server.prod.hmheng-infra.br.internal
.. _aurora-task: https://aurora.br.hmheng.io/scheduler/hmheng-infra/prod/doc-server

Dtabs
~~~~~

Dtabs define how the requests are routed. The initial ingress on Haproxy is handled by two Dtabs ``haproxy`` for internal and ``haproxy-ext`` for external.
These Dtabs provide context into the request and will route to the appropriate downstream router (sidecar routers).

The internal will identify the request based on domain and route to the right stage router which are announcing to zookeeper.

internal-dtab: ::

    /host                                   => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-sidecar ;
    /internal/br/dev/api                    => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-dev-api ;
    /internal/br/int/api                    => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-int-api ;
    /internal/br/cert/api                   => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-cert-api ;
    /internal/br/api                        => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-prod-api ;
    /internal/br/hmheng-dmps/devel/dmps     => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/staging1/dmps  => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/staging0/dmps  => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /internal/br/hmheng-dmps/prod/dmps      => /#/io.l5d.serversets/discovery/linkerd-announcer/hmheng-infra/prod/linkerd-plugin ;
    /host                                   => /$/io.buoyant.http.domainToPath ;
    /http/1.1/*                             => /host ;

Dtab priority is bottom up, first it will try for a dmps application to use the plugin router.
If not matching dmps it will try and match to an api and use that stages api router.
Finally if none of the above is matched we send it downstream and allow to sidecar to route ``$APPLICATION.$STAGE.$ROLE.br.internal``

The external is similar but there is no fall though sidecar, then the api routers will only route explicitly, meaning if it doesnt match it will drop the request.

Mesos sidecar pattern
~~~~~~~~~~~~~~~~~~~~~

All Mesos agents run Linkerd, this allows for high availability with 75+ instance of Linkerd running.
This also allows for applications to make local calls and hit Linkerd directly, rather then going out to load balencer and back in.


Each non-prod and prod load balancer have their own target groups and will only direct traffic to agents of their group.


Upstream collaborator
---------------------

Namerd
~~~~~~

Namerd is a service that manages routing for multiple Linkerd instances. It does this by storing dtabs and using namers for service discovery.
Using Namerd means a small cluster of jobs need to talk directly to the service discovery backends instead of every linkerd instance.
By storing dtabs in Namerd instead of hardcoding them in the Linkerd configs, it ensures that routing policy is in sync across the instances and gives you one central place when you need to make changes.


For more information on :ref:`namerd` read the docs!
