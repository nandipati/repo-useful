.. _lifecycle-service:

Lifecycle service
=================

Lifecycle service is an internal bedrock service that tries to make replacing
instances as safe and easy as possible. The service itself has a database backend
where all the state is stored.

At the moment lifecycler service (2018-07-10) doesn't support all instance types,
but we are constantly adding more supported services.

Deployment
----------

.. blockdiag::

   blockdiag {
     service[label="Lifecycle Service"]
     elb[label="elb/ssl termination"]
     cli[label="Lifecycle cli"]
     user[label="User", shape="actor"]
     webui[label="Web UI"]
     db[label="Postgres db", shape="flowchart.database"]

     user -> cli
     user -> webui
     webui -> elb
     cli -> elb
     elb -> service
     service -> db

     group uis {
       label = "User Interfaces"
       cli, webui
     }

     group lifecycler {
       label = "Service components"
       orientation = "portrait"
       service, db
     }

     default_group_color = "lightgray"
   }

There is an load balancer infront of lifecycle service for SSL termination. At the moment
the certs are missing from the elb, so ssl encryption is not enabled at the moment.

The only thing that the service exposes is a REST API that binds to port :code:`80` on the
instance. This is configurable.

Access rights
*************

Lifecycle service needs quite a bit of IAM access rights in order to complete all the different
types of lifecycling actions, and this needs to be kept in mind when creating new lifecyclers.

Upstream collaborators
----------------------

- Git repository: https://github.com/hmhco/io.hmheng.lifecycle/
- Jenkins job: http://jenkins.prod.hmheng-infra.brnp.internal/job/br-lifecycle-service-rpm/

Authentication
--------------

Authentication is configured in the main config file that (when deployed) lies in
:code:`/etc/lifecycle/service.ini` and is configured by salt.

Lifecycle service itself authenticates against databse (postgres) and requires authentication on
the REST API. The REST API authentication credentials are configured in the same file.

Artifacts
---------

All the artifacts (rpms) are created by jenkins and pushed to artifactory for future usage. Versioning
is read from :code:`setup.py` and should be bumped every time a new version is released.

The version to be installed is configured in salt pillars.

- br-lifecycle-service-<version>-1.noarch.rpm


Database schema migrations
--------------------------

Lifecycle service uses sqlalchemy as ORM and alembic to handle schema migrations. Migrations are applied
automatically when new version of lifecycle service is deployed into production.

- Alembic: http://alembic.zzzcomputing.com/en/latest/
- SQLAlchemy: https://www.sqlalchemy.org/

Alembic is baked inside the pexfile, with the application itself, so there is no need to separately install
it.

Configuration
-------------

All lifecycle service configurations are in a single :code:`lifecycle-config.ini` which in production is
located in :code:`/etc/lifecyc/service.ini`. This file is populated by salt.

The main things to configure are database address, database username and password. This way the application
can start, but cannot yet lifecycle anything unless elasticserach, mesos, aurora etc. have been configured
correctly.

Logs
----

Logs are located in :code:`/var/logs/lifecycle`
