Environment Overview
====================

AWS
---

vpc
~~~

overview
^^^^^^^^

Bedrock is currently split into 2 AWS hosted VPCS, brnpa and brnpb, with
only one active vpc at a time. This configuration enables the ability to
do canary or green/blue deployments for major architecture changes such
as vpc reconfiguration (subnets, routes, etc...), major mesos/aurora
changes (tc/network isolation options), etc...

BRCORE01 - 10.35.0.0/18 / vpc-87d95ce0
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

SUBNETS

+-----------------------------------------+--------------+---------------+---------------+
| Subnet Role                             | us-east-1b   | us-east-1c    | us-east-1e    |
+=========================================+==============+===============+===============+
| public                                  | 10.35.0.0/24 | 10.35.16.0/24 | 10.35.32.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| public restricted (nat gateways)        | 10.35.1.0/24 | 10.35.17.0/24 | 10.35.33.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| core infra 01 (salt, dns, efs, bastion) | 10.35.2.0/24 | 10.35.18.0/24 | 10.35.34.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| core infra 02 (zk, es, jenkins, artif)  | 10.35.3.0/24 | 10.35.19.0/24 | 10.35.35.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| service infra 01 (gatling/other)        | 10.35.4.0/24 | 10.35.20.0/24 | 10.35.36.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| service infra 02 (database/cache)       | 10.35.5.0/24 | 10.35.21.0/24 | 10.35.37.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| service public 01 (gatling only)        | 10.35.6.0/24 | 10.35.22.0/24 | 10.35.38.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| proxy internal                          | 10.35.7.0/24 | 10.35.23.0/24 | 10.35.39.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+
| proxy external                          | 10.35.8.0/24 | 10.35.24.0/24 | 10.35.40.0/24 |
|                                         |              |               |               |
+-----------------------------------------+--------------+---------------+---------------+

ROUTE TABLES

+---------------------+-------------------------+
| Name                | Associated Subnet CIDRs |
+=====================+=========================+
| brcore01-public     | 10.35.0.0/24,           |
|                     | 10.35.16.0/24,          |
|                     | 10.35.32.0/24,          |
|                     | 10.35.1.0/24,           |
|                     | 10.35.17.0/24,          |
|                     | 10.35.33.0/24,          |
|                     | 10.35.6.0/24,           |
|                     | 10.35.22.0/24,          |
|                     | 10.35.38.0/24           |
|                     |                         |
+---------------------+-------------------------+
| brcore01-us-east-1b | 10.35.2.0/24,           |
|                     | 10.35.3.0/24,           |
|                     | 10.35.4.0/24,           |
|                     | 10.35.5.0/24            |
|                     |                         |
+---------------------+-------------------------+
| brcore01-us-east-1c | 10.35.18.0/24,          |
|                     | 10.35.19.0/24,          |
|                     | 10.35.20.0/24,          |
|                     | 10.35.21.0/24           |
|                     |                         |
+---------------------+-------------------------+
| brcore01-us-east-1e | 10.35.34.0/24,          |
|                     | 10.35.35.0/24,          |
|                     | 10.35.36.0/24,          |
|                     | 10.35.37.0/24           |
|                     |                         |
+---------------------+-------------------------+

NAT GATEWAYS

+-------------------+---------------+---------------------+-------------------+-------------------------------+
| Availability Zone | Subnet CIDR   | Route Table         | Route Destination | Detail                        |
|                   |               |                     |                   |                               |
+===================+===============+=====================+===================+===============================+
| us-east-1b        | 10.35.1.0/24  | brcore01-us-east-1b | 0.0.0.0/0         | ext access from 1b instances  |
|                   |               |                     |                   |                               |
+-------------------+---------------+---------------------+-------------------+-------------------------------+
| us-east-1c        | 10.35.17.0/24 | brcore01-us-east-1c | 0.0.0.0/0         | ext access from 1c  instances |
|                   |               |                     |                   |                               |
+-------------------+---------------+---------------------+-------------------+-------------------------------+
| us-east-1e        | 10.35.33.0/24 | brcore01-us-east-1e | 0.0.0.0/0         | ext access from 1e  instances |
|                   |               |                     |                   |                               |
+-------------------+---------------+---------------------+-------------------+-------------------------------+

DNS

+-------------------+---------------+------------------------------------------------+
| Zone              | Forward To    | Detail                                         |
+===================+===============+================================================+
| brcore01.internal | 10.35.0.2     | aws provided dns (vpc internal & all external) |
|                   |               |                                                |
+-------------------+---------------+------------------------------------------------+
| brnpa.internal    | 10.32.97.10,  | brnpa dns forwarder instances                  |
|                   | 10.32.101.10, |                                                |
|                   | 10.32.105.10  |                                                |
|                   |               |                                                |
+-------------------+---------------+------------------------------------------------+
| brnpb.internal    | 10.32.113.10, | brnpb dns forwarder instances                  |
|                   | 10.32.117.10, |                                                |
|                   | 10.32.121.10  |                                                |
|                   |               |                                                |
+-------------------+---------------+------------------------------------------------+
| hmh internal      | 10.33.7.54,   | hmh dns servers                                |
|                   | 10.33.20.192  |                                                |
|                   |               |                                                |
+-------------------+---------------+------------------------------------------------+

BRNPA
^^^^^

+----------------------------------+-----------------+------------------+------------------+
| Subnet Role                      | us-east-1b      | us-east-1c       | us-east-1e       |
+==================================+=================+==================+==================+
| bastion                          | 10.32.96.0/28   | 10.32.100.0/28   | 10.32.104.0/28   |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| deployment console               | 10.32.96.16/28  | 10.32.100.16/28  | 10.32.104.16/28  |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| nat gateways / public restricted | 10.32.96.32/27  | 10.32.100.32/27  | 10.32.104.32/27  |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| internal elbs 01                 | 10.32.96.64/26  | 10.32.100.64/26  | 10.32.104.64/26  |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| rds                              | 10.32.96.128/26 | 10.32.100.128/26 | 10.32.104.128/26 |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| elasticache                      | 10.32.96.192/26 | 10.32.100.192/26 | 10.32.104.192/26 |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| public elbs 01                   | 10.32.97.0/24   | 10.32.101.0/24   | 10.32.105.0/24   |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| infrastructure                   | 10.32.97.0/24   | 10.32.102.0/24   | 10.32.106.0/24   |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| web services - non prod          | 10.32.99.0/25   | 10.32.103.0/25   | 10.32.107.0/25   |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| web services - prod              | 10.32.99.128/25 | 10.32.103.128/25 | 10.32.107.128/25 |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+
| internal elbs 02                 | 10.32.109.0/24  | 10.32.110.0/24   | 10.32.111.0/24   |
|                                  |                 |                  |                  |
+----------------------------------+-----------------+------------------+------------------+

BRNPB
^^^^^

**Note: prod mesos agents are running in "web services - prod" subnets**

+----------------------------------+------------------+------------------+------------------+
| Subnet Role                      | us-east-1b       | us-east-1c       | us-east-1e       |
+==================================+==================+==================+==================+
| bastion                          | 10.32.112.0/28   | 10.32.116.0/28   | 10.32.120.0/28   |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| deployment console               | 10.32.112.16/28  | 10.32.116.16/28  | 10.32.120.16/28  |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| nat gateways / public restricted | 10.32.112.32/27  | 10.32.116.32/27  | 10.32.120.32/27  |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| internal elbs 01                 | 10.32.112.64/26  | 10.32.116.64/26  | 10.32.120.64/26  |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| rds                              | 10.32.112.128/26 | 10.32.116.128/26 | 10.32.120.128/26 |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| elasticache                      | 10.32.112.192/26 | 10.32.116.192/26 | 10.32.120.192/26 |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| public elbs 01                   | 10.32.113.0/24   | 10.32.117.0/24   | 10.32.121.0/24   |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| infrastructure                   | 10.32.114.0/24   | 10.32.118.0/24   | 10.32.122.0/24   |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| web services - non prod          | 10.32.115.0/25   | 10.32.119.0/25   | 10.32.123.0/25   |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| web services - prod              | 10.32.115.128/25 | 10.32.119.128/25 | 10.32.123.128/25 |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+
| internal elbs 02                 | 10.32.125.0/24   | 10.32.126.0/24   | 10.32.127.0/24   |
|                                  |                  |                  |                  |
+----------------------------------+------------------+------------------+------------------+

nat
^^^

The bedrock VPCs utilize the aws nat gateway service for all externally
routed traffic from internal subnets. This service adds aws managed high
availability and the ability to burst up to 10 Gbps of bandwidth and is
secured via network access control lists (nacl) associated with the
subnets that the service is hosted in. Click
`here <http://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/vpc-nat-gateway.html>`__
for more information about aws nat gateway service.

dns
^^^

**coming soon**

Apache Zookeeper
----------------

overview
~~~~~~~~

"ZooKeeper is a centralized service for maintaining configuration
information, naming, providing distributed synchronization, and
providing group services." This is the service discovery component of
the bedrock stacks and is currently used by mesos masters, mesos agents,
aurora scheduler, aurora observer, finagle proxy nodes, and at least one
hmh service that was designed as a mesos framework. Zookeeper ensures
that the configurations, or server sets, that are shared by these
bedrock components remain in sync and remain highly available. Click
`here <https://zookeeper.apache.org/>`__ to read more about apache
zookeeper.

bedrock architecture
^^^^^^^^^^^^^^^^^^^^

Zookeeper nodes are split in to two types, zookeeper server & zookeeper
observers. There are currently 5 zookeeper server nodes, with a quorum
of 3, that are spread across 3 availability zones. These server nodes do
have election abilities and their current role is to accept write
requests. All read requests are directed to the 3 current zookeeper
observers, which do not have election abilities. The reason for this
configuration to to reduce load on the zookeeper servers by reading all
config data from the observers, which can be referred to as commodity
instances and easily increased/decreased without affecting quorum or the
zookeeper cluster functionality.

.. blockdiag::

   blockdiag {
     class zkm [ label = "zookeeper\nmaster\n0.0.0.0.2181" ];
     class zko [ label = "zookeper\nobserver\n127.0.0.1:2181" ];
     class fin [ label = "finagle" ];
     class por [ label = "proxy instance" ];

     zkm_0, zkm_1, zkm_2, zkm_3, zkm_4 [ class = "zkm" ];

     zko_0 [ class ="zko", stacked ];

     fin_0 [ class = "fin", stacked ];

     zkm_0 -- zkm_1, zkm_2, zkm_3, zkm_4;

     zkm_2 <- zko_0 [ folded ];

     zko_0 <- fin_0;

     group {
       color = "#4C6C8F";
       zkm_1; zkm_2; zkm_3;
       label = "Minimal Quorum";

       group {
         color = "#CFDCED";
         zkm_2;
         label = "Leader";
       }

     }

     group {
       color = "#BBBBBB";
       fin_0;
       zko_0;
       class = "por";
       orientation = "portrait";
     }

   }

Apache Mesos
------------

overview
~~~~~~~~

"Apache Mesos abstracts CPU, memory, storage, and other compute
resources away from machines (physical or virtual), enabling
fault-tolerant and elastic distributed systems to easily be built and
run effectively." This allows ec2 instance resources across 1 to n
availability zones (3 for bedrock) to be combined, then offered as
resources would be from a single instance. See mesos
`website <http://mesos.apache.org/>`__ for full details about mesos
architecture.

bedrock architecture
~~~~~~~~~~~~~~~~~~~~

Mesos nodes are also split into two types, mesos master nodes & mesos
agent nodes. There are currently 5 mesos master nodes, with a quorum of
3, that are spread across 3 availability zones. Only one mesos master is
elected at a time and the elected master config is hosted & maintained
in zookeeper for access by mesos agent nodes and aurora master nodes.
The master node manages mesos agent nodes and is responsible for sending
resource offers to the registered frameworks (ie. apache aurora) based
on the resources available on each mesos agent node. The mesos master
nodes also do serve a SSL encrypted GUI over port 5050 that provides an
easy method of viewing registered frameworks, registered mesos agents,
incoming resource offers and available resources. The GUI also provides
a quick redirect to the mesos agent hosting the mesos job for access to
sandbox files (logs, executors, etc...).

The mesos agent nodes host all running mesos jobs, which can consist of
docker containers, cron jobs, jar files, or any other type of job that
can be scheduled via a mesos framework. Any application or service that
has been deployed to bedrock is running on one of these nodes. The mesos
agent nodes are also spread across 3 availability zones and are split
into standard nonprod, standard prod, and spot non prod clusters (spot
not yet used). The cluster that the application/service is deployed to
is defined as a constraint in the aurorafile associated with the
application/service deployment. The mesos agent instance count does
change frequently, so exact amount will not be documented here.

Apache Aurora
-------------

overview
~~~~~~~~

Apache Aurora is made up of scheduler, client, executor, and observer
components. The scheduler is a mesos framework that is responsible for
accepting job offers made by mesos and assigning jobs, services, or
tasks based on deployments made via the aurora client with aurorafile.
The aurora scheduler runs as a service on the same ec2 instance nodes as
the mesos master service and utilize zookeeper to write aurora configs
and read mesos configs.

The aurora client is a command line utility that is used to deploy jobs,
tasks, or services defined in the pystachio based aurorafiles. Commonly
used commands are ``aurora job start`` and ``aurora update start``. The
client also has an admin utility that allows users with appropriate
permissions to set/adjust role quotas, put agent nodes into maintenance
node, and many other maintenance level tasks.

The aurora executor is automatically deployed to any properly configured
docker or thermos containerized tasks. The executor is a requirement for
any task to function to work with the aurora scheduler, because it is
the component that talks with the scheduler and observer to confirm that
task is running or not running. The executor also has some dependencies,
so it is important to use the base containers that have been provided
specifically for bedrock.

The aurora observer serves a web based gui that is used to access the
status of tasks that have been executed on mesos agent nodes. This gui
is commonly used to view specific task container logs.

A fantastic diagram that outlines all aurora components is available
`here <http://aurora.apache.org/documentation/latest/getting-started/overview/>`__.

.. figure:: http://aurora.apache.org/documentation/latest/images/components.png
   :alt:

.. figure:: http://aurora.apache.org/documentation/latest/images/aurora_hierarchy.png
   :alt:

bedrock infrastructure
~~~~~~~~~~~~~~~~~~~~~~

**coming soon**
