Kibana
======

Kibana is an application that lets you visualize Elasticsearch data and navigate
the Elastic Stack. In bedrock terms this means that you can filter out only the
relevant log messages from certain period of time with relative ease.

Deployment
----------

.. blockdiag::

  blockdiag {
    orientation = portrait;
    mesos[label="mesos",stacked];
    aurora[label="aurora"];
    docker[label="docker container"];
    user[label="user", shape=actor];
    elasticsearch[label="Elastic Search", shape=flowchart.database];

    aurora -> mesos [label=schedules, fontsize="8"];
    user -> aurora [label=issues, fontsize="8"];
    mesos -> docker [label=starts];
    user -> kibana [label=accesses, fontsize="8"];
    kibana -> elasticsearch [label=queries];
  }

Artifacts
~~~~~~~~~

Kibana gets bundled in a docker image and is run in a docker container on top of
mesos. Building the docker image happens manually at the moment because of
version differences and very unfrequent updates.

Current Kibana is located in `docker/kibana/4.5.1`_ and can be built by
accessing the folder and running
``docker build -t docker.br.hmheng.io/io-hmheng-infra/kibana:4.5.1 .``

.. note::
   Kibana version is heavily tied into running elasticsearch version. When
   updating Kibana make sure to verify that the new version of Kibana works with
   the existing version of Elastic Search. Also verify the upgrade pattern.
   https://www.elastic.co/guide/en/kibana/current/upgrade.html

.. _docker/kibana/4.5.1: https://github.com/hmhco/io.hmheng.platform/tree/develop/docker/kibana/4.5.1

Configuration
~~~~~~~~~~~~~

All the relevant configuration is in `aurorafile`_::

  echo "logging.dest: stdout" >> /opt/kibana/config/kibana.yml && \
  echo "server.port: {{thermos.ports[http]}}" >> /opt/kibana/config/kibana.yml && \
  echo "elasticsearch.url: https://{{profile.bedrock_env}}-es.br.hmheng.io" >> /opt/kibana/config/kibana.yml && \
  echo "elasticsearch.requestTimeout: 300000" >> /opt/kibana/config/kibana.yml && \
  cat /opt/kibana/config/kibana.yml \

What happens there:

1. Log to stdout
2. Use the port assigned by thermos
3. Set elasticsearch address
4. Increase elasticsearch request timeout

All the configurations are written to ``kibana.yml`` configuration file.

Other configurations that are passed to kibana executable are
``NODE_OPTIONS="--max-old-space-size=768``

.. _aurorafile: https://github.com/hmhco/io.hmheng.platform/blob/develop/docker/kibana/4.5.1/kibana451.aurora

Networking
~~~~~~~~~~

Kibana needs access from mesos agents to elasticsearch cluster.

Playbook
--------

Kibana deployment follows the normal pattern of deploying any mesos task.

1. Make sure that kibana docker image is available in artifactory.
2. Login to deployment server (``ssh hmheng-infra@brnpb-deploy.br.hmheng.io``).
3. Copy `aurorafile`_ to deployment server
4. Run ``aurora update start brnpb-us-east-1/hmheng-infra/prod/kibana
   kibana.aurora --bind tag=4.5.11``
5. Access kibana ``https://kibana.br.hmheng.io/``
