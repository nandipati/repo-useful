Keepsake-daemon
===============

Managing certificates from vault.

Overview
--------

.. blockdiag::

        blockdiag {
                keepsake-daemon -> "keepsake instance" <-> vault
                "keepsake instance" [stacked]
                vault [shape = flowchart.database]
         }

`Keepsake-daemon`_ is a collection of upstart instances running `keepsake`_. They're supposed to get ssl-certificates from vault and update them as needed.

Usage
-----

Include `keepsake.daemon` state and instantiate the macro. Here is an example how to do it with consul:

.. code-block:: salt

        ---
        # {% set keepsake = salt['pillar.get']('consul:config:keepsake', '') %}
        # {% from 'keepsake/daemon/init.sls' import monitored with context %}
        include:
          - keepsake.daemon

        {{ monitored('consul',
          keepsake.vault_role,
          keepsake.vault_path,
          keepsake.cn,
          keepsake.certFile,
          keepsake.keyFile,
          keepsake.caFile,
          keepsake.certTTL,
          keepsake.cmd) }}

.. _Keepsake-daemon: https://github.com/hmhco/io.hmheng.platform/tree/develop/packages/keepsake-daemon/
.. _keepsake: https://github.com/hmhco/keepsake
