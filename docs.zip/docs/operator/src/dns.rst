DNS
===

We run our own DNS servers to work around poorly performing HMH nameservers.

Deployment
----------

.. blockdiag::

   blockdiag {
     asg1[label = "ASG 1"]
     asg2[label = "ASG 2"]
     asg3[label = "ASG 3"]
     
     dns1[label = "DNS 1"]
     dns2[label = "DNS 2"]
     dns3[label = "DNS 3"]
   
     eni1[label = "ENI 1"]
     eni2[label = "ENI 2"]
     eni3[label = "ENI 3"]
   
     dhcp[label = "VPC DHCP options"]
     
     asg1 -> dns1 -> eni1 <- dhcp
     asg2 -> dns2 -> eni2 <- dhcp
     asg3 -> dns3 -> eni3 <- dhcp
   
     group asgs {
       label = "autoscaling groups"
       asg1, asg2, asg3
     }
   
     group instances {
       label = "instances"
       dns1, dns2, dns3
     }
   
     group eni {
       label = "ENIs"
       eni1, eni2, eni3
     }
   
     default_group_color = "lightgray"
   }

We deploy DNS instances to three availability zones, and each instance is
governed by an auto scaling group. Each instance has an associated elastic
network interface, which is used to give the DNS instances a static IP address.

VPC DHCP options are configured to point to our DNS servers using the static IP
addresses assigned to the elastic network interfaces.

Currently we run DNS servers both in the ref:`core-vpc` and in the
ref:`cluster-vpc`, but we will eventually remove the DNS servers from the
Cluster VPC.

We use ``named`` as our DNS server.

Bootstrapping
~~~~~~~~~~~~~

Because all other instances depend on functional DNS, the DNS servers must be
stood up before everything else, and consequently ``named`` must be configured
even before ref:`salt-master` is running. Therefore, we've build a bespoke DNS
AMI, that is able to configure itself just enough to provide DNS for the Salt
master. After Salt master is running, it will provide final configuration for
the DNS instances.

Upstream Collaborators
~~~~~~~~~~~~~~~~~~~~~~

All other EC2 instances and VPC bound Lambdas depend on the DNS.

Artifacts
~~~~~~~~~

DNS servers are deployed using a custom AMI built using Packer. AWS resources
are configured using Terraform, and SaltStack is used for most of the
configuration.

- `DNS AMI`_ is built using Packer
- Terraform configuration lives in `dns.tf`_
- SaltStack configuration is split into `dns pillar`_ and `dns state`_

.. _DNS AMI: https://github.com/hmhco/io.hmheng.platform/blob/develop/packer/dns-base
.. _dns.tf: https://github.com/hmhco/io.hmheng.platform/blob/develop/terraform-base/dns.tf 
.. _dns pillar: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/pillars/dns
.. _dns state: https://github.com/hmhco/io.hmheng.platform/tree/develop/saltstack/states/dns

Configuration
~~~~~~~~~~~~~

``named`` configuration is located in ``/etc/named.conf``.

Logs
~~~~

``named`` logs are included in ``/var/log/messages``.

Backups
~~~~~~~

DNS servers are stateless beyond their configuration, and therefore there is
nothing to backup.
