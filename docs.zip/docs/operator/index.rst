Bedrock documentation
=====================

Developing Bedrock
------------------

.. toctree::
   :maxdepth: 2

   src/repos
   src/artifactory
   src/bot-accounts
   src/br-core-dev
   src/centralized-logging
   src/creating-a-dependency-graph-from-salt-highstate
   src/deployed-application-details
   src/deployed-applications
   src/adding-a-teams-role
   src/dns
   src/doctorkafka
   src/elasticsearch
   src/environment-overview
   src/gnotify
   src/image-independent-thermos-executor-hack
   src/kafka
   src/keepsake-daemon
   src/kibana
   src/ldap-access---auth0
   src/ldap-access---okta
   src/lifecycle-cli
   src/lifecycle-service
   src/sherpa
   src/namerd
   src/influxdb
   src/openvpn
   src/packer
   src/playbook
   src/recovering-aurora-from-backup
   src/replacing-mesos-aurora-masters
   src/team-jenkins
   src/upgrading-aurora-mesos-cluster
   src/zookeeper
   src/backups

Meta
====

.. toctree::
   :maxdepth: 2

   src/meta.rst
   src/howto-make-screencasts

Security
--------

.. toctree::
   :maxdepth: 2

   src/security/customer-facing

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
