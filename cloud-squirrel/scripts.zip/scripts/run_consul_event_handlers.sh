#!/bin/bash
consul watch -type=checks -http-addr=$1:$2 /usr/local/bin/consul_event_handler.sh
