cs quota init  rcscorenp--rcs_infra--cpu 8000
cs quota init  rcscorenp--rcs_infra--memory 17000

cs quota init  rcscorenp--qa-automation--cpu 2800
cs quota init  rcscorenp--qa-automation--memory  10000

cs quota init  rcscorenp--easycbm-services--cpu 8800
cs quota init  rcscorenp--easycbm-services--memory  15000

cs quota init  rcscorenp--adaptive-services--cpu 8800
cs quota init  rcscorenp--adaptive-services--memory  15000
