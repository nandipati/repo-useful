VAULT_HOST=http://127.0.0.1:8200
VAULT_TOKEN=80aab5d7-2e72-e0e5-45d7-780cade98e9d

curl -k -X GET $VAULT_HOST/v1/secret/data/infrastructure -H "X-Vault-Token: $VAULT_TOKEN"
