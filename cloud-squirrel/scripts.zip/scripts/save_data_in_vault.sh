#!/bin/bash

VAULT_HOST=http://127.0.0.1:8200
VAULT_TOKEN=ca1b03ab-ab21-6d2d-dd33-d0675184f37b


tee payload.json <<EOF
{
  "data": {
    "key": "KIDKIDKDIDIDKD"
  }
}
EOF

curl -v --header "X-Vault-Token: $VAULT_TOKEN" --request POST \
       --data @payload.json \
       $VAULT_HOST/v1/secret/data/rcs-infrastructure/awskid

rm -rf payload.json
