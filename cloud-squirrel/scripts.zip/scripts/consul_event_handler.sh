#!/usr/bin/env sh

cat > /dev/null

update_quotas_usage