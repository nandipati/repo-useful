#!/bin/bash

AWSKID=$1
AWSSAK=$2
REGION=$3

 export AWS_ACCESS_KEY_ID=$AWSKID
   export AWS_SECRET_ACCESS_KEY=$AWSSAK
  aws acm import-certificate --region=$REGION --certificate file://certificate.pem --private-key file://private.key --certificate-chain file://ca_chain.key
