#!/bin/bash

VAULT_ADDR=$1
VAULT_TOKEN=$2
VAULT_ROLE=$3
DOMAIN_NAME=$4
TIME_TO_LIVE=$5

export VAULT_ADDR=$VAULT_ADDR
export VAULT_TOKEN=$VAULT_TOKEN
vault write -format=json pki_int/issue/$VAULT_ROLE   common_name=$DOMAIN_NAME ttl=$TIME_TO_LIVE > cert.json

cat cert.json | jq -r .data.certificate > certificate.pem
cat cert.json | jq -r .data.private_key > private.key
cat cert.json | jq -r .data.ca_chain[0,1]  > ca_chain.key

