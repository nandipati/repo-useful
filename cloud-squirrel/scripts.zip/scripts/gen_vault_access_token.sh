#!/bin/bash

# Example roles: infrastructure, scoring, data_manager
ROLE=$1

VAULT_HOST=http://vault:8200
VAULT_TOKEN=`curl -sS  consul:8500/v1/kv/rcsnp/u?raw`


# Payload to pass in the API call
tee payload.json <<EOF
{
  "policy": "path \"secret/$ROLE\" { capabilities = [\"create\", \"read\", \"update\", \"delete\", \"list\"] }"
}
EOF

# Create  policy
curl -v --header "X-Vault-Token: $VAULT_TOKEN" --request PUT \
       --data @payload.json \
       $VAULT_HOST/v1/sys/policy/$ROLE-policy

rm -rf payload.json

# Generate a new token with the created policy
curl -v --header "X-Vault-Token: $VAULT_TOKEN" --request POST \
       --data "{\"policies\": [\"$ROLE-policy\"]}" \
       $VAULT_HOST/v1/auth/token/create | jq
