
--Role creation query:
----------------------

CREATE USER vagrant WITH
  PASSWORD 'vagrant'
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  CREATEROLE
  NOREPLICATION;

--Database creation query:
------------------------

CREATE DATABASE "reporting"
    WITH
    OWNER = vagrant
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;




