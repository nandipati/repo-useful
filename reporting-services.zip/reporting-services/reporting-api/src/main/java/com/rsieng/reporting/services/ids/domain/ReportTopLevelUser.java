package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/11/19.
 */
@Data
public class ReportTopLevelUser extends User {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("level")
  private String level;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("testEvents")
  private List<TestEvent> testEvents;
}
