package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

import java.util.List;

/**
 * Created by nandipatim on 4/7/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestScore implements Serializable{

  @JsonProperty("id")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Integer id;

  @JsonProperty("stanadrdScore")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Integer stanadrdScore;

  @JsonProperty("scores")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<Score> scores;

}
