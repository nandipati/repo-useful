package com.rsieng.reporting.graphql;

import graphql.ExecutionResult;
import java.util.Map;


public interface GraphQLExecutor {

  public ExecutionResult execute(String query, String authToken, String authCurrentDateTime, boolean enableTracing,
                                 boolean introspectionQuery);

  public ExecutionResult execute(String query, String operation, String authToken, String authCurrentDateTime,
                                 boolean enableTracing, Map<String, Object> parameters, boolean introspectionQuery);

}
