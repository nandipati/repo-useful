package com.rsieng.reporting.graphql.resolvers.student;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.rsieng.reporting.services.ids.domain.Grade;
import com.rsieng.reporting.services.ids.domain.PerformanceBand;
import com.rsieng.reporting.services.ids.domain.Score;
import com.rsieng.reporting.services.ids.domain.StudentTestEvent;
import com.rsieng.reporting.services.ids.domain.TestScore;
import com.rsieng.reporting.services.ids.domain.User;
import graphql.schema.DataFetchingEnvironment;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserResolver implements GraphQLResolver<User> {

  public UserResolver(){}

  public StudentTestEvent getCurrentTestEvent(User user, Integer userId ,
                                              Integer testEventId , DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {


    log.info("Start of getCurrentTestEvent for UserResolver - Student Schema --> {} ", LocalDateTime.now());
    StudentTestEvent studentTestEvent = new StudentTestEvent();
    studentTestEvent.setTestEventId(1234);
    studentTestEvent.setTestEventName("Event1");
    studentTestEvent.setTestDate("2019-04-13T04:58:14.390Z");
    Grade grade = new Grade();
    grade.setName("3");
    studentTestEvent.setGrade(grade);
    TestScore testScore = new TestScore();
    testScore.setStanadrdScore(77);
    testScore.setId(1);
    List<Score> scores = new ArrayList<>();
    Score score = new Score();
    score.setId(1);
    score.setType("Q");
    score.setValue(100);
    List<PerformanceBand> performanceBands = new ArrayList<>();
    PerformanceBand performanceBand = new PerformanceBand();
    performanceBand.setId(2);
    performanceBand.setLower(1);
    performanceBand.setUpper(20);
    performanceBands.add(performanceBand);
    score.setPerformanceBands(performanceBands);
    testScore.setScores(scores);
    studentTestEvent.setTestScore(testScore);
    log.info("End of getCurrentTestEvent for UserResolver - Student Schema --> {} ", LocalDateTime.now());

    return studentTestEvent;
  }

  public List<StudentTestEvent> getTestEvents(User user , Integer userId , DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("Start of getTestEvents for UserResolver - Student Schema --> {} ", LocalDateTime.now());
    List<StudentTestEvent> studentTestEvents = new ArrayList<>();

    StudentTestEvent studentTestEvent1 = new StudentTestEvent();
    studentTestEvent1.setTestDate("2019-04-13T04:58:14.390Z");
    Grade grade = new Grade();
    grade.setName("3");
    studentTestEvent1.setGrade(grade);
    TestScore testScore = new TestScore();
    testScore.setId(1);
    testScore.setStanadrdScore(77);
    studentTestEvent1.setTestScore(testScore);

    StudentTestEvent studentTestEvent2 = new StudentTestEvent();
    studentTestEvent2.setTestDate("2018-04-13T04:58:14.390Z");
    Grade grade1 = new Grade();
    grade.setName("3");
    studentTestEvent2.setGrade(grade1);
    TestScore testScore1 = new TestScore();
    testScore1.setId(2);
    testScore1.setStanadrdScore(72);
    studentTestEvent2.setTestScore(testScore);

    studentTestEvents.add(studentTestEvent1);
    studentTestEvents.add(studentTestEvent2);
    log.info("End of getTestEvents for UserResolver - Student Schema --> {} ", LocalDateTime.now());

    return studentTestEvents;
  }

}
