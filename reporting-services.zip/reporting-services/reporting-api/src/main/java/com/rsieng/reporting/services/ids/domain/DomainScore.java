package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.UUID;
import lombok.Data;
import java.util.List;

/**
 * Created by nandipatim on 4/7/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DomainScore implements Serializable {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("id")
  private Integer id;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("guid")
  private UUID guid;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("desc")
  private String desc;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("score")
  private Integer score;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("performanceLevels")
  private List<PerformanceLevel> performanceLevels;
}
