package com.rsieng.reporting.graphql;

import java.util.Map;
import java.util.UUID;
import lombok.Builder;
import lombok.Data;
import org.springframework.context.ApplicationContext;

@Data
@Builder
public class GraphQLExecutionContext {

  private final ApplicationContext applicationContext;

  private final String userAuthToken;

  private final String authCurrentDateTime;

  private final Integer userId;

  private final Boolean isTrustedApi;

  private final Map<String, Object> contextStorage;

}
