package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * Created by nandipatim on 4/5/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name implements Serializable {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("firstName")
  private String firstName;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("middleName")
  private String middleName;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("lastName")
  private String lastName;

}
