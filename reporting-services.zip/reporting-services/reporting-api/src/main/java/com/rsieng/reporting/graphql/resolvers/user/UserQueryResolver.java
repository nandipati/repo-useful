package com.rsieng.reporting.graphql.resolvers.user;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.rsieng.reporting.graphql.GraphQLExecutionContext;
import com.rsieng.reporting.services.ids.domain.TestEvent;
import com.rsieng.reporting.services.ids.domain.ReportTopLevelUser;
import com.rsieng.reporting.services.ids.domain.User;
import graphql.schema.DataFetchingEnvironment;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserQueryResolver implements GraphQLQueryResolver {


 public String getResolverName() {
    return "Query";
  }

 public ReportTopLevelUser getUser(int userId, DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

   log.info("Start of getUser for UserQueryResolver - User Schema --> {} ", LocalDateTime.now());
   GraphQLExecutionContext context = environment.getContext();
   ReportTopLevelUser user = new ReportTopLevelUser();
   user.setUserId(userId);
   user.setLevel("District");
   TestEvent testEvent = new TestEvent();
   testEvent.setTestEventId(1234);
   testEvent.setTestEventName("TestEvent1");
   List<TestEvent> testEvents = new ArrayList<>();
   testEvents.add(testEvent);
   user.setTestEvents(testEvents);
   log.info("End of getUser for UserQueryResolver - User Schema --> {} ", LocalDateTime.now());

   return user;
  }
}
