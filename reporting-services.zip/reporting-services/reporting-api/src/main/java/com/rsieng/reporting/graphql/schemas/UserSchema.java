package com.rsieng.reporting.graphql.schemas;


import com.coxautodev.graphql.tools.SchemaParser;
import com.rsieng.reporting.graphql.resolvers.user.TestEventResolver;
import com.rsieng.reporting.graphql.resolvers.user.UserQueryResolver;
import com.rsieng.reporting.graphql.resolvers.user.UserResolver;
import com.rsieng.reporting.graphql.types.GraphQLScalars;
import com.rsieng.reporting.services.ids.domain.Name;
import com.rsieng.reporting.services.ids.domain.Population;
import com.rsieng.reporting.services.ids.domain.ReportTopLevelUser;
import com.rsieng.reporting.services.ids.domain.TestEvent;
import com.rsieng.reporting.services.ids.domain.User;
import java.io.IOException;
import java.nio.charset.Charset;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

public class UserSchema {

  public SchemaParser getSchemaParser() throws IOException {

    String userSchema = IOUtils.toString(
        new ClassPathResource("/schemas/user.graphqls").getInputStream(),
        Charset.defaultCharset());

    SchemaParser parser = SchemaParser.newParser().schemaString(userSchema).resolvers(
        new UserQueryResolver() {
        },new UserResolver() {
        },new TestEventResolver() {
        }).scalars(GraphQLScalars.GraphQLUUID, GraphQLScalars.GraphQLLocalDateTime)
        .dictionary("UserTopLevel", ReportTopLevelUser.class)
        .dictionary("TestEvent", TestEvent.class)
        .dictionary("Name", Name.class)
        .dictionary("Population" , Population.class)
        .build();

    return parser;
  }

  }
