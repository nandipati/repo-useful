package com.rsieng.reporting.graphql.resolvers.user;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.rsieng.reporting.graphql.GraphQLExecutionContext;
import com.rsieng.reporting.services.ids.domain.ReportTopLevelUser;
import com.rsieng.reporting.services.ids.domain.TestEvent;
import graphql.schema.DataFetchingEnvironment;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by nandipatim on 4/12/19.
 */
@Slf4j
public class UserResolver implements GraphQLResolver<ReportTopLevelUser> {

  public UserResolver() {}

  public List<TestEvent> getTestEvents(ReportTopLevelUser user , Integer testEventId, List<String> grades,
                                       List<Integer> districts, List<Integer> buildings, List<Integer> classes,
                                       List<Integer> students, DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("Start of getTestEvents for UserResolver - User Schema --> {} ", LocalDateTime.now());
    GraphQLExecutionContext context = environment.getContext();

    List<TestEvent> testEvents = new ArrayList<>();
    TestEvent testEvent = new TestEvent();
    testEvent.setTestEventId(1234);
    testEvent.setTestEventName("TestEvent1");
    testEvents.add(testEvent);
    log.info("End of getTestEvents for UserResolver - User Schema --> {} ", LocalDateTime.now());

    return testEvents;
  }

}
