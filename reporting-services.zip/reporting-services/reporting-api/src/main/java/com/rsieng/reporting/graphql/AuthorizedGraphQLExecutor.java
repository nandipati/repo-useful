package com.rsieng.reporting.graphql;

import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsi.security.common.utils.SecurityUtils;
import graphql.ErrorType;
import graphql.ExecutionResult;
import graphql.GraphQLError;
import graphql.language.SourceLocation;
import graphql.schema.GraphQLSchema;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.Data;
import lombok.NonNull;
import org.springframework.context.ApplicationContext;

@Data
public class AuthorizedGraphQLExecutor extends SimpleGraphQLExecutor {

  private final List<String> acceptedRoles;

  public AuthorizedGraphQLExecutor(ApplicationContext applicationContext, @NonNull GraphQLSchema schema,
                                   @NonNull List<String> acceptedRoles) {
    super(applicationContext, schema);
    this.acceptedRoles = acceptedRoles;
  }

  @Override
  protected ExecutionResult executeInternal(String query, String operation, GraphQLExecutionContext context,
                                            boolean enableTracing, Map<String, Object> parameters, boolean introspectionQuery) {

    if (SecurityUtils.isTrustedApi() && acceptedRoles.contains(RSIRoleConverter.ROLE_TRUSTEDAPI)) {
      return super
          .executeInternal(query, operation, context, enableTracing,
              Optional.ofNullable(parameters).orElse(Collections.emptyMap()), introspectionQuery);
  } else {
      return new ExecutionResult() {
        @Override
        public <T> T getData() {
          return null;
        }

        @Override
        public List<GraphQLError> getErrors() {
          return Arrays.asList(new GraphQLError() {
            @Override
            public String getMessage() {
              return "Invalid user role! This is an authorized schema.";
            }

            @Override
            public List<SourceLocation> getLocations() {
              return new ArrayList<>();
            }

            @Override
            public ErrorType getErrorType() {
              return ErrorType.ValidationError;
            }

          });
        }

        @Override
        public Map<Object, Object> getExtensions() {
          return null;
        }

        @Override
        public Map<String, Object> toSpecification() {
          return null;
        }

      };
    }

  }
}
