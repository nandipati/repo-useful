package com.rsieng.reporting.graphql.resolvers.user;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.rsieng.reporting.graphql.GraphQLExecutionContext;
import com.rsieng.reporting.services.ids.domain.DomainScore;
import com.rsieng.reporting.services.ids.domain.LocationDomainScores;
import com.rsieng.reporting.services.ids.domain.LocationRoster;
import com.rsieng.reporting.services.ids.domain.Page;
import com.rsieng.reporting.services.ids.domain.PerformanceBand;
import com.rsieng.reporting.services.ids.domain.PerformanceLevel;
import com.rsieng.reporting.services.ids.domain.StudentDomainScores;
import com.rsieng.reporting.services.ids.domain.StudentRoster;
import com.rsieng.reporting.services.ids.domain.TestEvent;
import com.rsieng.reporting.services.ids.domain.TestScore;
import com.rsieng.reporting.services.ids.domain.input.DomainFilterInput;
import com.rsieng.reporting.services.ids.domain.input.PopulationInput;
import graphql.schema.DataFetchingEnvironment;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import com.rsieng.reporting.services.ids.domain.Score;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by nandipatim on 4/11/19.
 */
@Slf4j
public class TestEventResolver implements GraphQLResolver<TestEvent> {

  public TestEventResolver(){}

  public TestScore getTestScore(TestEvent testEvent, Integer testEventId, List<String> grades, List<Integer> districts,
                                List<Integer> buildings, List<Integer> classes, List<Integer> students,
                                List<PopulationInput> populations , DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("Start of getTestScore for TestEventResolver - User Schema --> {} ", LocalDateTime.now());
    GraphQLExecutionContext context = environment.getContext();

    TestScore testScore = new TestScore();
    testScore.setStanadrdScore(77);
    testScore.setId(1);
    List<Score> scores = new ArrayList<>();
    Score score = new Score();
    score.setId(1);
    score.setType("NPR");
    score.setValue(100);
    List<PerformanceBand> performanceBands = new ArrayList<>();
    PerformanceBand performanceBand = new PerformanceBand();
    performanceBand.setId(2);
    performanceBand.setLower(1);
    performanceBand.setUpper(20);
    performanceBand.setNOfStudents(10);
    performanceBand.setPercent(100);
    performanceBands.add(performanceBand);
    score.setPerformanceBands(performanceBands);
    scores.add(score);
    testScore.setScores(scores);
    log.info("End of getTestScore for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    return testScore;
  }

  public List<DomainScore> getDomainScores(TestEvent testEvent, Integer testEventId, List<String> grades, List<Integer> districts,
                                           List<Integer> buildings, List<Integer> classes, List<Integer> students,
                                           List<PopulationInput> populations , DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("Start of getDomainScores for TestEventResolver - User Schema --> {} ", LocalDateTime.now());
    GraphQLExecutionContext context = environment.getContext();

    List<DomainScore> domainScores = new ArrayList<>();
    DomainScore domainScore = new DomainScore();
    domainScore.setId(1);
    domainScore.setGuid(UUID.randomUUID());
    domainScore.setDesc("Operations and Algebric Thinking");
    List<PerformanceLevel> performanceLevels = new ArrayList<>();
    PerformanceLevel performanceLevel = new PerformanceLevel();
    performanceLevel.setDesc("Mid Performers");
    performanceLevel.setId(1234);
    performanceLevel.setNOfStudents(50);
    performanceLevel.setPercent(50);
    performanceLevels.add(performanceLevel);
    domainScore.setPerformanceLevels(performanceLevels);
    domainScores.add(domainScore);
    log.info("End of getDomainScores for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    return domainScores;
  }

  public LocationRoster getLocationRoster(TestEvent testEvent, Integer testEventId, List<String> grades, List<Integer> districts,
                                         List<Integer> buildings, List<Integer> classes, List<Integer> students,
                                         List<PopulationInput> populations , String level,
                                         String performanceBand , DomainFilterInput domainFilter,
                                         Integer size , Integer page , String sortOrder , String sortField,
                                         DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException{

    log.info("Start of getLocationRoster for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    LocationRoster locationRoster = new LocationRoster();

    Page pageObject = new Page();
    pageObject.setNumber(1);
    pageObject.setSize(100);
    pageObject.setTotalElements(1000);
    pageObject.setTotalPages(10);
    locationRoster.setPage(pageObject);

    List<LocationDomainScores> locationDomainScores = new ArrayList<>();
    LocationDomainScores locationDomainScore = new LocationDomainScores();
    locationDomainScore.setId(1);
    locationDomainScore.setName("Building1");
    locationDomainScore.setAverageScore(45);
    List<DomainScore> domainScores = new ArrayList<>();
    DomainScore score = new DomainScore();
    score.setId(123);
    score.setDesc("O&AT");
    List<PerformanceLevel> performanceLevels = new ArrayList<>();
    PerformanceLevel performanceLevel = new PerformanceLevel();
    performanceLevel.setId(123);
    performanceLevel.setDesc("Mid Performance");
    performanceLevel.setScore(50);
    performanceLevels.add(performanceLevel);
    score.setPerformanceLevels(performanceLevels);
    domainScores.add(score);
    locationDomainScore.setDomainScores(domainScores);
    locationDomainScores.add(locationDomainScore);
    locationRoster.setLocations(locationDomainScores);

    log.info("End of getLocationRoster for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    return locationRoster;
  }

  public StudentRoster getStudentRoster(TestEvent testEvent, Integer testEventId, List<String> grades, List<Integer> districts,
                                        List<Integer> buildings, List<Integer> classes, List<Integer> students,
                                        List<PopulationInput> populations ,
                                        String performanceBand , DomainFilterInput domainFilter,
                                        Integer size , Integer page , String sortOrder , String sortField,
                                        DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException{

    log.info("Start of getStudentRoster for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    StudentRoster studentRoster = new StudentRoster();
    Page pageObject = new Page();
    pageObject.setNumber(1);
    pageObject.setSize(100);
    pageObject.setTotalElements(1000);
    pageObject.setTotalPages(10);
    studentRoster.setPage(pageObject);

    List<StudentDomainScores> studentDomainScores = new ArrayList<>();
    StudentDomainScores studentDomainScore = new StudentDomainScores();
    studentDomainScore.setId(1);
    studentDomainScore.setName("Student1");
    studentDomainScore.setTestScore(25);
    List<DomainScore> domainScores = new ArrayList<>();
    DomainScore score = new DomainScore();
    score.setId(123);
    score.setDesc("O&AT");
    score.setScore(75);
    domainScores.add(score);
    studentDomainScore.setDomainScores(domainScores);
    studentDomainScores.add(studentDomainScore);
    studentRoster.setStudents(studentDomainScores);
    log.info("End of getStudentRoster for TestEventResolver - User Schema --> {} ", LocalDateTime.now());

    return studentRoster;
  }
}
