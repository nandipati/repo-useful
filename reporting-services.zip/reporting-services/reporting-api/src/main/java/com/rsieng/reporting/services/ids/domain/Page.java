package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * Created by nandipatim on 4/17/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Page implements Serializable{

  @JsonProperty("size")
  public int size;

  @JsonProperty("totalElements")
  public int totalElements;

  @JsonProperty("totalPages")
  public int totalPages;

  @JsonProperty("number")
  public int number;
}
