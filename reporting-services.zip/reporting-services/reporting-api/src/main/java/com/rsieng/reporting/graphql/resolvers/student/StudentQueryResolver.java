package com.rsieng.reporting.graphql.resolvers.student;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.rsieng.reporting.dao.readonly.StudentRepository;
import com.rsieng.reporting.entity.Student;
import com.rsieng.reporting.graphql.GraphQLExecutionContext;
import com.rsieng.reporting.services.ids.domain.User;
import com.rsieng.reporting.services.ids.domain.Name;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StudentQueryResolver implements GraphQLQueryResolver {


  private final StudentRepository studentRepository;

  public StudentQueryResolver(StudentRepository studentRepository) {
    this.studentRepository =studentRepository;
  }

  public String getResolverName() {
    return "Query";
  }

  public User getStudent(Integer userId , DataFetchingEnvironment environment)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("Start of getStudent for StudentQueryResolver - Student Schema --> {} ", LocalDateTime.now());
    GraphQLExecutionContext context = environment.getContext();
    User user = null;
    try {

      Student student = null;
          //studentRepository.findByStudentId(new Long(userId));
      user = new User();
      if(student!=null) {
        System.out.println(student);

        user.setUserId(userId);
        //user.setUsername(String.valueOf(student.getId()));
        Name name = new Name();
        name.setFirstName(student.getFirstName());
        name.setLastName(student.getLastName());
        name.setMiddleName("");
      }else{
        user.setUserId(userId);
        //user.setUsername(String.valueOf(student.getId()));
      }
    } catch (Exception e) {
      log.error("Error while getting Student Data getStudent {} ", e);
    }
    log.info("End of getStudent for StudentQueryResolver - Student Schema --> {} ", LocalDateTime.now());

    return user;
  }

}
