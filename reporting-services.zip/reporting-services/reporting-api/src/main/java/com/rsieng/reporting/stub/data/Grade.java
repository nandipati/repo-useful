package com.rsieng.reporting.stub.data;

/**
 * Created by nandipatim on 5/22/19.
 */
public enum Grade {

  GRADE_K("Grade K"), GRADE_1("Grade 1"), GRADE_2("Grade 2"), GRADE_3("Grade 3"), GRADE_4("Grade 4"),
  GRADE_5("Grade 5"), GRADE_6("Grade 6"), GRADE_7("Grade 7"), GRADE_8("Grade 8"), GRADE_9("Grade 9"),
  GRADE_10("Grade 10"), GRADE_11("Grade 11");

  private final String desc;

  Grade(String desc){
    this.desc = desc;
  }

  public String getDesc() {
    return desc;
  }

  public static Grade fromOrdinal(int ordinal) {
    int valuesCount = values().length;
    if (ordinal < 0 || ordinal >= valuesCount) {
      throw new IllegalArgumentException("ordinal " + ordinal + " is less than 0 or " +
          "greater than the number of values [" + valuesCount + "]");
    }
    return values()[ordinal];

  }

  public static Grade fromOrdinal(String ordinal) {
    return fromOrdinal(Integer.valueOf(ordinal));
  }
}