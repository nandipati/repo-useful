package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/11/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentTestEvent implements Serializable {

  @JsonProperty("testEventId")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private int testEventId;

  @JsonProperty("testEventName")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String testEventName;

  @JsonProperty("testDate")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String testDate;

  @JsonProperty("grade")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Grade grade;

  @JsonProperty("district")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Location district;

  @JsonProperty("testScore")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private TestScore testScore;

  @JsonProperty("domainScores")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<DomainScore> domainScores;


}
