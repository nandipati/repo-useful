package com.rsieng.reporting.stub.data;

import java.util.Arrays;

/**
 * Created by nandipatim on 5/2/19.
 */
public enum DomainStub {
  DOMAIN_1(1,"OPERATIONS & ALGEBRIC THINKING","O&AT"),
  DOMAIN_2(2,"NUMBER & OPERATIONS IN BASE TEN","N&O-BT"),
  DOMAIN_3(3,"NUMBER & OPERATIONS-FRACTIONS","N&O-F"),
  DOMAIN_4(4,"MEASUREMENT & DATA","M&D"),
  DOMAIN_5(5,"GEOMETRY","Geo");

  private final int id;
  private final String description;
  private final String shotDescription;

  DomainStub(int id , String description , String shotDescription){
    this.id = id;
    this.description = description;
    this.shotDescription = shotDescription;
  }

  public static DomainStub getDomainStubById(int id) {

    return Arrays.stream(values()).filter(hl -> hl.id == id).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("no DomainStub for " + id));

  }

  public int getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }

  public String getShotDescription() {
    return shotDescription;
  }
}
