package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

import java.util.List;

/**
 * Created by nandipatim on 4/7/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Population implements Serializable {

  @JsonProperty("key")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  String key;

  @JsonProperty("values")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  List<String> values;
}
