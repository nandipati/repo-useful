package com.rsieng.reporting.controller;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import lombok.Data;


@Data
public class GraphQLRequest {

  private String query;

  private String operation;

  private GraphQLVariables variables;

  public Map<String, Object> getParameters() {
    if (variables ==null) {
      return null;
    } else {
      return Collections.unmodifiableMap(Optional.ofNullable(variables.getVariables()).orElse(Collections.EMPTY_MAP));
    }
  }

}
