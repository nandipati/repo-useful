package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/17/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StudentRoster extends PageRoster {

  @JsonProperty("students")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<StudentDomainScores> students;
}
