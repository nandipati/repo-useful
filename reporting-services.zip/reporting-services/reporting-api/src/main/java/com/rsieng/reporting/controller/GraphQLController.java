package com.rsieng.reporting.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsieng.reporting.graphql.GraphQLExecutor;
import com.rsieng.reporting.services.ids.domain.StringResponse;
import graphql.ExecutionResult;
import graphql.GraphQLError;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@RequestMapping({"/reporting/data-api"})
public class GraphQLController {

  private final Map<String, GraphQLExecutor> schemas;

  private final ApplicationContext applicationContext;

  @Autowired
  public GraphQLController(Map<String, GraphQLExecutor> schemas, ApplicationContext applicationContext) {
    this.schemas = schemas;
    this.applicationContext = applicationContext;
  }

  @RequestMapping(method = RequestMethod.GET,path = "/{schema}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.TEXT_PLAIN_VALUE)
  @PreAuthorize("isAuthenticated()")
  public ResponseEntity<Object> graphQLQuery(@PathVariable String schema,
                                             @RequestHeader(name = "Authorization") String authToken,
                                             @RequestHeader(name = "authCurrentDateTime", required = false) String authCurrentDateTime,
                                             @RequestHeader(name = "tracing", required = false) boolean enableTracing,
                                             @RequestBody String query)
      throws JsonProcessingException {
    GraphQLRequest request = new GraphQLRequest();
    request.setQuery(query);
    ResponseEntity<Object> execResult = graphQLQuery(schema, authToken, authCurrentDateTime,
        enableTracing, request);
    if (execResult.getBody() instanceof ExecutionResult) {
      return ResponseEntity.status(execResult.getStatusCode()).body(((ExecutionResult) execResult.getBody()).getData());
    } else {
      return execResult;
    }
  }

  @RequestMapping(method= RequestMethod.POST, path = "/{schema}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("isAuthenticated()")
  public ResponseEntity<Object> graphQLQuery(@PathVariable String schema,
                                             @RequestHeader(name = "Authorization") String authToken,
                                             @RequestHeader(name = "authCurrentDateTime", required = false) String authCurrentDateTime,
                                             @RequestHeader(name = "tracing", required = false) boolean enableTracing,
                                             @RequestBody GraphQLRequest request)
      throws JsonProcessingException {
    ResponseEntity<Object> ret;
    if (schemas.containsKey(schema)) {
      GraphQLExecutor executor = schemas.get(schema);
      boolean introspectionQuery = request.getQuery().contains("query IntrospectionQuery");
      ExecutionResult data = executor.execute(request.getQuery(), request.getOperation(), authToken,
          authCurrentDateTime, enableTracing, request.getParameters(), introspectionQuery);
      if (CollectionUtils.isEmpty(data.getErrors())) {
        ret = ResponseEntity.ok(data);
        log.info("Query request successful {}", request.getQuery());
      } else {
        ret = ResponseEntity.badRequest().body(data);
        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(data);
        log.error("Query response has errors: request:{} response:{}", request.getQuery(), jsonInString);
      }
    } else {
      ret = ResponseEntity.status(HttpStatus.BAD_REQUEST)
          .body(new StringResponse("No such schema! See /schemas for available schemas."));
      log.error("No such schema! See /schemas for available schemas {}", schema);
    }
    return ret;
  }



  protected String createErrorMessage(List<GraphQLError> errors) {
    if (errors != null && !errors.isEmpty()) {
      return errors.stream().map(error -> error.getMessage()).collect(Collectors.joining("\n"));
    } else {
      return "";
    }
  }

  @RequestMapping(method= RequestMethod.GET, path = "schemas", produces = MediaType.TEXT_PLAIN_VALUE)
  @PreAuthorize("isAuthenticated()")
  public String getSchemas() {
    return schemas.keySet().stream().collect(Collectors.joining("\n"));
  }

}
