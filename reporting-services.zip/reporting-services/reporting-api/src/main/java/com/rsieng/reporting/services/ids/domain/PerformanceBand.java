package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * Created by nandipatim on 4/7/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PerformanceBand implements Serializable {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("id")
  private Integer id;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("lower")
  private Integer lower;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("upper")
  private Integer upper;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("nOfStudents")
  private Integer nOfStudents;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("percent")
  private Integer percent;
}
