package com.rsieng.reporting.services.ids.domain;

import lombok.Data;

/**
 * Created by nandipatim on 4/5/19.
 */
@Data
public class StringResponse {
  private final String response;
}
