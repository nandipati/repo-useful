package com.rsieng.reporting.dao.readonly;

import com.amazonaws.cache.CacheLoader;
import com.rsieng.reporting.entity.Student;
import org.apache.ignite.springdata20.repository.IgniteRepository;
import org.apache.ignite.springdata20.repository.config.RepositoryConfig;

/**
 * Created by jayachandranj on 4/30/19.
 */
//@RepositoryConfig(cacheName = "STUDENTCACHE")
public class StudentRepository
    //extends IgniteRepository<Student, Long>
{
//public interface StudentRepository extends CacheLoader<Student, Long>,IgniteRepository<Student, Long> {

//   Student findByStudentId(Long studentId);

}
