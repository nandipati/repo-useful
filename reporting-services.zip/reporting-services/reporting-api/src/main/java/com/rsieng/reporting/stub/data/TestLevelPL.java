package com.rsieng.reporting.stub.data;

import java.util.Arrays;

/**
 * Created by nandipatim on 5/2/19.
 */
public enum TestLevelPL {
  NPR_1_20(1,"NPR 1-20", 1 , 20),
  NPR_21_40(2,"NPR 21-40", 21 , 40),
  NPR_41_60(3,"NPR 41-60", 41 , 60),
  NPR_61_80(4,"NPR 61-80", 61 , 80),
  NPR_81_100(5,"NPR 81-100", 81 , 100);

  private final int id;
  private final String description;
  private final int lower;
  private final int upper;

  TestLevelPL(int id , String description , int lower, int upper) {
    this.id = id;
    this.description = description;
    this.lower = lower;
    this.upper = upper;
  }

  public static TestLevelPL getTestLevelPLById(int id) {

    return Arrays.stream(values()).filter(hl -> hl.id == id).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("no TestLevelPL for " + id));

  }

  public int getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }

  public int getLower() {
    return lower;
  }

  public int getUpper() {
    return upper;
  }
}
