package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/17/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocationDomainScores implements Serializable {

  @JsonProperty("id")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  Integer id;

  @JsonProperty("name")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  String name;

  @JsonProperty("averageScore")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  Integer averageScore;

  @JsonProperty("domainScores")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<DomainScore> domainScores;
}
