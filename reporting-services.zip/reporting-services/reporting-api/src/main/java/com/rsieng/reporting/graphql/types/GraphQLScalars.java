package com.rsieng.reporting.graphql.types;

import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.GraphQLScalarType;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by fodori on 5/24/17.
 */
@Slf4j
public class GraphQLScalars {

  public static GraphQLScalarType GraphQLLocalDateTime = new GraphQLScalarType("localDateTime", "Local Date Time", new Coercing<LocalDateTime, String>() {
    private static final String ISO_PATTERN="yyyy-MM-dd'T'HH:mm:ss.SSS";

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_PATTERN);
    @Override
    public String serialize(Object o) {
      if(o instanceof LocalDateTime)
        return formatter.format((LocalDateTime)o);
      return o.toString();
    }

    @Override
    public LocalDateTime parseValue(Object o) {
      return LocalDateTime.parse(o.toString());
    }

    @Override
    public LocalDateTime parseLiteral(Object o) {
      return LocalDateTime.parse(o.toString());
    }
  });
  public static GraphQLScalarType GraphQLUUID = new GraphQLScalarType("UUID", "UUID Type", new Coercing<UUID, UUID>() {

    @Override
    public UUID serialize(Object input) {
      return parse(input);
    }

    @Override
    public UUID parseValue(Object input) {
      return parse(input);
    }

    @Override
    public UUID parseLiteral(Object input) {
      return parse(input);
    }

    public UUID parse(Object input) {
      if (input instanceof StringValue) {
        UUID uuid = null;
        try {
          uuid = UUID.fromString(((StringValue) input).getValue());
        } catch (IllegalArgumentException e) {
          log.error("Unable to parse UUID", e);
        }
        return uuid;
      }
      if (input instanceof String) {
        UUID uuid = null;
        try {
          uuid = UUID.fromString((String) input);
        } catch (IllegalArgumentException e) {
          log.error("Unable to parse UUID", e);
        }
        return uuid;
      } else if (input instanceof UUID) {
        return (UUID) input;
      }
      return null;
    }
  });

}
