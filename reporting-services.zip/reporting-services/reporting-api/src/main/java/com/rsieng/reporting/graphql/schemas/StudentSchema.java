package com.rsieng.reporting.graphql.schemas;


import com.coxautodev.graphql.tools.SchemaParser;
import com.rsieng.reporting.dao.readonly.StudentRepository;
import com.rsieng.reporting.graphql.resolvers.student.UserResolver;
import com.rsieng.reporting.graphql.types.GraphQLScalars;
import com.rsieng.reporting.services.ids.domain.User;
import com.rsieng.reporting.services.ids.domain.Name;
import java.io.IOException;
import java.nio.charset.Charset;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import com.rsieng.reporting.graphql.resolvers.student.StudentQueryResolver;

public class StudentSchema {

  public SchemaParser getSchemaParser(final StudentRepository studentRepository) throws IOException {

    String studentSchema = IOUtils.toString(
        new ClassPathResource("/schemas/student.graphqls").getInputStream(),
        Charset.defaultCharset());

    SchemaParser parser = SchemaParser.newParser().schemaString(studentSchema).resolvers(
        new StudentQueryResolver(studentRepository) {
        }, new UserResolver(){}).scalars(GraphQLScalars.GraphQLUUID, GraphQLScalars.GraphQLLocalDateTime)
        .dictionary("StudentTopLevel", User.class)
        .dictionary("Name" , Name.class)
        .build();

    return parser;
  }

  }
