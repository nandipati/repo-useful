package com.rsieng.reporting.graphql.schemas;

import com.coxautodev.graphql.tools.SchemaParser;
import com.rsi.security.common.converter.RSIRoleConverter;
import com.rsieng.reporting.dao.readonly.StudentRepository;
import com.rsieng.reporting.graphql.AuthorizedGraphQLExecutor;
import com.rsieng.reporting.graphql.types.LocalDateTimeFunction;
import com.rsieng.reporting.graphql.types.UUIDTypeFunction;
import graphql.annotations.GraphQLAnnotations;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.SchemaPrinter;
import java.io.IOException;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class SchemaConfig {

  static {
    GraphQLAnnotations.register(new UUIDTypeFunction());
    GraphQLAnnotations.register(new LocalDateTimeFunction());
  }

  @Autowired
  private ApplicationContext applicationContext;

//  @Autowired
  private StudentRepository studentRepository;


  @Bean(name="user")
  public AuthorizedGraphQLExecutor user() throws IOException {
    UserSchema userSchema = new UserSchema();
    SchemaParser parser = userSchema.getSchemaParser();
    GraphQLSchema schema = parser.makeExecutableSchema();
    logSchema("manifest", schema);
    return new AuthorizedGraphQLExecutor(applicationContext, schema, Arrays.asList(RSIRoleConverter.ROLE_TRUSTEDAPI));
  }

 @Bean(name="student")
  public AuthorizedGraphQLExecutor student() throws IOException {
    StudentSchema studentSchema = new StudentSchema();
    SchemaParser parser = studentSchema.getSchemaParser(studentRepository);
    GraphQLSchema schema = parser.makeExecutableSchema();
    logSchema("manifest", schema);
    return new AuthorizedGraphQLExecutor(applicationContext, schema, Arrays.asList(RSIRoleConverter.ROLE_TRUSTEDAPI));
  }

  protected void logSchema(String schemaName, GraphQLSchema schema) {
    if (log.isDebugEnabled()) {
      SchemaPrinter printer = new SchemaPrinter();
      log.debug("{} schema:\n{}", schemaName, printer.print(schema));
    }
  }

}
