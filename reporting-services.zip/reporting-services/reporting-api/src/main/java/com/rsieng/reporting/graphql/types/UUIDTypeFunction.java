package com.rsieng.reporting.graphql.types;

import graphql.annotations.TypeFunction;
import graphql.schema.GraphQLType;
import java.lang.reflect.AnnotatedType;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by fodori on 5/24/17.
 */
@Slf4j
public class UUIDTypeFunction implements TypeFunction {

  @Override
  public boolean canBuildType(Class<?> aClass, AnnotatedType annotatedType) {
    return aClass == UUID.class;
  }

  @Override
  public String getTypeName(Class<?> aClass, AnnotatedType annotatedType) {
    return "UUID";
  }

  @Override
  public GraphQLType buildType(String typeName, Class<?> aClass, AnnotatedType annotatedType) {
    return GraphQLScalars.GraphQLUUID;
  }
}