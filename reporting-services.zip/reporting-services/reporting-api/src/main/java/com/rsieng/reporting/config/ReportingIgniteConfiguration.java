package com.rsieng.reporting.config;

import com.amazonaws.auth.InstanceProfileCredentialsProvider;

import com.zaxxer.hikari.HikariDataSource;
import java.util.Arrays;

//import liquibase.integration.spring.SpringLiquibase;
import lombok.extern.slf4j.Slf4j;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CacheWriteSynchronizationMode;
import org.apache.ignite.configuration.BinaryConfiguration;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.ConnectorConfiguration;
import org.apache.ignite.configuration.DataRegionConfiguration;
import org.apache.ignite.configuration.DataStorageConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.s3.TcpDiscoveryS3IpFinder;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import java.util.List;
import com.rsieng.reporting.entity.Student;


/**
 * Created by nandipatim on 4/16/19.
 */

@Configuration
@Slf4j
public class ReportingIgniteConfiguration {

  @Value("${ignite.enableFilePersistence:true}")
  private boolean enableFilePersistence;
  @Value("${ignite.enableCache:false}")
  private boolean enableCache;
  @Value("${ignite.enableCluster:false}")
  private boolean enableCluster;
  @Value("${ignite.isAWSS3Cluster:true}")
  private boolean enableAWSS3Cluster;
  @Value("${ignite.connectorPort:11211}")
  private int igniteConnectorPort;
  @Value("${ignitec.serverPortRange:47500..47509}")
  private String igniteServerPortRange;
  @Value("${ignite.persistenceFilePath}")
  private String ignitePersistenceFilePath;
  @Value("${ignite.clusterS3BucketName}")
  private String igniteClusterS3BucketName;
  @Value("${spring.application.name:reportingapi}")
  private String applicationName;

  @Value("${spring.application.consitentid:localhost}")
  private String consitentId;

  @Value("${app.database.schema:PUBLIC}")
  private String schema;

  private static final String DATA_CONFIG_NAME = "REPORTING";

  @Bean(name = "igniteInitialization")
  @ConditionalOnProperty(value = "ignite.enable", havingValue = "true", matchIfMissing = true)
  IgniteConfiguration igniteConfiguration() {

    IgniteConfiguration igniteConfiguration = new IgniteConfiguration();
    igniteConfiguration.setWorkDirectory(ignitePersistenceFilePath);
    igniteConfiguration.setClientMode(false);
    // durable file memory persistence
    if(enableFilePersistence){

      DataStorageConfiguration dataStorageConfiguration = new DataStorageConfiguration();
      dataStorageConfiguration.setStoragePath(ignitePersistenceFilePath + "/store");
      dataStorageConfiguration.setWalArchivePath(ignitePersistenceFilePath + "/walArchive");
      dataStorageConfiguration.setWalPath(ignitePersistenceFilePath + "/walStore");
      dataStorageConfiguration.setPageSize(4 * 1024);
      DataRegionConfiguration dataRegionConfiguration = new DataRegionConfiguration();
      dataRegionConfiguration.setName(DATA_CONFIG_NAME);
      dataRegionConfiguration.setInitialSize(100 * 1000 * 1000);
      dataRegionConfiguration.setMaxSize(200 * 1000 * 1000);
      dataRegionConfiguration.setPersistenceEnabled(true);
      dataStorageConfiguration.setDataRegionConfigurations(dataRegionConfiguration);
      igniteConfiguration.setDataStorageConfiguration(dataStorageConfiguration);
//      igniteConfiguration.setConsistentId(UUID.randomUUID());
      igniteConfiguration.setConsistentId(consitentId);
    }
    // connector configuration
    ConnectorConfiguration connectorConfiguration=new ConnectorConfiguration();
    connectorConfiguration.setPort(igniteConnectorPort);
    // common ignite configuration
    igniteConfiguration.setMetricsLogFrequency(0);
    igniteConfiguration.setQueryThreadPoolSize(2);
    igniteConfiguration.setDataStreamerThreadPoolSize(1);
    igniteConfiguration.setManagementThreadPoolSize(2);
    igniteConfiguration.setPublicThreadPoolSize(2);
    igniteConfiguration.setSystemThreadPoolSize(2);
    igniteConfiguration.setRebalanceThreadPoolSize(1);
    igniteConfiguration.setAsyncCallbackPoolSize(2);
    igniteConfiguration.setIgniteInstanceName(applicationName);
    BinaryConfiguration binaryConfiguration = new BinaryConfiguration();
    binaryConfiguration.setCompactFooter(false);
    igniteConfiguration.setBinaryConfiguration(binaryConfiguration);
    igniteConfiguration.setPeerClassLoadingEnabled(true);
    // cluster tcp configuration

    if(enableCluster) {

      TcpDiscoverySpi tcpDiscoverySpi = new TcpDiscoverySpi();
/*
        TcpDiscoveryJdbcIpFinder ipFinder = new TcpDiscoveryJdbcIpFinder();
        ipFinder.setDataSource(igniteDataSource);
        ipFinder.setInitSchema(true);
        tcpDiscoverySpi.setIpFinder(ipFinder);
*/

      if (enableAWSS3Cluster) {

        TcpDiscoveryS3IpFinder tcpDiscoveryS3IpFinder = new TcpDiscoveryS3IpFinder();
        // need to be changed when it come to real cluster
        InstanceProfileCredentialsProvider instanceProfileCredentialsProvider = new InstanceProfileCredentialsProvider(false);

        tcpDiscoveryS3IpFinder.setAwsCredentialsProvider(instanceProfileCredentialsProvider);
        tcpDiscoveryS3IpFinder.setBucketName(igniteClusterS3BucketName);
        tcpDiscoverySpi.setIpFinder(tcpDiscoveryS3IpFinder);
      } else {
        TcpDiscoveryVmIpFinder tcpDiscoveryVmIpFinder = new TcpDiscoveryVmIpFinder();
        // need to be changed when it come to real cluster
        tcpDiscoveryVmIpFinder.setAddresses(Arrays.asList("127.0.0.1:47500..47509"));
        tcpDiscoverySpi.setIpFinder(tcpDiscoveryVmIpFinder);
      }
      igniteConfiguration.setDiscoverySpi(tcpDiscoverySpi);
    }

    if(enableCache) {

      // cache configuration
/*
      CacheConfiguration cacheConfiguration = new CacheConfiguration();
      cacheConfiguration.setCopyOnRead(false);
      cacheConfiguration.setBackups(1);
      cacheConfiguration.setAtomicityMode(CacheAtomicityMode.ATOMIC);
      cacheConfiguration.setCacheMode(CacheMode.PARTITIONED);
      cacheConfiguration.setName("STUDENTCACHE");
      cacheConfiguration.setDataRegionName(DATA_CONFIG_NAME);
      cacheConfiguration.setWriteSynchronizationMode(CacheWriteSynchronizationMode.FULL_ASYNC);
*/
//    Incase we need to do only read through that is the case for Reporting.
//    cacheConfiguration.setReadThrough(Boolean.TRUE);
//    cacheConfiguration.setWriteThrough(Boolean.TRUE);
//      cacheConfiguration.setIndexedTypes(Long.class,Student.class,Long.class,Student.class,Long.class,Student.class);
//      cacheConfiguration.setIndexedTypes(List.class,Student.class);
//      cacheConfiguration.setIndexedTypes(Long.class,Student.class);
//      igniteConfiguration.setCacheConfiguration(cacheConfiguration);

    }

    return igniteConfiguration;
}

  @Bean(destroyMethod = "close" , name = "igniteInstance")
  Ignite ignite(IgniteConfiguration igniteConfiguration) throws IgniteException {
    final Ignite ignite = Ignition.start(igniteConfiguration);
    // Activate the cluster. Automatic topology initialization occurs
    // only if you manually activate the cluster for the very first time.
    ignite.cluster().active(true);
    ignite.cache("STUDENTCACHE");
    return ignite;
  }

  @Bean
  @Primary
  @ConfigurationProperties("app.datasource")
  public DataSourceProperties dataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean(name = "dataSource")
  @Primary
  @ConditionalOnBean(IgniteConfiguration.class)
  @ConditionalOnClass(HikariDataSource.class)
  @ConditionalOnMissingBean(javax.sql.DataSource.class)
  @ConfigurationProperties("app.datasource.configuration")
  public HikariDataSource dataSource(DataSourceProperties properties) {
    return properties.initializeDataSourceBuilder().type(HikariDataSource.class)
        .build();

  }


 /*
  // Liquibase is not needed as tables are created by Cache.
  @Bean
  @Primary
  @ConfigurationProperties(prefix = "spring.liquibase")
  @DependsOn({"dataSource","igniteInitialization","igniteInstance"})
  public SpringLiquibase liquibase(HikariDataSource ds) {

    SpringLiquibase liquibase = new SpringLiquibase();
    liquibase.setDataSource(ds);
    liquibase.setDefaultSchema(schema);
//    liquibase.setLiquibaseSchema(schema);
    try {

      Connection conn =   ds.getConnection();
      conn.createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS "+schema+".DATABASECHANGELOGLOCK (ID INT PRIMARY KEY , LOCKED INT, LOCKEDBY VARCHAR(255), LOCKGRANTED datetime)");

    } catch (Exception ex) {
      log.error("Error for creation of DATABASECHANGELOGLOCK {}", ex);
    }

    try {

      ds.getConnection().createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS "+schema+".DATABASECHANGELOG (ID VARCHAR(255) NOT NULL PRIMARY KEY , AUTHOR VARCHAR(255) NOT NULL, FILENAME VARCHAR(255) NOT NULL, DATEEXECUTED datetime NOT NULL, ORDEREXECUTED INT NOT NULL, EXECTYPE VARCHAR(10) NOT NULL, MD5SUM VARCHAR(35), DESCRIPTION VARCHAR(255), COMMENTS VARCHAR(255), TAG VARCHAR(255), LIQUIBASE VARCHAR(20), CONTEXTS VARCHAR(255), LABELS VARCHAR(255), DEPLOYMENT_ID VARCHAR(10))  with \"TEMPLATE=PARTITIONED, backups=3\"");

    } catch (SQLException sqlex) {
      log.error("Error for creation of DATABASECHANGELOG {}", sqlex);
    }
    return liquibase;
  }
  */


}
