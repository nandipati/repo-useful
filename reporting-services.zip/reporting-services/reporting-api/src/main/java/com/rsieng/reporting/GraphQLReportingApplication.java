package com.rsieng.reporting;

import org.apache.ignite.springdata20.repository.config.EnableIgniteRepositories;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

/**
 * Created by nandipatim on 4/3/19.
 */
@SpringBootApplication
@ComponentScan({"com.rsi","com.rsieng.reporting"})
@EnableConfigurationProperties
@EnableIgniteRepositories
@EnableAutoConfiguration(exclude = {HibernateJpaAutoConfiguration.class})
public class GraphQLReportingApplication {

  public static void main(String[] args) {
    SpringApplication.run(GraphQLReportingApplication.class, args);
  }

}
