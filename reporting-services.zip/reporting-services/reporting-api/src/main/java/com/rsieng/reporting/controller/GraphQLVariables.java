package com.rsieng.reporting.controller;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Data;

@Data
public class GraphQLVariables {

  private Map<String, Object> variables = new ConcurrentHashMap<>();

  @JsonAnySetter
  public void setVariable(String parameterName, Object value) {
    variables.put(parameterName, value);
  }

  public Map<String, Object> getVariables() {
    return Collections.unmodifiableMap(variables);
  }
}
