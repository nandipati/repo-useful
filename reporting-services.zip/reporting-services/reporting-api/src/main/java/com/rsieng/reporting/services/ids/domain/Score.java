package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/7/19.
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Score implements Serializable {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("id")
  private Integer id;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("type")
  private String type;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("value")
  private Integer value;


  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonProperty("performanceBands")
  private List<PerformanceBand> performanceBands;

}
