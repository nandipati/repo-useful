package com.rsieng.reporting.graphql.types;

import graphql.annotations.TypeFunction;
import graphql.schema.GraphQLType;
import java.lang.reflect.AnnotatedType;
import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by ron on 6/2/2017.
 */
@Slf4j
public class LocalDateTimeFunction implements TypeFunction {

    @Override
    public boolean canBuildType(Class<?> aClass, AnnotatedType annotatedType) {
        return aClass == LocalDateTime.class;
    }

    @Override
    public String getTypeName(Class<?> aClass, AnnotatedType annotatedType) {
        return "LocalDateTime";
    }

    @Override
    public GraphQLType buildType(String typeName, Class<?> aClass, AnnotatedType annotatedType) {
        return GraphQLScalars.GraphQLLocalDateTime;
    }
}