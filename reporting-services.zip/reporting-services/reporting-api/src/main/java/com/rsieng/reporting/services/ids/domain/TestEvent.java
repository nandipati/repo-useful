package com.rsieng.reporting.services.ids.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Created by nandipatim on 4/4/19.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestEvent implements Serializable{

  @JsonProperty("testEventId")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private int testEventId;

  @JsonProperty("testEventName")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String testEventName;

  @JsonProperty("isDefault")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean isDefault;

  @JsonProperty("grades")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<Grade> grades;

  @JsonProperty("parentLocations")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<Location> parentLocations;

  @JsonProperty("populations")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<Population> populations;

  @JsonProperty("testScore")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private TestScore testScore;

  @JsonProperty("domainScores")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<DomainScore> domainScores;

  @JsonProperty("locationRoster")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LocationRoster locationRoster;

  @JsonProperty("studentRoster")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private StudentRoster studentRoster;
}
