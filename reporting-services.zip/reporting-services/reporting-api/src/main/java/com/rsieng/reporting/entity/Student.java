package com.rsieng.reporting.entity;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteAtomicLong;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.affinity.AffinityKeyMapped;
import org.apache.ignite.cache.query.annotations.QuerySqlField;


@Data
public class Student implements Serializable {

  Ignite ignite = Ignition.ignite();

  final IgniteAtomicLong studentIdSeq = ignite.atomicLong("student_id_seq", 1, true);


  public void init() {
    this.id = studentIdSeq.incrementAndGet();
  }

  @QuerySqlField
  private Long id;

  @QuerySqlField
  private Long testEventId;

  @QuerySqlField
  private String testEventName;

  @QuerySqlField
  private Long studentId;

  @QuerySqlField
  private String lastName;

  @QuerySqlField
  private String firstName;

}
