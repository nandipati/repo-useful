package com.rsieng.reporting.stub.data;

import java.util.Arrays;

/**
 * Created by nandipatim on 5/2/19.
 */
public enum DomainLevelPL {
  LOW(1,"Low Performers"),
  MID(2,"Mid Performers"),
  HIGH(3,"High Performers");

  private final int id;
  private final String description;

  DomainLevelPL(int id , String description) {
    this.id = id;
    this.description = description;
  }

  public static DomainLevelPL getDomainLevelPLById(int id) {

    return Arrays.stream(values()).filter(hl -> hl.id == id).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("no DomainLevelPL for " + id));

  }

  public int getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }

}
