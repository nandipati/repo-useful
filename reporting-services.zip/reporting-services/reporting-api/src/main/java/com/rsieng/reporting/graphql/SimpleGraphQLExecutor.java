package com.rsieng.reporting.graphql;

import com.rsi.security.common.utils.SecurityUtils;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.analysis.MaxQueryComplexityInstrumentation;
import graphql.analysis.MaxQueryDepthInstrumentation;
import graphql.execution.instrumentation.ChainedInstrumentation;
import graphql.execution.instrumentation.Instrumentation;
import graphql.execution.instrumentation.tracing.TracingInstrumentation;
import graphql.schema.GraphQLSchema;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

@Slf4j
@Data
public class SimpleGraphQLExecutor implements GraphQLExecutor {

  private final ApplicationContext applicationContext;

  private final GraphQLSchema schema;

  @Value("${graphql.instrumentation.maxQueryComplexity}")
  private String maxQueryComplexity;

  @Value("${graphql.instrumentation.maxQueryDepth}")
  private String maxQueryDepth;

  public SimpleGraphQLExecutor(ApplicationContext applicationContext, GraphQLSchema schema) {
    this.schema = schema;
    this.applicationContext = applicationContext;
  }

  protected GraphQL createGraphQL(GraphQLSchema schema, boolean enableTracing, boolean introspectionQuery) {
    List<Instrumentation> chainedList = new ArrayList<>();

    if (!introspectionQuery) {
      if (enableTracing) {
        chainedList.add(new TracingInstrumentation());
      }

      if (maxQueryComplexity != null) {
        Integer queryComplexity = Integer.parseInt(maxQueryComplexity);
        if (queryComplexity > 0) {
          log.info("maxQueryComplexity: {}", queryComplexity);
          chainedList.add(new MaxQueryComplexityInstrumentation(queryComplexity));
        }
      }

      if (maxQueryDepth != null) {
        Integer queryDepth = Integer.parseInt(maxQueryDepth);
        if (queryDepth > 0) {
          log.info("maxQueryDepth: {}", queryDepth);
          chainedList.add(new MaxQueryDepthInstrumentation(queryDepth));
        }
      }

      if (chainedList.size() > 0) {
        ChainedInstrumentation chainedInstrumentation = new ChainedInstrumentation(chainedList);

        return GraphQL.newGraphQL(schema)
            .instrumentation(chainedInstrumentation)
            .build();
      }
    }

    return GraphQL.newGraphQL(schema)
        .build();

  }

  public ExecutionResult execute(String query, String authToken, String authCurrentDateTime, boolean enableTracing,
                                 boolean introspectionQuery) {
   return execute(query, null, authToken, authCurrentDateTime, enableTracing, null, introspectionQuery);
  }

  public ExecutionResult execute(String query, String operation, String authToken, String authCurrentDateTime,
                                 boolean enableTracing, Map<String, Object> parameters, boolean introspectionQuery) {
    GraphQLExecutionContext context = createContext(authToken, authCurrentDateTime, parameters);
    return executeInternal(query, operation, context, enableTracing,
        Optional.ofNullable(parameters).orElse(Collections.emptyMap()), introspectionQuery);
  }

  protected ExecutionResult executeInternal(String query, String operation, GraphQLExecutionContext context,
                                            boolean enableTracing, Map<String, Object> parameters, boolean introspectionQuery) {
      return createGraphQL(schema, enableTracing, introspectionQuery).execute(query, operation, context, parameters);
  }

  public GraphQLExecutionContext createContext(String authToken, String authCurrentDateTime,
                                               Map<String, Object> additionalContextValues) {
    return GraphQLExecutionContext.builder().applicationContext(applicationContext).userAuthToken(authToken)
        .authCurrentDateTime(authCurrentDateTime).isTrustedApi(SecurityUtils.isTrustedApi())
        .contextStorage(Optional.ofNullable(additionalContextValues).map(m -> new ConcurrentHashMap<>(m))
            .orElse(new ConcurrentHashMap<>())).build();
  }

}
