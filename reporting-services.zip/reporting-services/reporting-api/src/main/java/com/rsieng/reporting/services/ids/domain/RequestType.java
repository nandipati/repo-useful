package com.rsieng.reporting.services.ids.domain;

/**
 * Created by nandipatim on 4/12/19.
 */
public enum RequestType {
  PROFILE_NARATIVE,
  STUDENT_PROGRESS
}
