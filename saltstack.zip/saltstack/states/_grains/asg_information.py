#!/usr/bin/env python

import httplib
import logging
import os
import pprint
from salt.utils.decorators import depends

log = logging.getLogger(__name__)
try:
    from boto import ec2
except ImportError as e:
    log.trace('Failed to import boto: {0}'.format(e))

ASG_TAG = "aws:autoscaling:groupName"

def _call_aws(url):
    conn = httplib.HTTPConnection("169.254.169.254", 80, timeout=1)
    conn.request('GET', url)
    response = conn.getresponse()
    if response.status == 200:
        return response.read()


def _get_az():
    az = _call_aws('/latest/meta-data/placement/availability-zone')
    return az


def _get_region():
    az = _get_az()
    region = az[:-1]
    return region


def _get_instance_id():
    instance_id = _call_aws('http://169.254.169.254/latest/meta-data/instance-id')
    return instance_id


def _fallback():
    '''
    Fallback function for the depends decorator to replace a function with
    '''
    return '"boto" needs to be installed for this custom grain to exist'


def _get_asg_private_ips(conn, asg_name):
    '''
    Returns a list of private ip addresses in the given EC2 AutoScaling Group
    '''
    reservations = conn.get_all_reservations(filters={ 'tag:aws:autoscaling:groupName': asg_name, 
                                                       'instance-state-name': 'running'})

    return [instance.private_ip_address for res in reservations
                                        for instance in res.instances]


#@depends('boto.ec2', fallback_function=_fallback)
def asg_information():
    try:
        _call_aws('http://169.254.169.254/latest/meta-data')
    except:
        return {}
    region = _get_region()

    try:
        conn = ec2.connect_to_region(region)
    except:
        log.error("%s: invalid AWS credentials found, see documentation for how to provide them.", __name__)
        return None

    instance_id = _get_instance_id()
    reservation = conn.get_all_reservations(instance_ids=[instance_id])[0]
    instance = reservation.instances.pop()

    asg_ips = _get_asg_private_ips(conn, instance.tags.get(ASG_TAG, ""))

    return {
        'asg': {
            'ips': asg_ips
        }
    }


if __name__ == '__main__':
    pprint.pprint(asg_information())
