#!/usr/bin/env python

import httplib
import logging
import os
import pprint
import json

log = logging.getLogger(__name__)
try:
    from boto import ec2
except ImportError as e:
    log.trace('Failed to import boto: {0}'.format(e))

CACHE_FILE = '/var/cache/salt/cnd/ec2-info.json'
AWS_CREDENTIALS = {}

EC2_STATE_CODE = {
    0: 'pending',
    16: 'running',
    32: 'shutting-down',
    48: 'terminated',
    64: 'stopping',
    80: 'stopped',
    272: 'running'
}


def _get_credentials():
    access_key = os.environ.get('AWS_ACCESS_KEY') or os.environ.get('AWS_ACCESS_KEY_ID')
    secret_key = os.environ.get('AWS_SECRET_KEY') or os.environ.get('AWS_SECRET_ACCESS_KEY')
    if access_key and secret_key:
        return {
            'aws_access_key_id': access_key,
            'aws_secret_access_key': secret_key, }

    return AWS_CREDENTIALS


def _call_aws(url):
    conn = httplib.HTTPConnection("169.254.169.254", 80, timeout=1)
    conn.request('GET', url)
    response = conn.getresponse()
    if response.status == 200:
        return response.read()


def _get_az():
    az = _call_aws('/latest/meta-data/placement/availability-zone')
    return az


def _get_region():
    az = _get_az()
    region = az[:-1]
    return region


def _get_instance_id():
    instance_id = _call_aws('http://169.254.169.254/latest/meta-data/instance-id')
    return instance_id


def _read_cache(filename):
    if not os.path.isfile(filename):
        return None
    with open(filename, 'r') as f:
        return json.load(f)

def _write_cache(filename, ec2_info):
    if not os.path.isdir(os.path.dirname(filename)):
        os.makedirs(os.path.dirname(filename))
    with open(filename, 'w') as f:
        json.dump(ec2_info, f)


def _read_ec2_information():
    results = {}
    try:
        _call_aws('http://169.254.169.254/latest/meta-data')
    except:
        return {}
    region = _get_region()

    credentials = _get_credentials()
    try:
        conn = ec2.connect_to_region(region, **credentials)

    except:
        if not (credentials['aws_access_key_id'] and credentials['aws_secret_access_key']):
            log.error("%s: no AWS credentials found, see documentation for how to provide them.", __name__)
            return None
        else:
            log.error("%s: invalid AWS credentials found, see documentation for how to provide them.", __name__)
            return None
    instance_id = _get_instance_id()
    reservation = conn.get_all_reservations(instance_ids=[instance_id])[0]
    instance = reservation.instances.pop()
    block_mapping = {}

    for bd_name, bd in instance.block_device_mapping.items():
        block_mapping[bd_name] = {
            # 'connection': bd.connection,
            'ephemeral_name': bd.ephemeral_name,
            'no_device': bd.no_device,
            'volume_id': bd.volume_id,
            'snapshot_id': bd.snapshot_id,
            'status': bd.status,
            'attach_time': bd.attach_time,
            'delete_on_termination': bd.delete_on_termination,
            'size': bd.size,
            'volume_type': bd.volume_type,
            'iops': bd.iops,
        }

    sec_group_ids = []
    sec_group_names = []
    for i in instance.groups:
        sec_group_ids.append(i.id)
        sec_group_names.append(i.name)
        results["sec_group_ids"] = sec_group_ids
        results["sec_group_names"] = sec_group_names

    interfaces = {}
    for eni in instance.interfaces:
        interfaces[eni.id] = {
            'id': eni.id,
            'mac_address': eni.mac_address,
            'subnet_id': eni.subnet_id,
            'status': eni.status,
            'vpc_id': eni.vpc_id,
            'owner_id': eni.owner_id,
            'private_ip_address': eni.private_ip_address,
            'description': eni.description
        }
        if 'privateDnsName' in eni.__dict__:
            interfaces[eni.id]['private_dns_name'] = eni.privateDnsName,
    return {
        'ec2': {
            'id': instance.id,
            'sec_group_ids': sec_group_ids,
            'sec_group_names': sec_group_names,
            'public_dns_name': instance.public_dns_name,
            'private_dns_name': instance.private_dns_name,
            'state_code': instance.state_code,
            'state': EC2_STATE_CODE[instance.state_code],
            'state_reason': instance.state_reason,
            'previous_state': instance.previous_state,
            'previous_state_code': instance.previous_state_code,
            'key_name': instance.key_name,
            'instance_type': instance.instance_type,
            'launch_time': instance.launch_time,
            'image_id': instance.image_id,
            'region': region,
            'placement': instance.placement,
            'placement_group': instance.placement_group,
            'placement_tenancy': instance.placement_tenancy,
            'kernel': instance.kernel,
            'ramdisk': instance.ramdisk,
            'architecture': instance.architecture,
            'hypervisor': instance.hypervisor,
            'virtualization_type': instance.virtualization_type,
            'product_codes': instance.product_codes,
            'ami_launch_index': instance.ami_launch_index,
            'monitored': instance.monitored,
            'monitoring_state': instance.monitoring_state,
            'spot_instance_request_id': instance.spot_instance_request_id,
            'subnet_id': instance.subnet_id,
            'vpc_id': instance.vpc_id,
            'private_ip_address': instance.private_ip_address,
            'ip_address': instance.ip_address,
            'platform': instance.platform,
            'root_device_name': instance.root_device_name,
            'root_device_type': instance.root_device_type,
            'block_device_mapping': block_mapping,
            'interfaces': interfaces,
            'ebs_optimized': instance.ebs_optimized,
            'instance_profile': instance.instance_profile,
            'tags': instance.tags
        }
    }


def ec2_information():
    ec2_info = _read_cache(CACHE_FILE)
    if not ec2_info:
        ec2_info = _read_ec2_information()
        if ec2_info:
            _write_cache(CACHE_FILE, ec2_info)
    return ec2_info


if __name__ == '__main__':
    pprint.pprint(ec2_information())
