import salt.returners
import salt.utils
import logging
import copy
import json

STATE_FUNCTIONS = set([
    'state.apply',
    'state.highstate',
    'state.sls',
])

log = logging.getLogger(__name__)


def _get_options(ret=None):
    defaults = {
        'state_filename': '/var/log/salt/state.jsonl',
    }

    attrs = {key: key for key in defaults.keys()}

    options = salt.returners.get_returner_options(__name__,
                                                  {},
                                                  attrs,
                                                  defaults=defaults,
                                                  __salt__=__salt__, # noqa
                                                  __opts__=__opts__) # noqa
    return options


def _log_objs(filename, kind, objs):
    try:
        with salt.utils.files.flopen(filename, 'a') as f:
            for obj in objs:
                json.dump(obj, f, separators=(',', ':'))
                f.write('\n')
    except Exception as e:
        log.error('Failed to log %s to \'%s\'' % (kind, filename))
        raise e


def _rename(_dict, old, new):
    if old in _dict:
        _dict[new] = _dict.pop(old)


# Event structure appears to be something like this:
#
#  dict ApplyResult {
#    // e.g. "state.highstate"
#    string fun
#    string[] fun_args
#    // minion ID
#    string id
#    // job ID
#    string jid
#
#    boolean success
#    // 0 on success
#    // 1 on error during rendering?
#    // 2 if any of StateResult.result is false (see check_state_result()
#    //   for gory details)
#    int retcode
#    // if apply failed due to rendering errors, result is an error message
#    Either<string, dict<string, StateResult>> result;
#  }
#
#  dict StateResult {
#    // name of the sls (e.g. "user.deployment")
#    string __sls__
#    // ID in a .sls
#    string __id__
#    string name
#    // HH:MM:SS.ssssss
#    string start_time
#    boolean result
#    // in millisecond
#    float duration
#    // human readable result
#    string comment
#    // depends on the executed function
#    dict<string,any> changes
#  }
def _log_apply(ret):
    states = []

    # Statistics gathered from executed functions
    num_states = 0
    num_ok = 0
    num_changes = 0

    if isinstance(ret['return'], dict):
        # Copy state results so that you can still fetch (mostly original)
        # apply event from Elasticsearch _source field.
        states = copy.deepcopy(ret['return'].values())
        for state in states:
            state['__type__'] = 'salt-state'

            _rename(state, 'comment', 'message')

            # Kibana really does not like fields that start with underscore
            # https://github.com/elastic/kibana/issues/2551
            _rename(state, '__id__', 'state_id')
            _rename(state, '__sls__', 'sls')
            _rename(state, '__run_num__', 'run_num')
            _rename(state, 'name', 'state_name')

            # Duplicate useful attributes from the parent
            state['minion_id'] = ret['id']
            state['parent_jid'] = ret['jid']

            # For easier searching with Elasticsearch
            changed = len(state.get('changes', {})) > 0
            state['changed'] = changed

            num_states += 1
            if state.get('result', False):
                num_ok += 1
            if changed:
                num_changes += 1
    elif isinstance(ret['return'], str) or isinstance(ret['return'], unicode):
        # We're not indexing return field, so let's pull the error message
        # into a separate field
        ret['message'] = ret['return']

    ret['__type__'] = 'salt-apply'
    ret['state_count'] = num_states
    ret['success_count'] = num_ok
    ret['failure_count'] = num_states - num_ok
    ret['change_count'] = num_changes

    _rename(ret, 'id', 'minion_id')

    events = [ret]
    events.extend(states)

    options = _get_options()
    _log_objs(options['state_filename'], 'state', events)


def returner(ret):
    if ret['fun'] in STATE_FUNCTIONS:
        _log_apply(ret)
