import salt.wheel
import salt.utils.minions
import logging as log

def _delete_key(minion_id):
    wheel = salt.wheel.Wheel(__opts__)
    wheel.call_func('key.delete', match=minion_id)

def _minion_ids(instance_id):
    minions = salt.utils.minions.CkMinions(__opts__)
    return minions.check_minions('ec2:id:%s' % instance_id, 'grain')

def delete_instance_key(**kwargs):
    instance_id = kwargs.get('id')
    if not instance_id:
        log.error('You must provide EC2 instance ID with id=i-foo')
        return {}

    minion_ids = _minion_ids(instance_id)
    for minion_id in minion_ids:
        log.info('Deleting minion %s' % minion_id)
        _delete_key(minion_id)

    return {'matched_minions': minion_ids }
