#!/bin/bash
PROCESS_NAME="salt-minion"
. /etc/bashrc
PATH=$PATH:/usr/sbin:/sbin

for pid in $(pgrep "$PROCESS_NAME"); do
    if lsof -p "$pid" | grep TCP | grep -q SYN; then
        service "$PROCESS_NAME" restart
        break
    fi
done
