# SALTSTACK

## coding guidelines
### states
* watch/watch_in - use watch_in when setting files as dependency to services (do not use watch)
* file locations - set in pillars unless file locations are truly static
* packages - set all package names/version in pkgs pillar
* pip installs
  * set all pip package names/versions in pkgs pillar
  * set bin_env value to python version desired for pip installation
* require - include require statements for all needed config files, packages, etc... (state must complete on first run)

### pillars
* security - use top file and includes properly to ensure that pillars are only loaded on the instances the pillars are required on
