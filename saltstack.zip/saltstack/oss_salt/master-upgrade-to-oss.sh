#!/bin/sh

# run the script as root
if [ "$(id -u)" -ne 0 ]; then
	exec sudo "$0" "$@"
fi

set -eu

# Disable salt-stack-enterprise repo
yum-config-manager --disable sse-*

# Stop services
monit stop salt_minion
service salt-minion stop
service salt-master stop

# Remove sse-repo-4.2-1
yum -y remove sse-repo-4.2-1.el6.noarch

# Install oss yum-repo
yum -y install https://repo.saltstack.com/yum/amazon/salt-amzn-repo-2018.3-1.amzn1.noarch.rpm

# Remove enterprise salt-master
yum -y remove salt-enterprise-master salt-enterprise-minion salt-enterprise

# Install oss salt-master
yum -y install salt-master salt-api salt-minion

# Start services
service salt-master start
service salt-minion start
monit start salt_minion

# Remove salt-stack-enterprise repo
rm -f /etc/yum.repos.d/sse-*.repo
