#!/bin/sh

# run the script as root
if [ "$(id -u)" -ne 0 ]; then
	exec sudo "$0" "$@"
fi

set -eu

# Disable salt-stack-enterprise repo
yum-config-manager --disable sse-*

# Stop salt-minion
monit stop salt_minion
service salt-minion stop

# Remove old repo package
yum -y remove sse-repo-4.2-1.el6.noarch

# Install oss yum-repo
yum -y install https://repo.saltstack.com/yum/amazon/salt-amzn-repo-2018.3-1.amzn1.noarch.rpm

# Remove enterprise salt-minion
yum -y remove salt-enterprise-minion salt-enterprise

# Install oss salt-minion
yum -y install salt-minion

# Start services
monit start salt_minion
service salt-minion start

# Remove salt-stack-enterprise repo
rm -f /etc/yum.repos.d/sse-*.repo
