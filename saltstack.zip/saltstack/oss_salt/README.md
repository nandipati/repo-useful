# Planned usage

0. Preflight Checklist
1. Upgrade master
2. Upgrade minions

## Preflight Checklist

Check the running versions on the master

```sh
salt-run manage.versions
```

Copy the scripts to master

```sh
scp master-upgrade-to-oss.sh upgrade-to-oss.sh ec2-user@salt.cndnp.internal:/tmp/
```

## Master

```sh
sh /tmp/master-upgrade-to-oss.sh
```

## Minion

the minions are a bit trickky. We need to upgrade the salt minion to run from different repo. So we have to schedule an at-job to do our bidding.

```sh
# copy the script to nodes
salt-cp -G 'os:Amazon' upgrade-to-oss.sh /tmp/upgrade-to-oss.sh
# run script
salt -C 'G@os:Amazon not G@saltversion:2016.3.5' cmd.run 'at -f /tmp/upgrade-to-oss.sh now'
```

### Ubuntu

```sh
# TBA
```
