export DEBIAN_FRONTEND=noninteractive
wget -O - https://repo.saltstack.com/apt/ubuntu/16.04/amd64/2016.3/SALTSTACK-GPG-KEY.pub | sudo apt-key add -
echo 'deb http://repo.saltstack.com/apt/ubuntu/16.04/amd64/2016.3 xenial main'  > /etc/apt/sources.list.d/salt.list
apt-get update
apt-get -qy install salt-minion
mkdir -p /etc/salt/minion.d
echo 'master: 10.10.10.11' > /etc/salt/minion.d/99-master-address.conf
echo "10.10.10.13" > /etc/salt/minion_id
service salt-minion restart
