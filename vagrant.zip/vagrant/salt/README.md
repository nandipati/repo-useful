
#running salt vagrant 

In the saltVagrant file run 'vagrant up' command, this will create three VMs `master01`, `minion02` and `minion02`. The first run may be slow, as it needs to download the box image.

Because of the fact there is no ec2 tags in this local environment  you will have to change the top.sls file located in /srv/salt/states/top.sls in the master in order to run states.
one way to do this is edit in the top.sls

```yaml
base:
  '*':
    - core
    - exampleStateToRun
```

now the minion will run the example state as well as default core.
