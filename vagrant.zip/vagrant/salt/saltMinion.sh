rpm -ivh https://erepo.saltstack.com/sse/4.2/rhel/sse-repo-4.2.el6.rpm
cd /etc/yum.repos.d/
sleep 10
sed -i 's/$releasever/6/' sse-4.*.repo
yum install -y python26-pip python26-boto salt-enterprise-minion
sleep 20
mkdir -p /etc/salt/minion.d
echo "master: 10.10.10.11" > /etc/salt/minion.d/99-master-address.conf
echo "10.10.10.12" > /etc/salt/minion_id
service salt-minion start
